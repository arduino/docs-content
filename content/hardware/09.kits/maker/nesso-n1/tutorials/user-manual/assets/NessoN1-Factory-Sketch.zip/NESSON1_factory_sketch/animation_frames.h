#include "logo_frame001.h"
#include "logo_frame002.h"
#include "logo_frame003.h"
#include "logo_frame004.h"
#include "logo_frame005.h"
#include "logo_frame006.h"
#include "logo_frame007.h"
#include "logo_frame008.h"
#include "logo_frame009.h"
#include "logo_frame010.h"
#include "logo_frame011.h"
#include "logo_frame012.h"
#include "logo_frame013.h"
#include "logo_frame014.h"
#include "logo_frame015.h"
#include "logo_frame016.h"
#include "logo_frame017.h"
#include "logo_frame018.h"
#include "logo_frame019.h"
#include "logo_frame020.h"
#include "logo_frame021.h"
#include "logo_frame022.h"
#include "logo_frame023.h"
#include "logo_frame024.h"
#include "logo_frame025.h"
#include "logo_frame026.h"
#include "logo_frame027.h"
#include "logo_frame028.h"
#include "logo_frame029.h"
#include "logo_frame030.h"
#include "logo_frame031.h"
#include "logo_frame032.h"
#include "logo_frame033.h"
#include "logo_frame034.h"
#include "logo_frame035.h"
#include "logo_frame036.h"
#include "logo_frame037.h"
#include "logo_frame038.h"
#include "logo_frame039.h"
#include "logo_frame040.h"
#include "logo_frame041.h"
#include "logo_frame042.h"
#include "logo_frame043.h"
#include "logo_frame044.h"

typedef struct {
    const unsigned char* data;
    size_t size;
    const char* name;  // optional, for debugging/identification
} image_info_t;

static const image_info_t frames[] = {
   {logo_frame_001, sizeof(logo_frame_001), "logo_frame_001"},
   {logo_frame_002, sizeof(logo_frame_002), "logo_frame_002"},
   {logo_frame_003, sizeof(logo_frame_003), "logo_frame_003"},
   {logo_frame_004, sizeof(logo_frame_004), "logo_frame_004"},
   {logo_frame_005, sizeof(logo_frame_005), "logo_frame_005"},
   {logo_frame_006, sizeof(logo_frame_006), "logo_frame_006"},
   {logo_frame_007, sizeof(logo_frame_007), "logo_frame_007"},
   {logo_frame_008, sizeof(logo_frame_008), "logo_frame_008"},
   {logo_frame_009, sizeof(logo_frame_009), "logo_frame_009"},
   {logo_frame_010, sizeof(logo_frame_010), "logo_frame_010"},
   {logo_frame_011, sizeof(logo_frame_011), "logo_frame_011"},
   {logo_frame_012, sizeof(logo_frame_012), "logo_frame_012"},
   {logo_frame_013, sizeof(logo_frame_013), "logo_frame_013"},
   {logo_frame_014, sizeof(logo_frame_014), "logo_frame_014"},
   {logo_frame_015, sizeof(logo_frame_015), "logo_frame_015"},
   {logo_frame_016, sizeof(logo_frame_016), "logo_frame_016"},
   {logo_frame_017, sizeof(logo_frame_017), "logo_frame_017"},
   {logo_frame_018, sizeof(logo_frame_018), "logo_frame_018"},
   {logo_frame_019, sizeof(logo_frame_019), "logo_frame_019"},
   {logo_frame_020, sizeof(logo_frame_020), "logo_frame_020"},
   {logo_frame_021, sizeof(logo_frame_021), "logo_frame_021"},
   {logo_frame_022, sizeof(logo_frame_022), "logo_frame_022"},
   {logo_frame_023, sizeof(logo_frame_023), "logo_frame_023"},
   {logo_frame_024, sizeof(logo_frame_024), "logo_frame_024"},
   {logo_frame_025, sizeof(logo_frame_025), "logo_frame_025"},
   {logo_frame_026, sizeof(logo_frame_026), "logo_frame_026"},
   {logo_frame_027, sizeof(logo_frame_027), "logo_frame_027"},
   {logo_frame_028, sizeof(logo_frame_028), "logo_frame_028"},
   {logo_frame_029, sizeof(logo_frame_029), "logo_frame_029"},
   {logo_frame_030, sizeof(logo_frame_030), "logo_frame_030"},
   {logo_frame_031, sizeof(logo_frame_031), "logo_frame_031"},
   {logo_frame_032, sizeof(logo_frame_032), "logo_frame_032"},
   {logo_frame_033, sizeof(logo_frame_033), "logo_frame_033"},
   {logo_frame_034, sizeof(logo_frame_034), "logo_frame_034"},
   {logo_frame_035, sizeof(logo_frame_035), "logo_frame_035"},
   {logo_frame_036, sizeof(logo_frame_036), "logo_frame_036"},
   {logo_frame_037, sizeof(logo_frame_037), "logo_frame_037"},
   {logo_frame_038, sizeof(logo_frame_038), "logo_frame_038"},
   {logo_frame_039, sizeof(logo_frame_039), "logo_frame_039"},
   {logo_frame_040, sizeof(logo_frame_040), "logo_frame_040"},
   {logo_frame_041, sizeof(logo_frame_041), "logo_frame_041"},
   {logo_frame_042, sizeof(logo_frame_042), "logo_frame_042"},
   {logo_frame_043, sizeof(logo_frame_043), "logo_frame_043"},
   {logo_frame_044, sizeof(logo_frame_044), "logo_frame_044"}
};