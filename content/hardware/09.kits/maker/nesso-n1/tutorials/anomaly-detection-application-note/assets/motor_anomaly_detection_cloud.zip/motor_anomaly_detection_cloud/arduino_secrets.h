// Credentials for your Wi-Fi access point.
#define SECRET_WIFI_SSID "your-wifi-network-name"
#define SECRET_WIFI_PASS "your-wifi-password"

// Device ID is not actually secret, but is defined alongside the secret key for convenience.
#define SECRET_DEVICE_ID "your-device-secret-id"
#define SECRET_DEVICE_KEY "your-device-secret-key"