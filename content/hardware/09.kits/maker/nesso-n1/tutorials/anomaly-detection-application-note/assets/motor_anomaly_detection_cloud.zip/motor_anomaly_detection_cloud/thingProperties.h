/**
  Arduino IoT Cloud Thing Properties Configuration
  Defines cloud variables and connection settings for remote monitoring
*/

#include <ArduinoIoTCloud.h>
#include "arduino_secrets.h"

// Cloud dashboard state indicators
bool idle;      // Motor in idle state
bool nominal;   // Normal operation
bool anomaly;   // Anomaly detected

void initProperties() {    
    // Register state variables
    ArduinoCloud.addProperty(idle, READ, ON_CHANGE, NULL);
    ArduinoCloud.addProperty(nominal, READ, ON_CHANGE, NULL);
    ArduinoCloud.addProperty(anomaly, READ, ON_CHANGE, NULL);
    
    ArduinoCloud.setBoardId(SECRET_DEVICE_ID);
    ArduinoCloud.setSecretDeviceKey(SECRET_DEVICE_KEY);
}

// Network connection handler
WiFiConnectionHandler ArduinoIoTPreferredConnection(SECRET_WIFI_SSID, SECRET_WIFI_PASS);