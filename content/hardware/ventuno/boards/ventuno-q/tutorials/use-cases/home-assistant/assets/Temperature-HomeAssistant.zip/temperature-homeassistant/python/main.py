from arduino.app_utils import *
import paho.mqtt.client as mqtt
import json

logger = Logger("thermo-mqtt-bridge")

# MQTT basic configuration
MQTT_BROKER = "172.17.0.1"
MQTT_TOPIC = "ventuno_q/thermo/state"

client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, "ventuno_bridge")

try:
    client.connect(MQTT_BROKER, 1883)
    client.loop_start()
    logger.info("Successfully connected to MQTT broker.")
except Exception as e:
    logger.error(f"Error connecting to MQTT: {e}")

# Function that receives the data from the sketch part
def record_thermo(celsius: float, humidity: float):
    payload = {
        "temperature": round(celsius, 2),
        "humidity": round(humidity, 2)
    }
    # Publish the data on the MQTT topic
    client.publish(MQTT_TOPIC, json.dumps(payload))
    logger.debug(f"Data published to Home Assistant: {payload}")

# Register the RPC endpoint
try:
    Bridge.provide("record_thermo", record_thermo)
    logger.info("Endpoint 'record_thermo' registered in the Bridge.")
except RuntimeError:
    pass

logger.info("Starting App")
App.run()