#include <Arduino_Modulino.h>
#include <Arduino_RouterBridge.h>

ModulinoThermo thermo;
unsigned long previousMillis = 0;
const long interval = 5000; // Read the sensor every 5 seconds

void setup() {
  Bridge.begin();
  Modulino.begin(Wire1);
  thermo.begin();
}

void loop() {
  unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;
    
    float celsius = thermo.getTemperature();
    float humidity = thermo.getHumidity();
    
    // Send data to the MPU using RPC
    Bridge.notify("record_thermo", celsius, humidity); 
  }
}