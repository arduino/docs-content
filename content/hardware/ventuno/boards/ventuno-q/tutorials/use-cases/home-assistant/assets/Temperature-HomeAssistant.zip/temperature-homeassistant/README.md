# MQTT Modulino Thermo Bridge

This Arduino App Lab application turns your Arduino® VENTUNO™ Q into a smart environmental sensor node. It reads real-time temperature and humidity data from a Modulino Thermo and broadcasts it over the network using the MQTT protocol. 

It is designed to easily integrate your VENTUNO Q's hardware with smart home platforms like Home Assistant, Node-RED, or any custom HomeLab setup.

## Hardware Requirements

* **Arduino® VENTUNO™ Q**
* **Modulino Thermo**
* **Qwiic Cable** (to connect the Modulino to the VENTUNO Q's I2C port)

## How it Works

This application utilizes the dual-core architecture of the VENTUNO Q, bridging the microcontroller and the Linux environment:

1.  **The C++ Sketch (Hardware Polling):** The MCU communicates with the Modulino Thermo via I2C. Every 5 seconds, it reads the temperature (in Celsius) and relative humidity (in %). It then pushes these values to the Python backend using Remote Procedure Calls (RPC) via the `Bridge.notify()` method.
2.  **The Python Script (MQTT Gateway):** The Python backend listens for these RPC calls. Once data is received, it formats the values into a standard JSON payload and publishes them to an MQTT broker over your local network.

### MQTT Payload Structure

The data is published to the topic `ventuno_q/thermo/state` in the following JSON format:

```json
{
  "temperature": 24.5,
  "humidity": 45.2
}
```

## Configuration

1. Open `main.py` in the App Lab editor.
2. Locate the following line at the top of the file:

```
MQTT_BROKER = "172.17.0.1"
```

3. Change the IP Address (if needed):
  - Leave it as `172.17.0.1` if your MQTT Broker (like Mosquitto) is running in a Docker container on this exact same VENTUNO Q board.
  - If your MQTT Broker is hosted on another machine (like a Raspberry Pi or NAS), change this string to that machine's local IP address (e.g., `"192.168.1.50"`).

## Usage

1. Connect the Modulino Thermo to the VENTUNO Q using the Qwiic cable.
2. Ensure your local MQTT Broker is running and configured to accept anonymous connections on port `1883`.
3. Click the **Run** button in Arduino App Lab.
4. Check the application logs to verify that the MQTT connection is successful and that the `record_thermo` data is being published.

## Home Assistant Integration

To view this data in Home Assistant, ensure you have the MQTT Integration configured, and add the following block to your configuration.yaml file:

```yaml
mqtt:
  sensor:
    - name: "Ventuno Temperature"
      state_topic: "ventuno_q/thermo/state"
      unit_of_measurement: "°C"
      device_class: temperature
      value_template: "{{ value_json.temperature }}"

    - name: "Ventuno Humidity"
      state_topic: "ventuno_q/thermo/state"
      unit_of_measurement: "%"
      device_class: humidity
      value_template: "{{ value_json.humidity }}"
```