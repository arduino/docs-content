<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.1.3">
<drawing>
<settings>
<setting alwaysvectorfont="no"/>
<setting keepoldvectorfont="yes"/>
<setting verticaltext="up"/>
</settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="no" active="no"/>
<layer number="2" name="Route2" color="1" fill="3" visible="no" active="no"/>
<layer number="3" name="Route3" color="4" fill="3" visible="no" active="no"/>
<layer number="4" name="Route4" color="1" fill="4" visible="no" active="no"/>
<layer number="5" name="Route5" color="4" fill="4" visible="no" active="no"/>
<layer number="6" name="Route6" color="1" fill="8" visible="no" active="no"/>
<layer number="7" name="Route7" color="4" fill="8" visible="no" active="no"/>
<layer number="8" name="Route8" color="1" fill="2" visible="no" active="no"/>
<layer number="9" name="Route9" color="4" fill="2" visible="no" active="no"/>
<layer number="10" name="Route10" color="1" fill="7" visible="no" active="no"/>
<layer number="11" name="Route11" color="4" fill="7" visible="no" active="no"/>
<layer number="12" name="Route12" color="1" fill="5" visible="no" active="no"/>
<layer number="13" name="Route13" color="4" fill="5" visible="no" active="no"/>
<layer number="14" name="Route14" color="1" fill="6" visible="no" active="no"/>
<layer number="15" name="Route15" color="4" fill="6" visible="no" active="no"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="no" active="no"/>
<layer number="17" name="Pads" color="2" fill="1" visible="no" active="no"/>
<layer number="18" name="Vias" color="2" fill="1" visible="no" active="no"/>
<layer number="19" name="Unrouted" color="6" fill="1" visible="no" active="no"/>
<layer number="20" name="Dimension" color="15" fill="1" visible="no" active="no"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="22" name="bPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="23" name="tOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="24" name="bOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="25" name="tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="26" name="bNames" color="7" fill="1" visible="no" active="no"/>
<layer number="27" name="tValues" color="7" fill="1" visible="no" active="no"/>
<layer number="28" name="bValues" color="7" fill="1" visible="no" active="no"/>
<layer number="29" name="tStop" color="7" fill="3" visible="no" active="no"/>
<layer number="30" name="bStop" color="7" fill="6" visible="no" active="no"/>
<layer number="31" name="tCream" color="7" fill="4" visible="no" active="no"/>
<layer number="32" name="bCream" color="7" fill="5" visible="no" active="no"/>
<layer number="33" name="tFinish" color="6" fill="3" visible="no" active="no"/>
<layer number="34" name="bFinish" color="6" fill="6" visible="no" active="no"/>
<layer number="35" name="tGlue" color="7" fill="4" visible="no" active="no"/>
<layer number="36" name="bGlue" color="7" fill="5" visible="no" active="no"/>
<layer number="37" name="tTest" color="7" fill="1" visible="no" active="no"/>
<layer number="38" name="bTest" color="7" fill="1" visible="no" active="no"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="no" active="no"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="no" active="no"/>
<layer number="41" name="tRestrict" color="4" fill="10" visible="no" active="no"/>
<layer number="42" name="bRestrict" color="1" fill="10" visible="no" active="no"/>
<layer number="43" name="vRestrict" color="2" fill="10" visible="no" active="no"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="no"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="no"/>
<layer number="46" name="Milling" color="3" fill="1" visible="no" active="no"/>
<layer number="47" name="Measures" color="7" fill="1" visible="no" active="no"/>
<layer number="48" name="Document" color="7" fill="1" visible="no" active="no"/>
<layer number="49" name="Reference" color="7" fill="1" visible="no" active="no"/>
<layer number="50" name="dxf" color="7" fill="1" visible="no" active="no"/>
<layer number="51" name="tDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="52" name="bDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="53" name="tGND_GNDA" color="7" fill="1" visible="no" active="no"/>
<layer number="54" name="bGND_GNDA" color="7" fill="1" visible="no" active="no"/>
<layer number="56" name="wert" color="7" fill="1" visible="no" active="no"/>
<layer number="57" name="tCAD" color="7" fill="1" visible="no" active="no"/>
<layer number="59" name="tCarbon" color="7" fill="1" visible="no" active="no"/>
<layer number="60" name="bCarbon" color="7" fill="1" visible="no" active="no"/>
<layer number="90" name="Modules" color="5" fill="1" visible="yes" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
<layer number="98" name="Guide" color="6" fill="1" visible="yes" active="yes"/>
<layer number="99" name="Muster" color="7" fill="1" visible="no" active="no"/>
<layer number="100" name="Muster" color="7" fill="1" visible="no" active="no"/>
<layer number="101" name="Top_Flash" color="7" fill="1" visible="yes" active="yes"/>
<layer number="102" name="Top_Traces" color="7" fill="1" visible="yes" active="yes"/>
<layer number="103" name="tMap" color="7" fill="1" visible="yes" active="yes"/>
<layer number="104" name="Botto_Traces" color="7" fill="1" visible="yes" active="yes"/>
<layer number="105" name="tPlate" color="7" fill="1" visible="yes" active="yes"/>
<layer number="106" name="bPlate" color="7" fill="1" visible="yes" active="yes"/>
<layer number="107" name="Crop" color="7" fill="1" visible="yes" active="yes"/>
<layer number="108" name="fp8" color="7" fill="1" visible="yes" active="yes"/>
<layer number="109" name="fp9" color="7" fill="1" visible="yes" active="yes"/>
<layer number="110" name="fp0" color="7" fill="1" visible="yes" active="yes"/>
<layer number="111" name="LPC17xx" color="7" fill="1" visible="yes" active="yes"/>
<layer number="112" name="tSilk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="113" name="ReferenceLS" color="7" fill="1" visible="no" active="no"/>
<layer number="114" name="FRNTMAAT1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="115" name="FRNTMAAT2" color="7" fill="1" visible="yes" active="yes"/>
<layer number="116" name="Patch_BOT" color="7" fill="1" visible="yes" active="yes"/>
<layer number="117" name="BACKMAAT1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="118" name="Rect_Pads" color="7" fill="1" visible="no" active="no"/>
<layer number="119" name="KAP_TEKEN" color="7" fill="1" visible="yes" active="yes"/>
<layer number="120" name="KAP_MAAT1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="121" name="_tsilk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="122" name="_bsilk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="123" name="tTestmark" color="7" fill="1" visible="yes" active="yes"/>
<layer number="124" name="bTestmark" color="7" fill="1" visible="yes" active="yes"/>
<layer number="125" name="_tNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="126" name="_bNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="127" name="_tValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="128" name="_bValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="129" name="top_silk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="130" name="SMDSTROOK" color="7" fill="1" visible="yes" active="yes"/>
<layer number="131" name="tAdjust" color="7" fill="1" visible="yes" active="yes"/>
<layer number="132" name="bAdjust" color="7" fill="1" visible="yes" active="yes"/>
<layer number="133" name="bottom_silk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="134" name="silk_top" color="7" fill="1" visible="yes" active="yes"/>
<layer number="135" name="silk_bottom" color="7" fill="1" visible="yes" active="yes"/>
<layer number="136" name="silktop" color="7" fill="1" visible="yes" active="yes"/>
<layer number="137" name="silkbottom" color="7" fill="1" visible="yes" active="yes"/>
<layer number="138" name="EEE" color="7" fill="1" visible="no" active="yes"/>
<layer number="139" name="_tKeepout" color="7" fill="1" visible="yes" active="yes"/>
<layer number="141" name="ASSEMBLY_TOP" color="7" fill="1" visible="no" active="yes"/>
<layer number="143" name="PLACE_BOUND_TOP" color="7" fill="1" visible="no" active="yes"/>
<layer number="144" name="_Drills" color="7" fill="1" visible="yes" active="yes"/>
<layer number="145" name="DrillLegend_01-16" color="7" fill="1" visible="yes" active="yes"/>
<layer number="146" name="DrillLegend_01-20" color="7" fill="1" visible="yes" active="yes"/>
<layer number="147" name="PIN_NUMBER" color="7" fill="1" visible="no" active="yes"/>
<layer number="150" name="Notes" color="7" fill="1" visible="yes" active="yes"/>
<layer number="151" name="HeatSink" color="7" fill="1" visible="yes" active="yes"/>
<layer number="152" name="_bDocu" color="7" fill="1" visible="yes" active="yes"/>
<layer number="153" name="FabDoc1" color="6" fill="1" visible="no" active="no"/>
<layer number="154" name="FabDoc2" color="2" fill="1" visible="no" active="no"/>
<layer number="155" name="FabDoc3" color="7" fill="15" visible="no" active="no"/>
<layer number="166" name="AntennaArea" color="7" fill="1" visible="yes" active="yes"/>
<layer number="168" name="4mmHeightArea" color="7" fill="1" visible="yes" active="yes"/>
<layer number="199" name="Contour" color="7" fill="1" visible="yes" active="yes"/>
<layer number="200" name="200bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="201" name="201bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="202" name="202bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="203" name="203bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="204" name="204bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="205" name="205bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="206" name="206bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="207" name="207bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="208" name="208bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="209" name="209bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="210" name="210bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="211" name="211bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="212" name="212bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="213" name="213bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="214" name="214bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="215" name="215bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="216" name="216bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="217" name="217bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="218" name="218bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="219" name="219bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="220" name="220bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="221" name="221bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="222" name="222bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="223" name="223bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="224" name="224bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="225" name="225bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="226" name="226bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="227" name="227bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="228" name="228bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="229" name="229bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="230" name="230bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="231" name="Eagle3D_PG1" color="14" fill="1" visible="yes" active="yes"/>
<layer number="232" name="Eagle3D_PG2" color="14" fill="2" visible="yes" active="yes"/>
<layer number="233" name="Eagle3D_PG3" color="14" fill="4" visible="yes" active="yes"/>
<layer number="248" name="Housing" color="7" fill="1" visible="yes" active="yes"/>
<layer number="249" name="Edge" color="7" fill="1" visible="yes" active="yes"/>
<layer number="250" name="Descript" color="3" fill="1" visible="no" active="no"/>
<layer number="251" name="SMDround" color="12" fill="11" visible="no" active="no"/>
<layer number="254" name="cooling" color="7" fill="1" visible="yes" active="yes"/>
<layer number="255" name="Accent" color="7" fill="1" visible="yes" active="yes"/>
</layers>
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<libraries>
<library name="Arduino-utility">
<packages>
<package name="MKRBOARD">
<wire x1="0" y1="2.25" x2="2.25" y2="0" width="0.1" layer="21" curve="90"/>
<wire x1="2.25" y1="0" x2="59.25" y2="0" width="0.1" layer="21"/>
<wire x1="59.25" y1="0" x2="61.5" y2="2.25" width="0.1" layer="21" curve="90"/>
<wire x1="61.5" y1="2.25" x2="61.5" y2="22.75" width="0.1" layer="21"/>
<wire x1="61.5" y1="22.75" x2="59.25" y2="25" width="0.1" layer="21" curve="90"/>
<wire x1="59.25" y1="25" x2="2.25" y2="25" width="0.1" layer="21"/>
<wire x1="2.25" y1="25" x2="0" y2="22.75" width="0.1" layer="21" curve="90"/>
<wire x1="0" y1="22.75" x2="0" y2="2.25" width="0.1" layer="21"/>
<pad name="6" x="55.1548" y="22.66" drill="0.8" diameter="1.524" shape="square"/>
<pad name="AREF" x="22.1348" y="2.34" drill="0.8" diameter="1.524" shape="square"/>
<pad name="7" x="52.6148" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="8" x="50.0748" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="9" x="47.5348" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="10" x="44.9948" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="11" x="42.4548" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="12" x="39.9148" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="13" x="37.3748" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="14" x="34.8348" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="RST" x="32.2948" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="GND" x="29.7548" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="VCC" x="27.2148" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="VIN" x="24.6748" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="5V" x="22.1348" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="A0" x="24.6748" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="A1" x="27.2148" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="A2" x="29.7548" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="A3" x="32.2948" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="A4" x="34.8348" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="A5" x="37.3748" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="A6" x="39.9148" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="0" x="42.4548" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="1" x="44.9948" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="2" x="47.5348" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="3" x="50.0748" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="4" x="52.6148" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="5" x="55.1548" y="2.34" drill="0.8" diameter="1.524"/>
<hole x="59.25" y="2.25" drill="2.25"/>
<hole x="59.25" y="22.75" drill="2.25"/>
<hole x="2.25" y="2.25" drill="2.25"/>
<hole x="2.25" y="22.75" drill="2.25"/>
<text x="22.86" y="5.08" size="1.016" layer="21" rot="R90">AREF</text>
<text x="25.4" y="5.08" size="1.016" layer="21" rot="R90">DAC0/A0</text>
<text x="27.94" y="5.08" size="1.016" layer="21" rot="R90">A1</text>
<text x="30.48" y="5.08" size="1.016" layer="21" rot="R90">A2</text>
<text x="33.02" y="5.08" size="1.016" layer="21" rot="R90">A3</text>
<text x="35.56" y="5.08" size="1.016" layer="21" rot="R90">A4</text>
<text x="38.1" y="5.08" size="1.016" layer="21" rot="R90">A5</text>
<text x="40.64" y="5.08" size="1.016" layer="21" rot="R90">A6</text>
<text x="43.18" y="5.08" size="1.016" layer="21" rot="R90">0</text>
<text x="45.72" y="5.08" size="1.016" layer="21" rot="R90">1</text>
<text x="48.26" y="5.08" size="1.016" layer="21" rot="R90">2</text>
<text x="50.8" y="5.08" size="1.016" layer="21" rot="R90">3</text>
<text x="53.34" y="5.08" size="1.016" layer="21" rot="R90">4</text>
<text x="55.88" y="5.08" size="1.016" layer="21" rot="R90">5</text>
<text x="22.86" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">5V</text>
<text x="25.4" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">VIN</text>
<text x="27.94" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">VCC</text>
<text x="30.48" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">GND</text>
<text x="33.02" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">RST</text>
<text x="35.56" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">14/TX</text>
<text x="38.1" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">13/RX</text>
<text x="40.64" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">12/SCL</text>
<text x="43.18" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">11/SDA</text>
<text x="45.72" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">10/MISO</text>
<text x="48.26" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">9/SCK</text>
<text x="50.8" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">8/MOSI</text>
<text x="53.34" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">7</text>
<text x="55.88" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">6</text>
</package>
<package name="MKRBOARD-NOOUTLINE">
<pad name="6" x="55.1548" y="22.66" drill="0.8" shape="square"/>
<pad name="AREF" x="22.1348" y="2.34" drill="0.8" shape="square"/>
<pad name="7" x="52.6148" y="22.66" drill="0.8"/>
<pad name="8" x="50.0748" y="22.66" drill="0.8"/>
<pad name="9" x="47.5348" y="22.66" drill="0.8"/>
<pad name="10" x="44.9948" y="22.66" drill="0.8"/>
<pad name="11" x="42.4548" y="22.66" drill="0.8"/>
<pad name="12" x="39.9148" y="22.66" drill="0.8"/>
<pad name="13" x="37.3748" y="22.66" drill="0.8"/>
<pad name="14" x="34.8348" y="22.66" drill="0.8"/>
<pad name="RST" x="32.2948" y="22.66" drill="0.8"/>
<pad name="GND" x="29.7548" y="22.66" drill="0.8"/>
<pad name="VCC" x="27.2148" y="22.66" drill="0.8"/>
<pad name="VIN" x="24.6748" y="22.66" drill="0.8"/>
<pad name="5V" x="22.1348" y="22.66" drill="0.8"/>
<pad name="A0" x="24.6748" y="2.34" drill="0.8"/>
<pad name="A1" x="27.2148" y="2.34" drill="0.8"/>
<pad name="A2" x="29.7548" y="2.34" drill="0.8"/>
<pad name="A3" x="32.2948" y="2.34" drill="0.8"/>
<pad name="A4" x="34.8348" y="2.34" drill="0.8"/>
<pad name="A5" x="37.3748" y="2.34" drill="0.8"/>
<pad name="A6" x="39.9148" y="2.34" drill="0.8"/>
<pad name="0" x="42.4548" y="2.34" drill="0.8"/>
<pad name="1" x="44.9948" y="2.34" drill="0.8"/>
<pad name="2" x="47.5348" y="2.34" drill="0.8"/>
<pad name="3" x="50.0748" y="2.34" drill="0.8"/>
<pad name="4" x="52.6148" y="2.34" drill="0.8"/>
<pad name="5" x="55.1548" y="2.34" drill="0.8"/>
<text x="22.86" y="5.08" size="1.016" layer="21" rot="R90">AREF</text>
<text x="25.4" y="5.08" size="1.016" layer="21" rot="R90">DAC0/A0</text>
<text x="27.94" y="5.08" size="1.016" layer="21" rot="R90">A1</text>
<text x="30.48" y="5.08" size="1.016" layer="21" rot="R90">A2</text>
<text x="33.02" y="5.08" size="1.016" layer="21" rot="R90">A3</text>
<text x="35.56" y="5.08" size="1.016" layer="21" rot="R90">A4</text>
<text x="38.1" y="5.08" size="1.016" layer="21" rot="R90">A5</text>
<text x="40.64" y="5.08" size="1.016" layer="21" rot="R90">A6</text>
<text x="43.18" y="5.08" size="1.016" layer="21" rot="R90">0</text>
<text x="45.72" y="5.08" size="1.016" layer="21" rot="R90">1</text>
<text x="48.26" y="5.08" size="1.016" layer="21" rot="R90">2</text>
<text x="50.8" y="5.08" size="1.016" layer="21" rot="R90">3</text>
<text x="53.34" y="5.08" size="1.016" layer="21" rot="R90">4</text>
<text x="55.88" y="5.08" size="1.016" layer="21" rot="R90">5</text>
<text x="22.86" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">5V</text>
<text x="25.4" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">VIN</text>
<text x="27.94" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">VCC</text>
<text x="30.48" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">GND</text>
<text x="33.02" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">RST</text>
<text x="35.56" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">14/TX</text>
<text x="38.1" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">13/RX</text>
<text x="40.64" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">12/SCL</text>
<text x="43.18" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">11/SDA</text>
<text x="45.72" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">10/MISO</text>
<text x="48.26" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">9/SCK</text>
<text x="50.8" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">8/MOSI</text>
<text x="53.34" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">7</text>
<text x="55.88" y="20.32" size="1.016" layer="21" rot="R270" align="top-left">6</text>
</package>
<package name="MKRBOARD-W-SMD">
<wire x1="22.1348" y1="1.99" x2="22.1348" y2="2.69" width="0.05" layer="39"/>
<pad name="AREF" x="22.1348" y="2.34" drill="1" first="yes"/>
<pad name="DAC0/A0" x="24.6748" y="2.34" drill="1"/>
<pad name="A1" x="27.2148" y="2.34" drill="1"/>
<pad name="A2" x="29.7548" y="2.34" drill="1"/>
<pad name="A3" x="32.2948" y="2.34" drill="1"/>
<pad name="A4" x="34.8348" y="2.34" drill="1"/>
<pad name="A5" x="37.3748" y="2.34" drill="1"/>
<pad name="A6" x="39.9148" y="2.34" drill="1"/>
<pad name="0" x="42.4548" y="2.34" drill="1"/>
<pad name="1" x="44.9948" y="2.34" drill="1"/>
<pad name="2" x="47.5348" y="2.34" drill="1"/>
<pad name="3" x="50.0748" y="2.34" drill="1"/>
<pad name="4" x="52.6148" y="2.34" drill="1"/>
<pad name="5" x="55.1548" y="2.34" drill="1"/>
<polygon width="0.0254" layer="29">
<vertex x="21.2585" y="3.3687"/>
<vertex x="23.0111" y="3.3687"/>
<vertex x="23.0111" y="1.3113"/>
<vertex x="21.2585" y="1.3113"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="21.2585" y="3.3687"/>
<vertex x="21.2585" y="1.5653"/>
<vertex x="21.8046" y="1.5653" curve="-90"/>
<vertex x="21.9062" y="1.4637"/>
<vertex x="21.3855" y="1.4637" curve="90"/>
<vertex x="21.2585" y="1.3367"/>
<vertex x="21.2585" y="0.4858" curve="90"/>
<vertex x="21.3855" y="0.3588"/>
<vertex x="22.8841" y="0.3588" curve="90"/>
<vertex x="23.0111" y="0.4858"/>
<vertex x="23.0111" y="1.3367" curve="90"/>
<vertex x="22.8841" y="1.4637"/>
<vertex x="22.3634" y="1.4637" curve="-90"/>
<vertex x="22.465" y="1.5653"/>
<vertex x="23.0111" y="1.5653"/>
<vertex x="23.0111" y="3.3687"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="23.7985" y="2.4924" curve="-90"/>
<vertex x="24.6621" y="3.356"/>
<vertex x="24.6875" y="3.356" curve="-90"/>
<vertex x="25.5511" y="2.4924"/>
<vertex x="25.5511" y="2.1876"/>
<vertex x="25.5257" y="1.9971"/>
<vertex x="25.4622" y="1.8066"/>
<vertex x="25.3098" y="1.5907"/>
<vertex x="25.259" y="1.5653"/>
<vertex x="25.005" y="1.5653" curve="90"/>
<vertex x="24.9034" y="1.4637"/>
<vertex x="25.4241" y="1.4637" curve="-90"/>
<vertex x="25.5511" y="1.3367"/>
<vertex x="25.5511" y="0.4858" curve="-90"/>
<vertex x="25.4241" y="0.3588"/>
<vertex x="23.9255" y="0.3588" curve="-90"/>
<vertex x="23.7985" y="0.4858"/>
<vertex x="23.7985" y="1.3367" curve="-90"/>
<vertex x="23.9255" y="1.4637"/>
<vertex x="24.4462" y="1.4637" curve="90"/>
<vertex x="24.3446" y="1.5653"/>
<vertex x="24.0906" y="1.5653"/>
<vertex x="24.0398" y="1.5907"/>
<vertex x="23.8874" y="1.8066"/>
<vertex x="23.7985" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="23.7985" y="2.4924" curve="-90"/>
<vertex x="24.6621" y="3.356"/>
<vertex x="24.6875" y="3.356" curve="-90"/>
<vertex x="25.5511" y="2.4924"/>
<vertex x="25.5511" y="2.1876"/>
<vertex x="25.5257" y="1.9971"/>
<vertex x="25.4622" y="1.8066"/>
<vertex x="25.3098" y="1.5907"/>
<vertex x="25.259" y="1.5653"/>
<vertex x="25.005" y="1.5653" curve="90"/>
<vertex x="24.9034" y="1.4637"/>
<vertex x="25.4241" y="1.4637" curve="-90"/>
<vertex x="25.5511" y="1.3367"/>
<vertex x="25.5511" y="0.4858" curve="-90"/>
<vertex x="25.4241" y="0.3588"/>
<vertex x="23.9255" y="0.3588" curve="-90"/>
<vertex x="23.7985" y="0.4858"/>
<vertex x="23.7985" y="1.3367" curve="-90"/>
<vertex x="23.9255" y="1.4637"/>
<vertex x="24.4462" y="1.4637" curve="90"/>
<vertex x="24.3446" y="1.5653"/>
<vertex x="24.0906" y="1.5653"/>
<vertex x="24.0398" y="1.5907"/>
<vertex x="23.8874" y="1.8066"/>
<vertex x="23.7985" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="26.3385" y="2.4924" curve="-90"/>
<vertex x="27.2021" y="3.356"/>
<vertex x="27.2275" y="3.356" curve="-90"/>
<vertex x="28.0911" y="2.4924"/>
<vertex x="28.0911" y="2.1876"/>
<vertex x="28.0657" y="1.9971"/>
<vertex x="28.0022" y="1.8066"/>
<vertex x="27.8498" y="1.5907"/>
<vertex x="27.799" y="1.5653"/>
<vertex x="27.545" y="1.5653" curve="90"/>
<vertex x="27.4434" y="1.4637"/>
<vertex x="27.9641" y="1.4637" curve="-90"/>
<vertex x="28.0911" y="1.3367"/>
<vertex x="28.0911" y="0.4858" curve="-90"/>
<vertex x="27.9641" y="0.3588"/>
<vertex x="26.4655" y="0.3588" curve="-90"/>
<vertex x="26.3385" y="0.4858"/>
<vertex x="26.3385" y="1.3367" curve="-90"/>
<vertex x="26.4655" y="1.4637"/>
<vertex x="26.9862" y="1.4637" curve="90"/>
<vertex x="26.8846" y="1.5653"/>
<vertex x="26.6306" y="1.5653"/>
<vertex x="26.5798" y="1.5907"/>
<vertex x="26.4274" y="1.8066"/>
<vertex x="26.3385" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="26.3385" y="2.4924" curve="-90"/>
<vertex x="27.2021" y="3.356"/>
<vertex x="27.2275" y="3.356" curve="-90"/>
<vertex x="28.0911" y="2.4924"/>
<vertex x="28.0911" y="2.1876"/>
<vertex x="28.0657" y="1.9971"/>
<vertex x="28.0022" y="1.8066"/>
<vertex x="27.8498" y="1.5907"/>
<vertex x="27.799" y="1.5653"/>
<vertex x="27.545" y="1.5653" curve="90"/>
<vertex x="27.4434" y="1.4637"/>
<vertex x="27.9641" y="1.4637" curve="-90"/>
<vertex x="28.0911" y="1.3367"/>
<vertex x="28.0911" y="0.4858" curve="-90"/>
<vertex x="27.9641" y="0.3588"/>
<vertex x="26.4655" y="0.3588" curve="-90"/>
<vertex x="26.3385" y="0.4858"/>
<vertex x="26.3385" y="1.3367" curve="-90"/>
<vertex x="26.4655" y="1.4637"/>
<vertex x="26.9862" y="1.4637" curve="90"/>
<vertex x="26.8846" y="1.5653"/>
<vertex x="26.6306" y="1.5653"/>
<vertex x="26.5798" y="1.5907"/>
<vertex x="26.4274" y="1.8066"/>
<vertex x="26.3385" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="28.8785" y="2.4924" curve="-90"/>
<vertex x="29.7421" y="3.356"/>
<vertex x="29.7675" y="3.356" curve="-90"/>
<vertex x="30.6311" y="2.4924"/>
<vertex x="30.6311" y="2.1876"/>
<vertex x="30.6057" y="1.9971"/>
<vertex x="30.5422" y="1.8066"/>
<vertex x="30.3898" y="1.5907"/>
<vertex x="30.339" y="1.5653"/>
<vertex x="30.085" y="1.5653" curve="90"/>
<vertex x="29.9834" y="1.4637"/>
<vertex x="30.5041" y="1.4637" curve="-90"/>
<vertex x="30.6311" y="1.3367"/>
<vertex x="30.6311" y="0.4858" curve="-90"/>
<vertex x="30.5041" y="0.3588"/>
<vertex x="29.0055" y="0.3588" curve="-90"/>
<vertex x="28.8785" y="0.4858"/>
<vertex x="28.8785" y="1.3367" curve="-90"/>
<vertex x="29.0055" y="1.4637"/>
<vertex x="29.5262" y="1.4637" curve="90"/>
<vertex x="29.4246" y="1.5653"/>
<vertex x="29.1706" y="1.5653"/>
<vertex x="29.1198" y="1.5907"/>
<vertex x="28.9674" y="1.8066"/>
<vertex x="28.8785" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="28.8785" y="2.4924" curve="-90"/>
<vertex x="29.7421" y="3.356"/>
<vertex x="29.7675" y="3.356" curve="-90"/>
<vertex x="30.6311" y="2.4924"/>
<vertex x="30.6311" y="2.1876"/>
<vertex x="30.6057" y="1.9971"/>
<vertex x="30.5422" y="1.8066"/>
<vertex x="30.3898" y="1.5907"/>
<vertex x="30.339" y="1.5653"/>
<vertex x="30.085" y="1.5653" curve="90"/>
<vertex x="29.9834" y="1.4637"/>
<vertex x="30.5041" y="1.4637" curve="-90"/>
<vertex x="30.6311" y="1.3367"/>
<vertex x="30.6311" y="0.4858" curve="-90"/>
<vertex x="30.5041" y="0.3588"/>
<vertex x="29.0055" y="0.3588" curve="-90"/>
<vertex x="28.8785" y="0.4858"/>
<vertex x="28.8785" y="1.3367" curve="-90"/>
<vertex x="29.0055" y="1.4637"/>
<vertex x="29.5262" y="1.4637" curve="90"/>
<vertex x="29.4246" y="1.5653"/>
<vertex x="29.1706" y="1.5653"/>
<vertex x="29.1198" y="1.5907"/>
<vertex x="28.9674" y="1.8066"/>
<vertex x="28.8785" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="31.4185" y="2.4924" curve="-90"/>
<vertex x="32.2821" y="3.356"/>
<vertex x="32.3075" y="3.356" curve="-90"/>
<vertex x="33.1711" y="2.4924"/>
<vertex x="33.1711" y="2.1876"/>
<vertex x="33.1457" y="1.9971"/>
<vertex x="33.0822" y="1.8066"/>
<vertex x="32.9298" y="1.5907"/>
<vertex x="32.879" y="1.5653"/>
<vertex x="32.625" y="1.5653" curve="90"/>
<vertex x="32.5234" y="1.4637"/>
<vertex x="33.0441" y="1.4637" curve="-90"/>
<vertex x="33.1711" y="1.3367"/>
<vertex x="33.1711" y="0.4858" curve="-90"/>
<vertex x="33.0441" y="0.3588"/>
<vertex x="31.5455" y="0.3588" curve="-90"/>
<vertex x="31.4185" y="0.4858"/>
<vertex x="31.4185" y="1.3367" curve="-90"/>
<vertex x="31.5455" y="1.4637"/>
<vertex x="32.0662" y="1.4637" curve="90"/>
<vertex x="31.9646" y="1.5653"/>
<vertex x="31.7106" y="1.5653"/>
<vertex x="31.6598" y="1.5907"/>
<vertex x="31.5074" y="1.8066"/>
<vertex x="31.4185" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="31.4185" y="2.4924" curve="-90"/>
<vertex x="32.2821" y="3.356"/>
<vertex x="32.3075" y="3.356" curve="-90"/>
<vertex x="33.1711" y="2.4924"/>
<vertex x="33.1711" y="2.1876"/>
<vertex x="33.1457" y="1.9971"/>
<vertex x="33.0822" y="1.8066"/>
<vertex x="32.9298" y="1.5907"/>
<vertex x="32.879" y="1.5653"/>
<vertex x="32.625" y="1.5653" curve="90"/>
<vertex x="32.5234" y="1.4637"/>
<vertex x="33.0441" y="1.4637" curve="-90"/>
<vertex x="33.1711" y="1.3367"/>
<vertex x="33.1711" y="0.4858" curve="-90"/>
<vertex x="33.0441" y="0.3588"/>
<vertex x="31.5455" y="0.3588" curve="-90"/>
<vertex x="31.4185" y="0.4858"/>
<vertex x="31.4185" y="1.3367" curve="-90"/>
<vertex x="31.5455" y="1.4637"/>
<vertex x="32.0662" y="1.4637" curve="90"/>
<vertex x="31.9646" y="1.5653"/>
<vertex x="31.7106" y="1.5653"/>
<vertex x="31.6598" y="1.5907"/>
<vertex x="31.5074" y="1.8066"/>
<vertex x="31.4185" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="33.9585" y="2.4924" curve="-90"/>
<vertex x="34.8221" y="3.356"/>
<vertex x="34.8475" y="3.356" curve="-90"/>
<vertex x="35.7111" y="2.4924"/>
<vertex x="35.7111" y="2.1876"/>
<vertex x="35.6857" y="1.9971"/>
<vertex x="35.6222" y="1.8066"/>
<vertex x="35.4698" y="1.5907"/>
<vertex x="35.419" y="1.5653"/>
<vertex x="35.165" y="1.5653" curve="90"/>
<vertex x="35.0634" y="1.4637"/>
<vertex x="35.5841" y="1.4637" curve="-90"/>
<vertex x="35.7111" y="1.3367"/>
<vertex x="35.7111" y="0.4858" curve="-90"/>
<vertex x="35.5841" y="0.3588"/>
<vertex x="34.0855" y="0.3588" curve="-90"/>
<vertex x="33.9585" y="0.4858"/>
<vertex x="33.9585" y="1.3367" curve="-90"/>
<vertex x="34.0855" y="1.4637"/>
<vertex x="34.6062" y="1.4637" curve="90"/>
<vertex x="34.5046" y="1.5653"/>
<vertex x="34.2506" y="1.5653"/>
<vertex x="34.1998" y="1.5907"/>
<vertex x="34.0474" y="1.8066"/>
<vertex x="33.9585" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="33.9585" y="2.4924" curve="-90"/>
<vertex x="34.8221" y="3.356"/>
<vertex x="34.8475" y="3.356" curve="-90"/>
<vertex x="35.7111" y="2.4924"/>
<vertex x="35.7111" y="2.1876"/>
<vertex x="35.6857" y="1.9971"/>
<vertex x="35.6222" y="1.8066"/>
<vertex x="35.4698" y="1.5907"/>
<vertex x="35.419" y="1.5653"/>
<vertex x="35.165" y="1.5653" curve="90"/>
<vertex x="35.0634" y="1.4637"/>
<vertex x="35.5841" y="1.4637" curve="-90"/>
<vertex x="35.7111" y="1.3367"/>
<vertex x="35.7111" y="0.4858" curve="-90"/>
<vertex x="35.5841" y="0.3588"/>
<vertex x="34.0855" y="0.3588" curve="-90"/>
<vertex x="33.9585" y="0.4858"/>
<vertex x="33.9585" y="1.3367" curve="-90"/>
<vertex x="34.0855" y="1.4637"/>
<vertex x="34.6062" y="1.4637" curve="90"/>
<vertex x="34.5046" y="1.5653"/>
<vertex x="34.2506" y="1.5653"/>
<vertex x="34.1998" y="1.5907"/>
<vertex x="34.0474" y="1.8066"/>
<vertex x="33.9585" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="36.4985" y="2.4924" curve="-90"/>
<vertex x="37.3621" y="3.356"/>
<vertex x="37.3875" y="3.356" curve="-90"/>
<vertex x="38.2511" y="2.4924"/>
<vertex x="38.2511" y="2.1876"/>
<vertex x="38.2257" y="1.9971"/>
<vertex x="38.1622" y="1.8066"/>
<vertex x="38.0098" y="1.5907"/>
<vertex x="37.959" y="1.5653"/>
<vertex x="37.705" y="1.5653" curve="90"/>
<vertex x="37.6034" y="1.4637"/>
<vertex x="38.1241" y="1.4637" curve="-90"/>
<vertex x="38.2511" y="1.3367"/>
<vertex x="38.2511" y="0.4858" curve="-90"/>
<vertex x="38.1241" y="0.3588"/>
<vertex x="36.6255" y="0.3588" curve="-90"/>
<vertex x="36.4985" y="0.4858"/>
<vertex x="36.4985" y="1.3367" curve="-90"/>
<vertex x="36.6255" y="1.4637"/>
<vertex x="37.1462" y="1.4637" curve="90"/>
<vertex x="37.0446" y="1.5653"/>
<vertex x="36.7906" y="1.5653"/>
<vertex x="36.7398" y="1.5907"/>
<vertex x="36.5874" y="1.8066"/>
<vertex x="36.4985" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="36.4985" y="2.4924" curve="-90"/>
<vertex x="37.3621" y="3.356"/>
<vertex x="37.3875" y="3.356" curve="-90"/>
<vertex x="38.2511" y="2.4924"/>
<vertex x="38.2511" y="2.1876"/>
<vertex x="38.2257" y="1.9971"/>
<vertex x="38.1622" y="1.8066"/>
<vertex x="38.0098" y="1.5907"/>
<vertex x="37.959" y="1.5653"/>
<vertex x="37.705" y="1.5653" curve="90"/>
<vertex x="37.6034" y="1.4637"/>
<vertex x="38.1241" y="1.4637" curve="-90"/>
<vertex x="38.2511" y="1.3367"/>
<vertex x="38.2511" y="0.4858" curve="-90"/>
<vertex x="38.1241" y="0.3588"/>
<vertex x="36.6255" y="0.3588" curve="-90"/>
<vertex x="36.4985" y="0.4858"/>
<vertex x="36.4985" y="1.3367" curve="-90"/>
<vertex x="36.6255" y="1.4637"/>
<vertex x="37.1462" y="1.4637" curve="90"/>
<vertex x="37.0446" y="1.5653"/>
<vertex x="36.7906" y="1.5653"/>
<vertex x="36.7398" y="1.5907"/>
<vertex x="36.5874" y="1.8066"/>
<vertex x="36.4985" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="39.0385" y="2.4924" curve="-90"/>
<vertex x="39.9021" y="3.356"/>
<vertex x="39.9275" y="3.356" curve="-90"/>
<vertex x="40.7911" y="2.4924"/>
<vertex x="40.7911" y="2.1876"/>
<vertex x="40.7657" y="1.9971"/>
<vertex x="40.7022" y="1.8066"/>
<vertex x="40.5498" y="1.5907"/>
<vertex x="40.499" y="1.5653"/>
<vertex x="40.245" y="1.5653" curve="90"/>
<vertex x="40.1434" y="1.4637"/>
<vertex x="40.6641" y="1.4637" curve="-90"/>
<vertex x="40.7911" y="1.3367"/>
<vertex x="40.7911" y="0.4858" curve="-90"/>
<vertex x="40.6641" y="0.3588"/>
<vertex x="39.1655" y="0.3588" curve="-90"/>
<vertex x="39.0385" y="0.4858"/>
<vertex x="39.0385" y="1.3367" curve="-90"/>
<vertex x="39.1655" y="1.4637"/>
<vertex x="39.6862" y="1.4637" curve="90"/>
<vertex x="39.5846" y="1.5653"/>
<vertex x="39.3306" y="1.5653"/>
<vertex x="39.2798" y="1.5907"/>
<vertex x="39.1274" y="1.8066"/>
<vertex x="39.0385" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="39.0385" y="2.4924" curve="-90"/>
<vertex x="39.9021" y="3.356"/>
<vertex x="39.9275" y="3.356" curve="-90"/>
<vertex x="40.7911" y="2.4924"/>
<vertex x="40.7911" y="2.1876"/>
<vertex x="40.7657" y="1.9971"/>
<vertex x="40.7022" y="1.8066"/>
<vertex x="40.5498" y="1.5907"/>
<vertex x="40.499" y="1.5653"/>
<vertex x="40.245" y="1.5653" curve="90"/>
<vertex x="40.1434" y="1.4637"/>
<vertex x="40.6641" y="1.4637" curve="-90"/>
<vertex x="40.7911" y="1.3367"/>
<vertex x="40.7911" y="0.4858" curve="-90"/>
<vertex x="40.6641" y="0.3588"/>
<vertex x="39.1655" y="0.3588" curve="-90"/>
<vertex x="39.0385" y="0.4858"/>
<vertex x="39.0385" y="1.3367" curve="-90"/>
<vertex x="39.1655" y="1.4637"/>
<vertex x="39.6862" y="1.4637" curve="90"/>
<vertex x="39.5846" y="1.5653"/>
<vertex x="39.3306" y="1.5653"/>
<vertex x="39.2798" y="1.5907"/>
<vertex x="39.1274" y="1.8066"/>
<vertex x="39.0385" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="41.5785" y="2.4924" curve="-90"/>
<vertex x="42.4421" y="3.356"/>
<vertex x="42.4675" y="3.356" curve="-90"/>
<vertex x="43.3311" y="2.4924"/>
<vertex x="43.3311" y="2.1876"/>
<vertex x="43.3057" y="1.9971"/>
<vertex x="43.2422" y="1.8066"/>
<vertex x="43.0898" y="1.5907"/>
<vertex x="43.039" y="1.5653"/>
<vertex x="42.785" y="1.5653" curve="90"/>
<vertex x="42.6834" y="1.4637"/>
<vertex x="43.2041" y="1.4637" curve="-90"/>
<vertex x="43.3311" y="1.3367"/>
<vertex x="43.3311" y="0.4858" curve="-90"/>
<vertex x="43.2041" y="0.3588"/>
<vertex x="41.7055" y="0.3588" curve="-90"/>
<vertex x="41.5785" y="0.4858"/>
<vertex x="41.5785" y="1.3367" curve="-90"/>
<vertex x="41.7055" y="1.4637"/>
<vertex x="42.2262" y="1.4637" curve="90"/>
<vertex x="42.1246" y="1.5653"/>
<vertex x="41.8706" y="1.5653"/>
<vertex x="41.8198" y="1.5907"/>
<vertex x="41.6674" y="1.8066"/>
<vertex x="41.5785" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="41.5785" y="2.4924" curve="-90"/>
<vertex x="42.4421" y="3.356"/>
<vertex x="42.4675" y="3.356" curve="-90"/>
<vertex x="43.3311" y="2.4924"/>
<vertex x="43.3311" y="2.1876"/>
<vertex x="43.3057" y="1.9971"/>
<vertex x="43.2422" y="1.8066"/>
<vertex x="43.0898" y="1.5907"/>
<vertex x="43.039" y="1.5653"/>
<vertex x="42.785" y="1.5653" curve="90"/>
<vertex x="42.6834" y="1.4637"/>
<vertex x="43.2041" y="1.4637" curve="-90"/>
<vertex x="43.3311" y="1.3367"/>
<vertex x="43.3311" y="0.4858" curve="-90"/>
<vertex x="43.2041" y="0.3588"/>
<vertex x="41.7055" y="0.3588" curve="-90"/>
<vertex x="41.5785" y="0.4858"/>
<vertex x="41.5785" y="1.3367" curve="-90"/>
<vertex x="41.7055" y="1.4637"/>
<vertex x="42.2262" y="1.4637" curve="90"/>
<vertex x="42.1246" y="1.5653"/>
<vertex x="41.8706" y="1.5653"/>
<vertex x="41.8198" y="1.5907"/>
<vertex x="41.6674" y="1.8066"/>
<vertex x="41.5785" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="44.1185" y="2.4924" curve="-90"/>
<vertex x="44.9821" y="3.356"/>
<vertex x="45.0075" y="3.356" curve="-90"/>
<vertex x="45.8711" y="2.4924"/>
<vertex x="45.8711" y="2.1876"/>
<vertex x="45.8457" y="1.9971"/>
<vertex x="45.7822" y="1.8066"/>
<vertex x="45.6298" y="1.5907"/>
<vertex x="45.579" y="1.5653"/>
<vertex x="45.325" y="1.5653" curve="90"/>
<vertex x="45.2234" y="1.4637"/>
<vertex x="45.7441" y="1.4637" curve="-90"/>
<vertex x="45.8711" y="1.3367"/>
<vertex x="45.8711" y="0.4858" curve="-90"/>
<vertex x="45.7441" y="0.3588"/>
<vertex x="44.2455" y="0.3588" curve="-90"/>
<vertex x="44.1185" y="0.4858"/>
<vertex x="44.1185" y="1.3367" curve="-90"/>
<vertex x="44.2455" y="1.4637"/>
<vertex x="44.7662" y="1.4637" curve="90"/>
<vertex x="44.6646" y="1.5653"/>
<vertex x="44.4106" y="1.5653"/>
<vertex x="44.3598" y="1.5907"/>
<vertex x="44.2074" y="1.8066"/>
<vertex x="44.1185" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="44.1185" y="2.4924" curve="-90"/>
<vertex x="44.9821" y="3.356"/>
<vertex x="45.0075" y="3.356" curve="-90"/>
<vertex x="45.8711" y="2.4924"/>
<vertex x="45.8711" y="2.1876"/>
<vertex x="45.8457" y="1.9971"/>
<vertex x="45.7822" y="1.8066"/>
<vertex x="45.6298" y="1.5907"/>
<vertex x="45.579" y="1.5653"/>
<vertex x="45.325" y="1.5653" curve="90"/>
<vertex x="45.2234" y="1.4637"/>
<vertex x="45.7441" y="1.4637" curve="-90"/>
<vertex x="45.8711" y="1.3367"/>
<vertex x="45.8711" y="0.4858" curve="-90"/>
<vertex x="45.7441" y="0.3588"/>
<vertex x="44.2455" y="0.3588" curve="-90"/>
<vertex x="44.1185" y="0.4858"/>
<vertex x="44.1185" y="1.3367" curve="-90"/>
<vertex x="44.2455" y="1.4637"/>
<vertex x="44.7662" y="1.4637" curve="90"/>
<vertex x="44.6646" y="1.5653"/>
<vertex x="44.4106" y="1.5653"/>
<vertex x="44.3598" y="1.5907"/>
<vertex x="44.2074" y="1.8066"/>
<vertex x="44.1185" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="46.6585" y="2.4924" curve="-90"/>
<vertex x="47.5221" y="3.356"/>
<vertex x="47.5475" y="3.356" curve="-90"/>
<vertex x="48.4111" y="2.4924"/>
<vertex x="48.4111" y="2.1876"/>
<vertex x="48.3857" y="1.9971"/>
<vertex x="48.3222" y="1.8066"/>
<vertex x="48.1698" y="1.5907"/>
<vertex x="48.119" y="1.5653"/>
<vertex x="47.865" y="1.5653" curve="90"/>
<vertex x="47.7634" y="1.4637"/>
<vertex x="48.2841" y="1.4637" curve="-90"/>
<vertex x="48.4111" y="1.3367"/>
<vertex x="48.4111" y="0.4858" curve="-90"/>
<vertex x="48.2841" y="0.3588"/>
<vertex x="46.7855" y="0.3588" curve="-90"/>
<vertex x="46.6585" y="0.4858"/>
<vertex x="46.6585" y="1.3367" curve="-90"/>
<vertex x="46.7855" y="1.4637"/>
<vertex x="47.3062" y="1.4637" curve="90"/>
<vertex x="47.2046" y="1.5653"/>
<vertex x="46.9506" y="1.5653"/>
<vertex x="46.8998" y="1.5907"/>
<vertex x="46.7474" y="1.8066"/>
<vertex x="46.6585" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="46.6585" y="2.4924" curve="-90"/>
<vertex x="47.5221" y="3.356"/>
<vertex x="47.5475" y="3.356" curve="-90"/>
<vertex x="48.4111" y="2.4924"/>
<vertex x="48.4111" y="2.1876"/>
<vertex x="48.3857" y="1.9971"/>
<vertex x="48.3222" y="1.8066"/>
<vertex x="48.1698" y="1.5907"/>
<vertex x="48.119" y="1.5653"/>
<vertex x="47.865" y="1.5653" curve="90"/>
<vertex x="47.7634" y="1.4637"/>
<vertex x="48.2841" y="1.4637" curve="-90"/>
<vertex x="48.4111" y="1.3367"/>
<vertex x="48.4111" y="0.4858" curve="-90"/>
<vertex x="48.2841" y="0.3588"/>
<vertex x="46.7855" y="0.3588" curve="-90"/>
<vertex x="46.6585" y="0.4858"/>
<vertex x="46.6585" y="1.3367" curve="-90"/>
<vertex x="46.7855" y="1.4637"/>
<vertex x="47.3062" y="1.4637" curve="90"/>
<vertex x="47.2046" y="1.5653"/>
<vertex x="46.9506" y="1.5653"/>
<vertex x="46.8998" y="1.5907"/>
<vertex x="46.7474" y="1.8066"/>
<vertex x="46.6585" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="49.1985" y="2.4924" curve="-90"/>
<vertex x="50.0621" y="3.356"/>
<vertex x="50.0875" y="3.356" curve="-90"/>
<vertex x="50.9511" y="2.4924"/>
<vertex x="50.9511" y="2.1876"/>
<vertex x="50.9257" y="1.9971"/>
<vertex x="50.8622" y="1.8066"/>
<vertex x="50.7098" y="1.5907"/>
<vertex x="50.659" y="1.5653"/>
<vertex x="50.405" y="1.5653" curve="90"/>
<vertex x="50.3034" y="1.4637"/>
<vertex x="50.8241" y="1.4637" curve="-90"/>
<vertex x="50.9511" y="1.3367"/>
<vertex x="50.9511" y="0.4858" curve="-90"/>
<vertex x="50.8241" y="0.3588"/>
<vertex x="49.3255" y="0.3588" curve="-90"/>
<vertex x="49.1985" y="0.4858"/>
<vertex x="49.1985" y="1.3367" curve="-90"/>
<vertex x="49.3255" y="1.4637"/>
<vertex x="49.8462" y="1.4637" curve="90"/>
<vertex x="49.7446" y="1.5653"/>
<vertex x="49.4906" y="1.5653"/>
<vertex x="49.4398" y="1.5907"/>
<vertex x="49.2874" y="1.8066"/>
<vertex x="49.1985" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="49.1985" y="2.4924" curve="-90"/>
<vertex x="50.0621" y="3.356"/>
<vertex x="50.0875" y="3.356" curve="-90"/>
<vertex x="50.9511" y="2.4924"/>
<vertex x="50.9511" y="2.1876"/>
<vertex x="50.9257" y="1.9971"/>
<vertex x="50.8622" y="1.8066"/>
<vertex x="50.7098" y="1.5907"/>
<vertex x="50.659" y="1.5653"/>
<vertex x="50.405" y="1.5653" curve="90"/>
<vertex x="50.3034" y="1.4637"/>
<vertex x="50.8241" y="1.4637" curve="-90"/>
<vertex x="50.9511" y="1.3367"/>
<vertex x="50.9511" y="0.4858" curve="-90"/>
<vertex x="50.8241" y="0.3588"/>
<vertex x="49.3255" y="0.3588" curve="-90"/>
<vertex x="49.1985" y="0.4858"/>
<vertex x="49.1985" y="1.3367" curve="-90"/>
<vertex x="49.3255" y="1.4637"/>
<vertex x="49.8462" y="1.4637" curve="90"/>
<vertex x="49.7446" y="1.5653"/>
<vertex x="49.4906" y="1.5653"/>
<vertex x="49.4398" y="1.5907"/>
<vertex x="49.2874" y="1.8066"/>
<vertex x="49.1985" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="51.7385" y="2.4924" curve="-90"/>
<vertex x="52.6021" y="3.356"/>
<vertex x="52.6275" y="3.356" curve="-90"/>
<vertex x="53.4911" y="2.4924"/>
<vertex x="53.4911" y="2.1876"/>
<vertex x="53.4657" y="1.9971"/>
<vertex x="53.4022" y="1.8066"/>
<vertex x="53.2498" y="1.5907"/>
<vertex x="53.199" y="1.5653"/>
<vertex x="52.945" y="1.5653" curve="90"/>
<vertex x="52.8434" y="1.4637"/>
<vertex x="53.3641" y="1.4637" curve="-90"/>
<vertex x="53.4911" y="1.3367"/>
<vertex x="53.4911" y="0.4858" curve="-90"/>
<vertex x="53.3641" y="0.3588"/>
<vertex x="51.8655" y="0.3588" curve="-90"/>
<vertex x="51.7385" y="0.4858"/>
<vertex x="51.7385" y="1.3367" curve="-90"/>
<vertex x="51.8655" y="1.4637"/>
<vertex x="52.3862" y="1.4637" curve="90"/>
<vertex x="52.2846" y="1.5653"/>
<vertex x="52.0306" y="1.5653"/>
<vertex x="51.9798" y="1.5907"/>
<vertex x="51.8274" y="1.8066"/>
<vertex x="51.7385" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="51.7385" y="2.4924" curve="-90"/>
<vertex x="52.6021" y="3.356"/>
<vertex x="52.6275" y="3.356" curve="-90"/>
<vertex x="53.4911" y="2.4924"/>
<vertex x="53.4911" y="2.1876"/>
<vertex x="53.4657" y="1.9971"/>
<vertex x="53.4022" y="1.8066"/>
<vertex x="53.2498" y="1.5907"/>
<vertex x="53.199" y="1.5653"/>
<vertex x="52.945" y="1.5653" curve="90"/>
<vertex x="52.8434" y="1.4637"/>
<vertex x="53.3641" y="1.4637" curve="-90"/>
<vertex x="53.4911" y="1.3367"/>
<vertex x="53.4911" y="0.4858" curve="-90"/>
<vertex x="53.3641" y="0.3588"/>
<vertex x="51.8655" y="0.3588" curve="-90"/>
<vertex x="51.7385" y="0.4858"/>
<vertex x="51.7385" y="1.3367" curve="-90"/>
<vertex x="51.8655" y="1.4637"/>
<vertex x="52.3862" y="1.4637" curve="90"/>
<vertex x="52.2846" y="1.5653"/>
<vertex x="52.0306" y="1.5653"/>
<vertex x="51.9798" y="1.5907"/>
<vertex x="51.8274" y="1.8066"/>
<vertex x="51.7385" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="54.2785" y="2.4924" curve="-90"/>
<vertex x="55.1421" y="3.356"/>
<vertex x="55.1675" y="3.356" curve="-90"/>
<vertex x="56.0311" y="2.4924"/>
<vertex x="56.0311" y="2.1876"/>
<vertex x="56.0057" y="1.9971"/>
<vertex x="55.9422" y="1.8066"/>
<vertex x="55.7898" y="1.5907"/>
<vertex x="55.739" y="1.5653"/>
<vertex x="55.485" y="1.5653" curve="90"/>
<vertex x="55.3834" y="1.4637"/>
<vertex x="55.9041" y="1.4637" curve="-90"/>
<vertex x="56.0311" y="1.3367"/>
<vertex x="56.0311" y="0.4858" curve="-90"/>
<vertex x="55.9041" y="0.3588"/>
<vertex x="54.4055" y="0.3588" curve="-90"/>
<vertex x="54.2785" y="0.4858"/>
<vertex x="54.2785" y="1.3367" curve="-90"/>
<vertex x="54.4055" y="1.4637"/>
<vertex x="54.9262" y="1.4637" curve="90"/>
<vertex x="54.8246" y="1.5653"/>
<vertex x="54.5706" y="1.5653"/>
<vertex x="54.5198" y="1.5907"/>
<vertex x="54.3674" y="1.8066"/>
<vertex x="54.2785" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="54.2785" y="2.4924" curve="-90"/>
<vertex x="55.1421" y="3.356"/>
<vertex x="55.1675" y="3.356" curve="-90"/>
<vertex x="56.0311" y="2.4924"/>
<vertex x="56.0311" y="2.1876"/>
<vertex x="56.0057" y="1.9971"/>
<vertex x="55.9422" y="1.8066"/>
<vertex x="55.7898" y="1.5907"/>
<vertex x="55.739" y="1.5653"/>
<vertex x="55.485" y="1.5653" curve="90"/>
<vertex x="55.3834" y="1.4637"/>
<vertex x="55.9041" y="1.4637" curve="-90"/>
<vertex x="56.0311" y="1.3367"/>
<vertex x="56.0311" y="0.4858" curve="-90"/>
<vertex x="55.9041" y="0.3588"/>
<vertex x="54.4055" y="0.3588" curve="-90"/>
<vertex x="54.2785" y="0.4858"/>
<vertex x="54.2785" y="1.3367" curve="-90"/>
<vertex x="54.4055" y="1.4637"/>
<vertex x="54.9262" y="1.4637" curve="90"/>
<vertex x="54.8246" y="1.5653"/>
<vertex x="54.5706" y="1.5653"/>
<vertex x="54.5198" y="1.5907"/>
<vertex x="54.3674" y="1.8066"/>
<vertex x="54.2785" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="23.7985" y="2.2003"/>
<vertex x="23.7985" y="2.467" curve="-90"/>
<vertex x="24.6748" y="3.356" curve="-90"/>
<vertex x="25.5511" y="2.467"/>
<vertex x="25.5511" y="2.2003" curve="-90"/>
<vertex x="24.6748" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="26.3385" y="2.2003"/>
<vertex x="26.3385" y="2.467" curve="-90"/>
<vertex x="27.2148" y="3.356" curve="-90"/>
<vertex x="28.0911" y="2.467"/>
<vertex x="28.0911" y="2.2003" curve="-90"/>
<vertex x="27.2148" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="28.8785" y="2.2003"/>
<vertex x="28.8785" y="2.467" curve="-90"/>
<vertex x="29.7548" y="3.356" curve="-90"/>
<vertex x="30.6311" y="2.467"/>
<vertex x="30.6311" y="2.2003" curve="-90"/>
<vertex x="29.7548" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="31.4185" y="2.2003"/>
<vertex x="31.4185" y="2.467" curve="-90"/>
<vertex x="32.2948" y="3.356" curve="-90"/>
<vertex x="33.1711" y="2.467"/>
<vertex x="33.1711" y="2.2003" curve="-90"/>
<vertex x="32.2948" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="33.9585" y="2.2003"/>
<vertex x="33.9585" y="2.467" curve="-90"/>
<vertex x="34.8348" y="3.356" curve="-90"/>
<vertex x="35.7111" y="2.467"/>
<vertex x="35.7111" y="2.2003" curve="-90"/>
<vertex x="34.8348" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="36.4985" y="2.2003"/>
<vertex x="36.4985" y="2.467" curve="-90"/>
<vertex x="37.3748" y="3.356" curve="-90"/>
<vertex x="38.2511" y="2.467"/>
<vertex x="38.2511" y="2.2003" curve="-90"/>
<vertex x="37.3748" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="39.0385" y="2.2003"/>
<vertex x="39.0385" y="2.467" curve="-90"/>
<vertex x="39.9148" y="3.356" curve="-90"/>
<vertex x="40.7911" y="2.467"/>
<vertex x="40.7911" y="2.2003" curve="-90"/>
<vertex x="39.9148" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="41.5785" y="2.2003"/>
<vertex x="41.5785" y="2.467" curve="-90"/>
<vertex x="42.4548" y="3.356" curve="-90"/>
<vertex x="43.3311" y="2.467"/>
<vertex x="43.3311" y="2.2003" curve="-90"/>
<vertex x="42.4548" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="44.1185" y="2.2003"/>
<vertex x="44.1185" y="2.467" curve="-90"/>
<vertex x="44.9948" y="3.356" curve="-90"/>
<vertex x="45.8711" y="2.467"/>
<vertex x="45.8711" y="2.2003" curve="-90"/>
<vertex x="44.9948" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="46.6585" y="2.2003"/>
<vertex x="46.6585" y="2.467" curve="-90"/>
<vertex x="47.5348" y="3.356" curve="-90"/>
<vertex x="48.4111" y="2.467"/>
<vertex x="48.4111" y="2.2003" curve="-90"/>
<vertex x="47.5348" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="49.1985" y="2.2003"/>
<vertex x="49.1985" y="2.467" curve="-90"/>
<vertex x="50.0748" y="3.356" curve="-90"/>
<vertex x="50.9511" y="2.467"/>
<vertex x="50.9511" y="2.2003" curve="-90"/>
<vertex x="50.0748" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="51.7385" y="2.2003"/>
<vertex x="51.7385" y="2.467" curve="-90"/>
<vertex x="52.6148" y="3.356" curve="-90"/>
<vertex x="53.4911" y="2.467"/>
<vertex x="53.4911" y="2.2003" curve="-90"/>
<vertex x="52.6148" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="54.2785" y="2.2003"/>
<vertex x="54.2785" y="2.467" curve="-90"/>
<vertex x="55.1548" y="3.356" curve="-90"/>
<vertex x="56.0311" y="2.467"/>
<vertex x="56.0311" y="2.2003" curve="-90"/>
<vertex x="55.1548" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="24.6748" y="3.229" curve="90"/>
<vertex x="23.9255" y="2.4797"/>
<vertex x="23.9255" y="2.1749"/>
<vertex x="23.9509" y="2.0225"/>
<vertex x="24.0017" y="1.8574"/>
<vertex x="24.116" y="1.6923"/>
<vertex x="24.3573" y="1.6923" curve="-90"/>
<vertex x="24.5732" y="1.4764"/>
<vertex x="24.5732" y="1.3494" curve="-90"/>
<vertex x="24.5605" y="1.3367"/>
<vertex x="23.9255" y="1.3367"/>
<vertex x="23.9255" y="0.4858"/>
<vertex x="25.4241" y="0.4858"/>
<vertex x="25.4241" y="1.3367"/>
<vertex x="24.7764" y="1.3367"/>
<vertex x="24.7764" y="1.4764" curve="-90"/>
<vertex x="24.9923" y="1.6923"/>
<vertex x="25.2336" y="1.6923"/>
<vertex x="25.3479" y="1.8574"/>
<vertex x="25.3987" y="2.0225"/>
<vertex x="25.4241" y="2.1749"/>
<vertex x="25.4241" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="55.1548" y="3.229" curve="90"/>
<vertex x="54.4055" y="2.4797"/>
<vertex x="54.4055" y="2.1749"/>
<vertex x="54.4309" y="2.0225"/>
<vertex x="54.4817" y="1.8574"/>
<vertex x="54.596" y="1.6923"/>
<vertex x="54.8373" y="1.6923" curve="-90"/>
<vertex x="55.0532" y="1.4764"/>
<vertex x="55.0532" y="1.3494" curve="-90"/>
<vertex x="55.0405" y="1.3367"/>
<vertex x="54.4055" y="1.3367"/>
<vertex x="54.4055" y="0.4858"/>
<vertex x="55.9041" y="0.4858"/>
<vertex x="55.9041" y="1.3367"/>
<vertex x="55.2564" y="1.3367"/>
<vertex x="55.2564" y="1.4764" curve="-90"/>
<vertex x="55.4723" y="1.6923"/>
<vertex x="55.7136" y="1.6923"/>
<vertex x="55.8279" y="1.8574"/>
<vertex x="55.8787" y="2.0225"/>
<vertex x="55.9041" y="2.1749"/>
<vertex x="55.9041" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="27.2148" y="3.229" curve="90"/>
<vertex x="26.4655" y="2.4797"/>
<vertex x="26.4655" y="2.1749"/>
<vertex x="26.4909" y="2.0225"/>
<vertex x="26.5417" y="1.8574"/>
<vertex x="26.656" y="1.6923"/>
<vertex x="26.8973" y="1.6923" curve="-90"/>
<vertex x="27.1132" y="1.4764"/>
<vertex x="27.1132" y="1.3494" curve="-90"/>
<vertex x="27.1005" y="1.3367"/>
<vertex x="26.4655" y="1.3367"/>
<vertex x="26.4655" y="0.4858"/>
<vertex x="27.9641" y="0.4858"/>
<vertex x="27.9641" y="1.3367"/>
<vertex x="27.3164" y="1.3367"/>
<vertex x="27.3164" y="1.4764" curve="-90"/>
<vertex x="27.5323" y="1.6923"/>
<vertex x="27.7736" y="1.6923"/>
<vertex x="27.8879" y="1.8574"/>
<vertex x="27.9387" y="2.0225"/>
<vertex x="27.9641" y="2.1749"/>
<vertex x="27.9641" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="29.7548" y="3.229" curve="90"/>
<vertex x="29.0055" y="2.4797"/>
<vertex x="29.0055" y="2.1749"/>
<vertex x="29.0309" y="2.0225"/>
<vertex x="29.0817" y="1.8574"/>
<vertex x="29.196" y="1.6923"/>
<vertex x="29.4373" y="1.6923" curve="-90"/>
<vertex x="29.6532" y="1.4764"/>
<vertex x="29.6532" y="1.3494" curve="-90"/>
<vertex x="29.6405" y="1.3367"/>
<vertex x="29.0055" y="1.3367"/>
<vertex x="29.0055" y="0.4858"/>
<vertex x="30.5041" y="0.4858"/>
<vertex x="30.5041" y="1.3367"/>
<vertex x="29.8564" y="1.3367"/>
<vertex x="29.8564" y="1.4764" curve="-90"/>
<vertex x="30.0723" y="1.6923"/>
<vertex x="30.3136" y="1.6923"/>
<vertex x="30.4279" y="1.8574"/>
<vertex x="30.4787" y="2.0225"/>
<vertex x="30.5041" y="2.1749"/>
<vertex x="30.5041" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="32.2948" y="3.229" curve="90"/>
<vertex x="31.5455" y="2.4797"/>
<vertex x="31.5455" y="2.1749"/>
<vertex x="31.5709" y="2.0225"/>
<vertex x="31.6217" y="1.8574"/>
<vertex x="31.736" y="1.6923"/>
<vertex x="31.9773" y="1.6923" curve="-90"/>
<vertex x="32.1932" y="1.4764"/>
<vertex x="32.1932" y="1.3494" curve="-90"/>
<vertex x="32.1805" y="1.3367"/>
<vertex x="31.5455" y="1.3367"/>
<vertex x="31.5455" y="0.4858"/>
<vertex x="33.0441" y="0.4858"/>
<vertex x="33.0441" y="1.3367"/>
<vertex x="32.3964" y="1.3367"/>
<vertex x="32.3964" y="1.4764" curve="-90"/>
<vertex x="32.6123" y="1.6923"/>
<vertex x="32.8536" y="1.6923"/>
<vertex x="32.9679" y="1.8574"/>
<vertex x="33.0187" y="2.0225"/>
<vertex x="33.0441" y="2.1749"/>
<vertex x="33.0441" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="34.8348" y="3.229" curve="90"/>
<vertex x="34.0855" y="2.4797"/>
<vertex x="34.0855" y="2.1749"/>
<vertex x="34.1109" y="2.0225"/>
<vertex x="34.1617" y="1.8574"/>
<vertex x="34.276" y="1.6923"/>
<vertex x="34.5173" y="1.6923" curve="-90"/>
<vertex x="34.7332" y="1.4764"/>
<vertex x="34.7332" y="1.3494" curve="-90"/>
<vertex x="34.7205" y="1.3367"/>
<vertex x="34.0855" y="1.3367"/>
<vertex x="34.0855" y="0.4858"/>
<vertex x="35.5841" y="0.4858"/>
<vertex x="35.5841" y="1.3367"/>
<vertex x="34.9364" y="1.3367"/>
<vertex x="34.9364" y="1.4764" curve="-90"/>
<vertex x="35.1523" y="1.6923"/>
<vertex x="35.3936" y="1.6923"/>
<vertex x="35.5079" y="1.8574"/>
<vertex x="35.5587" y="2.0225"/>
<vertex x="35.5841" y="2.1749"/>
<vertex x="35.5841" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="37.3748" y="3.229" curve="90"/>
<vertex x="36.6255" y="2.4797"/>
<vertex x="36.6255" y="2.1749"/>
<vertex x="36.6509" y="2.0225"/>
<vertex x="36.7017" y="1.8574"/>
<vertex x="36.816" y="1.6923"/>
<vertex x="37.0573" y="1.6923" curve="-90"/>
<vertex x="37.2732" y="1.4764"/>
<vertex x="37.2732" y="1.3494" curve="-90"/>
<vertex x="37.2605" y="1.3367"/>
<vertex x="36.6255" y="1.3367"/>
<vertex x="36.6255" y="0.4858"/>
<vertex x="38.1241" y="0.4858"/>
<vertex x="38.1241" y="1.3367"/>
<vertex x="37.4764" y="1.3367"/>
<vertex x="37.4764" y="1.4764" curve="-90"/>
<vertex x="37.6923" y="1.6923"/>
<vertex x="37.9336" y="1.6923"/>
<vertex x="38.0479" y="1.8574"/>
<vertex x="38.0987" y="2.0225"/>
<vertex x="38.1241" y="2.1749"/>
<vertex x="38.1241" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="39.9148" y="3.229" curve="90"/>
<vertex x="39.1655" y="2.4797"/>
<vertex x="39.1655" y="2.1749"/>
<vertex x="39.1909" y="2.0225"/>
<vertex x="39.2417" y="1.8574"/>
<vertex x="39.356" y="1.6923"/>
<vertex x="39.5973" y="1.6923" curve="-90"/>
<vertex x="39.8132" y="1.4764"/>
<vertex x="39.8132" y="1.3494" curve="-90"/>
<vertex x="39.8005" y="1.3367"/>
<vertex x="39.1655" y="1.3367"/>
<vertex x="39.1655" y="0.4858"/>
<vertex x="40.6641" y="0.4858"/>
<vertex x="40.6641" y="1.3367"/>
<vertex x="40.0164" y="1.3367"/>
<vertex x="40.0164" y="1.4764" curve="-90"/>
<vertex x="40.2323" y="1.6923"/>
<vertex x="40.4736" y="1.6923"/>
<vertex x="40.5879" y="1.8574"/>
<vertex x="40.6387" y="2.0225"/>
<vertex x="40.6641" y="2.1749"/>
<vertex x="40.6641" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="42.4548" y="3.229" curve="90"/>
<vertex x="41.7055" y="2.4797"/>
<vertex x="41.7055" y="2.1749"/>
<vertex x="41.7309" y="2.0225"/>
<vertex x="41.7817" y="1.8574"/>
<vertex x="41.896" y="1.6923"/>
<vertex x="42.1373" y="1.6923" curve="-90"/>
<vertex x="42.3532" y="1.4764"/>
<vertex x="42.3532" y="1.3494" curve="-90"/>
<vertex x="42.3405" y="1.3367"/>
<vertex x="41.7055" y="1.3367"/>
<vertex x="41.7055" y="0.4858"/>
<vertex x="43.2041" y="0.4858"/>
<vertex x="43.2041" y="1.3367"/>
<vertex x="42.5564" y="1.3367"/>
<vertex x="42.5564" y="1.4764" curve="-90"/>
<vertex x="42.7723" y="1.6923"/>
<vertex x="43.0136" y="1.6923"/>
<vertex x="43.1279" y="1.8574"/>
<vertex x="43.1787" y="2.0225"/>
<vertex x="43.2041" y="2.1749"/>
<vertex x="43.2041" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="47.5348" y="3.229" curve="90"/>
<vertex x="46.7855" y="2.4797"/>
<vertex x="46.7855" y="2.1749"/>
<vertex x="46.8109" y="2.0225"/>
<vertex x="46.8617" y="1.8574"/>
<vertex x="46.976" y="1.6923"/>
<vertex x="47.2173" y="1.6923" curve="-90"/>
<vertex x="47.4332" y="1.4764"/>
<vertex x="47.4332" y="1.3494" curve="-90"/>
<vertex x="47.4205" y="1.3367"/>
<vertex x="46.7855" y="1.3367"/>
<vertex x="46.7855" y="0.4858"/>
<vertex x="48.2841" y="0.4858"/>
<vertex x="48.2841" y="1.3367"/>
<vertex x="47.6364" y="1.3367"/>
<vertex x="47.6364" y="1.4764" curve="-90"/>
<vertex x="47.8523" y="1.6923"/>
<vertex x="48.0936" y="1.6923"/>
<vertex x="48.2079" y="1.8574"/>
<vertex x="48.2587" y="2.0225"/>
<vertex x="48.2841" y="2.1749"/>
<vertex x="48.2841" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="50.0748" y="3.229" curve="90"/>
<vertex x="49.3255" y="2.4797"/>
<vertex x="49.3255" y="2.1749"/>
<vertex x="49.3509" y="2.0225"/>
<vertex x="49.4017" y="1.8574"/>
<vertex x="49.516" y="1.6923"/>
<vertex x="49.7573" y="1.6923" curve="-90"/>
<vertex x="49.9732" y="1.4764"/>
<vertex x="49.9732" y="1.3494" curve="-90"/>
<vertex x="49.9605" y="1.3367"/>
<vertex x="49.3255" y="1.3367"/>
<vertex x="49.3255" y="0.4858"/>
<vertex x="50.8241" y="0.4858"/>
<vertex x="50.8241" y="1.3367"/>
<vertex x="50.1764" y="1.3367"/>
<vertex x="50.1764" y="1.4764" curve="-90"/>
<vertex x="50.3923" y="1.6923"/>
<vertex x="50.6336" y="1.6923"/>
<vertex x="50.7479" y="1.8574"/>
<vertex x="50.7987" y="2.0225"/>
<vertex x="50.8241" y="2.1749"/>
<vertex x="50.8241" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="52.6148" y="3.229" curve="90"/>
<vertex x="51.8655" y="2.4797"/>
<vertex x="51.8655" y="2.1749"/>
<vertex x="51.8909" y="2.0225"/>
<vertex x="51.9417" y="1.8574"/>
<vertex x="52.056" y="1.6923"/>
<vertex x="52.2973" y="1.6923" curve="-90"/>
<vertex x="52.5132" y="1.4764"/>
<vertex x="52.5132" y="1.3494" curve="-90"/>
<vertex x="52.5005" y="1.3367"/>
<vertex x="51.8655" y="1.3367"/>
<vertex x="51.8655" y="0.4858"/>
<vertex x="53.3641" y="0.4858"/>
<vertex x="53.3641" y="1.3367"/>
<vertex x="52.7164" y="1.3367"/>
<vertex x="52.7164" y="1.4764" curve="-90"/>
<vertex x="52.9323" y="1.6923"/>
<vertex x="53.1736" y="1.6923"/>
<vertex x="53.2879" y="1.8574"/>
<vertex x="53.3387" y="2.0225"/>
<vertex x="53.3641" y="2.1749"/>
<vertex x="53.3641" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="44.9948" y="3.229" curve="90"/>
<vertex x="44.2455" y="2.4797"/>
<vertex x="44.2455" y="2.1749"/>
<vertex x="44.2709" y="2.0225"/>
<vertex x="44.3217" y="1.8574"/>
<vertex x="44.436" y="1.6923"/>
<vertex x="44.6773" y="1.6923" curve="-90"/>
<vertex x="44.8932" y="1.4764"/>
<vertex x="44.8932" y="1.3494" curve="-90"/>
<vertex x="44.8805" y="1.3367"/>
<vertex x="44.2455" y="1.3367"/>
<vertex x="44.2455" y="0.4858"/>
<vertex x="45.7441" y="0.4858"/>
<vertex x="45.7441" y="1.3367"/>
<vertex x="45.0964" y="1.3367"/>
<vertex x="45.0964" y="1.4764" curve="-90"/>
<vertex x="45.3123" y="1.6923"/>
<vertex x="45.5536" y="1.6923"/>
<vertex x="45.6679" y="1.8574"/>
<vertex x="45.7187" y="2.0225"/>
<vertex x="45.7441" y="2.1749"/>
<vertex x="45.7441" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="21.3855" y="3.2417"/>
<vertex x="21.3855" y="1.6923"/>
<vertex x="21.8173" y="1.6923" curve="-90"/>
<vertex x="22.0332" y="1.4764"/>
<vertex x="22.0332" y="1.3494" curve="-90"/>
<vertex x="22.0205" y="1.3367"/>
<vertex x="21.3855" y="1.3367"/>
<vertex x="21.3855" y="0.4858"/>
<vertex x="22.8841" y="0.4858"/>
<vertex x="22.8841" y="1.3367"/>
<vertex x="22.2364" y="1.3367"/>
<vertex x="22.2364" y="1.4764" curve="-90"/>
<vertex x="22.4523" y="1.6923"/>
<vertex x="22.8841" y="1.6923"/>
<vertex x="22.8841" y="3.2417"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="24.6748" y="3.229" curve="90"/>
<vertex x="23.9255" y="2.4797"/>
<vertex x="23.9255" y="2.1368" curve="90"/>
<vertex x="24.6748" y="1.3875" curve="90"/>
<vertex x="25.4241" y="2.1368"/>
<vertex x="25.4241" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="22.8841" y="3.229"/>
<vertex x="21.3855" y="3.229"/>
<vertex x="21.3855" y="1.4383"/>
<vertex x="22.8841" y="1.4383"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="27.2148" y="3.229" curve="90"/>
<vertex x="26.4655" y="2.4797"/>
<vertex x="26.4655" y="2.1368" curve="90"/>
<vertex x="27.2148" y="1.3875" curve="90"/>
<vertex x="27.9641" y="2.1368"/>
<vertex x="27.9641" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="29.7548" y="3.229" curve="90"/>
<vertex x="29.0055" y="2.4797"/>
<vertex x="29.0055" y="2.1368" curve="90"/>
<vertex x="29.7548" y="1.3875" curve="90"/>
<vertex x="30.5041" y="2.1368"/>
<vertex x="30.5041" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="32.2948" y="3.229" curve="90"/>
<vertex x="31.5455" y="2.4797"/>
<vertex x="31.5455" y="2.1368" curve="90"/>
<vertex x="32.2948" y="1.3875" curve="90"/>
<vertex x="33.0441" y="2.1368"/>
<vertex x="33.0441" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="34.8348" y="3.229" curve="90"/>
<vertex x="34.0855" y="2.4797"/>
<vertex x="34.0855" y="2.1368" curve="90"/>
<vertex x="34.8348" y="1.3875" curve="90"/>
<vertex x="35.5841" y="2.1368"/>
<vertex x="35.5841" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="37.3748" y="3.229" curve="90"/>
<vertex x="36.6255" y="2.4797"/>
<vertex x="36.6255" y="2.1368" curve="90"/>
<vertex x="37.3748" y="1.3875" curve="90"/>
<vertex x="38.1241" y="2.1368"/>
<vertex x="38.1241" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="39.9148" y="3.229" curve="90"/>
<vertex x="39.1655" y="2.4797"/>
<vertex x="39.1655" y="2.1368" curve="90"/>
<vertex x="39.9148" y="1.3875" curve="90"/>
<vertex x="40.6641" y="2.1368"/>
<vertex x="40.6641" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="42.4548" y="3.229" curve="90"/>
<vertex x="41.7055" y="2.4797"/>
<vertex x="41.7055" y="2.1368" curve="90"/>
<vertex x="42.4548" y="1.3875" curve="90"/>
<vertex x="43.2041" y="2.1368"/>
<vertex x="43.2041" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="44.9948" y="3.229" curve="90"/>
<vertex x="44.2455" y="2.4797"/>
<vertex x="44.2455" y="2.1368" curve="90"/>
<vertex x="44.9948" y="1.3875" curve="90"/>
<vertex x="45.7441" y="2.1368"/>
<vertex x="45.7441" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="47.5348" y="3.229" curve="90"/>
<vertex x="46.7855" y="2.4797"/>
<vertex x="46.7855" y="2.1368" curve="90"/>
<vertex x="47.5348" y="1.3875" curve="90"/>
<vertex x="48.2841" y="2.1368"/>
<vertex x="48.2841" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="50.0748" y="3.229" curve="90"/>
<vertex x="49.3255" y="2.4797"/>
<vertex x="49.3255" y="2.1368" curve="90"/>
<vertex x="50.0748" y="1.3875" curve="90"/>
<vertex x="50.8241" y="2.1368"/>
<vertex x="50.8241" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="52.6148" y="3.229" curve="90"/>
<vertex x="51.8655" y="2.4797"/>
<vertex x="51.8655" y="2.1368" curve="90"/>
<vertex x="52.6148" y="1.3875" curve="90"/>
<vertex x="53.3641" y="2.1368"/>
<vertex x="53.3641" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="55.1548" y="3.229" curve="90"/>
<vertex x="54.4055" y="2.4797"/>
<vertex x="54.4055" y="2.1368" curve="90"/>
<vertex x="55.1548" y="1.3875" curve="90"/>
<vertex x="55.9041" y="2.1368"/>
<vertex x="55.9041" y="2.4797" curve="90"/>
</polygon>
<wire x1="55.1652" y1="22.97" x2="55.1652" y2="22.27" width="0.05" layer="39"/>
<pad name="6" x="55.1652" y="22.62" drill="1" rot="R180" first="yes"/>
<pad name="7" x="52.6252" y="22.62" drill="1" rot="R180"/>
<pad name="8" x="50.0852" y="22.62" drill="1" rot="R180"/>
<pad name="9" x="47.5452" y="22.62" drill="1" rot="R180"/>
<pad name="10" x="45.0052" y="22.62" drill="1" rot="R180"/>
<pad name="11" x="42.4652" y="22.62" drill="1" rot="R180"/>
<pad name="12" x="39.9252" y="22.62" drill="1" rot="R180"/>
<pad name="13" x="37.3852" y="22.62" drill="1" rot="R180"/>
<pad name="14" x="34.8452" y="22.62" drill="1" rot="R180"/>
<pad name="RST" x="32.3052" y="22.62" drill="1" rot="R180"/>
<pad name="GND" x="29.7652" y="22.62" drill="1" rot="R180"/>
<pad name="VCC" x="27.2252" y="22.62" drill="1" rot="R180"/>
<pad name="5V" x="24.6852" y="22.62" drill="1" rot="R180"/>
<pad name="VIN" x="22.1452" y="22.62" drill="1" rot="R180"/>
<polygon width="0.0254" layer="29">
<vertex x="56.0415" y="21.5913"/>
<vertex x="54.2889" y="21.5913"/>
<vertex x="54.2889" y="23.6487"/>
<vertex x="56.0415" y="23.6487"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="56.0415" y="21.5913"/>
<vertex x="56.0415" y="23.3947"/>
<vertex x="55.4954" y="23.3947" curve="-90"/>
<vertex x="55.3938" y="23.4963"/>
<vertex x="55.9145" y="23.4963" curve="90"/>
<vertex x="56.0415" y="23.6233"/>
<vertex x="56.0415" y="24.4742" curve="90"/>
<vertex x="55.9145" y="24.6012"/>
<vertex x="54.4159" y="24.6012" curve="90"/>
<vertex x="54.2889" y="24.4742"/>
<vertex x="54.2889" y="23.6233" curve="90"/>
<vertex x="54.4159" y="23.4963"/>
<vertex x="54.9366" y="23.4963" curve="-90"/>
<vertex x="54.835" y="23.3947"/>
<vertex x="54.2889" y="23.3947"/>
<vertex x="54.2889" y="21.5913"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="53.5015" y="22.4676" curve="-90"/>
<vertex x="52.6379" y="21.604"/>
<vertex x="52.6125" y="21.604" curve="-90"/>
<vertex x="51.7489" y="22.4676"/>
<vertex x="51.7489" y="22.7724"/>
<vertex x="51.7743" y="22.9629"/>
<vertex x="51.8378" y="23.1534"/>
<vertex x="51.9902" y="23.3693"/>
<vertex x="52.041" y="23.3947"/>
<vertex x="52.295" y="23.3947" curve="90"/>
<vertex x="52.3966" y="23.4963"/>
<vertex x="51.8759" y="23.4963" curve="-90"/>
<vertex x="51.7489" y="23.6233"/>
<vertex x="51.7489" y="24.4742" curve="-90"/>
<vertex x="51.8759" y="24.6012"/>
<vertex x="53.3745" y="24.6012" curve="-90"/>
<vertex x="53.5015" y="24.4742"/>
<vertex x="53.5015" y="23.6233" curve="-90"/>
<vertex x="53.3745" y="23.4963"/>
<vertex x="52.8538" y="23.4963" curve="90"/>
<vertex x="52.9554" y="23.3947"/>
<vertex x="53.2094" y="23.3947"/>
<vertex x="53.2602" y="23.3693"/>
<vertex x="53.4126" y="23.1534"/>
<vertex x="53.5015" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="53.5015" y="22.4676" curve="-90"/>
<vertex x="52.6379" y="21.604"/>
<vertex x="52.6125" y="21.604" curve="-90"/>
<vertex x="51.7489" y="22.4676"/>
<vertex x="51.7489" y="22.7724"/>
<vertex x="51.7743" y="22.9629"/>
<vertex x="51.8378" y="23.1534"/>
<vertex x="51.9902" y="23.3693"/>
<vertex x="52.041" y="23.3947"/>
<vertex x="52.295" y="23.3947" curve="90"/>
<vertex x="52.3966" y="23.4963"/>
<vertex x="51.8759" y="23.4963" curve="-90"/>
<vertex x="51.7489" y="23.6233"/>
<vertex x="51.7489" y="24.4742" curve="-90"/>
<vertex x="51.8759" y="24.6012"/>
<vertex x="53.3745" y="24.6012" curve="-90"/>
<vertex x="53.5015" y="24.4742"/>
<vertex x="53.5015" y="23.6233" curve="-90"/>
<vertex x="53.3745" y="23.4963"/>
<vertex x="52.8538" y="23.4963" curve="90"/>
<vertex x="52.9554" y="23.3947"/>
<vertex x="53.2094" y="23.3947"/>
<vertex x="53.2602" y="23.3693"/>
<vertex x="53.4126" y="23.1534"/>
<vertex x="53.5015" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="50.9615" y="22.4676" curve="-90"/>
<vertex x="50.0979" y="21.604"/>
<vertex x="50.0725" y="21.604" curve="-90"/>
<vertex x="49.2089" y="22.4676"/>
<vertex x="49.2089" y="22.7724"/>
<vertex x="49.2343" y="22.9629"/>
<vertex x="49.2978" y="23.1534"/>
<vertex x="49.4502" y="23.3693"/>
<vertex x="49.501" y="23.3947"/>
<vertex x="49.755" y="23.3947" curve="90"/>
<vertex x="49.8566" y="23.4963"/>
<vertex x="49.3359" y="23.4963" curve="-90"/>
<vertex x="49.2089" y="23.6233"/>
<vertex x="49.2089" y="24.4742" curve="-90"/>
<vertex x="49.3359" y="24.6012"/>
<vertex x="50.8345" y="24.6012" curve="-90"/>
<vertex x="50.9615" y="24.4742"/>
<vertex x="50.9615" y="23.6233" curve="-90"/>
<vertex x="50.8345" y="23.4963"/>
<vertex x="50.3138" y="23.4963" curve="90"/>
<vertex x="50.4154" y="23.3947"/>
<vertex x="50.6694" y="23.3947"/>
<vertex x="50.7202" y="23.3693"/>
<vertex x="50.8726" y="23.1534"/>
<vertex x="50.9615" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="50.9615" y="22.4676" curve="-90"/>
<vertex x="50.0979" y="21.604"/>
<vertex x="50.0725" y="21.604" curve="-90"/>
<vertex x="49.2089" y="22.4676"/>
<vertex x="49.2089" y="22.7724"/>
<vertex x="49.2343" y="22.9629"/>
<vertex x="49.2978" y="23.1534"/>
<vertex x="49.4502" y="23.3693"/>
<vertex x="49.501" y="23.3947"/>
<vertex x="49.755" y="23.3947" curve="90"/>
<vertex x="49.8566" y="23.4963"/>
<vertex x="49.3359" y="23.4963" curve="-90"/>
<vertex x="49.2089" y="23.6233"/>
<vertex x="49.2089" y="24.4742" curve="-90"/>
<vertex x="49.3359" y="24.6012"/>
<vertex x="50.8345" y="24.6012" curve="-90"/>
<vertex x="50.9615" y="24.4742"/>
<vertex x="50.9615" y="23.6233" curve="-90"/>
<vertex x="50.8345" y="23.4963"/>
<vertex x="50.3138" y="23.4963" curve="90"/>
<vertex x="50.4154" y="23.3947"/>
<vertex x="50.6694" y="23.3947"/>
<vertex x="50.7202" y="23.3693"/>
<vertex x="50.8726" y="23.1534"/>
<vertex x="50.9615" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="48.4215" y="22.4676" curve="-90"/>
<vertex x="47.5579" y="21.604"/>
<vertex x="47.5325" y="21.604" curve="-90"/>
<vertex x="46.6689" y="22.4676"/>
<vertex x="46.6689" y="22.7724"/>
<vertex x="46.6943" y="22.9629"/>
<vertex x="46.7578" y="23.1534"/>
<vertex x="46.9102" y="23.3693"/>
<vertex x="46.961" y="23.3947"/>
<vertex x="47.215" y="23.3947" curve="90"/>
<vertex x="47.3166" y="23.4963"/>
<vertex x="46.7959" y="23.4963" curve="-90"/>
<vertex x="46.6689" y="23.6233"/>
<vertex x="46.6689" y="24.4742" curve="-90"/>
<vertex x="46.7959" y="24.6012"/>
<vertex x="48.2945" y="24.6012" curve="-90"/>
<vertex x="48.4215" y="24.4742"/>
<vertex x="48.4215" y="23.6233" curve="-90"/>
<vertex x="48.2945" y="23.4963"/>
<vertex x="47.7738" y="23.4963" curve="90"/>
<vertex x="47.8754" y="23.3947"/>
<vertex x="48.1294" y="23.3947"/>
<vertex x="48.1802" y="23.3693"/>
<vertex x="48.3326" y="23.1534"/>
<vertex x="48.4215" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="48.4215" y="22.4676" curve="-90"/>
<vertex x="47.5579" y="21.604"/>
<vertex x="47.5325" y="21.604" curve="-90"/>
<vertex x="46.6689" y="22.4676"/>
<vertex x="46.6689" y="22.7724"/>
<vertex x="46.6943" y="22.9629"/>
<vertex x="46.7578" y="23.1534"/>
<vertex x="46.9102" y="23.3693"/>
<vertex x="46.961" y="23.3947"/>
<vertex x="47.215" y="23.3947" curve="90"/>
<vertex x="47.3166" y="23.4963"/>
<vertex x="46.7959" y="23.4963" curve="-90"/>
<vertex x="46.6689" y="23.6233"/>
<vertex x="46.6689" y="24.4742" curve="-90"/>
<vertex x="46.7959" y="24.6012"/>
<vertex x="48.2945" y="24.6012" curve="-90"/>
<vertex x="48.4215" y="24.4742"/>
<vertex x="48.4215" y="23.6233" curve="-90"/>
<vertex x="48.2945" y="23.4963"/>
<vertex x="47.7738" y="23.4963" curve="90"/>
<vertex x="47.8754" y="23.3947"/>
<vertex x="48.1294" y="23.3947"/>
<vertex x="48.1802" y="23.3693"/>
<vertex x="48.3326" y="23.1534"/>
<vertex x="48.4215" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="45.8815" y="22.4676" curve="-90"/>
<vertex x="45.0179" y="21.604"/>
<vertex x="44.9925" y="21.604" curve="-90"/>
<vertex x="44.1289" y="22.4676"/>
<vertex x="44.1289" y="22.7724"/>
<vertex x="44.1543" y="22.9629"/>
<vertex x="44.2178" y="23.1534"/>
<vertex x="44.3702" y="23.3693"/>
<vertex x="44.421" y="23.3947"/>
<vertex x="44.675" y="23.3947" curve="90"/>
<vertex x="44.7766" y="23.4963"/>
<vertex x="44.2559" y="23.4963" curve="-90"/>
<vertex x="44.1289" y="23.6233"/>
<vertex x="44.1289" y="24.4742" curve="-90"/>
<vertex x="44.2559" y="24.6012"/>
<vertex x="45.7545" y="24.6012" curve="-90"/>
<vertex x="45.8815" y="24.4742"/>
<vertex x="45.8815" y="23.6233" curve="-90"/>
<vertex x="45.7545" y="23.4963"/>
<vertex x="45.2338" y="23.4963" curve="90"/>
<vertex x="45.3354" y="23.3947"/>
<vertex x="45.5894" y="23.3947"/>
<vertex x="45.6402" y="23.3693"/>
<vertex x="45.7926" y="23.1534"/>
<vertex x="45.8815" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="45.8815" y="22.4676" curve="-90"/>
<vertex x="45.0179" y="21.604"/>
<vertex x="44.9925" y="21.604" curve="-90"/>
<vertex x="44.1289" y="22.4676"/>
<vertex x="44.1289" y="22.7724"/>
<vertex x="44.1543" y="22.9629"/>
<vertex x="44.2178" y="23.1534"/>
<vertex x="44.3702" y="23.3693"/>
<vertex x="44.421" y="23.3947"/>
<vertex x="44.675" y="23.3947" curve="90"/>
<vertex x="44.7766" y="23.4963"/>
<vertex x="44.2559" y="23.4963" curve="-90"/>
<vertex x="44.1289" y="23.6233"/>
<vertex x="44.1289" y="24.4742" curve="-90"/>
<vertex x="44.2559" y="24.6012"/>
<vertex x="45.7545" y="24.6012" curve="-90"/>
<vertex x="45.8815" y="24.4742"/>
<vertex x="45.8815" y="23.6233" curve="-90"/>
<vertex x="45.7545" y="23.4963"/>
<vertex x="45.2338" y="23.4963" curve="90"/>
<vertex x="45.3354" y="23.3947"/>
<vertex x="45.5894" y="23.3947"/>
<vertex x="45.6402" y="23.3693"/>
<vertex x="45.7926" y="23.1534"/>
<vertex x="45.8815" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="43.3415" y="22.4676" curve="-90"/>
<vertex x="42.4779" y="21.604"/>
<vertex x="42.4525" y="21.604" curve="-90"/>
<vertex x="41.5889" y="22.4676"/>
<vertex x="41.5889" y="22.7724"/>
<vertex x="41.6143" y="22.9629"/>
<vertex x="41.6778" y="23.1534"/>
<vertex x="41.8302" y="23.3693"/>
<vertex x="41.881" y="23.3947"/>
<vertex x="42.135" y="23.3947" curve="90"/>
<vertex x="42.2366" y="23.4963"/>
<vertex x="41.7159" y="23.4963" curve="-90"/>
<vertex x="41.5889" y="23.6233"/>
<vertex x="41.5889" y="24.4742" curve="-90"/>
<vertex x="41.7159" y="24.6012"/>
<vertex x="43.2145" y="24.6012" curve="-90"/>
<vertex x="43.3415" y="24.4742"/>
<vertex x="43.3415" y="23.6233" curve="-90"/>
<vertex x="43.2145" y="23.4963"/>
<vertex x="42.6938" y="23.4963" curve="90"/>
<vertex x="42.7954" y="23.3947"/>
<vertex x="43.0494" y="23.3947"/>
<vertex x="43.1002" y="23.3693"/>
<vertex x="43.2526" y="23.1534"/>
<vertex x="43.3415" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="43.3415" y="22.4676" curve="-90"/>
<vertex x="42.4779" y="21.604"/>
<vertex x="42.4525" y="21.604" curve="-90"/>
<vertex x="41.5889" y="22.4676"/>
<vertex x="41.5889" y="22.7724"/>
<vertex x="41.6143" y="22.9629"/>
<vertex x="41.6778" y="23.1534"/>
<vertex x="41.8302" y="23.3693"/>
<vertex x="41.881" y="23.3947"/>
<vertex x="42.135" y="23.3947" curve="90"/>
<vertex x="42.2366" y="23.4963"/>
<vertex x="41.7159" y="23.4963" curve="-90"/>
<vertex x="41.5889" y="23.6233"/>
<vertex x="41.5889" y="24.4742" curve="-90"/>
<vertex x="41.7159" y="24.6012"/>
<vertex x="43.2145" y="24.6012" curve="-90"/>
<vertex x="43.3415" y="24.4742"/>
<vertex x="43.3415" y="23.6233" curve="-90"/>
<vertex x="43.2145" y="23.4963"/>
<vertex x="42.6938" y="23.4963" curve="90"/>
<vertex x="42.7954" y="23.3947"/>
<vertex x="43.0494" y="23.3947"/>
<vertex x="43.1002" y="23.3693"/>
<vertex x="43.2526" y="23.1534"/>
<vertex x="43.3415" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="40.8015" y="22.4676" curve="-90"/>
<vertex x="39.9379" y="21.604"/>
<vertex x="39.9125" y="21.604" curve="-90"/>
<vertex x="39.0489" y="22.4676"/>
<vertex x="39.0489" y="22.7724"/>
<vertex x="39.0743" y="22.9629"/>
<vertex x="39.1378" y="23.1534"/>
<vertex x="39.2902" y="23.3693"/>
<vertex x="39.341" y="23.3947"/>
<vertex x="39.595" y="23.3947" curve="90"/>
<vertex x="39.6966" y="23.4963"/>
<vertex x="39.1759" y="23.4963" curve="-90"/>
<vertex x="39.0489" y="23.6233"/>
<vertex x="39.0489" y="24.4742" curve="-90"/>
<vertex x="39.1759" y="24.6012"/>
<vertex x="40.6745" y="24.6012" curve="-90"/>
<vertex x="40.8015" y="24.4742"/>
<vertex x="40.8015" y="23.6233" curve="-90"/>
<vertex x="40.6745" y="23.4963"/>
<vertex x="40.1538" y="23.4963" curve="90"/>
<vertex x="40.2554" y="23.3947"/>
<vertex x="40.5094" y="23.3947"/>
<vertex x="40.5602" y="23.3693"/>
<vertex x="40.7126" y="23.1534"/>
<vertex x="40.8015" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="40.8015" y="22.4676" curve="-90"/>
<vertex x="39.9379" y="21.604"/>
<vertex x="39.9125" y="21.604" curve="-90"/>
<vertex x="39.0489" y="22.4676"/>
<vertex x="39.0489" y="22.7724"/>
<vertex x="39.0743" y="22.9629"/>
<vertex x="39.1378" y="23.1534"/>
<vertex x="39.2902" y="23.3693"/>
<vertex x="39.341" y="23.3947"/>
<vertex x="39.595" y="23.3947" curve="90"/>
<vertex x="39.6966" y="23.4963"/>
<vertex x="39.1759" y="23.4963" curve="-90"/>
<vertex x="39.0489" y="23.6233"/>
<vertex x="39.0489" y="24.4742" curve="-90"/>
<vertex x="39.1759" y="24.6012"/>
<vertex x="40.6745" y="24.6012" curve="-90"/>
<vertex x="40.8015" y="24.4742"/>
<vertex x="40.8015" y="23.6233" curve="-90"/>
<vertex x="40.6745" y="23.4963"/>
<vertex x="40.1538" y="23.4963" curve="90"/>
<vertex x="40.2554" y="23.3947"/>
<vertex x="40.5094" y="23.3947"/>
<vertex x="40.5602" y="23.3693"/>
<vertex x="40.7126" y="23.1534"/>
<vertex x="40.8015" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="38.2615" y="22.4676" curve="-90"/>
<vertex x="37.3979" y="21.604"/>
<vertex x="37.3725" y="21.604" curve="-90"/>
<vertex x="36.5089" y="22.4676"/>
<vertex x="36.5089" y="22.7724"/>
<vertex x="36.5343" y="22.9629"/>
<vertex x="36.5978" y="23.1534"/>
<vertex x="36.7502" y="23.3693"/>
<vertex x="36.801" y="23.3947"/>
<vertex x="37.055" y="23.3947" curve="90"/>
<vertex x="37.1566" y="23.4963"/>
<vertex x="36.6359" y="23.4963" curve="-90"/>
<vertex x="36.5089" y="23.6233"/>
<vertex x="36.5089" y="24.4742" curve="-90"/>
<vertex x="36.6359" y="24.6012"/>
<vertex x="38.1345" y="24.6012" curve="-90"/>
<vertex x="38.2615" y="24.4742"/>
<vertex x="38.2615" y="23.6233" curve="-90"/>
<vertex x="38.1345" y="23.4963"/>
<vertex x="37.6138" y="23.4963" curve="90"/>
<vertex x="37.7154" y="23.3947"/>
<vertex x="37.9694" y="23.3947"/>
<vertex x="38.0202" y="23.3693"/>
<vertex x="38.1726" y="23.1534"/>
<vertex x="38.2615" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="38.2615" y="22.4676" curve="-90"/>
<vertex x="37.3979" y="21.604"/>
<vertex x="37.3725" y="21.604" curve="-90"/>
<vertex x="36.5089" y="22.4676"/>
<vertex x="36.5089" y="22.7724"/>
<vertex x="36.5343" y="22.9629"/>
<vertex x="36.5978" y="23.1534"/>
<vertex x="36.7502" y="23.3693"/>
<vertex x="36.801" y="23.3947"/>
<vertex x="37.055" y="23.3947" curve="90"/>
<vertex x="37.1566" y="23.4963"/>
<vertex x="36.6359" y="23.4963" curve="-90"/>
<vertex x="36.5089" y="23.6233"/>
<vertex x="36.5089" y="24.4742" curve="-90"/>
<vertex x="36.6359" y="24.6012"/>
<vertex x="38.1345" y="24.6012" curve="-90"/>
<vertex x="38.2615" y="24.4742"/>
<vertex x="38.2615" y="23.6233" curve="-90"/>
<vertex x="38.1345" y="23.4963"/>
<vertex x="37.6138" y="23.4963" curve="90"/>
<vertex x="37.7154" y="23.3947"/>
<vertex x="37.9694" y="23.3947"/>
<vertex x="38.0202" y="23.3693"/>
<vertex x="38.1726" y="23.1534"/>
<vertex x="38.2615" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="35.7215" y="22.4676" curve="-90"/>
<vertex x="34.8579" y="21.604"/>
<vertex x="34.8325" y="21.604" curve="-90"/>
<vertex x="33.9689" y="22.4676"/>
<vertex x="33.9689" y="22.7724"/>
<vertex x="33.9943" y="22.9629"/>
<vertex x="34.0578" y="23.1534"/>
<vertex x="34.2102" y="23.3693"/>
<vertex x="34.261" y="23.3947"/>
<vertex x="34.515" y="23.3947" curve="90"/>
<vertex x="34.6166" y="23.4963"/>
<vertex x="34.0959" y="23.4963" curve="-90"/>
<vertex x="33.9689" y="23.6233"/>
<vertex x="33.9689" y="24.4742" curve="-90"/>
<vertex x="34.0959" y="24.6012"/>
<vertex x="35.5945" y="24.6012" curve="-90"/>
<vertex x="35.7215" y="24.4742"/>
<vertex x="35.7215" y="23.6233" curve="-90"/>
<vertex x="35.5945" y="23.4963"/>
<vertex x="35.0738" y="23.4963" curve="90"/>
<vertex x="35.1754" y="23.3947"/>
<vertex x="35.4294" y="23.3947"/>
<vertex x="35.4802" y="23.3693"/>
<vertex x="35.6326" y="23.1534"/>
<vertex x="35.7215" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="35.7215" y="22.4676" curve="-90"/>
<vertex x="34.8579" y="21.604"/>
<vertex x="34.8325" y="21.604" curve="-90"/>
<vertex x="33.9689" y="22.4676"/>
<vertex x="33.9689" y="22.7724"/>
<vertex x="33.9943" y="22.9629"/>
<vertex x="34.0578" y="23.1534"/>
<vertex x="34.2102" y="23.3693"/>
<vertex x="34.261" y="23.3947"/>
<vertex x="34.515" y="23.3947" curve="90"/>
<vertex x="34.6166" y="23.4963"/>
<vertex x="34.0959" y="23.4963" curve="-90"/>
<vertex x="33.9689" y="23.6233"/>
<vertex x="33.9689" y="24.4742" curve="-90"/>
<vertex x="34.0959" y="24.6012"/>
<vertex x="35.5945" y="24.6012" curve="-90"/>
<vertex x="35.7215" y="24.4742"/>
<vertex x="35.7215" y="23.6233" curve="-90"/>
<vertex x="35.5945" y="23.4963"/>
<vertex x="35.0738" y="23.4963" curve="90"/>
<vertex x="35.1754" y="23.3947"/>
<vertex x="35.4294" y="23.3947"/>
<vertex x="35.4802" y="23.3693"/>
<vertex x="35.6326" y="23.1534"/>
<vertex x="35.7215" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="33.1815" y="22.4676" curve="-90"/>
<vertex x="32.3179" y="21.604"/>
<vertex x="32.2925" y="21.604" curve="-90"/>
<vertex x="31.4289" y="22.4676"/>
<vertex x="31.4289" y="22.7724"/>
<vertex x="31.4543" y="22.9629"/>
<vertex x="31.5178" y="23.1534"/>
<vertex x="31.6702" y="23.3693"/>
<vertex x="31.721" y="23.3947"/>
<vertex x="31.975" y="23.3947" curve="90"/>
<vertex x="32.0766" y="23.4963"/>
<vertex x="31.5559" y="23.4963" curve="-90"/>
<vertex x="31.4289" y="23.6233"/>
<vertex x="31.4289" y="24.4742" curve="-90"/>
<vertex x="31.5559" y="24.6012"/>
<vertex x="33.0545" y="24.6012" curve="-90"/>
<vertex x="33.1815" y="24.4742"/>
<vertex x="33.1815" y="23.6233" curve="-90"/>
<vertex x="33.0545" y="23.4963"/>
<vertex x="32.5338" y="23.4963" curve="90"/>
<vertex x="32.6354" y="23.3947"/>
<vertex x="32.8894" y="23.3947"/>
<vertex x="32.9402" y="23.3693"/>
<vertex x="33.0926" y="23.1534"/>
<vertex x="33.1815" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="33.1815" y="22.4676" curve="-90"/>
<vertex x="32.3179" y="21.604"/>
<vertex x="32.2925" y="21.604" curve="-90"/>
<vertex x="31.4289" y="22.4676"/>
<vertex x="31.4289" y="22.7724"/>
<vertex x="31.4543" y="22.9629"/>
<vertex x="31.5178" y="23.1534"/>
<vertex x="31.6702" y="23.3693"/>
<vertex x="31.721" y="23.3947"/>
<vertex x="31.975" y="23.3947" curve="90"/>
<vertex x="32.0766" y="23.4963"/>
<vertex x="31.5559" y="23.4963" curve="-90"/>
<vertex x="31.4289" y="23.6233"/>
<vertex x="31.4289" y="24.4742" curve="-90"/>
<vertex x="31.5559" y="24.6012"/>
<vertex x="33.0545" y="24.6012" curve="-90"/>
<vertex x="33.1815" y="24.4742"/>
<vertex x="33.1815" y="23.6233" curve="-90"/>
<vertex x="33.0545" y="23.4963"/>
<vertex x="32.5338" y="23.4963" curve="90"/>
<vertex x="32.6354" y="23.3947"/>
<vertex x="32.8894" y="23.3947"/>
<vertex x="32.9402" y="23.3693"/>
<vertex x="33.0926" y="23.1534"/>
<vertex x="33.1815" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="30.6415" y="22.4676" curve="-90"/>
<vertex x="29.7779" y="21.604"/>
<vertex x="29.7525" y="21.604" curve="-90"/>
<vertex x="28.8889" y="22.4676"/>
<vertex x="28.8889" y="22.7724"/>
<vertex x="28.9143" y="22.9629"/>
<vertex x="28.9778" y="23.1534"/>
<vertex x="29.1302" y="23.3693"/>
<vertex x="29.181" y="23.3947"/>
<vertex x="29.435" y="23.3947" curve="90"/>
<vertex x="29.5366" y="23.4963"/>
<vertex x="29.0159" y="23.4963" curve="-90"/>
<vertex x="28.8889" y="23.6233"/>
<vertex x="28.8889" y="24.4742" curve="-90"/>
<vertex x="29.0159" y="24.6012"/>
<vertex x="30.5145" y="24.6012" curve="-90"/>
<vertex x="30.6415" y="24.4742"/>
<vertex x="30.6415" y="23.6233" curve="-90"/>
<vertex x="30.5145" y="23.4963"/>
<vertex x="29.9938" y="23.4963" curve="90"/>
<vertex x="30.0954" y="23.3947"/>
<vertex x="30.3494" y="23.3947"/>
<vertex x="30.4002" y="23.3693"/>
<vertex x="30.5526" y="23.1534"/>
<vertex x="30.6415" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="30.6415" y="22.4676" curve="-90"/>
<vertex x="29.7779" y="21.604"/>
<vertex x="29.7525" y="21.604" curve="-90"/>
<vertex x="28.8889" y="22.4676"/>
<vertex x="28.8889" y="22.7724"/>
<vertex x="28.9143" y="22.9629"/>
<vertex x="28.9778" y="23.1534"/>
<vertex x="29.1302" y="23.3693"/>
<vertex x="29.181" y="23.3947"/>
<vertex x="29.435" y="23.3947" curve="90"/>
<vertex x="29.5366" y="23.4963"/>
<vertex x="29.0159" y="23.4963" curve="-90"/>
<vertex x="28.8889" y="23.6233"/>
<vertex x="28.8889" y="24.4742" curve="-90"/>
<vertex x="29.0159" y="24.6012"/>
<vertex x="30.5145" y="24.6012" curve="-90"/>
<vertex x="30.6415" y="24.4742"/>
<vertex x="30.6415" y="23.6233" curve="-90"/>
<vertex x="30.5145" y="23.4963"/>
<vertex x="29.9938" y="23.4963" curve="90"/>
<vertex x="30.0954" y="23.3947"/>
<vertex x="30.3494" y="23.3947"/>
<vertex x="30.4002" y="23.3693"/>
<vertex x="30.5526" y="23.1534"/>
<vertex x="30.6415" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="28.1015" y="22.4676" curve="-90"/>
<vertex x="27.2379" y="21.604"/>
<vertex x="27.2125" y="21.604" curve="-90"/>
<vertex x="26.3489" y="22.4676"/>
<vertex x="26.3489" y="22.7724"/>
<vertex x="26.3743" y="22.9629"/>
<vertex x="26.4378" y="23.1534"/>
<vertex x="26.5902" y="23.3693"/>
<vertex x="26.641" y="23.3947"/>
<vertex x="26.895" y="23.3947" curve="90"/>
<vertex x="26.9966" y="23.4963"/>
<vertex x="26.4759" y="23.4963" curve="-90"/>
<vertex x="26.3489" y="23.6233"/>
<vertex x="26.3489" y="24.4742" curve="-90"/>
<vertex x="26.4759" y="24.6012"/>
<vertex x="27.9745" y="24.6012" curve="-90"/>
<vertex x="28.1015" y="24.4742"/>
<vertex x="28.1015" y="23.6233" curve="-90"/>
<vertex x="27.9745" y="23.4963"/>
<vertex x="27.4538" y="23.4963" curve="90"/>
<vertex x="27.5554" y="23.3947"/>
<vertex x="27.8094" y="23.3947"/>
<vertex x="27.8602" y="23.3693"/>
<vertex x="28.0126" y="23.1534"/>
<vertex x="28.1015" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="28.1015" y="22.4676" curve="-90"/>
<vertex x="27.2379" y="21.604"/>
<vertex x="27.2125" y="21.604" curve="-90"/>
<vertex x="26.3489" y="22.4676"/>
<vertex x="26.3489" y="22.7724"/>
<vertex x="26.3743" y="22.9629"/>
<vertex x="26.4378" y="23.1534"/>
<vertex x="26.5902" y="23.3693"/>
<vertex x="26.641" y="23.3947"/>
<vertex x="26.895" y="23.3947" curve="90"/>
<vertex x="26.9966" y="23.4963"/>
<vertex x="26.4759" y="23.4963" curve="-90"/>
<vertex x="26.3489" y="23.6233"/>
<vertex x="26.3489" y="24.4742" curve="-90"/>
<vertex x="26.4759" y="24.6012"/>
<vertex x="27.9745" y="24.6012" curve="-90"/>
<vertex x="28.1015" y="24.4742"/>
<vertex x="28.1015" y="23.6233" curve="-90"/>
<vertex x="27.9745" y="23.4963"/>
<vertex x="27.4538" y="23.4963" curve="90"/>
<vertex x="27.5554" y="23.3947"/>
<vertex x="27.8094" y="23.3947"/>
<vertex x="27.8602" y="23.3693"/>
<vertex x="28.0126" y="23.1534"/>
<vertex x="28.1015" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="25.5615" y="22.4676" curve="-90"/>
<vertex x="24.6979" y="21.604"/>
<vertex x="24.6725" y="21.604" curve="-90"/>
<vertex x="23.8089" y="22.4676"/>
<vertex x="23.8089" y="22.7724"/>
<vertex x="23.8343" y="22.9629"/>
<vertex x="23.8978" y="23.1534"/>
<vertex x="24.0502" y="23.3693"/>
<vertex x="24.101" y="23.3947"/>
<vertex x="24.355" y="23.3947" curve="90"/>
<vertex x="24.4566" y="23.4963"/>
<vertex x="23.9359" y="23.4963" curve="-90"/>
<vertex x="23.8089" y="23.6233"/>
<vertex x="23.8089" y="24.4742" curve="-90"/>
<vertex x="23.9359" y="24.6012"/>
<vertex x="25.4345" y="24.6012" curve="-90"/>
<vertex x="25.5615" y="24.4742"/>
<vertex x="25.5615" y="23.6233" curve="-90"/>
<vertex x="25.4345" y="23.4963"/>
<vertex x="24.9138" y="23.4963" curve="90"/>
<vertex x="25.0154" y="23.3947"/>
<vertex x="25.2694" y="23.3947"/>
<vertex x="25.3202" y="23.3693"/>
<vertex x="25.4726" y="23.1534"/>
<vertex x="25.5615" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="25.5615" y="22.4676" curve="-90"/>
<vertex x="24.6979" y="21.604"/>
<vertex x="24.6725" y="21.604" curve="-90"/>
<vertex x="23.8089" y="22.4676"/>
<vertex x="23.8089" y="22.7724"/>
<vertex x="23.8343" y="22.9629"/>
<vertex x="23.8978" y="23.1534"/>
<vertex x="24.0502" y="23.3693"/>
<vertex x="24.101" y="23.3947"/>
<vertex x="24.355" y="23.3947" curve="90"/>
<vertex x="24.4566" y="23.4963"/>
<vertex x="23.9359" y="23.4963" curve="-90"/>
<vertex x="23.8089" y="23.6233"/>
<vertex x="23.8089" y="24.4742" curve="-90"/>
<vertex x="23.9359" y="24.6012"/>
<vertex x="25.4345" y="24.6012" curve="-90"/>
<vertex x="25.5615" y="24.4742"/>
<vertex x="25.5615" y="23.6233" curve="-90"/>
<vertex x="25.4345" y="23.4963"/>
<vertex x="24.9138" y="23.4963" curve="90"/>
<vertex x="25.0154" y="23.3947"/>
<vertex x="25.2694" y="23.3947"/>
<vertex x="25.3202" y="23.3693"/>
<vertex x="25.4726" y="23.1534"/>
<vertex x="25.5615" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="23.0215" y="22.4676" curve="-90"/>
<vertex x="22.1579" y="21.604"/>
<vertex x="22.1325" y="21.604" curve="-90"/>
<vertex x="21.2689" y="22.4676"/>
<vertex x="21.2689" y="22.7724"/>
<vertex x="21.2943" y="22.9629"/>
<vertex x="21.3578" y="23.1534"/>
<vertex x="21.5102" y="23.3693"/>
<vertex x="21.561" y="23.3947"/>
<vertex x="21.815" y="23.3947" curve="90"/>
<vertex x="21.9166" y="23.4963"/>
<vertex x="21.3959" y="23.4963" curve="-90"/>
<vertex x="21.2689" y="23.6233"/>
<vertex x="21.2689" y="24.4742" curve="-90"/>
<vertex x="21.3959" y="24.6012"/>
<vertex x="22.8945" y="24.6012" curve="-90"/>
<vertex x="23.0215" y="24.4742"/>
<vertex x="23.0215" y="23.6233" curve="-90"/>
<vertex x="22.8945" y="23.4963"/>
<vertex x="22.3738" y="23.4963" curve="90"/>
<vertex x="22.4754" y="23.3947"/>
<vertex x="22.7294" y="23.3947"/>
<vertex x="22.7802" y="23.3693"/>
<vertex x="22.9326" y="23.1534"/>
<vertex x="23.0215" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="23.0215" y="22.4676" curve="-90"/>
<vertex x="22.1579" y="21.604"/>
<vertex x="22.1325" y="21.604" curve="-90"/>
<vertex x="21.2689" y="22.4676"/>
<vertex x="21.2689" y="22.7724"/>
<vertex x="21.2943" y="22.9629"/>
<vertex x="21.3578" y="23.1534"/>
<vertex x="21.5102" y="23.3693"/>
<vertex x="21.561" y="23.3947"/>
<vertex x="21.815" y="23.3947" curve="90"/>
<vertex x="21.9166" y="23.4963"/>
<vertex x="21.3959" y="23.4963" curve="-90"/>
<vertex x="21.2689" y="23.6233"/>
<vertex x="21.2689" y="24.4742" curve="-90"/>
<vertex x="21.3959" y="24.6012"/>
<vertex x="22.8945" y="24.6012" curve="-90"/>
<vertex x="23.0215" y="24.4742"/>
<vertex x="23.0215" y="23.6233" curve="-90"/>
<vertex x="22.8945" y="23.4963"/>
<vertex x="22.3738" y="23.4963" curve="90"/>
<vertex x="22.4754" y="23.3947"/>
<vertex x="22.7294" y="23.3947"/>
<vertex x="22.7802" y="23.3693"/>
<vertex x="22.9326" y="23.1534"/>
<vertex x="23.0215" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="53.5015" y="22.7597"/>
<vertex x="53.5015" y="22.493" curve="-90"/>
<vertex x="52.6252" y="21.604" curve="-90"/>
<vertex x="51.7489" y="22.493"/>
<vertex x="51.7489" y="22.7597" curve="-90"/>
<vertex x="52.6252" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="50.9615" y="22.7597"/>
<vertex x="50.9615" y="22.493" curve="-90"/>
<vertex x="50.0852" y="21.604" curve="-90"/>
<vertex x="49.2089" y="22.493"/>
<vertex x="49.2089" y="22.7597" curve="-90"/>
<vertex x="50.0852" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="48.4215" y="22.7597"/>
<vertex x="48.4215" y="22.493" curve="-90"/>
<vertex x="47.5452" y="21.604" curve="-90"/>
<vertex x="46.6689" y="22.493"/>
<vertex x="46.6689" y="22.7597" curve="-90"/>
<vertex x="47.5452" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="45.8815" y="22.7597"/>
<vertex x="45.8815" y="22.493" curve="-90"/>
<vertex x="45.0052" y="21.604" curve="-90"/>
<vertex x="44.1289" y="22.493"/>
<vertex x="44.1289" y="22.7597" curve="-90"/>
<vertex x="45.0052" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="43.3415" y="22.7597"/>
<vertex x="43.3415" y="22.493" curve="-90"/>
<vertex x="42.4652" y="21.604" curve="-90"/>
<vertex x="41.5889" y="22.493"/>
<vertex x="41.5889" y="22.7597" curve="-90"/>
<vertex x="42.4652" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="40.8015" y="22.7597"/>
<vertex x="40.8015" y="22.493" curve="-90"/>
<vertex x="39.9252" y="21.604" curve="-90"/>
<vertex x="39.0489" y="22.493"/>
<vertex x="39.0489" y="22.7597" curve="-90"/>
<vertex x="39.9252" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="38.2615" y="22.7597"/>
<vertex x="38.2615" y="22.493" curve="-90"/>
<vertex x="37.3852" y="21.604" curve="-90"/>
<vertex x="36.5089" y="22.493"/>
<vertex x="36.5089" y="22.7597" curve="-90"/>
<vertex x="37.3852" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="35.7215" y="22.7597"/>
<vertex x="35.7215" y="22.493" curve="-90"/>
<vertex x="34.8452" y="21.604" curve="-90"/>
<vertex x="33.9689" y="22.493"/>
<vertex x="33.9689" y="22.7597" curve="-90"/>
<vertex x="34.8452" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="33.1815" y="22.7597"/>
<vertex x="33.1815" y="22.493" curve="-90"/>
<vertex x="32.3052" y="21.604" curve="-90"/>
<vertex x="31.4289" y="22.493"/>
<vertex x="31.4289" y="22.7597" curve="-90"/>
<vertex x="32.3052" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="30.6415" y="22.7597"/>
<vertex x="30.6415" y="22.493" curve="-90"/>
<vertex x="29.7652" y="21.604" curve="-90"/>
<vertex x="28.8889" y="22.493"/>
<vertex x="28.8889" y="22.7597" curve="-90"/>
<vertex x="29.7652" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="28.1015" y="22.7597"/>
<vertex x="28.1015" y="22.493" curve="-90"/>
<vertex x="27.2252" y="21.604" curve="-90"/>
<vertex x="26.3489" y="22.493"/>
<vertex x="26.3489" y="22.7597" curve="-90"/>
<vertex x="27.2252" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="25.5615" y="22.7597"/>
<vertex x="25.5615" y="22.493" curve="-90"/>
<vertex x="24.6852" y="21.604" curve="-90"/>
<vertex x="23.8089" y="22.493"/>
<vertex x="23.8089" y="22.7597" curve="-90"/>
<vertex x="24.6852" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="23.0215" y="22.7597"/>
<vertex x="23.0215" y="22.493" curve="-90"/>
<vertex x="22.1452" y="21.604" curve="-90"/>
<vertex x="21.2689" y="22.493"/>
<vertex x="21.2689" y="22.7597" curve="-90"/>
<vertex x="22.1452" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="52.6252" y="21.731" curve="90"/>
<vertex x="53.3745" y="22.4803"/>
<vertex x="53.3745" y="22.7851"/>
<vertex x="53.3491" y="22.9375"/>
<vertex x="53.2983" y="23.1026"/>
<vertex x="53.184" y="23.2677"/>
<vertex x="52.9427" y="23.2677" curve="-90"/>
<vertex x="52.7268" y="23.4836"/>
<vertex x="52.7268" y="23.6106" curve="-90"/>
<vertex x="52.7395" y="23.6233"/>
<vertex x="53.3745" y="23.6233"/>
<vertex x="53.3745" y="24.4742"/>
<vertex x="51.8759" y="24.4742"/>
<vertex x="51.8759" y="23.6233"/>
<vertex x="52.5236" y="23.6233"/>
<vertex x="52.5236" y="23.4836" curve="-90"/>
<vertex x="52.3077" y="23.2677"/>
<vertex x="52.0664" y="23.2677"/>
<vertex x="51.9521" y="23.1026"/>
<vertex x="51.9013" y="22.9375"/>
<vertex x="51.8759" y="22.7851"/>
<vertex x="51.8759" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="22.1452" y="21.731" curve="90"/>
<vertex x="22.8945" y="22.4803"/>
<vertex x="22.8945" y="22.7851"/>
<vertex x="22.8691" y="22.9375"/>
<vertex x="22.8183" y="23.1026"/>
<vertex x="22.704" y="23.2677"/>
<vertex x="22.4627" y="23.2677" curve="-90"/>
<vertex x="22.2468" y="23.4836"/>
<vertex x="22.2468" y="23.6106" curve="-90"/>
<vertex x="22.2595" y="23.6233"/>
<vertex x="22.8945" y="23.6233"/>
<vertex x="22.8945" y="24.4742"/>
<vertex x="21.3959" y="24.4742"/>
<vertex x="21.3959" y="23.6233"/>
<vertex x="22.0436" y="23.6233"/>
<vertex x="22.0436" y="23.4836" curve="-90"/>
<vertex x="21.8277" y="23.2677"/>
<vertex x="21.5864" y="23.2677"/>
<vertex x="21.4721" y="23.1026"/>
<vertex x="21.4213" y="22.9375"/>
<vertex x="21.3959" y="22.7851"/>
<vertex x="21.3959" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="50.0852" y="21.731" curve="90"/>
<vertex x="50.8345" y="22.4803"/>
<vertex x="50.8345" y="22.7851"/>
<vertex x="50.8091" y="22.9375"/>
<vertex x="50.7583" y="23.1026"/>
<vertex x="50.644" y="23.2677"/>
<vertex x="50.4027" y="23.2677" curve="-90"/>
<vertex x="50.1868" y="23.4836"/>
<vertex x="50.1868" y="23.6106" curve="-90"/>
<vertex x="50.1995" y="23.6233"/>
<vertex x="50.8345" y="23.6233"/>
<vertex x="50.8345" y="24.4742"/>
<vertex x="49.3359" y="24.4742"/>
<vertex x="49.3359" y="23.6233"/>
<vertex x="49.9836" y="23.6233"/>
<vertex x="49.9836" y="23.4836" curve="-90"/>
<vertex x="49.7677" y="23.2677"/>
<vertex x="49.5264" y="23.2677"/>
<vertex x="49.4121" y="23.1026"/>
<vertex x="49.3613" y="22.9375"/>
<vertex x="49.3359" y="22.7851"/>
<vertex x="49.3359" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="47.5452" y="21.731" curve="90"/>
<vertex x="48.2945" y="22.4803"/>
<vertex x="48.2945" y="22.7851"/>
<vertex x="48.2691" y="22.9375"/>
<vertex x="48.2183" y="23.1026"/>
<vertex x="48.104" y="23.2677"/>
<vertex x="47.8627" y="23.2677" curve="-90"/>
<vertex x="47.6468" y="23.4836"/>
<vertex x="47.6468" y="23.6106" curve="-90"/>
<vertex x="47.6595" y="23.6233"/>
<vertex x="48.2945" y="23.6233"/>
<vertex x="48.2945" y="24.4742"/>
<vertex x="46.7959" y="24.4742"/>
<vertex x="46.7959" y="23.6233"/>
<vertex x="47.4436" y="23.6233"/>
<vertex x="47.4436" y="23.4836" curve="-90"/>
<vertex x="47.2277" y="23.2677"/>
<vertex x="46.9864" y="23.2677"/>
<vertex x="46.8721" y="23.1026"/>
<vertex x="46.8213" y="22.9375"/>
<vertex x="46.7959" y="22.7851"/>
<vertex x="46.7959" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="45.0052" y="21.731" curve="90"/>
<vertex x="45.7545" y="22.4803"/>
<vertex x="45.7545" y="22.7851"/>
<vertex x="45.7291" y="22.9375"/>
<vertex x="45.6783" y="23.1026"/>
<vertex x="45.564" y="23.2677"/>
<vertex x="45.3227" y="23.2677" curve="-90"/>
<vertex x="45.1068" y="23.4836"/>
<vertex x="45.1068" y="23.6106" curve="-90"/>
<vertex x="45.1195" y="23.6233"/>
<vertex x="45.7545" y="23.6233"/>
<vertex x="45.7545" y="24.4742"/>
<vertex x="44.2559" y="24.4742"/>
<vertex x="44.2559" y="23.6233"/>
<vertex x="44.9036" y="23.6233"/>
<vertex x="44.9036" y="23.4836" curve="-90"/>
<vertex x="44.6877" y="23.2677"/>
<vertex x="44.4464" y="23.2677"/>
<vertex x="44.3321" y="23.1026"/>
<vertex x="44.2813" y="22.9375"/>
<vertex x="44.2559" y="22.7851"/>
<vertex x="44.2559" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="42.4652" y="21.731" curve="90"/>
<vertex x="43.2145" y="22.4803"/>
<vertex x="43.2145" y="22.7851"/>
<vertex x="43.1891" y="22.9375"/>
<vertex x="43.1383" y="23.1026"/>
<vertex x="43.024" y="23.2677"/>
<vertex x="42.7827" y="23.2677" curve="-90"/>
<vertex x="42.5668" y="23.4836"/>
<vertex x="42.5668" y="23.6106" curve="-90"/>
<vertex x="42.5795" y="23.6233"/>
<vertex x="43.2145" y="23.6233"/>
<vertex x="43.2145" y="24.4742"/>
<vertex x="41.7159" y="24.4742"/>
<vertex x="41.7159" y="23.6233"/>
<vertex x="42.3636" y="23.6233"/>
<vertex x="42.3636" y="23.4836" curve="-90"/>
<vertex x="42.1477" y="23.2677"/>
<vertex x="41.9064" y="23.2677"/>
<vertex x="41.7921" y="23.1026"/>
<vertex x="41.7413" y="22.9375"/>
<vertex x="41.7159" y="22.7851"/>
<vertex x="41.7159" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="39.9252" y="21.731" curve="90"/>
<vertex x="40.6745" y="22.4803"/>
<vertex x="40.6745" y="22.7851"/>
<vertex x="40.6491" y="22.9375"/>
<vertex x="40.5983" y="23.1026"/>
<vertex x="40.484" y="23.2677"/>
<vertex x="40.2427" y="23.2677" curve="-90"/>
<vertex x="40.0268" y="23.4836"/>
<vertex x="40.0268" y="23.6106" curve="-90"/>
<vertex x="40.0395" y="23.6233"/>
<vertex x="40.6745" y="23.6233"/>
<vertex x="40.6745" y="24.4742"/>
<vertex x="39.1759" y="24.4742"/>
<vertex x="39.1759" y="23.6233"/>
<vertex x="39.8236" y="23.6233"/>
<vertex x="39.8236" y="23.4836" curve="-90"/>
<vertex x="39.6077" y="23.2677"/>
<vertex x="39.3664" y="23.2677"/>
<vertex x="39.2521" y="23.1026"/>
<vertex x="39.2013" y="22.9375"/>
<vertex x="39.1759" y="22.7851"/>
<vertex x="39.1759" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="37.3852" y="21.731" curve="90"/>
<vertex x="38.1345" y="22.4803"/>
<vertex x="38.1345" y="22.7851"/>
<vertex x="38.1091" y="22.9375"/>
<vertex x="38.0583" y="23.1026"/>
<vertex x="37.944" y="23.2677"/>
<vertex x="37.7027" y="23.2677" curve="-90"/>
<vertex x="37.4868" y="23.4836"/>
<vertex x="37.4868" y="23.6106" curve="-90"/>
<vertex x="37.4995" y="23.6233"/>
<vertex x="38.1345" y="23.6233"/>
<vertex x="38.1345" y="24.4742"/>
<vertex x="36.6359" y="24.4742"/>
<vertex x="36.6359" y="23.6233"/>
<vertex x="37.2836" y="23.6233"/>
<vertex x="37.2836" y="23.4836" curve="-90"/>
<vertex x="37.0677" y="23.2677"/>
<vertex x="36.8264" y="23.2677"/>
<vertex x="36.7121" y="23.1026"/>
<vertex x="36.6613" y="22.9375"/>
<vertex x="36.6359" y="22.7851"/>
<vertex x="36.6359" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="34.8452" y="21.731" curve="90"/>
<vertex x="35.5945" y="22.4803"/>
<vertex x="35.5945" y="22.7851"/>
<vertex x="35.5691" y="22.9375"/>
<vertex x="35.5183" y="23.1026"/>
<vertex x="35.404" y="23.2677"/>
<vertex x="35.1627" y="23.2677" curve="-90"/>
<vertex x="34.9468" y="23.4836"/>
<vertex x="34.9468" y="23.6106" curve="-90"/>
<vertex x="34.9595" y="23.6233"/>
<vertex x="35.5945" y="23.6233"/>
<vertex x="35.5945" y="24.4742"/>
<vertex x="34.0959" y="24.4742"/>
<vertex x="34.0959" y="23.6233"/>
<vertex x="34.7436" y="23.6233"/>
<vertex x="34.7436" y="23.4836" curve="-90"/>
<vertex x="34.5277" y="23.2677"/>
<vertex x="34.2864" y="23.2677"/>
<vertex x="34.1721" y="23.1026"/>
<vertex x="34.1213" y="22.9375"/>
<vertex x="34.0959" y="22.7851"/>
<vertex x="34.0959" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="29.7652" y="21.731" curve="90"/>
<vertex x="30.5145" y="22.4803"/>
<vertex x="30.5145" y="22.7851"/>
<vertex x="30.4891" y="22.9375"/>
<vertex x="30.4383" y="23.1026"/>
<vertex x="30.324" y="23.2677"/>
<vertex x="30.0827" y="23.2677" curve="-90"/>
<vertex x="29.8668" y="23.4836"/>
<vertex x="29.8668" y="23.6106" curve="-90"/>
<vertex x="29.8795" y="23.6233"/>
<vertex x="30.5145" y="23.6233"/>
<vertex x="30.5145" y="24.4742"/>
<vertex x="29.0159" y="24.4742"/>
<vertex x="29.0159" y="23.6233"/>
<vertex x="29.6636" y="23.6233"/>
<vertex x="29.6636" y="23.4836" curve="-90"/>
<vertex x="29.4477" y="23.2677"/>
<vertex x="29.2064" y="23.2677"/>
<vertex x="29.0921" y="23.1026"/>
<vertex x="29.0413" y="22.9375"/>
<vertex x="29.0159" y="22.7851"/>
<vertex x="29.0159" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="27.2252" y="21.731" curve="90"/>
<vertex x="27.9745" y="22.4803"/>
<vertex x="27.9745" y="22.7851"/>
<vertex x="27.9491" y="22.9375"/>
<vertex x="27.8983" y="23.1026"/>
<vertex x="27.784" y="23.2677"/>
<vertex x="27.5427" y="23.2677" curve="-90"/>
<vertex x="27.3268" y="23.4836"/>
<vertex x="27.3268" y="23.6106" curve="-90"/>
<vertex x="27.3395" y="23.6233"/>
<vertex x="27.9745" y="23.6233"/>
<vertex x="27.9745" y="24.4742"/>
<vertex x="26.4759" y="24.4742"/>
<vertex x="26.4759" y="23.6233"/>
<vertex x="27.1236" y="23.6233"/>
<vertex x="27.1236" y="23.4836" curve="-90"/>
<vertex x="26.9077" y="23.2677"/>
<vertex x="26.6664" y="23.2677"/>
<vertex x="26.5521" y="23.1026"/>
<vertex x="26.5013" y="22.9375"/>
<vertex x="26.4759" y="22.7851"/>
<vertex x="26.4759" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="24.6852" y="21.731" curve="90"/>
<vertex x="25.4345" y="22.4803"/>
<vertex x="25.4345" y="22.7851"/>
<vertex x="25.4091" y="22.9375"/>
<vertex x="25.3583" y="23.1026"/>
<vertex x="25.244" y="23.2677"/>
<vertex x="25.0027" y="23.2677" curve="-90"/>
<vertex x="24.7868" y="23.4836"/>
<vertex x="24.7868" y="23.6106" curve="-90"/>
<vertex x="24.7995" y="23.6233"/>
<vertex x="25.4345" y="23.6233"/>
<vertex x="25.4345" y="24.4742"/>
<vertex x="23.9359" y="24.4742"/>
<vertex x="23.9359" y="23.6233"/>
<vertex x="24.5836" y="23.6233"/>
<vertex x="24.5836" y="23.4836" curve="-90"/>
<vertex x="24.3677" y="23.2677"/>
<vertex x="24.1264" y="23.2677"/>
<vertex x="24.0121" y="23.1026"/>
<vertex x="23.9613" y="22.9375"/>
<vertex x="23.9359" y="22.7851"/>
<vertex x="23.9359" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="32.3052" y="21.731" curve="90"/>
<vertex x="33.0545" y="22.4803"/>
<vertex x="33.0545" y="22.7851"/>
<vertex x="33.0291" y="22.9375"/>
<vertex x="32.9783" y="23.1026"/>
<vertex x="32.864" y="23.2677"/>
<vertex x="32.6227" y="23.2677" curve="-90"/>
<vertex x="32.4068" y="23.4836"/>
<vertex x="32.4068" y="23.6106" curve="-90"/>
<vertex x="32.4195" y="23.6233"/>
<vertex x="33.0545" y="23.6233"/>
<vertex x="33.0545" y="24.4742"/>
<vertex x="31.5559" y="24.4742"/>
<vertex x="31.5559" y="23.6233"/>
<vertex x="32.2036" y="23.6233"/>
<vertex x="32.2036" y="23.4836" curve="-90"/>
<vertex x="31.9877" y="23.2677"/>
<vertex x="31.7464" y="23.2677"/>
<vertex x="31.6321" y="23.1026"/>
<vertex x="31.5813" y="22.9375"/>
<vertex x="31.5559" y="22.7851"/>
<vertex x="31.5559" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="55.9145" y="21.7183"/>
<vertex x="55.9145" y="23.2677"/>
<vertex x="55.4827" y="23.2677" curve="-90"/>
<vertex x="55.2668" y="23.4836"/>
<vertex x="55.2668" y="23.6106" curve="-90"/>
<vertex x="55.2795" y="23.6233"/>
<vertex x="55.9145" y="23.6233"/>
<vertex x="55.9145" y="24.4742"/>
<vertex x="54.4159" y="24.4742"/>
<vertex x="54.4159" y="23.6233"/>
<vertex x="55.0636" y="23.6233"/>
<vertex x="55.0636" y="23.4836" curve="-90"/>
<vertex x="54.8477" y="23.2677"/>
<vertex x="54.4159" y="23.2677"/>
<vertex x="54.4159" y="21.7183"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="52.6252" y="21.731" curve="90"/>
<vertex x="53.3745" y="22.4803"/>
<vertex x="53.3745" y="22.8232" curve="90"/>
<vertex x="52.6252" y="23.5725" curve="90"/>
<vertex x="51.8759" y="22.8232"/>
<vertex x="51.8759" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="54.4159" y="21.731"/>
<vertex x="55.9145" y="21.731"/>
<vertex x="55.9145" y="23.5217"/>
<vertex x="54.4159" y="23.5217"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="50.0852" y="21.731" curve="90"/>
<vertex x="50.8345" y="22.4803"/>
<vertex x="50.8345" y="22.8232" curve="90"/>
<vertex x="50.0852" y="23.5725" curve="90"/>
<vertex x="49.3359" y="22.8232"/>
<vertex x="49.3359" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="47.5452" y="21.731" curve="90"/>
<vertex x="48.2945" y="22.4803"/>
<vertex x="48.2945" y="22.8232" curve="90"/>
<vertex x="47.5452" y="23.5725" curve="90"/>
<vertex x="46.7959" y="22.8232"/>
<vertex x="46.7959" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="45.0052" y="21.731" curve="90"/>
<vertex x="45.7545" y="22.4803"/>
<vertex x="45.7545" y="22.8232" curve="90"/>
<vertex x="45.0052" y="23.5725" curve="90"/>
<vertex x="44.2559" y="22.8232"/>
<vertex x="44.2559" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="42.4652" y="21.731" curve="90"/>
<vertex x="43.2145" y="22.4803"/>
<vertex x="43.2145" y="22.8232" curve="90"/>
<vertex x="42.4652" y="23.5725" curve="90"/>
<vertex x="41.7159" y="22.8232"/>
<vertex x="41.7159" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="39.9252" y="21.731" curve="90"/>
<vertex x="40.6745" y="22.4803"/>
<vertex x="40.6745" y="22.8232" curve="90"/>
<vertex x="39.9252" y="23.5725" curve="90"/>
<vertex x="39.1759" y="22.8232"/>
<vertex x="39.1759" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="37.3852" y="21.731" curve="90"/>
<vertex x="38.1345" y="22.4803"/>
<vertex x="38.1345" y="22.8232" curve="90"/>
<vertex x="37.3852" y="23.5725" curve="90"/>
<vertex x="36.6359" y="22.8232"/>
<vertex x="36.6359" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="34.8452" y="21.731" curve="90"/>
<vertex x="35.5945" y="22.4803"/>
<vertex x="35.5945" y="22.8232" curve="90"/>
<vertex x="34.8452" y="23.5725" curve="90"/>
<vertex x="34.0959" y="22.8232"/>
<vertex x="34.0959" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="32.3052" y="21.731" curve="90"/>
<vertex x="33.0545" y="22.4803"/>
<vertex x="33.0545" y="22.8232" curve="90"/>
<vertex x="32.3052" y="23.5725" curve="90"/>
<vertex x="31.5559" y="22.8232"/>
<vertex x="31.5559" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="29.7652" y="21.731" curve="90"/>
<vertex x="30.5145" y="22.4803"/>
<vertex x="30.5145" y="22.8232" curve="90"/>
<vertex x="29.7652" y="23.5725" curve="90"/>
<vertex x="29.0159" y="22.8232"/>
<vertex x="29.0159" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="27.2252" y="21.731" curve="90"/>
<vertex x="27.9745" y="22.4803"/>
<vertex x="27.9745" y="22.8232" curve="90"/>
<vertex x="27.2252" y="23.5725" curve="90"/>
<vertex x="26.4759" y="22.8232"/>
<vertex x="26.4759" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="24.6852" y="21.731" curve="90"/>
<vertex x="25.4345" y="22.4803"/>
<vertex x="25.4345" y="22.8232" curve="90"/>
<vertex x="24.6852" y="23.5725" curve="90"/>
<vertex x="23.9359" y="22.8232"/>
<vertex x="23.9359" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="22.1452" y="21.731" curve="90"/>
<vertex x="22.8945" y="22.4803"/>
<vertex x="22.8945" y="22.8232" curve="90"/>
<vertex x="22.1452" y="23.5725" curve="90"/>
<vertex x="21.3959" y="22.8232"/>
<vertex x="21.3959" y="22.4803" curve="90"/>
</polygon>
<hole x="2.25" y="2.25" drill="2.25"/>
<hole x="2.25" y="22.75" drill="2.25"/>
<hole x="59.25" y="22.75" drill="2.25"/>
<hole x="59.25" y="2.25" drill="2.25"/>
<wire x1="2.25" y1="0" x2="59.25" y2="0" width="0.1" layer="21"/>
<wire x1="59.25" y1="0" x2="61.5" y2="2.25" width="0.1" layer="21" curve="90"/>
<wire x1="61.5" y1="2.25" x2="61.5" y2="22.75" width="0.1" layer="21"/>
<wire x1="61.5" y1="22.75" x2="59.25" y2="25" width="0.1" layer="21" curve="90"/>
<wire x1="59.25" y1="25" x2="2.25" y2="25" width="0.1" layer="21"/>
<wire x1="2.25" y1="25" x2="0" y2="22.75" width="0.1" layer="21" curve="90"/>
<wire x1="0" y1="22.75" x2="0" y2="2.25" width="0.1" layer="21"/>
<wire x1="0" y1="2.25" x2="2.25" y2="0" width="0.1" layer="21" curve="90"/>
</package>
<package name="MKRBOARD-SOLDER">
<wire x1="22.1348" y1="1.99" x2="22.1348" y2="2.69" width="0.05" layer="39"/>
<pad name="AREF" x="22.1348" y="2.34" drill="1" first="yes"/>
<pad name="DAC0/A0" x="24.6748" y="2.34" drill="1"/>
<pad name="A1" x="27.2148" y="2.34" drill="1"/>
<pad name="A2" x="29.7548" y="2.34" drill="1"/>
<pad name="A3" x="32.2948" y="2.34" drill="1"/>
<pad name="A4" x="34.8348" y="2.34" drill="1"/>
<pad name="A5" x="37.3748" y="2.34" drill="1"/>
<pad name="A6" x="39.9148" y="2.34" drill="1"/>
<pad name="0" x="42.4548" y="2.34" drill="1"/>
<pad name="1" x="44.9948" y="2.34" drill="1"/>
<pad name="2" x="47.5348" y="2.34" drill="1"/>
<pad name="3" x="50.0748" y="2.34" drill="1"/>
<pad name="4" x="52.6148" y="2.34" drill="1"/>
<pad name="5" x="55.1548" y="2.34" drill="1"/>
<polygon width="0.0254" layer="29">
<vertex x="21.2585" y="3.3687"/>
<vertex x="23.0111" y="3.3687"/>
<vertex x="23.0111" y="1.3113"/>
<vertex x="21.2585" y="1.3113"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="21.2585" y="3.3687"/>
<vertex x="21.2585" y="1.5653"/>
<vertex x="21.8046" y="1.5653" curve="-90"/>
<vertex x="21.9062" y="1.4637"/>
<vertex x="21.3855" y="1.4637" curve="90"/>
<vertex x="21.2585" y="1.3367"/>
<vertex x="21.2585" y="0.4858" curve="90"/>
<vertex x="21.3855" y="0.3588"/>
<vertex x="22.8841" y="0.3588" curve="90"/>
<vertex x="23.0111" y="0.4858"/>
<vertex x="23.0111" y="1.3367" curve="90"/>
<vertex x="22.8841" y="1.4637"/>
<vertex x="22.3634" y="1.4637" curve="-90"/>
<vertex x="22.465" y="1.5653"/>
<vertex x="23.0111" y="1.5653"/>
<vertex x="23.0111" y="3.3687"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="23.7985" y="2.4924" curve="-90"/>
<vertex x="24.6621" y="3.356"/>
<vertex x="24.6875" y="3.356" curve="-90"/>
<vertex x="25.5511" y="2.4924"/>
<vertex x="25.5511" y="2.1876"/>
<vertex x="25.5257" y="1.9971"/>
<vertex x="25.4622" y="1.8066"/>
<vertex x="25.3098" y="1.5907"/>
<vertex x="25.259" y="1.5653"/>
<vertex x="25.005" y="1.5653" curve="90"/>
<vertex x="24.9034" y="1.4637"/>
<vertex x="25.4241" y="1.4637" curve="-90"/>
<vertex x="25.5511" y="1.3367"/>
<vertex x="25.5511" y="0.4858" curve="-90"/>
<vertex x="25.4241" y="0.3588"/>
<vertex x="23.9255" y="0.3588" curve="-90"/>
<vertex x="23.7985" y="0.4858"/>
<vertex x="23.7985" y="1.3367" curve="-90"/>
<vertex x="23.9255" y="1.4637"/>
<vertex x="24.4462" y="1.4637" curve="90"/>
<vertex x="24.3446" y="1.5653"/>
<vertex x="24.0906" y="1.5653"/>
<vertex x="24.0398" y="1.5907"/>
<vertex x="23.8874" y="1.8066"/>
<vertex x="23.7985" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="23.7985" y="2.4924" curve="-90"/>
<vertex x="24.6621" y="3.356"/>
<vertex x="24.6875" y="3.356" curve="-90"/>
<vertex x="25.5511" y="2.4924"/>
<vertex x="25.5511" y="2.1876"/>
<vertex x="25.5257" y="1.9971"/>
<vertex x="25.4622" y="1.8066"/>
<vertex x="25.3098" y="1.5907"/>
<vertex x="25.259" y="1.5653"/>
<vertex x="25.005" y="1.5653" curve="90"/>
<vertex x="24.9034" y="1.4637"/>
<vertex x="25.4241" y="1.4637" curve="-90"/>
<vertex x="25.5511" y="1.3367"/>
<vertex x="25.5511" y="0.4858" curve="-90"/>
<vertex x="25.4241" y="0.3588"/>
<vertex x="23.9255" y="0.3588" curve="-90"/>
<vertex x="23.7985" y="0.4858"/>
<vertex x="23.7985" y="1.3367" curve="-90"/>
<vertex x="23.9255" y="1.4637"/>
<vertex x="24.4462" y="1.4637" curve="90"/>
<vertex x="24.3446" y="1.5653"/>
<vertex x="24.0906" y="1.5653"/>
<vertex x="24.0398" y="1.5907"/>
<vertex x="23.8874" y="1.8066"/>
<vertex x="23.7985" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="26.3385" y="2.4924" curve="-90"/>
<vertex x="27.2021" y="3.356"/>
<vertex x="27.2275" y="3.356" curve="-90"/>
<vertex x="28.0911" y="2.4924"/>
<vertex x="28.0911" y="2.1876"/>
<vertex x="28.0657" y="1.9971"/>
<vertex x="28.0022" y="1.8066"/>
<vertex x="27.8498" y="1.5907"/>
<vertex x="27.799" y="1.5653"/>
<vertex x="27.545" y="1.5653" curve="90"/>
<vertex x="27.4434" y="1.4637"/>
<vertex x="27.9641" y="1.4637" curve="-90"/>
<vertex x="28.0911" y="1.3367"/>
<vertex x="28.0911" y="0.4858" curve="-90"/>
<vertex x="27.9641" y="0.3588"/>
<vertex x="26.4655" y="0.3588" curve="-90"/>
<vertex x="26.3385" y="0.4858"/>
<vertex x="26.3385" y="1.3367" curve="-90"/>
<vertex x="26.4655" y="1.4637"/>
<vertex x="26.9862" y="1.4637" curve="90"/>
<vertex x="26.8846" y="1.5653"/>
<vertex x="26.6306" y="1.5653"/>
<vertex x="26.5798" y="1.5907"/>
<vertex x="26.4274" y="1.8066"/>
<vertex x="26.3385" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="26.3385" y="2.4924" curve="-90"/>
<vertex x="27.2021" y="3.356"/>
<vertex x="27.2275" y="3.356" curve="-90"/>
<vertex x="28.0911" y="2.4924"/>
<vertex x="28.0911" y="2.1876"/>
<vertex x="28.0657" y="1.9971"/>
<vertex x="28.0022" y="1.8066"/>
<vertex x="27.8498" y="1.5907"/>
<vertex x="27.799" y="1.5653"/>
<vertex x="27.545" y="1.5653" curve="90"/>
<vertex x="27.4434" y="1.4637"/>
<vertex x="27.9641" y="1.4637" curve="-90"/>
<vertex x="28.0911" y="1.3367"/>
<vertex x="28.0911" y="0.4858" curve="-90"/>
<vertex x="27.9641" y="0.3588"/>
<vertex x="26.4655" y="0.3588" curve="-90"/>
<vertex x="26.3385" y="0.4858"/>
<vertex x="26.3385" y="1.3367" curve="-90"/>
<vertex x="26.4655" y="1.4637"/>
<vertex x="26.9862" y="1.4637" curve="90"/>
<vertex x="26.8846" y="1.5653"/>
<vertex x="26.6306" y="1.5653"/>
<vertex x="26.5798" y="1.5907"/>
<vertex x="26.4274" y="1.8066"/>
<vertex x="26.3385" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="28.8785" y="2.4924" curve="-90"/>
<vertex x="29.7421" y="3.356"/>
<vertex x="29.7675" y="3.356" curve="-90"/>
<vertex x="30.6311" y="2.4924"/>
<vertex x="30.6311" y="2.1876"/>
<vertex x="30.6057" y="1.9971"/>
<vertex x="30.5422" y="1.8066"/>
<vertex x="30.3898" y="1.5907"/>
<vertex x="30.339" y="1.5653"/>
<vertex x="30.085" y="1.5653" curve="90"/>
<vertex x="29.9834" y="1.4637"/>
<vertex x="30.5041" y="1.4637" curve="-90"/>
<vertex x="30.6311" y="1.3367"/>
<vertex x="30.6311" y="0.4858" curve="-90"/>
<vertex x="30.5041" y="0.3588"/>
<vertex x="29.0055" y="0.3588" curve="-90"/>
<vertex x="28.8785" y="0.4858"/>
<vertex x="28.8785" y="1.3367" curve="-90"/>
<vertex x="29.0055" y="1.4637"/>
<vertex x="29.5262" y="1.4637" curve="90"/>
<vertex x="29.4246" y="1.5653"/>
<vertex x="29.1706" y="1.5653"/>
<vertex x="29.1198" y="1.5907"/>
<vertex x="28.9674" y="1.8066"/>
<vertex x="28.8785" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="28.8785" y="2.4924" curve="-90"/>
<vertex x="29.7421" y="3.356"/>
<vertex x="29.7675" y="3.356" curve="-90"/>
<vertex x="30.6311" y="2.4924"/>
<vertex x="30.6311" y="2.1876"/>
<vertex x="30.6057" y="1.9971"/>
<vertex x="30.5422" y="1.8066"/>
<vertex x="30.3898" y="1.5907"/>
<vertex x="30.339" y="1.5653"/>
<vertex x="30.085" y="1.5653" curve="90"/>
<vertex x="29.9834" y="1.4637"/>
<vertex x="30.5041" y="1.4637" curve="-90"/>
<vertex x="30.6311" y="1.3367"/>
<vertex x="30.6311" y="0.4858" curve="-90"/>
<vertex x="30.5041" y="0.3588"/>
<vertex x="29.0055" y="0.3588" curve="-90"/>
<vertex x="28.8785" y="0.4858"/>
<vertex x="28.8785" y="1.3367" curve="-90"/>
<vertex x="29.0055" y="1.4637"/>
<vertex x="29.5262" y="1.4637" curve="90"/>
<vertex x="29.4246" y="1.5653"/>
<vertex x="29.1706" y="1.5653"/>
<vertex x="29.1198" y="1.5907"/>
<vertex x="28.9674" y="1.8066"/>
<vertex x="28.8785" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="31.4185" y="2.4924" curve="-90"/>
<vertex x="32.2821" y="3.356"/>
<vertex x="32.3075" y="3.356" curve="-90"/>
<vertex x="33.1711" y="2.4924"/>
<vertex x="33.1711" y="2.1876"/>
<vertex x="33.1457" y="1.9971"/>
<vertex x="33.0822" y="1.8066"/>
<vertex x="32.9298" y="1.5907"/>
<vertex x="32.879" y="1.5653"/>
<vertex x="32.625" y="1.5653" curve="90"/>
<vertex x="32.5234" y="1.4637"/>
<vertex x="33.0441" y="1.4637" curve="-90"/>
<vertex x="33.1711" y="1.3367"/>
<vertex x="33.1711" y="0.4858" curve="-90"/>
<vertex x="33.0441" y="0.3588"/>
<vertex x="31.5455" y="0.3588" curve="-90"/>
<vertex x="31.4185" y="0.4858"/>
<vertex x="31.4185" y="1.3367" curve="-90"/>
<vertex x="31.5455" y="1.4637"/>
<vertex x="32.0662" y="1.4637" curve="90"/>
<vertex x="31.9646" y="1.5653"/>
<vertex x="31.7106" y="1.5653"/>
<vertex x="31.6598" y="1.5907"/>
<vertex x="31.5074" y="1.8066"/>
<vertex x="31.4185" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="31.4185" y="2.4924" curve="-90"/>
<vertex x="32.2821" y="3.356"/>
<vertex x="32.3075" y="3.356" curve="-90"/>
<vertex x="33.1711" y="2.4924"/>
<vertex x="33.1711" y="2.1876"/>
<vertex x="33.1457" y="1.9971"/>
<vertex x="33.0822" y="1.8066"/>
<vertex x="32.9298" y="1.5907"/>
<vertex x="32.879" y="1.5653"/>
<vertex x="32.625" y="1.5653" curve="90"/>
<vertex x="32.5234" y="1.4637"/>
<vertex x="33.0441" y="1.4637" curve="-90"/>
<vertex x="33.1711" y="1.3367"/>
<vertex x="33.1711" y="0.4858" curve="-90"/>
<vertex x="33.0441" y="0.3588"/>
<vertex x="31.5455" y="0.3588" curve="-90"/>
<vertex x="31.4185" y="0.4858"/>
<vertex x="31.4185" y="1.3367" curve="-90"/>
<vertex x="31.5455" y="1.4637"/>
<vertex x="32.0662" y="1.4637" curve="90"/>
<vertex x="31.9646" y="1.5653"/>
<vertex x="31.7106" y="1.5653"/>
<vertex x="31.6598" y="1.5907"/>
<vertex x="31.5074" y="1.8066"/>
<vertex x="31.4185" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="33.9585" y="2.4924" curve="-90"/>
<vertex x="34.8221" y="3.356"/>
<vertex x="34.8475" y="3.356" curve="-90"/>
<vertex x="35.7111" y="2.4924"/>
<vertex x="35.7111" y="2.1876"/>
<vertex x="35.6857" y="1.9971"/>
<vertex x="35.6222" y="1.8066"/>
<vertex x="35.4698" y="1.5907"/>
<vertex x="35.419" y="1.5653"/>
<vertex x="35.165" y="1.5653" curve="90"/>
<vertex x="35.0634" y="1.4637"/>
<vertex x="35.5841" y="1.4637" curve="-90"/>
<vertex x="35.7111" y="1.3367"/>
<vertex x="35.7111" y="0.4858" curve="-90"/>
<vertex x="35.5841" y="0.3588"/>
<vertex x="34.0855" y="0.3588" curve="-90"/>
<vertex x="33.9585" y="0.4858"/>
<vertex x="33.9585" y="1.3367" curve="-90"/>
<vertex x="34.0855" y="1.4637"/>
<vertex x="34.6062" y="1.4637" curve="90"/>
<vertex x="34.5046" y="1.5653"/>
<vertex x="34.2506" y="1.5653"/>
<vertex x="34.1998" y="1.5907"/>
<vertex x="34.0474" y="1.8066"/>
<vertex x="33.9585" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="33.9585" y="2.4924" curve="-90"/>
<vertex x="34.8221" y="3.356"/>
<vertex x="34.8475" y="3.356" curve="-90"/>
<vertex x="35.7111" y="2.4924"/>
<vertex x="35.7111" y="2.1876"/>
<vertex x="35.6857" y="1.9971"/>
<vertex x="35.6222" y="1.8066"/>
<vertex x="35.4698" y="1.5907"/>
<vertex x="35.419" y="1.5653"/>
<vertex x="35.165" y="1.5653" curve="90"/>
<vertex x="35.0634" y="1.4637"/>
<vertex x="35.5841" y="1.4637" curve="-90"/>
<vertex x="35.7111" y="1.3367"/>
<vertex x="35.7111" y="0.4858" curve="-90"/>
<vertex x="35.5841" y="0.3588"/>
<vertex x="34.0855" y="0.3588" curve="-90"/>
<vertex x="33.9585" y="0.4858"/>
<vertex x="33.9585" y="1.3367" curve="-90"/>
<vertex x="34.0855" y="1.4637"/>
<vertex x="34.6062" y="1.4637" curve="90"/>
<vertex x="34.5046" y="1.5653"/>
<vertex x="34.2506" y="1.5653"/>
<vertex x="34.1998" y="1.5907"/>
<vertex x="34.0474" y="1.8066"/>
<vertex x="33.9585" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="36.4985" y="2.4924" curve="-90"/>
<vertex x="37.3621" y="3.356"/>
<vertex x="37.3875" y="3.356" curve="-90"/>
<vertex x="38.2511" y="2.4924"/>
<vertex x="38.2511" y="2.1876"/>
<vertex x="38.2257" y="1.9971"/>
<vertex x="38.1622" y="1.8066"/>
<vertex x="38.0098" y="1.5907"/>
<vertex x="37.959" y="1.5653"/>
<vertex x="37.705" y="1.5653" curve="90"/>
<vertex x="37.6034" y="1.4637"/>
<vertex x="38.1241" y="1.4637" curve="-90"/>
<vertex x="38.2511" y="1.3367"/>
<vertex x="38.2511" y="0.4858" curve="-90"/>
<vertex x="38.1241" y="0.3588"/>
<vertex x="36.6255" y="0.3588" curve="-90"/>
<vertex x="36.4985" y="0.4858"/>
<vertex x="36.4985" y="1.3367" curve="-90"/>
<vertex x="36.6255" y="1.4637"/>
<vertex x="37.1462" y="1.4637" curve="90"/>
<vertex x="37.0446" y="1.5653"/>
<vertex x="36.7906" y="1.5653"/>
<vertex x="36.7398" y="1.5907"/>
<vertex x="36.5874" y="1.8066"/>
<vertex x="36.4985" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="36.4985" y="2.4924" curve="-90"/>
<vertex x="37.3621" y="3.356"/>
<vertex x="37.3875" y="3.356" curve="-90"/>
<vertex x="38.2511" y="2.4924"/>
<vertex x="38.2511" y="2.1876"/>
<vertex x="38.2257" y="1.9971"/>
<vertex x="38.1622" y="1.8066"/>
<vertex x="38.0098" y="1.5907"/>
<vertex x="37.959" y="1.5653"/>
<vertex x="37.705" y="1.5653" curve="90"/>
<vertex x="37.6034" y="1.4637"/>
<vertex x="38.1241" y="1.4637" curve="-90"/>
<vertex x="38.2511" y="1.3367"/>
<vertex x="38.2511" y="0.4858" curve="-90"/>
<vertex x="38.1241" y="0.3588"/>
<vertex x="36.6255" y="0.3588" curve="-90"/>
<vertex x="36.4985" y="0.4858"/>
<vertex x="36.4985" y="1.3367" curve="-90"/>
<vertex x="36.6255" y="1.4637"/>
<vertex x="37.1462" y="1.4637" curve="90"/>
<vertex x="37.0446" y="1.5653"/>
<vertex x="36.7906" y="1.5653"/>
<vertex x="36.7398" y="1.5907"/>
<vertex x="36.5874" y="1.8066"/>
<vertex x="36.4985" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="39.0385" y="2.4924" curve="-90"/>
<vertex x="39.9021" y="3.356"/>
<vertex x="39.9275" y="3.356" curve="-90"/>
<vertex x="40.7911" y="2.4924"/>
<vertex x="40.7911" y="2.1876"/>
<vertex x="40.7657" y="1.9971"/>
<vertex x="40.7022" y="1.8066"/>
<vertex x="40.5498" y="1.5907"/>
<vertex x="40.499" y="1.5653"/>
<vertex x="40.245" y="1.5653" curve="90"/>
<vertex x="40.1434" y="1.4637"/>
<vertex x="40.6641" y="1.4637" curve="-90"/>
<vertex x="40.7911" y="1.3367"/>
<vertex x="40.7911" y="0.4858" curve="-90"/>
<vertex x="40.6641" y="0.3588"/>
<vertex x="39.1655" y="0.3588" curve="-90"/>
<vertex x="39.0385" y="0.4858"/>
<vertex x="39.0385" y="1.3367" curve="-90"/>
<vertex x="39.1655" y="1.4637"/>
<vertex x="39.6862" y="1.4637" curve="90"/>
<vertex x="39.5846" y="1.5653"/>
<vertex x="39.3306" y="1.5653"/>
<vertex x="39.2798" y="1.5907"/>
<vertex x="39.1274" y="1.8066"/>
<vertex x="39.0385" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="39.0385" y="2.4924" curve="-90"/>
<vertex x="39.9021" y="3.356"/>
<vertex x="39.9275" y="3.356" curve="-90"/>
<vertex x="40.7911" y="2.4924"/>
<vertex x="40.7911" y="2.1876"/>
<vertex x="40.7657" y="1.9971"/>
<vertex x="40.7022" y="1.8066"/>
<vertex x="40.5498" y="1.5907"/>
<vertex x="40.499" y="1.5653"/>
<vertex x="40.245" y="1.5653" curve="90"/>
<vertex x="40.1434" y="1.4637"/>
<vertex x="40.6641" y="1.4637" curve="-90"/>
<vertex x="40.7911" y="1.3367"/>
<vertex x="40.7911" y="0.4858" curve="-90"/>
<vertex x="40.6641" y="0.3588"/>
<vertex x="39.1655" y="0.3588" curve="-90"/>
<vertex x="39.0385" y="0.4858"/>
<vertex x="39.0385" y="1.3367" curve="-90"/>
<vertex x="39.1655" y="1.4637"/>
<vertex x="39.6862" y="1.4637" curve="90"/>
<vertex x="39.5846" y="1.5653"/>
<vertex x="39.3306" y="1.5653"/>
<vertex x="39.2798" y="1.5907"/>
<vertex x="39.1274" y="1.8066"/>
<vertex x="39.0385" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="41.5785" y="2.4924" curve="-90"/>
<vertex x="42.4421" y="3.356"/>
<vertex x="42.4675" y="3.356" curve="-90"/>
<vertex x="43.3311" y="2.4924"/>
<vertex x="43.3311" y="2.1876"/>
<vertex x="43.3057" y="1.9971"/>
<vertex x="43.2422" y="1.8066"/>
<vertex x="43.0898" y="1.5907"/>
<vertex x="43.039" y="1.5653"/>
<vertex x="42.785" y="1.5653" curve="90"/>
<vertex x="42.6834" y="1.4637"/>
<vertex x="43.2041" y="1.4637" curve="-90"/>
<vertex x="43.3311" y="1.3367"/>
<vertex x="43.3311" y="0.4858" curve="-90"/>
<vertex x="43.2041" y="0.3588"/>
<vertex x="41.7055" y="0.3588" curve="-90"/>
<vertex x="41.5785" y="0.4858"/>
<vertex x="41.5785" y="1.3367" curve="-90"/>
<vertex x="41.7055" y="1.4637"/>
<vertex x="42.2262" y="1.4637" curve="90"/>
<vertex x="42.1246" y="1.5653"/>
<vertex x="41.8706" y="1.5653"/>
<vertex x="41.8198" y="1.5907"/>
<vertex x="41.6674" y="1.8066"/>
<vertex x="41.5785" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="41.5785" y="2.4924" curve="-90"/>
<vertex x="42.4421" y="3.356"/>
<vertex x="42.4675" y="3.356" curve="-90"/>
<vertex x="43.3311" y="2.4924"/>
<vertex x="43.3311" y="2.1876"/>
<vertex x="43.3057" y="1.9971"/>
<vertex x="43.2422" y="1.8066"/>
<vertex x="43.0898" y="1.5907"/>
<vertex x="43.039" y="1.5653"/>
<vertex x="42.785" y="1.5653" curve="90"/>
<vertex x="42.6834" y="1.4637"/>
<vertex x="43.2041" y="1.4637" curve="-90"/>
<vertex x="43.3311" y="1.3367"/>
<vertex x="43.3311" y="0.4858" curve="-90"/>
<vertex x="43.2041" y="0.3588"/>
<vertex x="41.7055" y="0.3588" curve="-90"/>
<vertex x="41.5785" y="0.4858"/>
<vertex x="41.5785" y="1.3367" curve="-90"/>
<vertex x="41.7055" y="1.4637"/>
<vertex x="42.2262" y="1.4637" curve="90"/>
<vertex x="42.1246" y="1.5653"/>
<vertex x="41.8706" y="1.5653"/>
<vertex x="41.8198" y="1.5907"/>
<vertex x="41.6674" y="1.8066"/>
<vertex x="41.5785" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="44.1185" y="2.4924" curve="-90"/>
<vertex x="44.9821" y="3.356"/>
<vertex x="45.0075" y="3.356" curve="-90"/>
<vertex x="45.8711" y="2.4924"/>
<vertex x="45.8711" y="2.1876"/>
<vertex x="45.8457" y="1.9971"/>
<vertex x="45.7822" y="1.8066"/>
<vertex x="45.6298" y="1.5907"/>
<vertex x="45.579" y="1.5653"/>
<vertex x="45.325" y="1.5653" curve="90"/>
<vertex x="45.2234" y="1.4637"/>
<vertex x="45.7441" y="1.4637" curve="-90"/>
<vertex x="45.8711" y="1.3367"/>
<vertex x="45.8711" y="0.4858" curve="-90"/>
<vertex x="45.7441" y="0.3588"/>
<vertex x="44.2455" y="0.3588" curve="-90"/>
<vertex x="44.1185" y="0.4858"/>
<vertex x="44.1185" y="1.3367" curve="-90"/>
<vertex x="44.2455" y="1.4637"/>
<vertex x="44.7662" y="1.4637" curve="90"/>
<vertex x="44.6646" y="1.5653"/>
<vertex x="44.4106" y="1.5653"/>
<vertex x="44.3598" y="1.5907"/>
<vertex x="44.2074" y="1.8066"/>
<vertex x="44.1185" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="44.1185" y="2.4924" curve="-90"/>
<vertex x="44.9821" y="3.356"/>
<vertex x="45.0075" y="3.356" curve="-90"/>
<vertex x="45.8711" y="2.4924"/>
<vertex x="45.8711" y="2.1876"/>
<vertex x="45.8457" y="1.9971"/>
<vertex x="45.7822" y="1.8066"/>
<vertex x="45.6298" y="1.5907"/>
<vertex x="45.579" y="1.5653"/>
<vertex x="45.325" y="1.5653" curve="90"/>
<vertex x="45.2234" y="1.4637"/>
<vertex x="45.7441" y="1.4637" curve="-90"/>
<vertex x="45.8711" y="1.3367"/>
<vertex x="45.8711" y="0.4858" curve="-90"/>
<vertex x="45.7441" y="0.3588"/>
<vertex x="44.2455" y="0.3588" curve="-90"/>
<vertex x="44.1185" y="0.4858"/>
<vertex x="44.1185" y="1.3367" curve="-90"/>
<vertex x="44.2455" y="1.4637"/>
<vertex x="44.7662" y="1.4637" curve="90"/>
<vertex x="44.6646" y="1.5653"/>
<vertex x="44.4106" y="1.5653"/>
<vertex x="44.3598" y="1.5907"/>
<vertex x="44.2074" y="1.8066"/>
<vertex x="44.1185" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="46.6585" y="2.4924" curve="-90"/>
<vertex x="47.5221" y="3.356"/>
<vertex x="47.5475" y="3.356" curve="-90"/>
<vertex x="48.4111" y="2.4924"/>
<vertex x="48.4111" y="2.1876"/>
<vertex x="48.3857" y="1.9971"/>
<vertex x="48.3222" y="1.8066"/>
<vertex x="48.1698" y="1.5907"/>
<vertex x="48.119" y="1.5653"/>
<vertex x="47.865" y="1.5653" curve="90"/>
<vertex x="47.7634" y="1.4637"/>
<vertex x="48.2841" y="1.4637" curve="-90"/>
<vertex x="48.4111" y="1.3367"/>
<vertex x="48.4111" y="0.4858" curve="-90"/>
<vertex x="48.2841" y="0.3588"/>
<vertex x="46.7855" y="0.3588" curve="-90"/>
<vertex x="46.6585" y="0.4858"/>
<vertex x="46.6585" y="1.3367" curve="-90"/>
<vertex x="46.7855" y="1.4637"/>
<vertex x="47.3062" y="1.4637" curve="90"/>
<vertex x="47.2046" y="1.5653"/>
<vertex x="46.9506" y="1.5653"/>
<vertex x="46.8998" y="1.5907"/>
<vertex x="46.7474" y="1.8066"/>
<vertex x="46.6585" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="46.6585" y="2.4924" curve="-90"/>
<vertex x="47.5221" y="3.356"/>
<vertex x="47.5475" y="3.356" curve="-90"/>
<vertex x="48.4111" y="2.4924"/>
<vertex x="48.4111" y="2.1876"/>
<vertex x="48.3857" y="1.9971"/>
<vertex x="48.3222" y="1.8066"/>
<vertex x="48.1698" y="1.5907"/>
<vertex x="48.119" y="1.5653"/>
<vertex x="47.865" y="1.5653" curve="90"/>
<vertex x="47.7634" y="1.4637"/>
<vertex x="48.2841" y="1.4637" curve="-90"/>
<vertex x="48.4111" y="1.3367"/>
<vertex x="48.4111" y="0.4858" curve="-90"/>
<vertex x="48.2841" y="0.3588"/>
<vertex x="46.7855" y="0.3588" curve="-90"/>
<vertex x="46.6585" y="0.4858"/>
<vertex x="46.6585" y="1.3367" curve="-90"/>
<vertex x="46.7855" y="1.4637"/>
<vertex x="47.3062" y="1.4637" curve="90"/>
<vertex x="47.2046" y="1.5653"/>
<vertex x="46.9506" y="1.5653"/>
<vertex x="46.8998" y="1.5907"/>
<vertex x="46.7474" y="1.8066"/>
<vertex x="46.6585" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="49.1985" y="2.4924" curve="-90"/>
<vertex x="50.0621" y="3.356"/>
<vertex x="50.0875" y="3.356" curve="-90"/>
<vertex x="50.9511" y="2.4924"/>
<vertex x="50.9511" y="2.1876"/>
<vertex x="50.9257" y="1.9971"/>
<vertex x="50.8622" y="1.8066"/>
<vertex x="50.7098" y="1.5907"/>
<vertex x="50.659" y="1.5653"/>
<vertex x="50.405" y="1.5653" curve="90"/>
<vertex x="50.3034" y="1.4637"/>
<vertex x="50.8241" y="1.4637" curve="-90"/>
<vertex x="50.9511" y="1.3367"/>
<vertex x="50.9511" y="0.4858" curve="-90"/>
<vertex x="50.8241" y="0.3588"/>
<vertex x="49.3255" y="0.3588" curve="-90"/>
<vertex x="49.1985" y="0.4858"/>
<vertex x="49.1985" y="1.3367" curve="-90"/>
<vertex x="49.3255" y="1.4637"/>
<vertex x="49.8462" y="1.4637" curve="90"/>
<vertex x="49.7446" y="1.5653"/>
<vertex x="49.4906" y="1.5653"/>
<vertex x="49.4398" y="1.5907"/>
<vertex x="49.2874" y="1.8066"/>
<vertex x="49.1985" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="49.1985" y="2.4924" curve="-90"/>
<vertex x="50.0621" y="3.356"/>
<vertex x="50.0875" y="3.356" curve="-90"/>
<vertex x="50.9511" y="2.4924"/>
<vertex x="50.9511" y="2.1876"/>
<vertex x="50.9257" y="1.9971"/>
<vertex x="50.8622" y="1.8066"/>
<vertex x="50.7098" y="1.5907"/>
<vertex x="50.659" y="1.5653"/>
<vertex x="50.405" y="1.5653" curve="90"/>
<vertex x="50.3034" y="1.4637"/>
<vertex x="50.8241" y="1.4637" curve="-90"/>
<vertex x="50.9511" y="1.3367"/>
<vertex x="50.9511" y="0.4858" curve="-90"/>
<vertex x="50.8241" y="0.3588"/>
<vertex x="49.3255" y="0.3588" curve="-90"/>
<vertex x="49.1985" y="0.4858"/>
<vertex x="49.1985" y="1.3367" curve="-90"/>
<vertex x="49.3255" y="1.4637"/>
<vertex x="49.8462" y="1.4637" curve="90"/>
<vertex x="49.7446" y="1.5653"/>
<vertex x="49.4906" y="1.5653"/>
<vertex x="49.4398" y="1.5907"/>
<vertex x="49.2874" y="1.8066"/>
<vertex x="49.1985" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="51.7385" y="2.4924" curve="-90"/>
<vertex x="52.6021" y="3.356"/>
<vertex x="52.6275" y="3.356" curve="-90"/>
<vertex x="53.4911" y="2.4924"/>
<vertex x="53.4911" y="2.1876"/>
<vertex x="53.4657" y="1.9971"/>
<vertex x="53.4022" y="1.8066"/>
<vertex x="53.2498" y="1.5907"/>
<vertex x="53.199" y="1.5653"/>
<vertex x="52.945" y="1.5653" curve="90"/>
<vertex x="52.8434" y="1.4637"/>
<vertex x="53.3641" y="1.4637" curve="-90"/>
<vertex x="53.4911" y="1.3367"/>
<vertex x="53.4911" y="0.4858" curve="-90"/>
<vertex x="53.3641" y="0.3588"/>
<vertex x="51.8655" y="0.3588" curve="-90"/>
<vertex x="51.7385" y="0.4858"/>
<vertex x="51.7385" y="1.3367" curve="-90"/>
<vertex x="51.8655" y="1.4637"/>
<vertex x="52.3862" y="1.4637" curve="90"/>
<vertex x="52.2846" y="1.5653"/>
<vertex x="52.0306" y="1.5653"/>
<vertex x="51.9798" y="1.5907"/>
<vertex x="51.8274" y="1.8066"/>
<vertex x="51.7385" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="51.7385" y="2.4924" curve="-90"/>
<vertex x="52.6021" y="3.356"/>
<vertex x="52.6275" y="3.356" curve="-90"/>
<vertex x="53.4911" y="2.4924"/>
<vertex x="53.4911" y="2.1876"/>
<vertex x="53.4657" y="1.9971"/>
<vertex x="53.4022" y="1.8066"/>
<vertex x="53.2498" y="1.5907"/>
<vertex x="53.199" y="1.5653"/>
<vertex x="52.945" y="1.5653" curve="90"/>
<vertex x="52.8434" y="1.4637"/>
<vertex x="53.3641" y="1.4637" curve="-90"/>
<vertex x="53.4911" y="1.3367"/>
<vertex x="53.4911" y="0.4858" curve="-90"/>
<vertex x="53.3641" y="0.3588"/>
<vertex x="51.8655" y="0.3588" curve="-90"/>
<vertex x="51.7385" y="0.4858"/>
<vertex x="51.7385" y="1.3367" curve="-90"/>
<vertex x="51.8655" y="1.4637"/>
<vertex x="52.3862" y="1.4637" curve="90"/>
<vertex x="52.2846" y="1.5653"/>
<vertex x="52.0306" y="1.5653"/>
<vertex x="51.9798" y="1.5907"/>
<vertex x="51.8274" y="1.8066"/>
<vertex x="51.7385" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="54.2785" y="2.4924" curve="-90"/>
<vertex x="55.1421" y="3.356"/>
<vertex x="55.1675" y="3.356" curve="-90"/>
<vertex x="56.0311" y="2.4924"/>
<vertex x="56.0311" y="2.1876"/>
<vertex x="56.0057" y="1.9971"/>
<vertex x="55.9422" y="1.8066"/>
<vertex x="55.7898" y="1.5907"/>
<vertex x="55.739" y="1.5653"/>
<vertex x="55.485" y="1.5653" curve="90"/>
<vertex x="55.3834" y="1.4637"/>
<vertex x="55.9041" y="1.4637" curve="-90"/>
<vertex x="56.0311" y="1.3367"/>
<vertex x="56.0311" y="0.4858" curve="-90"/>
<vertex x="55.9041" y="0.3588"/>
<vertex x="54.4055" y="0.3588" curve="-90"/>
<vertex x="54.2785" y="0.4858"/>
<vertex x="54.2785" y="1.3367" curve="-90"/>
<vertex x="54.4055" y="1.4637"/>
<vertex x="54.9262" y="1.4637" curve="90"/>
<vertex x="54.8246" y="1.5653"/>
<vertex x="54.5706" y="1.5653"/>
<vertex x="54.5198" y="1.5907"/>
<vertex x="54.3674" y="1.8066"/>
<vertex x="54.2785" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="54.2785" y="2.4924" curve="-90"/>
<vertex x="55.1421" y="3.356"/>
<vertex x="55.1675" y="3.356" curve="-90"/>
<vertex x="56.0311" y="2.4924"/>
<vertex x="56.0311" y="2.1876"/>
<vertex x="56.0057" y="1.9971"/>
<vertex x="55.9422" y="1.8066"/>
<vertex x="55.7898" y="1.5907"/>
<vertex x="55.739" y="1.5653"/>
<vertex x="55.485" y="1.5653" curve="90"/>
<vertex x="55.3834" y="1.4637"/>
<vertex x="55.9041" y="1.4637" curve="-90"/>
<vertex x="56.0311" y="1.3367"/>
<vertex x="56.0311" y="0.4858" curve="-90"/>
<vertex x="55.9041" y="0.3588"/>
<vertex x="54.4055" y="0.3588" curve="-90"/>
<vertex x="54.2785" y="0.4858"/>
<vertex x="54.2785" y="1.3367" curve="-90"/>
<vertex x="54.4055" y="1.4637"/>
<vertex x="54.9262" y="1.4637" curve="90"/>
<vertex x="54.8246" y="1.5653"/>
<vertex x="54.5706" y="1.5653"/>
<vertex x="54.5198" y="1.5907"/>
<vertex x="54.3674" y="1.8066"/>
<vertex x="54.2785" y="2.1876"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="23.7985" y="2.2003"/>
<vertex x="23.7985" y="2.467" curve="-90"/>
<vertex x="24.6748" y="3.356" curve="-90"/>
<vertex x="25.5511" y="2.467"/>
<vertex x="25.5511" y="2.2003" curve="-90"/>
<vertex x="24.6748" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="26.3385" y="2.2003"/>
<vertex x="26.3385" y="2.467" curve="-90"/>
<vertex x="27.2148" y="3.356" curve="-90"/>
<vertex x="28.0911" y="2.467"/>
<vertex x="28.0911" y="2.2003" curve="-90"/>
<vertex x="27.2148" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="28.8785" y="2.2003"/>
<vertex x="28.8785" y="2.467" curve="-90"/>
<vertex x="29.7548" y="3.356" curve="-90"/>
<vertex x="30.6311" y="2.467"/>
<vertex x="30.6311" y="2.2003" curve="-90"/>
<vertex x="29.7548" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="31.4185" y="2.2003"/>
<vertex x="31.4185" y="2.467" curve="-90"/>
<vertex x="32.2948" y="3.356" curve="-90"/>
<vertex x="33.1711" y="2.467"/>
<vertex x="33.1711" y="2.2003" curve="-90"/>
<vertex x="32.2948" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="33.9585" y="2.2003"/>
<vertex x="33.9585" y="2.467" curve="-90"/>
<vertex x="34.8348" y="3.356" curve="-90"/>
<vertex x="35.7111" y="2.467"/>
<vertex x="35.7111" y="2.2003" curve="-90"/>
<vertex x="34.8348" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="36.4985" y="2.2003"/>
<vertex x="36.4985" y="2.467" curve="-90"/>
<vertex x="37.3748" y="3.356" curve="-90"/>
<vertex x="38.2511" y="2.467"/>
<vertex x="38.2511" y="2.2003" curve="-90"/>
<vertex x="37.3748" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="39.0385" y="2.2003"/>
<vertex x="39.0385" y="2.467" curve="-90"/>
<vertex x="39.9148" y="3.356" curve="-90"/>
<vertex x="40.7911" y="2.467"/>
<vertex x="40.7911" y="2.2003" curve="-90"/>
<vertex x="39.9148" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="41.5785" y="2.2003"/>
<vertex x="41.5785" y="2.467" curve="-90"/>
<vertex x="42.4548" y="3.356" curve="-90"/>
<vertex x="43.3311" y="2.467"/>
<vertex x="43.3311" y="2.2003" curve="-90"/>
<vertex x="42.4548" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="44.1185" y="2.2003"/>
<vertex x="44.1185" y="2.467" curve="-90"/>
<vertex x="44.9948" y="3.356" curve="-90"/>
<vertex x="45.8711" y="2.467"/>
<vertex x="45.8711" y="2.2003" curve="-90"/>
<vertex x="44.9948" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="46.6585" y="2.2003"/>
<vertex x="46.6585" y="2.467" curve="-90"/>
<vertex x="47.5348" y="3.356" curve="-90"/>
<vertex x="48.4111" y="2.467"/>
<vertex x="48.4111" y="2.2003" curve="-90"/>
<vertex x="47.5348" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="49.1985" y="2.2003"/>
<vertex x="49.1985" y="2.467" curve="-90"/>
<vertex x="50.0748" y="3.356" curve="-90"/>
<vertex x="50.9511" y="2.467"/>
<vertex x="50.9511" y="2.2003" curve="-90"/>
<vertex x="50.0748" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="51.7385" y="2.2003"/>
<vertex x="51.7385" y="2.467" curve="-90"/>
<vertex x="52.6148" y="3.356" curve="-90"/>
<vertex x="53.4911" y="2.467"/>
<vertex x="53.4911" y="2.2003" curve="-90"/>
<vertex x="52.6148" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="54.2785" y="2.2003"/>
<vertex x="54.2785" y="2.467" curve="-90"/>
<vertex x="55.1548" y="3.356" curve="-90"/>
<vertex x="56.0311" y="2.467"/>
<vertex x="56.0311" y="2.2003" curve="-90"/>
<vertex x="55.1548" y="1.324" curve="-90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="24.6748" y="3.229" curve="90"/>
<vertex x="23.9255" y="2.4797"/>
<vertex x="23.9255" y="2.1749"/>
<vertex x="23.9509" y="2.0225"/>
<vertex x="24.0017" y="1.8574"/>
<vertex x="24.116" y="1.6923"/>
<vertex x="24.3573" y="1.6923" curve="-90"/>
<vertex x="24.5732" y="1.4764"/>
<vertex x="24.5732" y="1.3494" curve="-90"/>
<vertex x="24.5605" y="1.3367"/>
<vertex x="23.9255" y="1.3367"/>
<vertex x="23.9255" y="0.4858"/>
<vertex x="25.4241" y="0.4858"/>
<vertex x="25.4241" y="1.3367"/>
<vertex x="24.7764" y="1.3367"/>
<vertex x="24.7764" y="1.4764" curve="-90"/>
<vertex x="24.9923" y="1.6923"/>
<vertex x="25.2336" y="1.6923"/>
<vertex x="25.3479" y="1.8574"/>
<vertex x="25.3987" y="2.0225"/>
<vertex x="25.4241" y="2.1749"/>
<vertex x="25.4241" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="55.1548" y="3.229" curve="90"/>
<vertex x="54.4055" y="2.4797"/>
<vertex x="54.4055" y="2.1749"/>
<vertex x="54.4309" y="2.0225"/>
<vertex x="54.4817" y="1.8574"/>
<vertex x="54.596" y="1.6923"/>
<vertex x="54.8373" y="1.6923" curve="-90"/>
<vertex x="55.0532" y="1.4764"/>
<vertex x="55.0532" y="1.3494" curve="-90"/>
<vertex x="55.0405" y="1.3367"/>
<vertex x="54.4055" y="1.3367"/>
<vertex x="54.4055" y="0.4858"/>
<vertex x="55.9041" y="0.4858"/>
<vertex x="55.9041" y="1.3367"/>
<vertex x="55.2564" y="1.3367"/>
<vertex x="55.2564" y="1.4764" curve="-90"/>
<vertex x="55.4723" y="1.6923"/>
<vertex x="55.7136" y="1.6923"/>
<vertex x="55.8279" y="1.8574"/>
<vertex x="55.8787" y="2.0225"/>
<vertex x="55.9041" y="2.1749"/>
<vertex x="55.9041" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="27.2148" y="3.229" curve="90"/>
<vertex x="26.4655" y="2.4797"/>
<vertex x="26.4655" y="2.1749"/>
<vertex x="26.4909" y="2.0225"/>
<vertex x="26.5417" y="1.8574"/>
<vertex x="26.656" y="1.6923"/>
<vertex x="26.8973" y="1.6923" curve="-90"/>
<vertex x="27.1132" y="1.4764"/>
<vertex x="27.1132" y="1.3494" curve="-90"/>
<vertex x="27.1005" y="1.3367"/>
<vertex x="26.4655" y="1.3367"/>
<vertex x="26.4655" y="0.4858"/>
<vertex x="27.9641" y="0.4858"/>
<vertex x="27.9641" y="1.3367"/>
<vertex x="27.3164" y="1.3367"/>
<vertex x="27.3164" y="1.4764" curve="-90"/>
<vertex x="27.5323" y="1.6923"/>
<vertex x="27.7736" y="1.6923"/>
<vertex x="27.8879" y="1.8574"/>
<vertex x="27.9387" y="2.0225"/>
<vertex x="27.9641" y="2.1749"/>
<vertex x="27.9641" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="29.7548" y="3.229" curve="90"/>
<vertex x="29.0055" y="2.4797"/>
<vertex x="29.0055" y="2.1749"/>
<vertex x="29.0309" y="2.0225"/>
<vertex x="29.0817" y="1.8574"/>
<vertex x="29.196" y="1.6923"/>
<vertex x="29.4373" y="1.6923" curve="-90"/>
<vertex x="29.6532" y="1.4764"/>
<vertex x="29.6532" y="1.3494" curve="-90"/>
<vertex x="29.6405" y="1.3367"/>
<vertex x="29.0055" y="1.3367"/>
<vertex x="29.0055" y="0.4858"/>
<vertex x="30.5041" y="0.4858"/>
<vertex x="30.5041" y="1.3367"/>
<vertex x="29.8564" y="1.3367"/>
<vertex x="29.8564" y="1.4764" curve="-90"/>
<vertex x="30.0723" y="1.6923"/>
<vertex x="30.3136" y="1.6923"/>
<vertex x="30.4279" y="1.8574"/>
<vertex x="30.4787" y="2.0225"/>
<vertex x="30.5041" y="2.1749"/>
<vertex x="30.5041" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="32.2948" y="3.229" curve="90"/>
<vertex x="31.5455" y="2.4797"/>
<vertex x="31.5455" y="2.1749"/>
<vertex x="31.5709" y="2.0225"/>
<vertex x="31.6217" y="1.8574"/>
<vertex x="31.736" y="1.6923"/>
<vertex x="31.9773" y="1.6923" curve="-90"/>
<vertex x="32.1932" y="1.4764"/>
<vertex x="32.1932" y="1.3494" curve="-90"/>
<vertex x="32.1805" y="1.3367"/>
<vertex x="31.5455" y="1.3367"/>
<vertex x="31.5455" y="0.4858"/>
<vertex x="33.0441" y="0.4858"/>
<vertex x="33.0441" y="1.3367"/>
<vertex x="32.3964" y="1.3367"/>
<vertex x="32.3964" y="1.4764" curve="-90"/>
<vertex x="32.6123" y="1.6923"/>
<vertex x="32.8536" y="1.6923"/>
<vertex x="32.9679" y="1.8574"/>
<vertex x="33.0187" y="2.0225"/>
<vertex x="33.0441" y="2.1749"/>
<vertex x="33.0441" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="34.8348" y="3.229" curve="90"/>
<vertex x="34.0855" y="2.4797"/>
<vertex x="34.0855" y="2.1749"/>
<vertex x="34.1109" y="2.0225"/>
<vertex x="34.1617" y="1.8574"/>
<vertex x="34.276" y="1.6923"/>
<vertex x="34.5173" y="1.6923" curve="-90"/>
<vertex x="34.7332" y="1.4764"/>
<vertex x="34.7332" y="1.3494" curve="-90"/>
<vertex x="34.7205" y="1.3367"/>
<vertex x="34.0855" y="1.3367"/>
<vertex x="34.0855" y="0.4858"/>
<vertex x="35.5841" y="0.4858"/>
<vertex x="35.5841" y="1.3367"/>
<vertex x="34.9364" y="1.3367"/>
<vertex x="34.9364" y="1.4764" curve="-90"/>
<vertex x="35.1523" y="1.6923"/>
<vertex x="35.3936" y="1.6923"/>
<vertex x="35.5079" y="1.8574"/>
<vertex x="35.5587" y="2.0225"/>
<vertex x="35.5841" y="2.1749"/>
<vertex x="35.5841" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="37.3748" y="3.229" curve="90"/>
<vertex x="36.6255" y="2.4797"/>
<vertex x="36.6255" y="2.1749"/>
<vertex x="36.6509" y="2.0225"/>
<vertex x="36.7017" y="1.8574"/>
<vertex x="36.816" y="1.6923"/>
<vertex x="37.0573" y="1.6923" curve="-90"/>
<vertex x="37.2732" y="1.4764"/>
<vertex x="37.2732" y="1.3494" curve="-90"/>
<vertex x="37.2605" y="1.3367"/>
<vertex x="36.6255" y="1.3367"/>
<vertex x="36.6255" y="0.4858"/>
<vertex x="38.1241" y="0.4858"/>
<vertex x="38.1241" y="1.3367"/>
<vertex x="37.4764" y="1.3367"/>
<vertex x="37.4764" y="1.4764" curve="-90"/>
<vertex x="37.6923" y="1.6923"/>
<vertex x="37.9336" y="1.6923"/>
<vertex x="38.0479" y="1.8574"/>
<vertex x="38.0987" y="2.0225"/>
<vertex x="38.1241" y="2.1749"/>
<vertex x="38.1241" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="39.9148" y="3.229" curve="90"/>
<vertex x="39.1655" y="2.4797"/>
<vertex x="39.1655" y="2.1749"/>
<vertex x="39.1909" y="2.0225"/>
<vertex x="39.2417" y="1.8574"/>
<vertex x="39.356" y="1.6923"/>
<vertex x="39.5973" y="1.6923" curve="-90"/>
<vertex x="39.8132" y="1.4764"/>
<vertex x="39.8132" y="1.3494" curve="-90"/>
<vertex x="39.8005" y="1.3367"/>
<vertex x="39.1655" y="1.3367"/>
<vertex x="39.1655" y="0.4858"/>
<vertex x="40.6641" y="0.4858"/>
<vertex x="40.6641" y="1.3367"/>
<vertex x="40.0164" y="1.3367"/>
<vertex x="40.0164" y="1.4764" curve="-90"/>
<vertex x="40.2323" y="1.6923"/>
<vertex x="40.4736" y="1.6923"/>
<vertex x="40.5879" y="1.8574"/>
<vertex x="40.6387" y="2.0225"/>
<vertex x="40.6641" y="2.1749"/>
<vertex x="40.6641" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="42.4548" y="3.229" curve="90"/>
<vertex x="41.7055" y="2.4797"/>
<vertex x="41.7055" y="2.1749"/>
<vertex x="41.7309" y="2.0225"/>
<vertex x="41.7817" y="1.8574"/>
<vertex x="41.896" y="1.6923"/>
<vertex x="42.1373" y="1.6923" curve="-90"/>
<vertex x="42.3532" y="1.4764"/>
<vertex x="42.3532" y="1.3494" curve="-90"/>
<vertex x="42.3405" y="1.3367"/>
<vertex x="41.7055" y="1.3367"/>
<vertex x="41.7055" y="0.4858"/>
<vertex x="43.2041" y="0.4858"/>
<vertex x="43.2041" y="1.3367"/>
<vertex x="42.5564" y="1.3367"/>
<vertex x="42.5564" y="1.4764" curve="-90"/>
<vertex x="42.7723" y="1.6923"/>
<vertex x="43.0136" y="1.6923"/>
<vertex x="43.1279" y="1.8574"/>
<vertex x="43.1787" y="2.0225"/>
<vertex x="43.2041" y="2.1749"/>
<vertex x="43.2041" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="47.5348" y="3.229" curve="90"/>
<vertex x="46.7855" y="2.4797"/>
<vertex x="46.7855" y="2.1749"/>
<vertex x="46.8109" y="2.0225"/>
<vertex x="46.8617" y="1.8574"/>
<vertex x="46.976" y="1.6923"/>
<vertex x="47.2173" y="1.6923" curve="-90"/>
<vertex x="47.4332" y="1.4764"/>
<vertex x="47.4332" y="1.3494" curve="-90"/>
<vertex x="47.4205" y="1.3367"/>
<vertex x="46.7855" y="1.3367"/>
<vertex x="46.7855" y="0.4858"/>
<vertex x="48.2841" y="0.4858"/>
<vertex x="48.2841" y="1.3367"/>
<vertex x="47.6364" y="1.3367"/>
<vertex x="47.6364" y="1.4764" curve="-90"/>
<vertex x="47.8523" y="1.6923"/>
<vertex x="48.0936" y="1.6923"/>
<vertex x="48.2079" y="1.8574"/>
<vertex x="48.2587" y="2.0225"/>
<vertex x="48.2841" y="2.1749"/>
<vertex x="48.2841" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="50.0748" y="3.229" curve="90"/>
<vertex x="49.3255" y="2.4797"/>
<vertex x="49.3255" y="2.1749"/>
<vertex x="49.3509" y="2.0225"/>
<vertex x="49.4017" y="1.8574"/>
<vertex x="49.516" y="1.6923"/>
<vertex x="49.7573" y="1.6923" curve="-90"/>
<vertex x="49.9732" y="1.4764"/>
<vertex x="49.9732" y="1.3494" curve="-90"/>
<vertex x="49.9605" y="1.3367"/>
<vertex x="49.3255" y="1.3367"/>
<vertex x="49.3255" y="0.4858"/>
<vertex x="50.8241" y="0.4858"/>
<vertex x="50.8241" y="1.3367"/>
<vertex x="50.1764" y="1.3367"/>
<vertex x="50.1764" y="1.4764" curve="-90"/>
<vertex x="50.3923" y="1.6923"/>
<vertex x="50.6336" y="1.6923"/>
<vertex x="50.7479" y="1.8574"/>
<vertex x="50.7987" y="2.0225"/>
<vertex x="50.8241" y="2.1749"/>
<vertex x="50.8241" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="52.6148" y="3.229" curve="90"/>
<vertex x="51.8655" y="2.4797"/>
<vertex x="51.8655" y="2.1749"/>
<vertex x="51.8909" y="2.0225"/>
<vertex x="51.9417" y="1.8574"/>
<vertex x="52.056" y="1.6923"/>
<vertex x="52.2973" y="1.6923" curve="-90"/>
<vertex x="52.5132" y="1.4764"/>
<vertex x="52.5132" y="1.3494" curve="-90"/>
<vertex x="52.5005" y="1.3367"/>
<vertex x="51.8655" y="1.3367"/>
<vertex x="51.8655" y="0.4858"/>
<vertex x="53.3641" y="0.4858"/>
<vertex x="53.3641" y="1.3367"/>
<vertex x="52.7164" y="1.3367"/>
<vertex x="52.7164" y="1.4764" curve="-90"/>
<vertex x="52.9323" y="1.6923"/>
<vertex x="53.1736" y="1.6923"/>
<vertex x="53.2879" y="1.8574"/>
<vertex x="53.3387" y="2.0225"/>
<vertex x="53.3641" y="2.1749"/>
<vertex x="53.3641" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="44.9948" y="3.229" curve="90"/>
<vertex x="44.2455" y="2.4797"/>
<vertex x="44.2455" y="2.1749"/>
<vertex x="44.2709" y="2.0225"/>
<vertex x="44.3217" y="1.8574"/>
<vertex x="44.436" y="1.6923"/>
<vertex x="44.6773" y="1.6923" curve="-90"/>
<vertex x="44.8932" y="1.4764"/>
<vertex x="44.8932" y="1.3494" curve="-90"/>
<vertex x="44.8805" y="1.3367"/>
<vertex x="44.2455" y="1.3367"/>
<vertex x="44.2455" y="0.4858"/>
<vertex x="45.7441" y="0.4858"/>
<vertex x="45.7441" y="1.3367"/>
<vertex x="45.0964" y="1.3367"/>
<vertex x="45.0964" y="1.4764" curve="-90"/>
<vertex x="45.3123" y="1.6923"/>
<vertex x="45.5536" y="1.6923"/>
<vertex x="45.6679" y="1.8574"/>
<vertex x="45.7187" y="2.0225"/>
<vertex x="45.7441" y="2.1749"/>
<vertex x="45.7441" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="21.3855" y="3.2417"/>
<vertex x="21.3855" y="1.6923"/>
<vertex x="21.8173" y="1.6923" curve="-90"/>
<vertex x="22.0332" y="1.4764"/>
<vertex x="22.0332" y="1.3494" curve="-90"/>
<vertex x="22.0205" y="1.3367"/>
<vertex x="21.3855" y="1.3367"/>
<vertex x="21.3855" y="0.4858"/>
<vertex x="22.8841" y="0.4858"/>
<vertex x="22.8841" y="1.3367"/>
<vertex x="22.2364" y="1.3367"/>
<vertex x="22.2364" y="1.4764" curve="-90"/>
<vertex x="22.4523" y="1.6923"/>
<vertex x="22.8841" y="1.6923"/>
<vertex x="22.8841" y="3.2417"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="24.6748" y="3.229" curve="90"/>
<vertex x="23.9255" y="2.4797"/>
<vertex x="23.9255" y="2.1368" curve="90"/>
<vertex x="24.6748" y="1.3875" curve="90"/>
<vertex x="25.4241" y="2.1368"/>
<vertex x="25.4241" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="22.8841" y="3.229"/>
<vertex x="21.3855" y="3.229"/>
<vertex x="21.3855" y="1.4383"/>
<vertex x="22.8841" y="1.4383"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="27.2148" y="3.229" curve="90"/>
<vertex x="26.4655" y="2.4797"/>
<vertex x="26.4655" y="2.1368" curve="90"/>
<vertex x="27.2148" y="1.3875" curve="90"/>
<vertex x="27.9641" y="2.1368"/>
<vertex x="27.9641" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="29.7548" y="3.229" curve="90"/>
<vertex x="29.0055" y="2.4797"/>
<vertex x="29.0055" y="2.1368" curve="90"/>
<vertex x="29.7548" y="1.3875" curve="90"/>
<vertex x="30.5041" y="2.1368"/>
<vertex x="30.5041" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="32.2948" y="3.229" curve="90"/>
<vertex x="31.5455" y="2.4797"/>
<vertex x="31.5455" y="2.1368" curve="90"/>
<vertex x="32.2948" y="1.3875" curve="90"/>
<vertex x="33.0441" y="2.1368"/>
<vertex x="33.0441" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="34.8348" y="3.229" curve="90"/>
<vertex x="34.0855" y="2.4797"/>
<vertex x="34.0855" y="2.1368" curve="90"/>
<vertex x="34.8348" y="1.3875" curve="90"/>
<vertex x="35.5841" y="2.1368"/>
<vertex x="35.5841" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="37.3748" y="3.229" curve="90"/>
<vertex x="36.6255" y="2.4797"/>
<vertex x="36.6255" y="2.1368" curve="90"/>
<vertex x="37.3748" y="1.3875" curve="90"/>
<vertex x="38.1241" y="2.1368"/>
<vertex x="38.1241" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="39.9148" y="3.229" curve="90"/>
<vertex x="39.1655" y="2.4797"/>
<vertex x="39.1655" y="2.1368" curve="90"/>
<vertex x="39.9148" y="1.3875" curve="90"/>
<vertex x="40.6641" y="2.1368"/>
<vertex x="40.6641" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="42.4548" y="3.229" curve="90"/>
<vertex x="41.7055" y="2.4797"/>
<vertex x="41.7055" y="2.1368" curve="90"/>
<vertex x="42.4548" y="1.3875" curve="90"/>
<vertex x="43.2041" y="2.1368"/>
<vertex x="43.2041" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="44.9948" y="3.229" curve="90"/>
<vertex x="44.2455" y="2.4797"/>
<vertex x="44.2455" y="2.1368" curve="90"/>
<vertex x="44.9948" y="1.3875" curve="90"/>
<vertex x="45.7441" y="2.1368"/>
<vertex x="45.7441" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="47.5348" y="3.229" curve="90"/>
<vertex x="46.7855" y="2.4797"/>
<vertex x="46.7855" y="2.1368" curve="90"/>
<vertex x="47.5348" y="1.3875" curve="90"/>
<vertex x="48.2841" y="2.1368"/>
<vertex x="48.2841" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="50.0748" y="3.229" curve="90"/>
<vertex x="49.3255" y="2.4797"/>
<vertex x="49.3255" y="2.1368" curve="90"/>
<vertex x="50.0748" y="1.3875" curve="90"/>
<vertex x="50.8241" y="2.1368"/>
<vertex x="50.8241" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="52.6148" y="3.229" curve="90"/>
<vertex x="51.8655" y="2.4797"/>
<vertex x="51.8655" y="2.1368" curve="90"/>
<vertex x="52.6148" y="1.3875" curve="90"/>
<vertex x="53.3641" y="2.1368"/>
<vertex x="53.3641" y="2.4797" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="55.1548" y="3.229" curve="90"/>
<vertex x="54.4055" y="2.4797"/>
<vertex x="54.4055" y="2.1368" curve="90"/>
<vertex x="55.1548" y="1.3875" curve="90"/>
<vertex x="55.9041" y="2.1368"/>
<vertex x="55.9041" y="2.4797" curve="90"/>
</polygon>
<wire x1="55.1652" y1="22.97" x2="55.1652" y2="22.27" width="0.05" layer="39"/>
<pad name="6" x="55.1652" y="22.62" drill="1" rot="R180" first="yes"/>
<pad name="7" x="52.6252" y="22.62" drill="1" rot="R180"/>
<pad name="8" x="50.0852" y="22.62" drill="1" rot="R180"/>
<pad name="9" x="47.5452" y="22.62" drill="1" rot="R180"/>
<pad name="10" x="45.0052" y="22.62" drill="1" rot="R180"/>
<pad name="11" x="42.4652" y="22.62" drill="1" rot="R180"/>
<pad name="12" x="39.9252" y="22.62" drill="1" rot="R180"/>
<pad name="13" x="37.3852" y="22.62" drill="1" rot="R180"/>
<pad name="14" x="34.8452" y="22.62" drill="1" rot="R180"/>
<pad name="RST" x="32.3052" y="22.62" drill="1" rot="R180"/>
<pad name="GND" x="29.7652" y="22.62" drill="1" rot="R180"/>
<pad name="VCC" x="27.2252" y="22.62" drill="1" rot="R180"/>
<pad name="5V" x="24.6852" y="22.62" drill="1" rot="R180"/>
<pad name="VIN" x="22.1452" y="22.62" drill="1" rot="R180"/>
<polygon width="0.0254" layer="29">
<vertex x="56.0415" y="21.5913"/>
<vertex x="54.2889" y="21.5913"/>
<vertex x="54.2889" y="23.6487"/>
<vertex x="56.0415" y="23.6487"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="56.0415" y="21.5913"/>
<vertex x="56.0415" y="23.3947"/>
<vertex x="55.4954" y="23.3947" curve="-90"/>
<vertex x="55.3938" y="23.4963"/>
<vertex x="55.9145" y="23.4963" curve="90"/>
<vertex x="56.0415" y="23.6233"/>
<vertex x="56.0415" y="24.4742" curve="90"/>
<vertex x="55.9145" y="24.6012"/>
<vertex x="54.4159" y="24.6012" curve="90"/>
<vertex x="54.2889" y="24.4742"/>
<vertex x="54.2889" y="23.6233" curve="90"/>
<vertex x="54.4159" y="23.4963"/>
<vertex x="54.9366" y="23.4963" curve="-90"/>
<vertex x="54.835" y="23.3947"/>
<vertex x="54.2889" y="23.3947"/>
<vertex x="54.2889" y="21.5913"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="53.5015" y="22.4676" curve="-90"/>
<vertex x="52.6379" y="21.604"/>
<vertex x="52.6125" y="21.604" curve="-90"/>
<vertex x="51.7489" y="22.4676"/>
<vertex x="51.7489" y="22.7724"/>
<vertex x="51.7743" y="22.9629"/>
<vertex x="51.8378" y="23.1534"/>
<vertex x="51.9902" y="23.3693"/>
<vertex x="52.041" y="23.3947"/>
<vertex x="52.295" y="23.3947" curve="90"/>
<vertex x="52.3966" y="23.4963"/>
<vertex x="51.8759" y="23.4963" curve="-90"/>
<vertex x="51.7489" y="23.6233"/>
<vertex x="51.7489" y="24.4742" curve="-90"/>
<vertex x="51.8759" y="24.6012"/>
<vertex x="53.3745" y="24.6012" curve="-90"/>
<vertex x="53.5015" y="24.4742"/>
<vertex x="53.5015" y="23.6233" curve="-90"/>
<vertex x="53.3745" y="23.4963"/>
<vertex x="52.8538" y="23.4963" curve="90"/>
<vertex x="52.9554" y="23.3947"/>
<vertex x="53.2094" y="23.3947"/>
<vertex x="53.2602" y="23.3693"/>
<vertex x="53.4126" y="23.1534"/>
<vertex x="53.5015" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="53.5015" y="22.4676" curve="-90"/>
<vertex x="52.6379" y="21.604"/>
<vertex x="52.6125" y="21.604" curve="-90"/>
<vertex x="51.7489" y="22.4676"/>
<vertex x="51.7489" y="22.7724"/>
<vertex x="51.7743" y="22.9629"/>
<vertex x="51.8378" y="23.1534"/>
<vertex x="51.9902" y="23.3693"/>
<vertex x="52.041" y="23.3947"/>
<vertex x="52.295" y="23.3947" curve="90"/>
<vertex x="52.3966" y="23.4963"/>
<vertex x="51.8759" y="23.4963" curve="-90"/>
<vertex x="51.7489" y="23.6233"/>
<vertex x="51.7489" y="24.4742" curve="-90"/>
<vertex x="51.8759" y="24.6012"/>
<vertex x="53.3745" y="24.6012" curve="-90"/>
<vertex x="53.5015" y="24.4742"/>
<vertex x="53.5015" y="23.6233" curve="-90"/>
<vertex x="53.3745" y="23.4963"/>
<vertex x="52.8538" y="23.4963" curve="90"/>
<vertex x="52.9554" y="23.3947"/>
<vertex x="53.2094" y="23.3947"/>
<vertex x="53.2602" y="23.3693"/>
<vertex x="53.4126" y="23.1534"/>
<vertex x="53.5015" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="50.9615" y="22.4676" curve="-90"/>
<vertex x="50.0979" y="21.604"/>
<vertex x="50.0725" y="21.604" curve="-90"/>
<vertex x="49.2089" y="22.4676"/>
<vertex x="49.2089" y="22.7724"/>
<vertex x="49.2343" y="22.9629"/>
<vertex x="49.2978" y="23.1534"/>
<vertex x="49.4502" y="23.3693"/>
<vertex x="49.501" y="23.3947"/>
<vertex x="49.755" y="23.3947" curve="90"/>
<vertex x="49.8566" y="23.4963"/>
<vertex x="49.3359" y="23.4963" curve="-90"/>
<vertex x="49.2089" y="23.6233"/>
<vertex x="49.2089" y="24.4742" curve="-90"/>
<vertex x="49.3359" y="24.6012"/>
<vertex x="50.8345" y="24.6012" curve="-90"/>
<vertex x="50.9615" y="24.4742"/>
<vertex x="50.9615" y="23.6233" curve="-90"/>
<vertex x="50.8345" y="23.4963"/>
<vertex x="50.3138" y="23.4963" curve="90"/>
<vertex x="50.4154" y="23.3947"/>
<vertex x="50.6694" y="23.3947"/>
<vertex x="50.7202" y="23.3693"/>
<vertex x="50.8726" y="23.1534"/>
<vertex x="50.9615" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="50.9615" y="22.4676" curve="-90"/>
<vertex x="50.0979" y="21.604"/>
<vertex x="50.0725" y="21.604" curve="-90"/>
<vertex x="49.2089" y="22.4676"/>
<vertex x="49.2089" y="22.7724"/>
<vertex x="49.2343" y="22.9629"/>
<vertex x="49.2978" y="23.1534"/>
<vertex x="49.4502" y="23.3693"/>
<vertex x="49.501" y="23.3947"/>
<vertex x="49.755" y="23.3947" curve="90"/>
<vertex x="49.8566" y="23.4963"/>
<vertex x="49.3359" y="23.4963" curve="-90"/>
<vertex x="49.2089" y="23.6233"/>
<vertex x="49.2089" y="24.4742" curve="-90"/>
<vertex x="49.3359" y="24.6012"/>
<vertex x="50.8345" y="24.6012" curve="-90"/>
<vertex x="50.9615" y="24.4742"/>
<vertex x="50.9615" y="23.6233" curve="-90"/>
<vertex x="50.8345" y="23.4963"/>
<vertex x="50.3138" y="23.4963" curve="90"/>
<vertex x="50.4154" y="23.3947"/>
<vertex x="50.6694" y="23.3947"/>
<vertex x="50.7202" y="23.3693"/>
<vertex x="50.8726" y="23.1534"/>
<vertex x="50.9615" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="48.4215" y="22.4676" curve="-90"/>
<vertex x="47.5579" y="21.604"/>
<vertex x="47.5325" y="21.604" curve="-90"/>
<vertex x="46.6689" y="22.4676"/>
<vertex x="46.6689" y="22.7724"/>
<vertex x="46.6943" y="22.9629"/>
<vertex x="46.7578" y="23.1534"/>
<vertex x="46.9102" y="23.3693"/>
<vertex x="46.961" y="23.3947"/>
<vertex x="47.215" y="23.3947" curve="90"/>
<vertex x="47.3166" y="23.4963"/>
<vertex x="46.7959" y="23.4963" curve="-90"/>
<vertex x="46.6689" y="23.6233"/>
<vertex x="46.6689" y="24.4742" curve="-90"/>
<vertex x="46.7959" y="24.6012"/>
<vertex x="48.2945" y="24.6012" curve="-90"/>
<vertex x="48.4215" y="24.4742"/>
<vertex x="48.4215" y="23.6233" curve="-90"/>
<vertex x="48.2945" y="23.4963"/>
<vertex x="47.7738" y="23.4963" curve="90"/>
<vertex x="47.8754" y="23.3947"/>
<vertex x="48.1294" y="23.3947"/>
<vertex x="48.1802" y="23.3693"/>
<vertex x="48.3326" y="23.1534"/>
<vertex x="48.4215" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="48.4215" y="22.4676" curve="-90"/>
<vertex x="47.5579" y="21.604"/>
<vertex x="47.5325" y="21.604" curve="-90"/>
<vertex x="46.6689" y="22.4676"/>
<vertex x="46.6689" y="22.7724"/>
<vertex x="46.6943" y="22.9629"/>
<vertex x="46.7578" y="23.1534"/>
<vertex x="46.9102" y="23.3693"/>
<vertex x="46.961" y="23.3947"/>
<vertex x="47.215" y="23.3947" curve="90"/>
<vertex x="47.3166" y="23.4963"/>
<vertex x="46.7959" y="23.4963" curve="-90"/>
<vertex x="46.6689" y="23.6233"/>
<vertex x="46.6689" y="24.4742" curve="-90"/>
<vertex x="46.7959" y="24.6012"/>
<vertex x="48.2945" y="24.6012" curve="-90"/>
<vertex x="48.4215" y="24.4742"/>
<vertex x="48.4215" y="23.6233" curve="-90"/>
<vertex x="48.2945" y="23.4963"/>
<vertex x="47.7738" y="23.4963" curve="90"/>
<vertex x="47.8754" y="23.3947"/>
<vertex x="48.1294" y="23.3947"/>
<vertex x="48.1802" y="23.3693"/>
<vertex x="48.3326" y="23.1534"/>
<vertex x="48.4215" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="45.8815" y="22.4676" curve="-90"/>
<vertex x="45.0179" y="21.604"/>
<vertex x="44.9925" y="21.604" curve="-90"/>
<vertex x="44.1289" y="22.4676"/>
<vertex x="44.1289" y="22.7724"/>
<vertex x="44.1543" y="22.9629"/>
<vertex x="44.2178" y="23.1534"/>
<vertex x="44.3702" y="23.3693"/>
<vertex x="44.421" y="23.3947"/>
<vertex x="44.675" y="23.3947" curve="90"/>
<vertex x="44.7766" y="23.4963"/>
<vertex x="44.2559" y="23.4963" curve="-90"/>
<vertex x="44.1289" y="23.6233"/>
<vertex x="44.1289" y="24.4742" curve="-90"/>
<vertex x="44.2559" y="24.6012"/>
<vertex x="45.7545" y="24.6012" curve="-90"/>
<vertex x="45.8815" y="24.4742"/>
<vertex x="45.8815" y="23.6233" curve="-90"/>
<vertex x="45.7545" y="23.4963"/>
<vertex x="45.2338" y="23.4963" curve="90"/>
<vertex x="45.3354" y="23.3947"/>
<vertex x="45.5894" y="23.3947"/>
<vertex x="45.6402" y="23.3693"/>
<vertex x="45.7926" y="23.1534"/>
<vertex x="45.8815" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="45.8815" y="22.4676" curve="-90"/>
<vertex x="45.0179" y="21.604"/>
<vertex x="44.9925" y="21.604" curve="-90"/>
<vertex x="44.1289" y="22.4676"/>
<vertex x="44.1289" y="22.7724"/>
<vertex x="44.1543" y="22.9629"/>
<vertex x="44.2178" y="23.1534"/>
<vertex x="44.3702" y="23.3693"/>
<vertex x="44.421" y="23.3947"/>
<vertex x="44.675" y="23.3947" curve="90"/>
<vertex x="44.7766" y="23.4963"/>
<vertex x="44.2559" y="23.4963" curve="-90"/>
<vertex x="44.1289" y="23.6233"/>
<vertex x="44.1289" y="24.4742" curve="-90"/>
<vertex x="44.2559" y="24.6012"/>
<vertex x="45.7545" y="24.6012" curve="-90"/>
<vertex x="45.8815" y="24.4742"/>
<vertex x="45.8815" y="23.6233" curve="-90"/>
<vertex x="45.7545" y="23.4963"/>
<vertex x="45.2338" y="23.4963" curve="90"/>
<vertex x="45.3354" y="23.3947"/>
<vertex x="45.5894" y="23.3947"/>
<vertex x="45.6402" y="23.3693"/>
<vertex x="45.7926" y="23.1534"/>
<vertex x="45.8815" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="43.3415" y="22.4676" curve="-90"/>
<vertex x="42.4779" y="21.604"/>
<vertex x="42.4525" y="21.604" curve="-90"/>
<vertex x="41.5889" y="22.4676"/>
<vertex x="41.5889" y="22.7724"/>
<vertex x="41.6143" y="22.9629"/>
<vertex x="41.6778" y="23.1534"/>
<vertex x="41.8302" y="23.3693"/>
<vertex x="41.881" y="23.3947"/>
<vertex x="42.135" y="23.3947" curve="90"/>
<vertex x="42.2366" y="23.4963"/>
<vertex x="41.7159" y="23.4963" curve="-90"/>
<vertex x="41.5889" y="23.6233"/>
<vertex x="41.5889" y="24.4742" curve="-90"/>
<vertex x="41.7159" y="24.6012"/>
<vertex x="43.2145" y="24.6012" curve="-90"/>
<vertex x="43.3415" y="24.4742"/>
<vertex x="43.3415" y="23.6233" curve="-90"/>
<vertex x="43.2145" y="23.4963"/>
<vertex x="42.6938" y="23.4963" curve="90"/>
<vertex x="42.7954" y="23.3947"/>
<vertex x="43.0494" y="23.3947"/>
<vertex x="43.1002" y="23.3693"/>
<vertex x="43.2526" y="23.1534"/>
<vertex x="43.3415" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="43.3415" y="22.4676" curve="-90"/>
<vertex x="42.4779" y="21.604"/>
<vertex x="42.4525" y="21.604" curve="-90"/>
<vertex x="41.5889" y="22.4676"/>
<vertex x="41.5889" y="22.7724"/>
<vertex x="41.6143" y="22.9629"/>
<vertex x="41.6778" y="23.1534"/>
<vertex x="41.8302" y="23.3693"/>
<vertex x="41.881" y="23.3947"/>
<vertex x="42.135" y="23.3947" curve="90"/>
<vertex x="42.2366" y="23.4963"/>
<vertex x="41.7159" y="23.4963" curve="-90"/>
<vertex x="41.5889" y="23.6233"/>
<vertex x="41.5889" y="24.4742" curve="-90"/>
<vertex x="41.7159" y="24.6012"/>
<vertex x="43.2145" y="24.6012" curve="-90"/>
<vertex x="43.3415" y="24.4742"/>
<vertex x="43.3415" y="23.6233" curve="-90"/>
<vertex x="43.2145" y="23.4963"/>
<vertex x="42.6938" y="23.4963" curve="90"/>
<vertex x="42.7954" y="23.3947"/>
<vertex x="43.0494" y="23.3947"/>
<vertex x="43.1002" y="23.3693"/>
<vertex x="43.2526" y="23.1534"/>
<vertex x="43.3415" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="40.8015" y="22.4676" curve="-90"/>
<vertex x="39.9379" y="21.604"/>
<vertex x="39.9125" y="21.604" curve="-90"/>
<vertex x="39.0489" y="22.4676"/>
<vertex x="39.0489" y="22.7724"/>
<vertex x="39.0743" y="22.9629"/>
<vertex x="39.1378" y="23.1534"/>
<vertex x="39.2902" y="23.3693"/>
<vertex x="39.341" y="23.3947"/>
<vertex x="39.595" y="23.3947" curve="90"/>
<vertex x="39.6966" y="23.4963"/>
<vertex x="39.1759" y="23.4963" curve="-90"/>
<vertex x="39.0489" y="23.6233"/>
<vertex x="39.0489" y="24.4742" curve="-90"/>
<vertex x="39.1759" y="24.6012"/>
<vertex x="40.6745" y="24.6012" curve="-90"/>
<vertex x="40.8015" y="24.4742"/>
<vertex x="40.8015" y="23.6233" curve="-90"/>
<vertex x="40.6745" y="23.4963"/>
<vertex x="40.1538" y="23.4963" curve="90"/>
<vertex x="40.2554" y="23.3947"/>
<vertex x="40.5094" y="23.3947"/>
<vertex x="40.5602" y="23.3693"/>
<vertex x="40.7126" y="23.1534"/>
<vertex x="40.8015" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="40.8015" y="22.4676" curve="-90"/>
<vertex x="39.9379" y="21.604"/>
<vertex x="39.9125" y="21.604" curve="-90"/>
<vertex x="39.0489" y="22.4676"/>
<vertex x="39.0489" y="22.7724"/>
<vertex x="39.0743" y="22.9629"/>
<vertex x="39.1378" y="23.1534"/>
<vertex x="39.2902" y="23.3693"/>
<vertex x="39.341" y="23.3947"/>
<vertex x="39.595" y="23.3947" curve="90"/>
<vertex x="39.6966" y="23.4963"/>
<vertex x="39.1759" y="23.4963" curve="-90"/>
<vertex x="39.0489" y="23.6233"/>
<vertex x="39.0489" y="24.4742" curve="-90"/>
<vertex x="39.1759" y="24.6012"/>
<vertex x="40.6745" y="24.6012" curve="-90"/>
<vertex x="40.8015" y="24.4742"/>
<vertex x="40.8015" y="23.6233" curve="-90"/>
<vertex x="40.6745" y="23.4963"/>
<vertex x="40.1538" y="23.4963" curve="90"/>
<vertex x="40.2554" y="23.3947"/>
<vertex x="40.5094" y="23.3947"/>
<vertex x="40.5602" y="23.3693"/>
<vertex x="40.7126" y="23.1534"/>
<vertex x="40.8015" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="38.2615" y="22.4676" curve="-90"/>
<vertex x="37.3979" y="21.604"/>
<vertex x="37.3725" y="21.604" curve="-90"/>
<vertex x="36.5089" y="22.4676"/>
<vertex x="36.5089" y="22.7724"/>
<vertex x="36.5343" y="22.9629"/>
<vertex x="36.5978" y="23.1534"/>
<vertex x="36.7502" y="23.3693"/>
<vertex x="36.801" y="23.3947"/>
<vertex x="37.055" y="23.3947" curve="90"/>
<vertex x="37.1566" y="23.4963"/>
<vertex x="36.6359" y="23.4963" curve="-90"/>
<vertex x="36.5089" y="23.6233"/>
<vertex x="36.5089" y="24.4742" curve="-90"/>
<vertex x="36.6359" y="24.6012"/>
<vertex x="38.1345" y="24.6012" curve="-90"/>
<vertex x="38.2615" y="24.4742"/>
<vertex x="38.2615" y="23.6233" curve="-90"/>
<vertex x="38.1345" y="23.4963"/>
<vertex x="37.6138" y="23.4963" curve="90"/>
<vertex x="37.7154" y="23.3947"/>
<vertex x="37.9694" y="23.3947"/>
<vertex x="38.0202" y="23.3693"/>
<vertex x="38.1726" y="23.1534"/>
<vertex x="38.2615" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="38.2615" y="22.4676" curve="-90"/>
<vertex x="37.3979" y="21.604"/>
<vertex x="37.3725" y="21.604" curve="-90"/>
<vertex x="36.5089" y="22.4676"/>
<vertex x="36.5089" y="22.7724"/>
<vertex x="36.5343" y="22.9629"/>
<vertex x="36.5978" y="23.1534"/>
<vertex x="36.7502" y="23.3693"/>
<vertex x="36.801" y="23.3947"/>
<vertex x="37.055" y="23.3947" curve="90"/>
<vertex x="37.1566" y="23.4963"/>
<vertex x="36.6359" y="23.4963" curve="-90"/>
<vertex x="36.5089" y="23.6233"/>
<vertex x="36.5089" y="24.4742" curve="-90"/>
<vertex x="36.6359" y="24.6012"/>
<vertex x="38.1345" y="24.6012" curve="-90"/>
<vertex x="38.2615" y="24.4742"/>
<vertex x="38.2615" y="23.6233" curve="-90"/>
<vertex x="38.1345" y="23.4963"/>
<vertex x="37.6138" y="23.4963" curve="90"/>
<vertex x="37.7154" y="23.3947"/>
<vertex x="37.9694" y="23.3947"/>
<vertex x="38.0202" y="23.3693"/>
<vertex x="38.1726" y="23.1534"/>
<vertex x="38.2615" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="35.7215" y="22.4676" curve="-90"/>
<vertex x="34.8579" y="21.604"/>
<vertex x="34.8325" y="21.604" curve="-90"/>
<vertex x="33.9689" y="22.4676"/>
<vertex x="33.9689" y="22.7724"/>
<vertex x="33.9943" y="22.9629"/>
<vertex x="34.0578" y="23.1534"/>
<vertex x="34.2102" y="23.3693"/>
<vertex x="34.261" y="23.3947"/>
<vertex x="34.515" y="23.3947" curve="90"/>
<vertex x="34.6166" y="23.4963"/>
<vertex x="34.0959" y="23.4963" curve="-90"/>
<vertex x="33.9689" y="23.6233"/>
<vertex x="33.9689" y="24.4742" curve="-90"/>
<vertex x="34.0959" y="24.6012"/>
<vertex x="35.5945" y="24.6012" curve="-90"/>
<vertex x="35.7215" y="24.4742"/>
<vertex x="35.7215" y="23.6233" curve="-90"/>
<vertex x="35.5945" y="23.4963"/>
<vertex x="35.0738" y="23.4963" curve="90"/>
<vertex x="35.1754" y="23.3947"/>
<vertex x="35.4294" y="23.3947"/>
<vertex x="35.4802" y="23.3693"/>
<vertex x="35.6326" y="23.1534"/>
<vertex x="35.7215" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="35.7215" y="22.4676" curve="-90"/>
<vertex x="34.8579" y="21.604"/>
<vertex x="34.8325" y="21.604" curve="-90"/>
<vertex x="33.9689" y="22.4676"/>
<vertex x="33.9689" y="22.7724"/>
<vertex x="33.9943" y="22.9629"/>
<vertex x="34.0578" y="23.1534"/>
<vertex x="34.2102" y="23.3693"/>
<vertex x="34.261" y="23.3947"/>
<vertex x="34.515" y="23.3947" curve="90"/>
<vertex x="34.6166" y="23.4963"/>
<vertex x="34.0959" y="23.4963" curve="-90"/>
<vertex x="33.9689" y="23.6233"/>
<vertex x="33.9689" y="24.4742" curve="-90"/>
<vertex x="34.0959" y="24.6012"/>
<vertex x="35.5945" y="24.6012" curve="-90"/>
<vertex x="35.7215" y="24.4742"/>
<vertex x="35.7215" y="23.6233" curve="-90"/>
<vertex x="35.5945" y="23.4963"/>
<vertex x="35.0738" y="23.4963" curve="90"/>
<vertex x="35.1754" y="23.3947"/>
<vertex x="35.4294" y="23.3947"/>
<vertex x="35.4802" y="23.3693"/>
<vertex x="35.6326" y="23.1534"/>
<vertex x="35.7215" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="33.1815" y="22.4676" curve="-90"/>
<vertex x="32.3179" y="21.604"/>
<vertex x="32.2925" y="21.604" curve="-90"/>
<vertex x="31.4289" y="22.4676"/>
<vertex x="31.4289" y="22.7724"/>
<vertex x="31.4543" y="22.9629"/>
<vertex x="31.5178" y="23.1534"/>
<vertex x="31.6702" y="23.3693"/>
<vertex x="31.721" y="23.3947"/>
<vertex x="31.975" y="23.3947" curve="90"/>
<vertex x="32.0766" y="23.4963"/>
<vertex x="31.5559" y="23.4963" curve="-90"/>
<vertex x="31.4289" y="23.6233"/>
<vertex x="31.4289" y="24.4742" curve="-90"/>
<vertex x="31.5559" y="24.6012"/>
<vertex x="33.0545" y="24.6012" curve="-90"/>
<vertex x="33.1815" y="24.4742"/>
<vertex x="33.1815" y="23.6233" curve="-90"/>
<vertex x="33.0545" y="23.4963"/>
<vertex x="32.5338" y="23.4963" curve="90"/>
<vertex x="32.6354" y="23.3947"/>
<vertex x="32.8894" y="23.3947"/>
<vertex x="32.9402" y="23.3693"/>
<vertex x="33.0926" y="23.1534"/>
<vertex x="33.1815" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="33.1815" y="22.4676" curve="-90"/>
<vertex x="32.3179" y="21.604"/>
<vertex x="32.2925" y="21.604" curve="-90"/>
<vertex x="31.4289" y="22.4676"/>
<vertex x="31.4289" y="22.7724"/>
<vertex x="31.4543" y="22.9629"/>
<vertex x="31.5178" y="23.1534"/>
<vertex x="31.6702" y="23.3693"/>
<vertex x="31.721" y="23.3947"/>
<vertex x="31.975" y="23.3947" curve="90"/>
<vertex x="32.0766" y="23.4963"/>
<vertex x="31.5559" y="23.4963" curve="-90"/>
<vertex x="31.4289" y="23.6233"/>
<vertex x="31.4289" y="24.4742" curve="-90"/>
<vertex x="31.5559" y="24.6012"/>
<vertex x="33.0545" y="24.6012" curve="-90"/>
<vertex x="33.1815" y="24.4742"/>
<vertex x="33.1815" y="23.6233" curve="-90"/>
<vertex x="33.0545" y="23.4963"/>
<vertex x="32.5338" y="23.4963" curve="90"/>
<vertex x="32.6354" y="23.3947"/>
<vertex x="32.8894" y="23.3947"/>
<vertex x="32.9402" y="23.3693"/>
<vertex x="33.0926" y="23.1534"/>
<vertex x="33.1815" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="30.6415" y="22.4676" curve="-90"/>
<vertex x="29.7779" y="21.604"/>
<vertex x="29.7525" y="21.604" curve="-90"/>
<vertex x="28.8889" y="22.4676"/>
<vertex x="28.8889" y="22.7724"/>
<vertex x="28.9143" y="22.9629"/>
<vertex x="28.9778" y="23.1534"/>
<vertex x="29.1302" y="23.3693"/>
<vertex x="29.181" y="23.3947"/>
<vertex x="29.435" y="23.3947" curve="90"/>
<vertex x="29.5366" y="23.4963"/>
<vertex x="29.0159" y="23.4963" curve="-90"/>
<vertex x="28.8889" y="23.6233"/>
<vertex x="28.8889" y="24.4742" curve="-90"/>
<vertex x="29.0159" y="24.6012"/>
<vertex x="30.5145" y="24.6012" curve="-90"/>
<vertex x="30.6415" y="24.4742"/>
<vertex x="30.6415" y="23.6233" curve="-90"/>
<vertex x="30.5145" y="23.4963"/>
<vertex x="29.9938" y="23.4963" curve="90"/>
<vertex x="30.0954" y="23.3947"/>
<vertex x="30.3494" y="23.3947"/>
<vertex x="30.4002" y="23.3693"/>
<vertex x="30.5526" y="23.1534"/>
<vertex x="30.6415" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="30.6415" y="22.4676" curve="-90"/>
<vertex x="29.7779" y="21.604"/>
<vertex x="29.7525" y="21.604" curve="-90"/>
<vertex x="28.8889" y="22.4676"/>
<vertex x="28.8889" y="22.7724"/>
<vertex x="28.9143" y="22.9629"/>
<vertex x="28.9778" y="23.1534"/>
<vertex x="29.1302" y="23.3693"/>
<vertex x="29.181" y="23.3947"/>
<vertex x="29.435" y="23.3947" curve="90"/>
<vertex x="29.5366" y="23.4963"/>
<vertex x="29.0159" y="23.4963" curve="-90"/>
<vertex x="28.8889" y="23.6233"/>
<vertex x="28.8889" y="24.4742" curve="-90"/>
<vertex x="29.0159" y="24.6012"/>
<vertex x="30.5145" y="24.6012" curve="-90"/>
<vertex x="30.6415" y="24.4742"/>
<vertex x="30.6415" y="23.6233" curve="-90"/>
<vertex x="30.5145" y="23.4963"/>
<vertex x="29.9938" y="23.4963" curve="90"/>
<vertex x="30.0954" y="23.3947"/>
<vertex x="30.3494" y="23.3947"/>
<vertex x="30.4002" y="23.3693"/>
<vertex x="30.5526" y="23.1534"/>
<vertex x="30.6415" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="28.1015" y="22.4676" curve="-90"/>
<vertex x="27.2379" y="21.604"/>
<vertex x="27.2125" y="21.604" curve="-90"/>
<vertex x="26.3489" y="22.4676"/>
<vertex x="26.3489" y="22.7724"/>
<vertex x="26.3743" y="22.9629"/>
<vertex x="26.4378" y="23.1534"/>
<vertex x="26.5902" y="23.3693"/>
<vertex x="26.641" y="23.3947"/>
<vertex x="26.895" y="23.3947" curve="90"/>
<vertex x="26.9966" y="23.4963"/>
<vertex x="26.4759" y="23.4963" curve="-90"/>
<vertex x="26.3489" y="23.6233"/>
<vertex x="26.3489" y="24.4742" curve="-90"/>
<vertex x="26.4759" y="24.6012"/>
<vertex x="27.9745" y="24.6012" curve="-90"/>
<vertex x="28.1015" y="24.4742"/>
<vertex x="28.1015" y="23.6233" curve="-90"/>
<vertex x="27.9745" y="23.4963"/>
<vertex x="27.4538" y="23.4963" curve="90"/>
<vertex x="27.5554" y="23.3947"/>
<vertex x="27.8094" y="23.3947"/>
<vertex x="27.8602" y="23.3693"/>
<vertex x="28.0126" y="23.1534"/>
<vertex x="28.1015" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="28.1015" y="22.4676" curve="-90"/>
<vertex x="27.2379" y="21.604"/>
<vertex x="27.2125" y="21.604" curve="-90"/>
<vertex x="26.3489" y="22.4676"/>
<vertex x="26.3489" y="22.7724"/>
<vertex x="26.3743" y="22.9629"/>
<vertex x="26.4378" y="23.1534"/>
<vertex x="26.5902" y="23.3693"/>
<vertex x="26.641" y="23.3947"/>
<vertex x="26.895" y="23.3947" curve="90"/>
<vertex x="26.9966" y="23.4963"/>
<vertex x="26.4759" y="23.4963" curve="-90"/>
<vertex x="26.3489" y="23.6233"/>
<vertex x="26.3489" y="24.4742" curve="-90"/>
<vertex x="26.4759" y="24.6012"/>
<vertex x="27.9745" y="24.6012" curve="-90"/>
<vertex x="28.1015" y="24.4742"/>
<vertex x="28.1015" y="23.6233" curve="-90"/>
<vertex x="27.9745" y="23.4963"/>
<vertex x="27.4538" y="23.4963" curve="90"/>
<vertex x="27.5554" y="23.3947"/>
<vertex x="27.8094" y="23.3947"/>
<vertex x="27.8602" y="23.3693"/>
<vertex x="28.0126" y="23.1534"/>
<vertex x="28.1015" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="25.5615" y="22.4676" curve="-90"/>
<vertex x="24.6979" y="21.604"/>
<vertex x="24.6725" y="21.604" curve="-90"/>
<vertex x="23.8089" y="22.4676"/>
<vertex x="23.8089" y="22.7724"/>
<vertex x="23.8343" y="22.9629"/>
<vertex x="23.8978" y="23.1534"/>
<vertex x="24.0502" y="23.3693"/>
<vertex x="24.101" y="23.3947"/>
<vertex x="24.355" y="23.3947" curve="90"/>
<vertex x="24.4566" y="23.4963"/>
<vertex x="23.9359" y="23.4963" curve="-90"/>
<vertex x="23.8089" y="23.6233"/>
<vertex x="23.8089" y="24.4742" curve="-90"/>
<vertex x="23.9359" y="24.6012"/>
<vertex x="25.4345" y="24.6012" curve="-90"/>
<vertex x="25.5615" y="24.4742"/>
<vertex x="25.5615" y="23.6233" curve="-90"/>
<vertex x="25.4345" y="23.4963"/>
<vertex x="24.9138" y="23.4963" curve="90"/>
<vertex x="25.0154" y="23.3947"/>
<vertex x="25.2694" y="23.3947"/>
<vertex x="25.3202" y="23.3693"/>
<vertex x="25.4726" y="23.1534"/>
<vertex x="25.5615" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="25.5615" y="22.4676" curve="-90"/>
<vertex x="24.6979" y="21.604"/>
<vertex x="24.6725" y="21.604" curve="-90"/>
<vertex x="23.8089" y="22.4676"/>
<vertex x="23.8089" y="22.7724"/>
<vertex x="23.8343" y="22.9629"/>
<vertex x="23.8978" y="23.1534"/>
<vertex x="24.0502" y="23.3693"/>
<vertex x="24.101" y="23.3947"/>
<vertex x="24.355" y="23.3947" curve="90"/>
<vertex x="24.4566" y="23.4963"/>
<vertex x="23.9359" y="23.4963" curve="-90"/>
<vertex x="23.8089" y="23.6233"/>
<vertex x="23.8089" y="24.4742" curve="-90"/>
<vertex x="23.9359" y="24.6012"/>
<vertex x="25.4345" y="24.6012" curve="-90"/>
<vertex x="25.5615" y="24.4742"/>
<vertex x="25.5615" y="23.6233" curve="-90"/>
<vertex x="25.4345" y="23.4963"/>
<vertex x="24.9138" y="23.4963" curve="90"/>
<vertex x="25.0154" y="23.3947"/>
<vertex x="25.2694" y="23.3947"/>
<vertex x="25.3202" y="23.3693"/>
<vertex x="25.4726" y="23.1534"/>
<vertex x="25.5615" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="23.0215" y="22.4676" curve="-90"/>
<vertex x="22.1579" y="21.604"/>
<vertex x="22.1325" y="21.604" curve="-90"/>
<vertex x="21.2689" y="22.4676"/>
<vertex x="21.2689" y="22.7724"/>
<vertex x="21.2943" y="22.9629"/>
<vertex x="21.3578" y="23.1534"/>
<vertex x="21.5102" y="23.3693"/>
<vertex x="21.561" y="23.3947"/>
<vertex x="21.815" y="23.3947" curve="90"/>
<vertex x="21.9166" y="23.4963"/>
<vertex x="21.3959" y="23.4963" curve="-90"/>
<vertex x="21.2689" y="23.6233"/>
<vertex x="21.2689" y="24.4742" curve="-90"/>
<vertex x="21.3959" y="24.6012"/>
<vertex x="22.8945" y="24.6012" curve="-90"/>
<vertex x="23.0215" y="24.4742"/>
<vertex x="23.0215" y="23.6233" curve="-90"/>
<vertex x="22.8945" y="23.4963"/>
<vertex x="22.3738" y="23.4963" curve="90"/>
<vertex x="22.4754" y="23.3947"/>
<vertex x="22.7294" y="23.3947"/>
<vertex x="22.7802" y="23.3693"/>
<vertex x="22.9326" y="23.1534"/>
<vertex x="23.0215" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="30">
<vertex x="23.0215" y="22.4676" curve="-90"/>
<vertex x="22.1579" y="21.604"/>
<vertex x="22.1325" y="21.604" curve="-90"/>
<vertex x="21.2689" y="22.4676"/>
<vertex x="21.2689" y="22.7724"/>
<vertex x="21.2943" y="22.9629"/>
<vertex x="21.3578" y="23.1534"/>
<vertex x="21.5102" y="23.3693"/>
<vertex x="21.561" y="23.3947"/>
<vertex x="21.815" y="23.3947" curve="90"/>
<vertex x="21.9166" y="23.4963"/>
<vertex x="21.3959" y="23.4963" curve="-90"/>
<vertex x="21.2689" y="23.6233"/>
<vertex x="21.2689" y="24.4742" curve="-90"/>
<vertex x="21.3959" y="24.6012"/>
<vertex x="22.8945" y="24.6012" curve="-90"/>
<vertex x="23.0215" y="24.4742"/>
<vertex x="23.0215" y="23.6233" curve="-90"/>
<vertex x="22.8945" y="23.4963"/>
<vertex x="22.3738" y="23.4963" curve="90"/>
<vertex x="22.4754" y="23.3947"/>
<vertex x="22.7294" y="23.3947"/>
<vertex x="22.7802" y="23.3693"/>
<vertex x="22.9326" y="23.1534"/>
<vertex x="23.0215" y="22.7724"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="53.5015" y="22.7597"/>
<vertex x="53.5015" y="22.493" curve="-90"/>
<vertex x="52.6252" y="21.604" curve="-90"/>
<vertex x="51.7489" y="22.493"/>
<vertex x="51.7489" y="22.7597" curve="-90"/>
<vertex x="52.6252" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="50.9615" y="22.7597"/>
<vertex x="50.9615" y="22.493" curve="-90"/>
<vertex x="50.0852" y="21.604" curve="-90"/>
<vertex x="49.2089" y="22.493"/>
<vertex x="49.2089" y="22.7597" curve="-90"/>
<vertex x="50.0852" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="48.4215" y="22.7597"/>
<vertex x="48.4215" y="22.493" curve="-90"/>
<vertex x="47.5452" y="21.604" curve="-90"/>
<vertex x="46.6689" y="22.493"/>
<vertex x="46.6689" y="22.7597" curve="-90"/>
<vertex x="47.5452" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="45.8815" y="22.7597"/>
<vertex x="45.8815" y="22.493" curve="-90"/>
<vertex x="45.0052" y="21.604" curve="-90"/>
<vertex x="44.1289" y="22.493"/>
<vertex x="44.1289" y="22.7597" curve="-90"/>
<vertex x="45.0052" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="43.3415" y="22.7597"/>
<vertex x="43.3415" y="22.493" curve="-90"/>
<vertex x="42.4652" y="21.604" curve="-90"/>
<vertex x="41.5889" y="22.493"/>
<vertex x="41.5889" y="22.7597" curve="-90"/>
<vertex x="42.4652" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="40.8015" y="22.7597"/>
<vertex x="40.8015" y="22.493" curve="-90"/>
<vertex x="39.9252" y="21.604" curve="-90"/>
<vertex x="39.0489" y="22.493"/>
<vertex x="39.0489" y="22.7597" curve="-90"/>
<vertex x="39.9252" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="38.2615" y="22.7597"/>
<vertex x="38.2615" y="22.493" curve="-90"/>
<vertex x="37.3852" y="21.604" curve="-90"/>
<vertex x="36.5089" y="22.493"/>
<vertex x="36.5089" y="22.7597" curve="-90"/>
<vertex x="37.3852" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="35.7215" y="22.7597"/>
<vertex x="35.7215" y="22.493" curve="-90"/>
<vertex x="34.8452" y="21.604" curve="-90"/>
<vertex x="33.9689" y="22.493"/>
<vertex x="33.9689" y="22.7597" curve="-90"/>
<vertex x="34.8452" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="33.1815" y="22.7597"/>
<vertex x="33.1815" y="22.493" curve="-90"/>
<vertex x="32.3052" y="21.604" curve="-90"/>
<vertex x="31.4289" y="22.493"/>
<vertex x="31.4289" y="22.7597" curve="-90"/>
<vertex x="32.3052" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="30.6415" y="22.7597"/>
<vertex x="30.6415" y="22.493" curve="-90"/>
<vertex x="29.7652" y="21.604" curve="-90"/>
<vertex x="28.8889" y="22.493"/>
<vertex x="28.8889" y="22.7597" curve="-90"/>
<vertex x="29.7652" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="28.1015" y="22.7597"/>
<vertex x="28.1015" y="22.493" curve="-90"/>
<vertex x="27.2252" y="21.604" curve="-90"/>
<vertex x="26.3489" y="22.493"/>
<vertex x="26.3489" y="22.7597" curve="-90"/>
<vertex x="27.2252" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="25.5615" y="22.7597"/>
<vertex x="25.5615" y="22.493" curve="-90"/>
<vertex x="24.6852" y="21.604" curve="-90"/>
<vertex x="23.8089" y="22.493"/>
<vertex x="23.8089" y="22.7597" curve="-90"/>
<vertex x="24.6852" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.0254" layer="29">
<vertex x="23.0215" y="22.7597"/>
<vertex x="23.0215" y="22.493" curve="-90"/>
<vertex x="22.1452" y="21.604" curve="-90"/>
<vertex x="21.2689" y="22.493"/>
<vertex x="21.2689" y="22.7597" curve="-90"/>
<vertex x="22.1452" y="23.636" curve="-90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="52.6252" y="21.731" curve="90"/>
<vertex x="53.3745" y="22.4803"/>
<vertex x="53.3745" y="22.7851"/>
<vertex x="53.3491" y="22.9375"/>
<vertex x="53.2983" y="23.1026"/>
<vertex x="53.184" y="23.2677"/>
<vertex x="52.9427" y="23.2677" curve="-90"/>
<vertex x="52.7268" y="23.4836"/>
<vertex x="52.7268" y="23.6106" curve="-90"/>
<vertex x="52.7395" y="23.6233"/>
<vertex x="53.3745" y="23.6233"/>
<vertex x="53.3745" y="24.4742"/>
<vertex x="51.8759" y="24.4742"/>
<vertex x="51.8759" y="23.6233"/>
<vertex x="52.5236" y="23.6233"/>
<vertex x="52.5236" y="23.4836" curve="-90"/>
<vertex x="52.3077" y="23.2677"/>
<vertex x="52.0664" y="23.2677"/>
<vertex x="51.9521" y="23.1026"/>
<vertex x="51.9013" y="22.9375"/>
<vertex x="51.8759" y="22.7851"/>
<vertex x="51.8759" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="22.1452" y="21.731" curve="90"/>
<vertex x="22.8945" y="22.4803"/>
<vertex x="22.8945" y="22.7851"/>
<vertex x="22.8691" y="22.9375"/>
<vertex x="22.8183" y="23.1026"/>
<vertex x="22.704" y="23.2677"/>
<vertex x="22.4627" y="23.2677" curve="-90"/>
<vertex x="22.2468" y="23.4836"/>
<vertex x="22.2468" y="23.6106" curve="-90"/>
<vertex x="22.2595" y="23.6233"/>
<vertex x="22.8945" y="23.6233"/>
<vertex x="22.8945" y="24.4742"/>
<vertex x="21.3959" y="24.4742"/>
<vertex x="21.3959" y="23.6233"/>
<vertex x="22.0436" y="23.6233"/>
<vertex x="22.0436" y="23.4836" curve="-90"/>
<vertex x="21.8277" y="23.2677"/>
<vertex x="21.5864" y="23.2677"/>
<vertex x="21.4721" y="23.1026"/>
<vertex x="21.4213" y="22.9375"/>
<vertex x="21.3959" y="22.7851"/>
<vertex x="21.3959" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="50.0852" y="21.731" curve="90"/>
<vertex x="50.8345" y="22.4803"/>
<vertex x="50.8345" y="22.7851"/>
<vertex x="50.8091" y="22.9375"/>
<vertex x="50.7583" y="23.1026"/>
<vertex x="50.644" y="23.2677"/>
<vertex x="50.4027" y="23.2677" curve="-90"/>
<vertex x="50.1868" y="23.4836"/>
<vertex x="50.1868" y="23.6106" curve="-90"/>
<vertex x="50.1995" y="23.6233"/>
<vertex x="50.8345" y="23.6233"/>
<vertex x="50.8345" y="24.4742"/>
<vertex x="49.3359" y="24.4742"/>
<vertex x="49.3359" y="23.6233"/>
<vertex x="49.9836" y="23.6233"/>
<vertex x="49.9836" y="23.4836" curve="-90"/>
<vertex x="49.7677" y="23.2677"/>
<vertex x="49.5264" y="23.2677"/>
<vertex x="49.4121" y="23.1026"/>
<vertex x="49.3613" y="22.9375"/>
<vertex x="49.3359" y="22.7851"/>
<vertex x="49.3359" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="47.5452" y="21.731" curve="90"/>
<vertex x="48.2945" y="22.4803"/>
<vertex x="48.2945" y="22.7851"/>
<vertex x="48.2691" y="22.9375"/>
<vertex x="48.2183" y="23.1026"/>
<vertex x="48.104" y="23.2677"/>
<vertex x="47.8627" y="23.2677" curve="-90"/>
<vertex x="47.6468" y="23.4836"/>
<vertex x="47.6468" y="23.6106" curve="-90"/>
<vertex x="47.6595" y="23.6233"/>
<vertex x="48.2945" y="23.6233"/>
<vertex x="48.2945" y="24.4742"/>
<vertex x="46.7959" y="24.4742"/>
<vertex x="46.7959" y="23.6233"/>
<vertex x="47.4436" y="23.6233"/>
<vertex x="47.4436" y="23.4836" curve="-90"/>
<vertex x="47.2277" y="23.2677"/>
<vertex x="46.9864" y="23.2677"/>
<vertex x="46.8721" y="23.1026"/>
<vertex x="46.8213" y="22.9375"/>
<vertex x="46.7959" y="22.7851"/>
<vertex x="46.7959" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="45.0052" y="21.731" curve="90"/>
<vertex x="45.7545" y="22.4803"/>
<vertex x="45.7545" y="22.7851"/>
<vertex x="45.7291" y="22.9375"/>
<vertex x="45.6783" y="23.1026"/>
<vertex x="45.564" y="23.2677"/>
<vertex x="45.3227" y="23.2677" curve="-90"/>
<vertex x="45.1068" y="23.4836"/>
<vertex x="45.1068" y="23.6106" curve="-90"/>
<vertex x="45.1195" y="23.6233"/>
<vertex x="45.7545" y="23.6233"/>
<vertex x="45.7545" y="24.4742"/>
<vertex x="44.2559" y="24.4742"/>
<vertex x="44.2559" y="23.6233"/>
<vertex x="44.9036" y="23.6233"/>
<vertex x="44.9036" y="23.4836" curve="-90"/>
<vertex x="44.6877" y="23.2677"/>
<vertex x="44.4464" y="23.2677"/>
<vertex x="44.3321" y="23.1026"/>
<vertex x="44.2813" y="22.9375"/>
<vertex x="44.2559" y="22.7851"/>
<vertex x="44.2559" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="42.4652" y="21.731" curve="90"/>
<vertex x="43.2145" y="22.4803"/>
<vertex x="43.2145" y="22.7851"/>
<vertex x="43.1891" y="22.9375"/>
<vertex x="43.1383" y="23.1026"/>
<vertex x="43.024" y="23.2677"/>
<vertex x="42.7827" y="23.2677" curve="-90"/>
<vertex x="42.5668" y="23.4836"/>
<vertex x="42.5668" y="23.6106" curve="-90"/>
<vertex x="42.5795" y="23.6233"/>
<vertex x="43.2145" y="23.6233"/>
<vertex x="43.2145" y="24.4742"/>
<vertex x="41.7159" y="24.4742"/>
<vertex x="41.7159" y="23.6233"/>
<vertex x="42.3636" y="23.6233"/>
<vertex x="42.3636" y="23.4836" curve="-90"/>
<vertex x="42.1477" y="23.2677"/>
<vertex x="41.9064" y="23.2677"/>
<vertex x="41.7921" y="23.1026"/>
<vertex x="41.7413" y="22.9375"/>
<vertex x="41.7159" y="22.7851"/>
<vertex x="41.7159" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="39.9252" y="21.731" curve="90"/>
<vertex x="40.6745" y="22.4803"/>
<vertex x="40.6745" y="22.7851"/>
<vertex x="40.6491" y="22.9375"/>
<vertex x="40.5983" y="23.1026"/>
<vertex x="40.484" y="23.2677"/>
<vertex x="40.2427" y="23.2677" curve="-90"/>
<vertex x="40.0268" y="23.4836"/>
<vertex x="40.0268" y="23.6106" curve="-90"/>
<vertex x="40.0395" y="23.6233"/>
<vertex x="40.6745" y="23.6233"/>
<vertex x="40.6745" y="24.4742"/>
<vertex x="39.1759" y="24.4742"/>
<vertex x="39.1759" y="23.6233"/>
<vertex x="39.8236" y="23.6233"/>
<vertex x="39.8236" y="23.4836" curve="-90"/>
<vertex x="39.6077" y="23.2677"/>
<vertex x="39.3664" y="23.2677"/>
<vertex x="39.2521" y="23.1026"/>
<vertex x="39.2013" y="22.9375"/>
<vertex x="39.1759" y="22.7851"/>
<vertex x="39.1759" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="37.3852" y="21.731" curve="90"/>
<vertex x="38.1345" y="22.4803"/>
<vertex x="38.1345" y="22.7851"/>
<vertex x="38.1091" y="22.9375"/>
<vertex x="38.0583" y="23.1026"/>
<vertex x="37.944" y="23.2677"/>
<vertex x="37.7027" y="23.2677" curve="-90"/>
<vertex x="37.4868" y="23.4836"/>
<vertex x="37.4868" y="23.6106" curve="-90"/>
<vertex x="37.4995" y="23.6233"/>
<vertex x="38.1345" y="23.6233"/>
<vertex x="38.1345" y="24.4742"/>
<vertex x="36.6359" y="24.4742"/>
<vertex x="36.6359" y="23.6233"/>
<vertex x="37.2836" y="23.6233"/>
<vertex x="37.2836" y="23.4836" curve="-90"/>
<vertex x="37.0677" y="23.2677"/>
<vertex x="36.8264" y="23.2677"/>
<vertex x="36.7121" y="23.1026"/>
<vertex x="36.6613" y="22.9375"/>
<vertex x="36.6359" y="22.7851"/>
<vertex x="36.6359" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="34.8452" y="21.731" curve="90"/>
<vertex x="35.5945" y="22.4803"/>
<vertex x="35.5945" y="22.7851"/>
<vertex x="35.5691" y="22.9375"/>
<vertex x="35.5183" y="23.1026"/>
<vertex x="35.404" y="23.2677"/>
<vertex x="35.1627" y="23.2677" curve="-90"/>
<vertex x="34.9468" y="23.4836"/>
<vertex x="34.9468" y="23.6106" curve="-90"/>
<vertex x="34.9595" y="23.6233"/>
<vertex x="35.5945" y="23.6233"/>
<vertex x="35.5945" y="24.4742"/>
<vertex x="34.0959" y="24.4742"/>
<vertex x="34.0959" y="23.6233"/>
<vertex x="34.7436" y="23.6233"/>
<vertex x="34.7436" y="23.4836" curve="-90"/>
<vertex x="34.5277" y="23.2677"/>
<vertex x="34.2864" y="23.2677"/>
<vertex x="34.1721" y="23.1026"/>
<vertex x="34.1213" y="22.9375"/>
<vertex x="34.0959" y="22.7851"/>
<vertex x="34.0959" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="29.7652" y="21.731" curve="90"/>
<vertex x="30.5145" y="22.4803"/>
<vertex x="30.5145" y="22.7851"/>
<vertex x="30.4891" y="22.9375"/>
<vertex x="30.4383" y="23.1026"/>
<vertex x="30.324" y="23.2677"/>
<vertex x="30.0827" y="23.2677" curve="-90"/>
<vertex x="29.8668" y="23.4836"/>
<vertex x="29.8668" y="23.6106" curve="-90"/>
<vertex x="29.8795" y="23.6233"/>
<vertex x="30.5145" y="23.6233"/>
<vertex x="30.5145" y="24.4742"/>
<vertex x="29.0159" y="24.4742"/>
<vertex x="29.0159" y="23.6233"/>
<vertex x="29.6636" y="23.6233"/>
<vertex x="29.6636" y="23.4836" curve="-90"/>
<vertex x="29.4477" y="23.2677"/>
<vertex x="29.2064" y="23.2677"/>
<vertex x="29.0921" y="23.1026"/>
<vertex x="29.0413" y="22.9375"/>
<vertex x="29.0159" y="22.7851"/>
<vertex x="29.0159" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="27.2252" y="21.731" curve="90"/>
<vertex x="27.9745" y="22.4803"/>
<vertex x="27.9745" y="22.7851"/>
<vertex x="27.9491" y="22.9375"/>
<vertex x="27.8983" y="23.1026"/>
<vertex x="27.784" y="23.2677"/>
<vertex x="27.5427" y="23.2677" curve="-90"/>
<vertex x="27.3268" y="23.4836"/>
<vertex x="27.3268" y="23.6106" curve="-90"/>
<vertex x="27.3395" y="23.6233"/>
<vertex x="27.9745" y="23.6233"/>
<vertex x="27.9745" y="24.4742"/>
<vertex x="26.4759" y="24.4742"/>
<vertex x="26.4759" y="23.6233"/>
<vertex x="27.1236" y="23.6233"/>
<vertex x="27.1236" y="23.4836" curve="-90"/>
<vertex x="26.9077" y="23.2677"/>
<vertex x="26.6664" y="23.2677"/>
<vertex x="26.5521" y="23.1026"/>
<vertex x="26.5013" y="22.9375"/>
<vertex x="26.4759" y="22.7851"/>
<vertex x="26.4759" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="24.6852" y="21.731" curve="90"/>
<vertex x="25.4345" y="22.4803"/>
<vertex x="25.4345" y="22.7851"/>
<vertex x="25.4091" y="22.9375"/>
<vertex x="25.3583" y="23.1026"/>
<vertex x="25.244" y="23.2677"/>
<vertex x="25.0027" y="23.2677" curve="-90"/>
<vertex x="24.7868" y="23.4836"/>
<vertex x="24.7868" y="23.6106" curve="-90"/>
<vertex x="24.7995" y="23.6233"/>
<vertex x="25.4345" y="23.6233"/>
<vertex x="25.4345" y="24.4742"/>
<vertex x="23.9359" y="24.4742"/>
<vertex x="23.9359" y="23.6233"/>
<vertex x="24.5836" y="23.6233"/>
<vertex x="24.5836" y="23.4836" curve="-90"/>
<vertex x="24.3677" y="23.2677"/>
<vertex x="24.1264" y="23.2677"/>
<vertex x="24.0121" y="23.1026"/>
<vertex x="23.9613" y="22.9375"/>
<vertex x="23.9359" y="22.7851"/>
<vertex x="23.9359" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="32.3052" y="21.731" curve="90"/>
<vertex x="33.0545" y="22.4803"/>
<vertex x="33.0545" y="22.7851"/>
<vertex x="33.0291" y="22.9375"/>
<vertex x="32.9783" y="23.1026"/>
<vertex x="32.864" y="23.2677"/>
<vertex x="32.6227" y="23.2677" curve="-90"/>
<vertex x="32.4068" y="23.4836"/>
<vertex x="32.4068" y="23.6106" curve="-90"/>
<vertex x="32.4195" y="23.6233"/>
<vertex x="33.0545" y="23.6233"/>
<vertex x="33.0545" y="24.4742"/>
<vertex x="31.5559" y="24.4742"/>
<vertex x="31.5559" y="23.6233"/>
<vertex x="32.2036" y="23.6233"/>
<vertex x="32.2036" y="23.4836" curve="-90"/>
<vertex x="31.9877" y="23.2677"/>
<vertex x="31.7464" y="23.2677"/>
<vertex x="31.6321" y="23.1026"/>
<vertex x="31.5813" y="22.9375"/>
<vertex x="31.5559" y="22.7851"/>
<vertex x="31.5559" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="1">
<vertex x="55.9145" y="21.7183"/>
<vertex x="55.9145" y="23.2677"/>
<vertex x="55.4827" y="23.2677" curve="-90"/>
<vertex x="55.2668" y="23.4836"/>
<vertex x="55.2668" y="23.6106" curve="-90"/>
<vertex x="55.2795" y="23.6233"/>
<vertex x="55.9145" y="23.6233"/>
<vertex x="55.9145" y="24.4742"/>
<vertex x="54.4159" y="24.4742"/>
<vertex x="54.4159" y="23.6233"/>
<vertex x="55.0636" y="23.6233"/>
<vertex x="55.0636" y="23.4836" curve="-90"/>
<vertex x="54.8477" y="23.2677"/>
<vertex x="54.4159" y="23.2677"/>
<vertex x="54.4159" y="21.7183"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="52.6252" y="21.731" curve="90"/>
<vertex x="53.3745" y="22.4803"/>
<vertex x="53.3745" y="22.8232" curve="90"/>
<vertex x="52.6252" y="23.5725" curve="90"/>
<vertex x="51.8759" y="22.8232"/>
<vertex x="51.8759" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="54.4159" y="21.731"/>
<vertex x="55.9145" y="21.731"/>
<vertex x="55.9145" y="23.5217"/>
<vertex x="54.4159" y="23.5217"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="50.0852" y="21.731" curve="90"/>
<vertex x="50.8345" y="22.4803"/>
<vertex x="50.8345" y="22.8232" curve="90"/>
<vertex x="50.0852" y="23.5725" curve="90"/>
<vertex x="49.3359" y="22.8232"/>
<vertex x="49.3359" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="47.5452" y="21.731" curve="90"/>
<vertex x="48.2945" y="22.4803"/>
<vertex x="48.2945" y="22.8232" curve="90"/>
<vertex x="47.5452" y="23.5725" curve="90"/>
<vertex x="46.7959" y="22.8232"/>
<vertex x="46.7959" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="45.0052" y="21.731" curve="90"/>
<vertex x="45.7545" y="22.4803"/>
<vertex x="45.7545" y="22.8232" curve="90"/>
<vertex x="45.0052" y="23.5725" curve="90"/>
<vertex x="44.2559" y="22.8232"/>
<vertex x="44.2559" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="42.4652" y="21.731" curve="90"/>
<vertex x="43.2145" y="22.4803"/>
<vertex x="43.2145" y="22.8232" curve="90"/>
<vertex x="42.4652" y="23.5725" curve="90"/>
<vertex x="41.7159" y="22.8232"/>
<vertex x="41.7159" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="39.9252" y="21.731" curve="90"/>
<vertex x="40.6745" y="22.4803"/>
<vertex x="40.6745" y="22.8232" curve="90"/>
<vertex x="39.9252" y="23.5725" curve="90"/>
<vertex x="39.1759" y="22.8232"/>
<vertex x="39.1759" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="37.3852" y="21.731" curve="90"/>
<vertex x="38.1345" y="22.4803"/>
<vertex x="38.1345" y="22.8232" curve="90"/>
<vertex x="37.3852" y="23.5725" curve="90"/>
<vertex x="36.6359" y="22.8232"/>
<vertex x="36.6359" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="34.8452" y="21.731" curve="90"/>
<vertex x="35.5945" y="22.4803"/>
<vertex x="35.5945" y="22.8232" curve="90"/>
<vertex x="34.8452" y="23.5725" curve="90"/>
<vertex x="34.0959" y="22.8232"/>
<vertex x="34.0959" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="32.3052" y="21.731" curve="90"/>
<vertex x="33.0545" y="22.4803"/>
<vertex x="33.0545" y="22.8232" curve="90"/>
<vertex x="32.3052" y="23.5725" curve="90"/>
<vertex x="31.5559" y="22.8232"/>
<vertex x="31.5559" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="29.7652" y="21.731" curve="90"/>
<vertex x="30.5145" y="22.4803"/>
<vertex x="30.5145" y="22.8232" curve="90"/>
<vertex x="29.7652" y="23.5725" curve="90"/>
<vertex x="29.0159" y="22.8232"/>
<vertex x="29.0159" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="27.2252" y="21.731" curve="90"/>
<vertex x="27.9745" y="22.4803"/>
<vertex x="27.9745" y="22.8232" curve="90"/>
<vertex x="27.2252" y="23.5725" curve="90"/>
<vertex x="26.4759" y="22.8232"/>
<vertex x="26.4759" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="24.6852" y="21.731" curve="90"/>
<vertex x="25.4345" y="22.4803"/>
<vertex x="25.4345" y="22.8232" curve="90"/>
<vertex x="24.6852" y="23.5725" curve="90"/>
<vertex x="23.9359" y="22.8232"/>
<vertex x="23.9359" y="22.4803" curve="90"/>
</polygon>
<polygon width="0.127" layer="16">
<vertex x="22.1452" y="21.731" curve="90"/>
<vertex x="22.8945" y="22.4803"/>
<vertex x="22.8945" y="22.8232" curve="90"/>
<vertex x="22.1452" y="23.5725" curve="90"/>
<vertex x="21.3959" y="22.8232"/>
<vertex x="21.3959" y="22.4803" curve="90"/>
</polygon>
<hole x="2.25" y="2.25" drill="2.25"/>
<hole x="2.25" y="22.75" drill="2.25"/>
<hole x="59.25" y="22.75" drill="2.25"/>
<hole x="59.25" y="2.25" drill="2.25"/>
<wire x1="2.25" y1="0" x2="59.25" y2="0" width="0.1" layer="21"/>
<wire x1="59.25" y1="0" x2="61.5" y2="2.25" width="0.1" layer="21" curve="90"/>
<wire x1="61.5" y1="2.25" x2="61.5" y2="22.75" width="0.1" layer="21"/>
<wire x1="61.5" y1="22.75" x2="59.25" y2="25" width="0.1" layer="21" curve="90"/>
<wire x1="59.25" y1="25" x2="2.25" y2="25" width="0.1" layer="21"/>
<wire x1="2.25" y1="25" x2="0" y2="22.75" width="0.1" layer="21" curve="90"/>
<wire x1="0" y1="22.75" x2="0" y2="2.25" width="0.1" layer="21"/>
<wire x1="0" y1="2.25" x2="2.25" y2="0" width="0.1" layer="21" curve="90"/>
</package>
<package name="MKRBOARD-DIM">
<wire x1="0" y1="2.25" x2="2.25" y2="0" width="0.1" layer="20" curve="90"/>
<wire x1="2.25" y1="0" x2="59.25" y2="0" width="0.1" layer="20"/>
<wire x1="59.25" y1="0" x2="61.5" y2="2.25" width="0.1" layer="20" curve="90"/>
<wire x1="61.5" y1="2.25" x2="61.5" y2="22.75" width="0.1" layer="20"/>
<wire x1="61.5" y1="22.75" x2="59.25" y2="25" width="0.1" layer="20" curve="90"/>
<wire x1="59.25" y1="25" x2="2.25" y2="25" width="0.1" layer="20"/>
<wire x1="2.25" y1="25" x2="0" y2="22.75" width="0.1" layer="20" curve="90"/>
<wire x1="0" y1="22.75" x2="0" y2="2.25" width="0.1" layer="20"/>
<pad name="6" x="55.1548" y="22.66" drill="0.8" diameter="1.524" shape="square"/>
<pad name="AREF" x="22.1348" y="2.34" drill="0.8" diameter="1.524" shape="square"/>
<pad name="7" x="52.6148" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="8" x="50.0748" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="9" x="47.5348" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="10" x="44.9948" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="11" x="42.4548" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="12" x="39.9148" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="13" x="37.3748" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="14" x="34.8348" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="RST" x="32.2948" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="GND" x="29.7548" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="VCC" x="27.2148" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="VIN" x="24.6748" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="5V" x="22.1348" y="22.66" drill="0.8" diameter="1.524"/>
<pad name="A0" x="24.6748" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="A1" x="27.2148" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="A2" x="29.7548" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="A3" x="32.2948" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="A4" x="34.8348" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="A5" x="37.3748" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="A6" x="39.9148" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="0" x="42.4548" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="1" x="44.9948" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="2" x="47.5348" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="3" x="50.0748" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="4" x="52.6148" y="2.34" drill="0.8" diameter="1.524"/>
<pad name="5" x="55.1548" y="2.34" drill="0.8" diameter="1.524"/>
<hole x="59.25" y="2.25" drill="2.25"/>
<hole x="59.25" y="22.75" drill="2.25"/>
<hole x="2.25" y="2.25" drill="2.25"/>
<hole x="2.25" y="22.75" drill="2.25"/>
<text x="22.86" y="3.41" size="0.6096" layer="21" rot="R90">AREF</text>
<text x="25.4" y="3.41" size="0.6096" layer="21" rot="R90">DAC0/A0</text>
<text x="27.94" y="3.41" size="0.6096" layer="21" rot="R90">A1</text>
<text x="30.48" y="3.41" size="0.6096" layer="21" rot="R90">A2</text>
<text x="33.02" y="3.41" size="0.6096" layer="21" rot="R90">A3</text>
<text x="35.56" y="3.41" size="0.6096" layer="21" rot="R90">A4</text>
<text x="38.1" y="3.41" size="0.6096" layer="21" rot="R90">A5</text>
<text x="40.64" y="3.41" size="0.6096" layer="21" rot="R90">A6</text>
<text x="43.18" y="3.41" size="0.6096" layer="21" rot="R90">0</text>
<text x="45.72" y="3.41" size="0.6096" layer="21" rot="R90">1</text>
<text x="48.26" y="3.41" size="0.6096" layer="21" rot="R90">2</text>
<text x="50.8" y="3.41" size="0.6096" layer="21" rot="R90">3</text>
<text x="53.34" y="3.41" size="0.6096" layer="21" rot="R90">4</text>
<text x="55.88" y="3.41" size="0.6096" layer="21" rot="R90">5</text>
<text x="22.86" y="21.59" size="0.6096" layer="21" rot="R270" align="top-left">5V</text>
<text x="25.4" y="21.59" size="0.6096" layer="21" rot="R270" align="top-left">VIN</text>
<text x="27.94" y="21.59" size="0.6096" layer="21" rot="R270" align="top-left">VCC</text>
<text x="30.48" y="21.59" size="0.6096" layer="21" rot="R270" align="top-left">GND</text>
<text x="33.02" y="21.59" size="0.6096" layer="21" rot="R270" align="top-left">RST</text>
<text x="35.56" y="21.59" size="0.6096" layer="21" rot="R270" align="top-left">14/TX</text>
<text x="38.1" y="21.59" size="0.6096" layer="21" rot="R270" align="top-left">13/RX</text>
<text x="40.64" y="21.59" size="0.6096" layer="21" rot="R270" align="top-left">12/SCL</text>
<text x="43.18" y="21.59" size="0.6096" layer="21" rot="R270" align="top-left">11/SDA</text>
<text x="45.72" y="21.59" size="0.6096" layer="21" rot="R270" align="top-left">10/MISO</text>
<text x="48.26" y="21.59" size="0.6096" layer="21" rot="R270" align="top-left">9/SCK</text>
<text x="50.8" y="21.59" size="0.6096" layer="21" rot="R270" align="top-left">8/MOSI</text>
<text x="53.34" y="21.59" size="0.6096" layer="21" rot="R270" align="top-left">7</text>
<text x="55.88" y="21.59" size="0.6096" layer="21" rot="R270" align="top-left">6</text>
<circle x="2.25" y="22.75" radius="2.25" width="0.1" layer="42"/>
<circle x="2.25" y="2.25" radius="2.25" width="0.1" layer="42"/>
<circle x="59.25" y="2.25" radius="2.25" width="0.1" layer="42"/>
<circle x="59.25" y="22.75" radius="2.25" width="0.1" layer="42"/>
<wire x1="2.25" y1="20.5" x2="0" y2="20.5" width="0.1" layer="42"/>
<wire x1="4.5" y1="22.75" x2="4.5" y2="25" width="0.1" layer="42"/>
<wire x1="57" y1="22.75" x2="57" y2="25" width="0.1" layer="42"/>
<wire x1="61.5" y1="20.5" x2="59.25" y2="20.5" width="0.1" layer="42"/>
<wire x1="2.25" y1="4.5" x2="0" y2="4.5" width="0.1" layer="42"/>
<wire x1="4.5" y1="0" x2="4.5" y2="2.25" width="0.1" layer="42"/>
<wire x1="61.5" y1="4.5" x2="59.25" y2="4.5" width="0.1" layer="42"/>
<wire x1="57" y1="0" x2="57" y2="2.25" width="0.1" layer="42"/>
<circle x="2.25" y="22.75" radius="2.25" width="0.1" layer="41"/>
<circle x="2.25" y="2.25" radius="2.25" width="0.1" layer="41"/>
<circle x="59.25" y="2.25" radius="2.25" width="0.1" layer="41"/>
<circle x="59.25" y="22.75" radius="2.25" width="0.1" layer="41"/>
<wire x1="2.25" y1="20.5" x2="0" y2="20.5" width="0.1" layer="41"/>
<wire x1="4.5" y1="22.75" x2="4.5" y2="25" width="0.1" layer="41"/>
<wire x1="57" y1="22.75" x2="57" y2="25" width="0.1" layer="41"/>
<wire x1="61.5" y1="20.5" x2="59.25" y2="20.5" width="0.1" layer="41"/>
<wire x1="2.25" y1="4.5" x2="0" y2="4.5" width="0.1" layer="41"/>
<wire x1="4.5" y1="0" x2="4.5" y2="2.25" width="0.1" layer="41"/>
<wire x1="61.5" y1="4.5" x2="59.25" y2="4.5" width="0.1" layer="41"/>
<wire x1="57" y1="0" x2="57" y2="2.25" width="0.1" layer="41"/>
</package>
<package name="FD-1-2">
<circle x="0" y="0" radius="0.5" width="2.1844" layer="29"/>
<circle x="0" y="0" radius="1.5" width="0.127" layer="41"/>
<smd name="P$1" x="0" y="0" dx="1.016" dy="1.016" layer="1" roundness="100"/>
</package>
<package name="FD-1-1.5">
<circle x="0" y="0" radius="0.5" width="1.2" layer="29"/>
<circle x="0" y="0" radius="1" width="0.127" layer="41"/>
<smd name="P$1" x="0" y="0" dx="1.016" dy="1.016" layer="1" roundness="100" cream="no"/>
</package>
<package name="FRAME">
<text x="0" y="-17.78" size="1.27" layer="51">Reference Designs ARE PROVIDED "AS IS" AND "WITH ALL FAULTS. Arduino SA DISCLAIMS ALL OTHER WARRANTIES, EXPRESS OR IMPLIED,
REGARDING PRODUCTS, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A 
PARTICULAR PURPOSE 
Arduino SA may make changes to specifications and product descriptions at any time, without notice. The Customer must not
rely on the absence or characteristics of any features or instructions marked "reserved" or "undefined." Arduino SA reserves
these for future definition and shall have no responsibility whatsoever for conflicts or incompatibilities arising from future changes to them.
The product information on the Web Site or Materials is subject to change without notice. Do not finalize a design with this info

ARDUINO and other Arduino brands and logos and Trademarks of Arduino SA. All Arduino SA Trademarks cannot be used without owner's formal permission

This file is licensed under : CC-SA-BY-NC</text>
</package>
<package name="FRAME-NO-BAN">
</package>
</packages>
<symbols>
<symbol name="MKRBOARD">
<pin name="A5" x="-15.24" y="2.54" visible="pin" length="middle"/>
<pin name="A4" x="-15.24" y="5.08" visible="pin" length="middle"/>
<pin name="A3" x="-15.24" y="7.62" visible="pin" length="middle"/>
<pin name="A2" x="-15.24" y="10.16" visible="pin" length="middle"/>
<pin name="A1" x="-15.24" y="12.7" visible="pin" length="middle"/>
<pin name="DAC0/A0" x="-15.24" y="15.24" visible="pin" length="middle"/>
<pin name="AREF" x="-15.24" y="17.78" visible="pin" length="middle"/>
<pin name="A6" x="-15.24" y="0" visible="pin" length="middle"/>
<pin name="0" x="-15.24" y="-2.54" visible="pin" length="middle"/>
<pin name="1" x="-15.24" y="-5.08" visible="pin" length="middle"/>
<pin name="2" x="-15.24" y="-7.62" visible="pin" length="middle"/>
<pin name="3" x="-15.24" y="-10.16" visible="pin" length="middle"/>
<pin name="4" x="-15.24" y="-12.7" visible="pin" length="middle"/>
<pin name="5" x="-15.24" y="-15.24" visible="pin" length="middle"/>
<pin name="5V" x="15.24" y="17.78" visible="pin" length="middle" rot="R180"/>
<pin name="VIN" x="15.24" y="15.24" visible="pin" length="middle" rot="R180"/>
<pin name="VCC" x="15.24" y="12.7" visible="pin" length="middle" rot="R180"/>
<pin name="GND" x="15.24" y="10.16" visible="pin" length="middle" rot="R180"/>
<pin name="RST" x="15.24" y="7.62" visible="pin" length="middle" rot="R180"/>
<pin name="14/TX" x="15.24" y="5.08" visible="pin" length="middle" rot="R180"/>
<pin name="13/RX" x="15.24" y="2.54" visible="pin" length="middle" rot="R180"/>
<pin name="12/SCL" x="15.24" y="0" visible="pin" length="middle" rot="R180"/>
<pin name="11/SDA" x="15.24" y="-2.54" visible="pin" length="middle" rot="R180"/>
<pin name="10/MISO" x="15.24" y="-5.08" visible="pin" length="middle" rot="R180"/>
<pin name="9/SCK" x="15.24" y="-7.62" visible="pin" length="middle" rot="R180"/>
<pin name="8/MOSI" x="15.24" y="-10.16" visible="pin" length="middle" rot="R180"/>
<pin name="7" x="15.24" y="-12.7" visible="pin" length="middle" rot="R180"/>
<pin name="6" x="15.24" y="-15.24" visible="pin" length="middle" rot="R180"/>
<wire x1="-10.16" y1="20.32" x2="-10.16" y2="-17.78" width="0.1524" layer="94"/>
<wire x1="-10.16" y1="-17.78" x2="-7.62" y2="-20.32" width="0.1524" layer="94" curve="90"/>
<wire x1="-7.62" y1="-20.32" x2="7.62" y2="-20.32" width="0.1524" layer="94"/>
<wire x1="7.62" y1="-20.32" x2="10.16" y2="-17.78" width="0.1524" layer="94" curve="90"/>
<wire x1="10.16" y1="-17.78" x2="10.16" y2="20.32" width="0.1524" layer="94"/>
<wire x1="10.16" y1="20.32" x2="7.62" y2="22.86" width="0.1524" layer="94" curve="90"/>
<wire x1="7.62" y1="22.86" x2="-7.62" y2="22.86" width="0.1524" layer="94"/>
<wire x1="-7.62" y1="22.86" x2="-10.16" y2="20.32" width="0.1524" layer="94" curve="90"/>
</symbol>
<symbol name="ARDUINO_FIDUCIAL">
<circle x="0" y="0" radius="2.54" width="0.254" layer="94"/>
</symbol>
<symbol name="A3L-LOC">
<wire x1="288.29" y1="3.81" x2="342.265" y2="3.81" width="0.1016" layer="94"/>
<wire x1="342.265" y1="3.81" x2="373.38" y2="3.81" width="0.1016" layer="94"/>
<wire x1="373.38" y1="3.81" x2="383.54" y2="3.81" width="0.1016" layer="94"/>
<wire x1="383.54" y1="3.81" x2="383.54" y2="8.89" width="0.1016" layer="94"/>
<wire x1="383.54" y1="8.89" x2="383.54" y2="13.97" width="0.1016" layer="94"/>
<wire x1="383.54" y1="13.97" x2="383.54" y2="19.05" width="0.1016" layer="94"/>
<wire x1="383.54" y1="19.05" x2="383.54" y2="24.13" width="0.1016" layer="94"/>
<wire x1="288.29" y1="3.81" x2="288.29" y2="24.13" width="0.1016" layer="94"/>
<wire x1="288.29" y1="24.13" x2="342.265" y2="24.13" width="0.1016" layer="94"/>
<wire x1="342.265" y1="24.13" x2="383.54" y2="24.13" width="0.1016" layer="94"/>
<wire x1="373.38" y1="3.81" x2="373.38" y2="8.89" width="0.1016" layer="94"/>
<wire x1="373.38" y1="8.89" x2="383.54" y2="8.89" width="0.1016" layer="94"/>
<wire x1="373.38" y1="8.89" x2="342.265" y2="8.89" width="0.1016" layer="94"/>
<wire x1="342.265" y1="8.89" x2="342.265" y2="3.81" width="0.1016" layer="94"/>
<wire x1="342.265" y1="8.89" x2="342.265" y2="13.97" width="0.1016" layer="94"/>
<wire x1="342.265" y1="13.97" x2="383.54" y2="13.97" width="0.1016" layer="94"/>
<wire x1="342.265" y1="13.97" x2="342.265" y2="19.05" width="0.1016" layer="94"/>
<wire x1="342.265" y1="19.05" x2="383.54" y2="19.05" width="0.1016" layer="94"/>
<wire x1="342.265" y1="19.05" x2="342.265" y2="24.13" width="0.1016" layer="94"/>
<text x="344.17" y="15.24" size="2.54" layer="94" font="vector">&gt;DRAWING_NAME</text>
<text x="344.17" y="10.16" size="2.286" layer="94" font="vector">&gt;LAST_DATE_TIME</text>
<text x="357.505" y="5.08" size="2.54" layer="94" font="vector">&gt;SHEET</text>
<text x="343.916" y="4.953" size="2.54" layer="94" font="vector">Sheet:</text>
<frame x1="0" y1="0" x2="387.35" y2="260.35" columns="8" rows="5" layer="94"/>
<text x="381" y="25.4" size="1.6764" layer="98" rot="R90">Reference Designs ARE PROVIDED "AS IS" AND "WITH ALL FAULTS. Arduino SA DISCLAIMS ALL OTHER WARRANTIES, EXPRESS OR IMPLIED,
REGARDING PRODUCTS, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A 
PARTICULAR PURPOSE 
Arduino SA may make changes to specifications and product descriptions at any time, without notice. The Customer must not
rely on the absence or characteristics of any features or instructions marked "reserved" or "undefined." Arduino SA reserves
these for future definition and shall have no responsibility whatsoever for conflicts or incompatibilities arising from future changes to them.
The product information on the Web Site or Materials is subject to change without notice. Do not finalize a design with this info

ARDUINO and other Arduino brands and logos and Trademarks of Arduino SA. All Arduino SA Trademarks cannot be used without owner's formal permission

This file is licensed under : CC-SA-BY-NC</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="MKRBOARD" prefix="MKR">
<description>MKR board footprint</description>
<gates>
<gate name="G$1" symbol="MKRBOARD" x="0" y="-2.54"/>
</gates>
<devices>
<device name="OUTLINE" package="MKRBOARD">
<connects>
<connect gate="G$1" pin="0" pad="0"/>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="10/MISO" pad="10"/>
<connect gate="G$1" pin="11/SDA" pad="11"/>
<connect gate="G$1" pin="12/SCL" pad="12"/>
<connect gate="G$1" pin="13/RX" pad="13"/>
<connect gate="G$1" pin="14/TX" pad="14"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="5V" pad="5V"/>
<connect gate="G$1" pin="6" pad="6"/>
<connect gate="G$1" pin="7" pad="7"/>
<connect gate="G$1" pin="8/MOSI" pad="8"/>
<connect gate="G$1" pin="9/SCK" pad="9"/>
<connect gate="G$1" pin="A1" pad="A1"/>
<connect gate="G$1" pin="A2" pad="A2"/>
<connect gate="G$1" pin="A3" pad="A3"/>
<connect gate="G$1" pin="A4" pad="A4"/>
<connect gate="G$1" pin="A5" pad="A5"/>
<connect gate="G$1" pin="A6" pad="A6"/>
<connect gate="G$1" pin="AREF" pad="AREF"/>
<connect gate="G$1" pin="DAC0/A0" pad="A0"/>
<connect gate="G$1" pin="GND" pad="GND"/>
<connect gate="G$1" pin="RST" pad="RST"/>
<connect gate="G$1" pin="VCC" pad="VCC"/>
<connect gate="G$1" pin="VIN" pad="VIN"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="NO-OUTLINE" package="MKRBOARD-NOOUTLINE">
<connects>
<connect gate="G$1" pin="0" pad="0"/>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="10/MISO" pad="10"/>
<connect gate="G$1" pin="11/SDA" pad="11"/>
<connect gate="G$1" pin="12/SCL" pad="12"/>
<connect gate="G$1" pin="13/RX" pad="13"/>
<connect gate="G$1" pin="14/TX" pad="14"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="5V" pad="5V"/>
<connect gate="G$1" pin="6" pad="6"/>
<connect gate="G$1" pin="7" pad="7"/>
<connect gate="G$1" pin="8/MOSI" pad="8"/>
<connect gate="G$1" pin="9/SCK" pad="9"/>
<connect gate="G$1" pin="A1" pad="A1"/>
<connect gate="G$1" pin="A2" pad="A2"/>
<connect gate="G$1" pin="A3" pad="A3"/>
<connect gate="G$1" pin="A4" pad="A4"/>
<connect gate="G$1" pin="A5" pad="A5"/>
<connect gate="G$1" pin="A6" pad="A6"/>
<connect gate="G$1" pin="AREF" pad="AREF"/>
<connect gate="G$1" pin="DAC0/A0" pad="A0"/>
<connect gate="G$1" pin="GND" pad="GND"/>
<connect gate="G$1" pin="RST" pad="RST"/>
<connect gate="G$1" pin="VCC" pad="VCC"/>
<connect gate="G$1" pin="VIN" pad="VIN"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="W-SMD" package="MKRBOARD-W-SMD">
<connects>
<connect gate="G$1" pin="0" pad="0"/>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="10/MISO" pad="10"/>
<connect gate="G$1" pin="11/SDA" pad="11"/>
<connect gate="G$1" pin="12/SCL" pad="12"/>
<connect gate="G$1" pin="13/RX" pad="13"/>
<connect gate="G$1" pin="14/TX" pad="14"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="5V" pad="5V"/>
<connect gate="G$1" pin="6" pad="6"/>
<connect gate="G$1" pin="7" pad="7"/>
<connect gate="G$1" pin="8/MOSI" pad="8"/>
<connect gate="G$1" pin="9/SCK" pad="9"/>
<connect gate="G$1" pin="A1" pad="A1"/>
<connect gate="G$1" pin="A2" pad="A2"/>
<connect gate="G$1" pin="A3" pad="A3"/>
<connect gate="G$1" pin="A4" pad="A4"/>
<connect gate="G$1" pin="A5" pad="A5"/>
<connect gate="G$1" pin="A6" pad="A6"/>
<connect gate="G$1" pin="AREF" pad="AREF"/>
<connect gate="G$1" pin="DAC0/A0" pad="DAC0/A0"/>
<connect gate="G$1" pin="GND" pad="GND"/>
<connect gate="G$1" pin="RST" pad="RST"/>
<connect gate="G$1" pin="VCC" pad="VCC"/>
<connect gate="G$1" pin="VIN" pad="VIN"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="SOLDER" package="MKRBOARD-SOLDER">
<connects>
<connect gate="G$1" pin="0" pad="0"/>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="10/MISO" pad="10"/>
<connect gate="G$1" pin="11/SDA" pad="11"/>
<connect gate="G$1" pin="12/SCL" pad="12"/>
<connect gate="G$1" pin="13/RX" pad="13"/>
<connect gate="G$1" pin="14/TX" pad="14"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="5V" pad="5V"/>
<connect gate="G$1" pin="6" pad="6"/>
<connect gate="G$1" pin="7" pad="7"/>
<connect gate="G$1" pin="8/MOSI" pad="8"/>
<connect gate="G$1" pin="9/SCK" pad="9"/>
<connect gate="G$1" pin="A1" pad="A1"/>
<connect gate="G$1" pin="A2" pad="A2"/>
<connect gate="G$1" pin="A3" pad="A3"/>
<connect gate="G$1" pin="A4" pad="A4"/>
<connect gate="G$1" pin="A5" pad="A5"/>
<connect gate="G$1" pin="A6" pad="A6"/>
<connect gate="G$1" pin="AREF" pad="AREF"/>
<connect gate="G$1" pin="DAC0/A0" pad="DAC0/A0"/>
<connect gate="G$1" pin="GND" pad="GND"/>
<connect gate="G$1" pin="RST" pad="RST"/>
<connect gate="G$1" pin="VCC" pad="VCC"/>
<connect gate="G$1" pin="VIN" pad="VIN"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="-DIM" package="MKRBOARD-DIM">
<connects>
<connect gate="G$1" pin="0" pad="0"/>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="10/MISO" pad="10"/>
<connect gate="G$1" pin="11/SDA" pad="11"/>
<connect gate="G$1" pin="12/SCL" pad="12"/>
<connect gate="G$1" pin="13/RX" pad="13"/>
<connect gate="G$1" pin="14/TX" pad="14"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="5V" pad="5V"/>
<connect gate="G$1" pin="6" pad="6"/>
<connect gate="G$1" pin="7" pad="7"/>
<connect gate="G$1" pin="8/MOSI" pad="8"/>
<connect gate="G$1" pin="9/SCK" pad="9"/>
<connect gate="G$1" pin="A1" pad="A1"/>
<connect gate="G$1" pin="A2" pad="A2"/>
<connect gate="G$1" pin="A3" pad="A3"/>
<connect gate="G$1" pin="A4" pad="A4"/>
<connect gate="G$1" pin="A5" pad="A5"/>
<connect gate="G$1" pin="A6" pad="A6"/>
<connect gate="G$1" pin="AREF" pad="AREF"/>
<connect gate="G$1" pin="DAC0/A0" pad="A0"/>
<connect gate="G$1" pin="GND" pad="GND"/>
<connect gate="G$1" pin="RST" pad="RST"/>
<connect gate="G$1" pin="VCC" pad="VCC"/>
<connect gate="G$1" pin="VIN" pad="VIN"/>
</connects>
<technologies>
<technology name="-DNP">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
<technology name="-MALE">
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="ELDECO" constant="no"/>
<attribute name="MANUFACTURER-PN" value="PH254-104DF113A00V" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="FIDUCIAL" prefix="FD">
<description>Fiducial mount</description>
<gates>
<gate name="G$1" symbol="ARDUINO_FIDUCIAL" x="0" y="0"/>
</gates>
<devices>
<device name="-2MM" package="FD-1-2">
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="-1.5MM" package="FD-1-1.5">
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="A3-FRAME" prefix="FRAME" uservalue="yes">
<description>Schematic frame</description>
<gates>
<gate name="G$1" symbol="A3L-LOC" x="0" y="0"/>
</gates>
<devices>
<device name="-STANDARD" package="FRAME">
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="-NO-BAN" package="FRAME-NO-BAN">
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-Sensors">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="BNO055">
<circle x="-3.4" y="1.6" radius="0.2" width="0.35" layer="21"/>
<wire x1="-2.6" y1="1.9" x2="2.6" y2="1.9" width="0.127" layer="51"/>
<wire x1="2.6" y1="1.9" x2="2.6" y2="-1.9" width="0.127" layer="51"/>
<wire x1="2.6" y1="-1.9" x2="-2.6" y2="-1.9" width="0.127" layer="51"/>
<wire x1="-2.6" y1="-1.9" x2="-2.6" y2="1.9" width="0.127" layer="51"/>
<wire x1="-2.8" y1="2.1" x2="2.8" y2="2.1" width="0.127" layer="21"/>
<wire x1="2.8" y1="2.1" x2="2.8" y2="-2.1" width="0.127" layer="21"/>
<wire x1="2.8" y1="-2.1" x2="-2.8" y2="-2.1" width="0.127" layer="21"/>
<wire x1="-2.8" y1="-2.1" x2="-2.8" y2="2.1" width="0.127" layer="21"/>
<smd name="1" x="-2.25" y="1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="2" x="-2.3125" y="0.75" dx="0.375" dy="0.25" layer="1"/>
<smd name="3" x="-2.3125" y="0.25" dx="0.375" dy="0.25" layer="1"/>
<smd name="4" x="-2.3125" y="-0.25" dx="0.375" dy="0.25" layer="1"/>
<smd name="5" x="-2.3125" y="-0.75" dx="0.375" dy="0.25" layer="1"/>
<smd name="6" x="-2.25" y="-1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="7" x="-1.75" y="-1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="8" x="-1.25" y="-1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="9" x="-0.75" y="-1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="10" x="-0.25" y="-1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="11" x="0.25" y="-1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="12" x="0.75" y="-1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="13" x="1.25" y="-1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="14" x="1.75" y="-1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="15" x="2.25" y="-1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="16" x="2.3125" y="-0.75" dx="0.375" dy="0.25" layer="1"/>
<smd name="17" x="2.3125" y="-0.25" dx="0.375" dy="0.25" layer="1"/>
<smd name="18" x="2.3125" y="0.25" dx="0.375" dy="0.25" layer="1"/>
<smd name="19" x="2.3125" y="0.75" dx="0.375" dy="0.25" layer="1"/>
<smd name="20" x="2.25" y="1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="21" x="1.75" y="1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="22" x="1.25" y="1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="23" x="0.75" y="1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="24" x="0.25" y="1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="25" x="-0.25" y="1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="26" x="-0.75" y="1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="27" x="-1.25" y="1.5625" dx="0.25" dy="0.475" layer="1"/>
<smd name="28" x="-1.75" y="1.5625" dx="0.25" dy="0.475" layer="1"/>
<text x="-2.84" y="2.248" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-2.74" y="-2.71" size="0.4064" layer="27" ratio="10">&gt;VALUE</text>
</package>
</packages>
<symbols>
<symbol name="BNO055">
<wire x1="-17.78" y1="20.32" x2="17.78" y2="20.32" width="0.254" layer="94"/>
<wire x1="17.78" y1="20.32" x2="17.78" y2="-20.32" width="0.254" layer="94"/>
<wire x1="17.78" y1="-20.32" x2="-17.78" y2="-20.32" width="0.254" layer="94"/>
<wire x1="-17.78" y1="-20.32" x2="-17.78" y2="20.32" width="0.254" layer="94"/>
<pin name="CAP" x="-20.32" y="10.16" length="short" direction="pas"/>
<pin name="COM0/SDA/TX" x="20.32" y="17.78" length="short" rot="R180"/>
<pin name="COM1/SCL/RX" x="20.32" y="15.24" length="short" rot="R180"/>
<pin name="COM2(GND)" x="20.32" y="12.7" length="short" rot="R180"/>
<pin name="COM3/I2C_ADDR" x="20.32" y="10.16" length="short" rot="R180"/>
<pin name="GND@1" x="-20.32" y="5.08" length="short" direction="pwr"/>
<pin name="GND@2" x="-20.32" y="2.54" length="short" direction="pwr"/>
<pin name="INT" x="20.32" y="5.08" length="short" direction="out" rot="R180"/>
<pin name="NBOOT_LOAD_PIN" x="20.32" y="-12.7" length="short" rot="R180"/>
<pin name="NRESET" x="20.32" y="0" length="short" rot="R180"/>
<pin name="PIN7(SWDIO)" x="20.32" y="-15.24" length="short" rot="R180"/>
<pin name="PIN8(SWCLK)" x="20.32" y="-17.78" length="short" rot="R180"/>
<pin name="PIN10(GND)" x="-20.32" y="-2.54" length="short"/>
<pin name="PIN15(GND)" x="-20.32" y="-5.08" length="short"/>
<pin name="PIN16(GND)" x="-20.32" y="-7.62" length="short"/>
<pin name="PS0" x="20.32" y="-5.08" length="short" direction="in" rot="R180"/>
<pin name="PS1" x="20.32" y="-7.62" length="short" direction="in" rot="R180"/>
<pin name="VDD" x="-20.32" y="17.78" length="short" direction="pwr"/>
<pin name="VDDIO" x="-20.32" y="15.24" length="short" direction="pwr"/>
<pin name="XIN32" x="-20.32" y="-12.7" length="short" direction="in"/>
<pin name="XOUT32" x="-20.32" y="-17.78" length="short" direction="out"/>
<text x="-17.78" y="21.59" size="1.27" layer="95">&gt;NAME</text>
<text x="-17.78" y="-22.86" size="1.27" layer="96">BNO055</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="BNO055" prefix="U" uservalue="yes">
<description>&lt;p&gt;&lt;b&gt;BNO055&lt;/b&gt; - Motion Co-Processor&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="BNO055" x="0" y="0"/>
</gates>
<devices>
<device name="" package="BNO055">
<connects>
<connect gate="G$1" pin="CAP" pad="9"/>
<connect gate="G$1" pin="COM0/SDA/TX" pad="20"/>
<connect gate="G$1" pin="COM1/SCL/RX" pad="19"/>
<connect gate="G$1" pin="COM2(GND)" pad="18"/>
<connect gate="G$1" pin="COM3/I2C_ADDR" pad="17"/>
<connect gate="G$1" pin="GND@1" pad="2"/>
<connect gate="G$1" pin="GND@2" pad="25"/>
<connect gate="G$1" pin="INT" pad="14"/>
<connect gate="G$1" pin="NBOOT_LOAD_PIN" pad="4"/>
<connect gate="G$1" pin="NRESET" pad="11"/>
<connect gate="G$1" pin="PIN10(GND)" pad="10"/>
<connect gate="G$1" pin="PIN15(GND)" pad="15"/>
<connect gate="G$1" pin="PIN16(GND)" pad="16"/>
<connect gate="G$1" pin="PIN7(SWDIO)" pad="7"/>
<connect gate="G$1" pin="PIN8(SWCLK)" pad="8"/>
<connect gate="G$1" pin="PS0" pad="6"/>
<connect gate="G$1" pin="PS1" pad="5"/>
<connect gate="G$1" pin="VDD" pad="3"/>
<connect gate="G$1" pin="VDDIO" pad="28"/>
<connect gate="G$1" pin="XIN32" pad="27"/>
<connect gate="G$1" pin="XOUT32" pad="26"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-BCE" value="-" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="https://ae-bst.resource.bosch.com/media/_tech/media/datasheets/BST_BNO055_DS000_14.pdf" constant="no"/>
<attribute name="DISTRIBIUTOR-PN" value="828-1058-1-ND" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.it/product-detail/it/bosch-sensortec/BNO055/828-1058-1-ND/6136309" constant="no"/>
<attribute name="MANUFACTURER" value="Bosch Sensortec" constant="no"/>
<attribute name="MANUFACTURER-PN" value="BNO055" constant="no"/>
<attribute name="VALUE" value="BNO055" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-supply">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
</packages>
<symbols>
<symbol name="+3V3">
<wire x1="0.889" y1="-1.27" x2="0" y2="0.127" width="0.254" layer="94"/>
<wire x1="0" y1="0.127" x2="-0.889" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-0.889" y1="-1.27" x2="0.889" y2="-1.27" width="0.254" layer="94"/>
<pin name="+3V3" x="0" y="-2.54" visible="off" length="short" direction="sup" rot="R90"/>
<text x="0" y="0.508" size="1.778" layer="96" align="bottom-center">&gt;VALUE</text>
</symbol>
<symbol name="GND">
<wire x1="-1.905" y1="0" x2="1.905" y2="0" width="0.254" layer="94"/>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
<text x="-2.54" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="+3V3" prefix="+3V3">
<description>3V3 symbol</description>
<gates>
<gate name="G$1" symbol="+3V3" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name="">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="+3V3" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="GND" prefix="GND">
<description>GND symbol</description>
<gates>
<gate name="1" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name="">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="GND" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-rcl">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="0402-1005X55N">
<circle x="0" y="0" radius="0.25" width="0.05" layer="39"/>
<wire x1="-0.5" y1="-0.25" x2="0.5" y2="-0.25" width="0.025" layer="51"/>
<wire x1="0.5" y1="-0.25" x2="0.5" y2="0.25" width="0.025" layer="51"/>
<wire x1="0.5" y1="0.25" x2="-0.5" y2="0.25" width="0.025" layer="51"/>
<wire x1="-0.5" y1="0.25" x2="-0.5" y2="-0.25" width="0.025" layer="51"/>
<wire x1="-0.35" y1="0" x2="0.35" y2="0" width="0.05" layer="39"/>
<wire x1="0" y1="-0.35" x2="0" y2="0.35" width="0.05" layer="39"/>
<wire x1="-0.95" y1="0.45" x2="0.95" y2="0.45" width="0.05" layer="39"/>
<wire x1="0.95" y1="0.45" x2="0.95" y2="-0.45" width="0.05" layer="39"/>
<wire x1="0.95" y1="-0.45" x2="-0.95" y2="-0.45" width="0.05" layer="39"/>
<wire x1="-0.95" y1="-0.45" x2="-0.95" y2="0.45" width="0.05" layer="39"/>
<smd name="1" x="-0.45" y="0" dx="0.62" dy="0.62" layer="1" roundness="3"/>
<smd name="2" x="0.45" y="0" dx="0.62" dy="0.62" layer="1" roundness="3"/>
<text x="-0.9" y="0.5" size="0.4064" layer="51" font="vector" ratio="10">&gt;NAME</text>
</package>
<package name="0805-R2013X50N">
<circle x="0" y="0" radius="0.25" width="0.05" layer="39"/>
<wire x1="1" y1="-0.625" x2="1" y2="0.625" width="0.025" layer="51"/>
<wire x1="1" y1="0.625" x2="-1" y2="0.625" width="0.025" layer="51"/>
<wire x1="-1" y1="0.625" x2="-1" y2="-0.625" width="0.025" layer="51"/>
<wire x1="-1" y1="-0.625" x2="1" y2="-0.625" width="0.025" layer="51"/>
<wire x1="0" y1="-0.35" x2="0" y2="0.35" width="0.05" layer="39"/>
<wire x1="0.35" y1="0" x2="-0.35" y2="0" width="0.05" layer="39"/>
<wire x1="-1.75" y1="1" x2="1.75" y2="1" width="0.05" layer="39"/>
<wire x1="1.75" y1="1" x2="1.75" y2="-1" width="0.05" layer="39"/>
<wire x1="1.75" y1="-1" x2="-1.75" y2="-1" width="0.05" layer="39"/>
<wire x1="-1.75" y1="-1" x2="-1.75" y2="1" width="0.05" layer="39"/>
<smd name="1" x="-1" y="0" dx="0.95" dy="1.45" layer="1" roundness="3"/>
<smd name="2" x="1" y="0" dx="0.95" dy="1.45" layer="1" roundness="3"/>
<text x="0" y="1.27" size="0.6096" layer="25" font="vector" ratio="10" align="center">&gt;NAME</text>
</package>
<package name="0603-1608X90N">
<circle x="0" y="0" radius="0.25" width="0.05" layer="39"/>
<wire x1="-0.814" y1="-0.4" x2="0.786" y2="-0.4" width="0.025" layer="51"/>
<wire x1="0.786" y1="-0.4" x2="0.786" y2="0.4" width="0.025" layer="51"/>
<wire x1="0.786" y1="0.4" x2="-0.814" y2="0.4" width="0.025" layer="51"/>
<wire x1="-0.814" y1="0.4" x2="-0.814" y2="-0.4" width="0.025" layer="51"/>
<wire x1="-0.35" y1="0" x2="0.35" y2="0" width="0.05" layer="39"/>
<wire x1="0" y1="-0.35" x2="0" y2="0.35" width="0.05" layer="39"/>
<wire x1="-1.6" y1="0.8" x2="-1.6" y2="-0.8" width="0.05" layer="39"/>
<wire x1="-1.6" y1="-0.8" x2="1.6" y2="-0.8" width="0.05" layer="39"/>
<wire x1="1.6" y1="-0.8" x2="1.6" y2="0.8" width="0.05" layer="39"/>
<wire x1="1.6" y1="0.8" x2="-1.6" y2="0.8" width="0.05" layer="39"/>
<smd name="1" x="-0.8" y="0" dx="0.95" dy="1" layer="1" roundness="3"/>
<smd name="2" x="0.8" y="0" dx="0.95" dy="1" layer="1" roundness="3"/>
<text x="-1.27" y="0.9525" size="0.6096" layer="25" font="vector" ratio="10">&gt;NAME</text>
</package>
<package name="C1206">
<smd name="1" x="0" y="1.4" dx="1.8" dy="1.45" layer="1" roundness="20"/>
<smd name="2" x="0" y="-1.4" dx="1.8" dy="1.45" layer="1" roundness="20"/>
<wire x1="-0.85" y1="1.6" x2="-0.85" y2="1" width="0.127" layer="21"/>
<wire x1="-0.85" y1="1" x2="-0.85" y2="-1" width="0.127" layer="21"/>
<wire x1="-0.85" y1="-1" x2="-0.85" y2="-1.6" width="0.127" layer="21"/>
<wire x1="0.85" y1="1.6" x2="0.85" y2="1" width="0.127" layer="21"/>
<wire x1="0.85" y1="1" x2="0.85" y2="-1" width="0.127" layer="21"/>
<wire x1="0.85" y1="-1" x2="0.85" y2="-1.6" width="0.127" layer="21"/>
<wire x1="0.85" y1="1.6" x2="-0.85" y2="1.6" width="0.127" layer="21"/>
<wire x1="0.85" y1="-1.6" x2="-0.85" y2="-1.6" width="0.127" layer="21"/>
<wire x1="0.85" y1="1" x2="-0.85" y2="1" width="0.127" layer="21"/>
<wire x1="0.85" y1="-1" x2="-0.85" y2="-1" width="0.127" layer="21"/>
<text x="-1.5875" y="0" size="0.8128" layer="25" font="vector" ratio="10" rot="R270" align="center">&gt;NAME</text>
</package>
<package name="0204V">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;&lt;p&gt;
type 0204, grid 2.5 mm</description>
<wire x1="-1.27" y1="0" x2="1.27" y2="0" width="0.508" layer="51"/>
<wire x1="-0.127" y1="0" x2="0.127" y2="0" width="0.508" layer="21"/>
<circle x="-1.27" y="0" radius="0.889" width="0.1524" layer="51"/>
<circle x="-1.27" y="0" radius="0.635" width="0.0508" layer="51"/>
<pad name="1" x="-1.27" y="0" drill="0.8128"/>
<pad name="2" x="1.27" y="0" drill="0.8128" shape="square"/>
<text x="-2.1336" y="1.1684" size="1.27" layer="25" ratio="12">&gt;NAME</text>
<text x="-2.1336" y="-2.3114" size="1.27" layer="27" ratio="12">&gt;VALUE</text>
</package>
<package name="PWR">
<description>Multilayer SMD</description>
<wire x1="-2.8004" y1="4.375" x2="2.8004" y2="4.375" width="0.127" layer="21"/>
<wire x1="2.8004" y1="-4.375" x2="-2.8004" y2="-4.375" width="0.127" layer="21"/>
<smd name="1" x="-5.4" y="0" dx="5.2" dy="8.75" layer="1"/>
<smd name="2" x="5.4" y="0" dx="5.2" dy="8.75" layer="1"/>
<text x="0" y="0" size="0.6096" layer="25" align="center">&gt;NAME</text>
</package>
<package name="C0201">
<smd name="1" x="0" y="0.35" dx="0.45" dy="0.45" layer="1" roundness="20"/>
<smd name="2" x="0" y="-0.33" dx="0.45" dy="0.45" layer="1" roundness="20"/>
<rectangle x1="-0.3" y1="-0.15" x2="0.3" y2="0.15" layer="21" rot="R270"/>
<text x="-0.9525" y="0" size="0.6096" layer="25" font="vector" ratio="10" rot="R270" align="center">&gt;NAME</text>
</package>
<package name="C0603">
<wire x1="0.45" y1="0.9" x2="0.45" y2="0.5" width="0.127" layer="21"/>
<wire x1="0.45" y1="0.5" x2="0.45" y2="-0.5" width="0.127" layer="21"/>
<wire x1="0.45" y1="-0.5" x2="0.45" y2="-0.9" width="0.127" layer="21"/>
<wire x1="-0.45" y1="0.9" x2="-0.45" y2="0.5" width="0.127" layer="21"/>
<wire x1="-0.45" y1="0.5" x2="-0.45" y2="-0.5" width="0.127" layer="21"/>
<wire x1="-0.45" y1="-0.5" x2="-0.45" y2="-0.9" width="0.127" layer="21"/>
<wire x1="0.45" y1="-0.9" x2="-0.45" y2="-0.9" width="0.127" layer="21"/>
<wire x1="0.45" y1="0.9" x2="-0.45" y2="0.9" width="0.127" layer="21"/>
<wire x1="0.45" y1="0.5" x2="-0.45" y2="0.5" width="0.127" layer="21"/>
<wire x1="0.45" y1="-0.5" x2="-0.45" y2="-0.5" width="0.127" layer="21"/>
<text x="-1.27" y="0" size="0.8128" layer="25" font="vector" ratio="10" rot="R270" align="center">&gt;NAME</text>
<text x="1.27" y="0" size="0.8128" layer="27" font="vector" ratio="10" rot="R270" align="center">&gt;VALUE</text>
<smd name="1" x="0" y="0.8" dx="1" dy="0.95" layer="1" roundness="20"/>
<smd name="2" x="0" y="-0.8" dx="1" dy="0.95" layer="1" roundness="20"/>
</package>
</packages>
<symbols>
<symbol name="C">
<rectangle x1="-2.032" y1="-0.762" x2="2.032" y2="-0.254" layer="94"/>
<rectangle x1="-2.032" y1="0.254" x2="2.032" y2="0.762" layer="94"/>
<wire x1="0" y1="2.54" x2="0" y2="0.762" width="0.1524" layer="94"/>
<wire x1="0" y1="-2.54" x2="0" y2="-0.762" width="0.1524" layer="94"/>
<pin name="1" x="0" y="2.54" visible="off" length="point" direction="pas" swaplevel="1" rot="R270"/>
<pin name="2" x="0" y="-2.54" visible="off" length="point" direction="pas" swaplevel="1" rot="R90"/>
<text x="1.524" y="1.651" size="1.778" layer="95">&gt;NAME</text>
<text x="1.524" y="-3.429" size="1.778" layer="96">&gt;VALUE</text>
</symbol>
<symbol name="R">
<description>Resistor</description>
<wire x1="-2.286" y1="0.762" x2="2.286" y2="0.762" width="0.2794" layer="94"/>
<wire x1="-2.286" y1="-0.762" x2="2.286" y2="-0.762" width="0.2794" layer="94"/>
<wire x1="-2.286" y1="-0.762" x2="-2.286" y2="0" width="0.2794" layer="94"/>
<wire x1="-2.286" y1="0" x2="-2.286" y2="0.762" width="0.2794" layer="94"/>
<wire x1="2.286" y1="0.762" x2="2.286" y2="0" width="0.2794" layer="94"/>
<wire x1="2.286" y1="0" x2="2.286" y2="-0.762" width="0.2794" layer="94"/>
<wire x1="2.286" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="0" x2="-2.286" y2="0" width="0.1524" layer="94"/>
<pin name="1" x="-2.54" y="0" visible="off" length="point" direction="pas" swaplevel="1"/>
<pin name="2" x="2.54" y="0" visible="off" length="point" direction="pas" swaplevel="1" rot="R180"/>
<text x="0" y="1.27" size="1.778" layer="95" align="bottom-center">&gt;NAME</text>
<text x="0" y="-1.27" size="1.778" layer="96" align="top-center">&gt;VALUE</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="C" prefix="C" uservalue="yes">
<description>SMD Capacitor</description>
<gates>
<gate name="G$1" symbol="C" x="0" y="0"/>
</gates>
<devices>
<device name="-0402" package="0402-1005X55N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-100NF">
<attribute name="DATASHEET" value="http://www.tdk.com/pdf/TDKMLCCCapRange.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/tdk-corporation/C1005X5R1H104K050BB/445-5942-1-ND/2443982" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="445-5942-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="TDK" constant="no"/>
<attribute name="MANUFACTURER-PN" value="C1005X5R1H104K050BB" constant="no"/>
<attribute name="VALUE" value="100n" constant="no"/>
</technology>
<technology name="-10NF">
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R71H103KA88J/490-6351-1-ND/3845548" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-6351-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata " constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R71H103KA88J " constant="no"/>
<attribute name="VALUE" value="10n" constant="no"/>
</technology>
<technology name="-110P">
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/G101/ENG/GRM1555C1H111GA01-01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM1555C1H111GA01D/490-6195-1-ND/3845392" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-6195-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM1555C1H111GA01D" constant="no"/>
<attribute name="VALUE" value="110p" constant="no"/>
</technology>
<technology name="-15PF">
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM1555C1H150JA01D/490-5888-1-ND/3315234" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-5888-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM1555C1H150JA01D" constant="no"/>
<attribute name="VALUE" value="15p" constant="no"/>
</technology>
<technology name="-1NF">
<attribute name="DATASHEET" value="http://www.samsungsem.com/kr/support/product-search/mlcc/__icsFiles/afieldfile/2016/08/18/S_CL05B102KB5NNNC.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/samsung-electro-mechanics-america-inc/CL05B102KB5NNNC/1276-1032-1-ND/3889118" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="1276-1032-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Samsung" constant="no"/>
<attribute name="MANUFACTURER-PN" value="CL05B102KB5NNNC " constant="no"/>
<attribute name="VALUE" value="1n" constant="no"/>
</technology>
<technology name="-1UF">
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R61E105KA12D/490-10017-1-ND/5026367" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-10017-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R61E105KA12D " constant="no"/>
<attribute name="VALUE" value="1u" constant="no"/>
</technology>
<technology name="-2.2UF">
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R61A225KE95D/490-10451-1-ND/5026361" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-10451-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R61A225KE95D" constant="no"/>
<attribute name="VALUE" value="2u2" constant="no"/>
</technology>
<technology name="-20PF">
<attribute name="DATASHEET" value="http://www.kemet.com/docfinder?Partnumber=CBR04C200J5GAC" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/kemet/CBR04C200J5GAC/399-6173-1-ND/2732143" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="399-6173-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Kemet" constant="no"/>
<attribute name="MANUFACTURER-PN" value="CBR04C200J5GAC " constant="no"/>
<attribute name="VALUE" value="20p" constant="no"/>
</technology>
<technology name="-22N">
<attribute name="DATASHEET" value="http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R71H223KA12D/490-3884-1-ND/965926" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-3884-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R71H223KA12D" constant="no"/>
<attribute name="VALUE" value="22n" constant="no"/>
</technology>
<technology name="-22PF">
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.se/products/en?keywords=490-8589-1-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-8589-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM1555C1H220FA01D" constant="no"/>
<attribute name="VALUE" value="22p" constant="no"/>
</technology>
<technology name="-33PF">
<attribute name="DATASHEET" value="http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.pdf " constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-search/en?keywords=490-5936-1-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-5936-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM1555C1H330JA01D" constant="no"/>
<attribute name="VALUE" value="33p" constant="no"/>
</technology>
<technology name="-4.7UF">
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R60J475ME47D/490-5915-1-ND/3719860" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-5915-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R60J475ME47D " constant="no"/>
<attribute name="VALUE" value="4u7" constant="no"/>
</technology>
<technology name="-47N">
<attribute name="DATASHEET" value="http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.pdf " constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R71E473KA88D/490-3254-1-ND/702795" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-3254-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R71E473KA88D" constant="no"/>
<attribute name="VALUE" value="47n" constant="no"/>
</technology>
<technology name="-4N7">
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R71H472KA01J/490-8259-1-ND/4380553" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-8259-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R71H472KA01J" constant="no"/>
<attribute name="VALUE" value="4n7" constant="no"/>
</technology>
<technology name="-56P">
<attribute name="DATASHEET" value="http://www.mouser.com/ds/2/281/c02e-2905.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.mouser.it/ProductDetail/Murata-Electronics/GRM1555C1E560JA01D/?qs=sGAEpiMZZMs0AnBnWHyRQA3eyUP2RfX77sTVhhB4SFb8UyJFwKUI8g%3d%3d" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="81-GRM1555C1E560JA1D" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value=" GRM1555C1E560JA01D " constant="no"/>
<attribute name="VALUE" value="56p" constant="no"/>
</technology>
<technology name="-6N8">
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/G101/ENG/GRM155R71H682KA88-01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R71H682KA88D/490-4515-1-ND/1033274" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-4515-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R71H682KA88D" constant="no"/>
<attribute name="VALUE" value="6n8" constant="no"/>
</technology>
<technology name="-8N2">
<attribute name="DATASHEET" value="http://www.yageo.com/documents/recent/UPY-GPHC_X7R_6.3V-to-50V_18.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/CC0402KRX7R7BB822/311-1041-1-ND/302958" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-1041-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="CC0402KRX7R7BB822" constant="no"/>
<attribute name="VALUE" value="8n2" constant="no"/>
</technology>
<technology name="DNP">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0805" package="0805-R2013X50N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-22U">
<attribute name="DATASHEET" value="https://media.digikey.com/pdf/Data%20Sheets/Samsung%20PDFs/CL21A226MQCLQNC_character.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/samsung-electro-mechanics-america-inc/CL21A226MQCLQNC/1276-2412-1-ND/3890498" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="1276-2412-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Samsung" constant="no"/>
<attribute name="MANUFACTURER-PN" value="CL21A226MQCLQNC" constant="no"/>
<attribute name="VALUE" value="22u" constant="no"/>
</technology>
<technology name="4.7NF">
<attribute name="DATASHEET" value="http://www.kemet.com/Lists/ProductCatalog/Attachments/40/KEM_C1010_X7R_HV_SMD.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="www.kemet.com/docfinder?Partnumber=C0805C472KDRACTU" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="399-6738-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Kemet" constant="no"/>
<attribute name="MANUFACTURER-PN" value="C0805C472KDRACTU" constant="no"/>
<attribute name="VALUE" value="4n7" constant="no"/>
</technology>
<technology name="DNP">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0603" package="0603-1608X90N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-10UF">
<attribute name="DATASHEET" value="http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.pdf " constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-search/en?keywords=490-10728-1-ND " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-10728-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM188R61C106KAALD" constant="no"/>
<attribute name="VALUE" value="10u" constant="no"/>
</technology>
<technology name="-1UF">
<attribute name="DATASHEET" value="http://www.samsungsem.com/kr/support/product-search/mlcc/__icsFiles/afieldfile/2016/08/18/S_CL10B105KP8NNNC.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/samsung-electro-mechanics-america-inc/CL10B105KP8NNNC/1276-1946-1-ND/3890032" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="1276-1946-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Samsung" constant="no"/>
<attribute name="MANUFACTURER-PN" value="CL10B105KP8NNNC" constant="no"/>
<attribute name="VALUE" value="1u" constant="no"/>
</technology>
<technology name="-22PF">
<attribute name="DATASHEET" value="http://www.samsungsem.com/kr/support/product-search/mlcc/__icsFiles/afieldfile/2016/08/18/S_CL10C220JB8NNNC.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/samsung-electro-mechanics-america-inc/CL10C220JB8NNNC/1276-1023-1-ND/3889109" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="1276-1023-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Samsung" constant="no"/>
<attribute name="MANUFACTURER-PN" value="CL10C220JB8NNNC" constant="no"/>
<attribute name="VALUE" value="22p" constant="no"/>
</technology>
<technology name="-4.7UF">
<attribute name="DATASHEET" value="http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-search/en?keywords=490-7203-1-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-7203-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM188R61E475KE11D" constant="no"/>
<attribute name="VALUE" value="4u7" constant="no"/>
</technology>
<technology name="-DNP">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="-1206" package="C1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-100UF">
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM31CD80J107ME39L/490-10525-1-ND/5026461" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-10525-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM31CD80J107ME39L" constant="no"/>
<attribute name="VALUE" value="100uF" constant="no"/>
</technology>
<technology name="-10UF">
<attribute name="DATASHEET" value="https://product.tdk.com/en/products/common/pdf/mlcc_partnumber_description.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.se/products/en?keywords=445-14694-1-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="445-14694-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="TDK Corporation" constant="no"/>
<attribute name="MANUFACTURER-PN" value="C3216X5R1V106K160AB" constant="no"/>
<attribute name="VALUE" value="10uF" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="R" prefix="R" uservalue="yes">
<description>SMD Resistor</description>
<gates>
<gate name="G$1" symbol="R" x="0" y="0"/>
</gates>
<devices>
<device name="-0402" package="0402-1005X55N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-0R">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-070RL/311-0.0LRCT-ND/2827888" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-0.0LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-070RL" constant="no"/>
<attribute name="VALUE" value="0R" constant="no"/>
</technology>
<technology name="-100K">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-07100KL/311-100KLRCT-ND/729473" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-100KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo " constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07100KL " constant="no"/>
<attribute name="VALUE" value="100k" constant="no"/>
</technology>
<technology name="-100R">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-search/en?keywords=311-100LRCT-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-100LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07100RL" constant="no"/>
<attribute name="VALUE" value="100R" constant="no"/>
</technology>
<technology name="-10K">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-0710KL/311-10.0KLRCT-ND/729470" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-10.0KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0710KL" constant="no"/>
<attribute name="VALUE" value="10k" constant="no"/>
</technology>
<technology name="-10K2">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RT0402DRD0710K2L/311-2129-1-ND/6128548" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-2129-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RT0402DRD0710K2L" constant="no"/>
<attribute name="VALUE" value="10k2" constant="no"/>
</technology>
<technology name="-10R">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402JR-0710KL/311-10KJRCT-ND/729365 " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-10KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-0710KL" constant="no"/>
<attribute name="VALUE" value="10R" constant="no"/>
</technology>
<technology name="-12K">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402JR-0712KL/311-12KJRCT-ND/729370" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-12KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-0712KL" constant="no"/>
<attribute name="VALUE" value="12k" constant="no"/>
</technology>
<technology name="-12K7">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-0712K7L/YAG2964CT-ND/5281829" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG2964CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0712K7L" constant="no"/>
<attribute name="VALUE" value="12k7" constant="no"/>
</technology>
<technology name="-137R">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-07137RL/YAG2973CT-ND/5281838" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG2973CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07137RL" constant="no"/>
<attribute name="VALUE" value="137R" constant="no"/>
</technology>
<technology name="-1K">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-071KL/311-1.00KLRCT-ND/729460 " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-1.00KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-071KL" constant="no"/>
<attribute name="VALUE" value="1k" constant="no"/>
</technology>
<technology name="-1K7">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-071K69L/YAG3044CT-ND/5281909" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3044CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-071K69L" constant="no"/>
<attribute name="VALUE" value="1k69" constant="no"/>
</technology>
<technology name="-1K91">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-071K91L/YAG3049CT-ND/5281914" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3049CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-071K91L" constant="no"/>
<attribute name="VALUE" value="1k91" constant="no"/>
</technology>
<technology name="-1M">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402JR-07330RL/311-330JRCT-ND/729412 " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-330JRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07330RL" constant="no"/>
<attribute name="VALUE" value="1M" constant="no"/>
</technology>
<technology name="-1M2">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/products/en?keywords=RC0402FR-071M2L-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="RC0402FR-071M2L-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-071M2L" constant="no"/>
<attribute name="VALUE" value="1M2" constant="no"/>
</technology>
<technology name="-200R">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-07200RL/311-200LRCT-ND/2827887" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-200LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07200RL" constant="no"/>
<attribute name="VALUE" value="200R" constant="no"/>
</technology>
<technology name="-220K">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402JR-07220KL/311-220KJRCT-ND/729390" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-220KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07220KL" constant="no"/>
<attribute name="VALUE" value="220k" constant="no"/>
</technology>
<technology name="-22R">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/products/en?keywords=311-22.0LRCT-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-22.0LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0722RL" constant="no"/>
<attribute name="VALUE" value="22R" constant="no"/>
</technology>
<technology name="-270R">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402JR-07270RL/311-270JRCT-ND/729395" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-270JRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07270RL" constant="no"/>
<attribute name="VALUE" value="270R" constant="no"/>
</technology>
<technology name="-2K87">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402JR-07330RL/311-330JRCT-ND/729412" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3105CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-072K87L" constant="no"/>
<attribute name="VALUE" value="2k87" constant="no"/>
</technology>
<technology name="-2M">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402JR-072ML/YAG3295CT-ND/5282161" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3295CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-072ML" constant="no"/>
<attribute name="VALUE" value="2M" constant="no"/>
</technology>
<technology name="-330K">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402JR-07330KL/311-330KJRCT-ND/729413 " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-330KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07330KL" constant="no"/>
<attribute name="VALUE" value="330k" constant="no"/>
</technology>
<technology name="-330R">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-07330RL/311-330LRCT-ND/729541" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-330LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo " constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07330RL " constant="no"/>
<attribute name="VALUE" value="330R" constant="no"/>
</technology>
<technology name="-390R">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-07390RL/311-390LRCT-ND/2827929" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-390LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07390RL" constant="no"/>
<attribute name="VALUE" value="390R" constant="no"/>
</technology>
<technology name="-39R">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-0739RL/311-39.0LRCT-ND/729549" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-39.0LRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo " constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0739RL " constant="no"/>
<attribute name="VALUE" value="39R" constant="no"/>
</technology>
<technology name="-3K3">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-073K3L/311-3.30KLRCT-ND/729527" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-3.30KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-073K3L" constant="no"/>
<attribute name="VALUE" value="3k3" constant="no"/>
</technology>
<technology name="-3K83">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-073K83L/311-3.83KLRCT-ND/2827952" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-3.83KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-073K83L" constant="no"/>
<attribute name="VALUE" value="3k83" constant="no"/>
</technology>
<technology name="-402R">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-07402RL/YAG3152CT-ND/5282017" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3152CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07402RL" constant="no"/>
<attribute name="VALUE" value="402R" constant="no"/>
</technology>
<technology name="-43K">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-0743KL/311-43.0KLRCT-ND/729556" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-43.0KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0743KL" constant="no"/>
<attribute name="VALUE" value="43k" constant="no"/>
</technology>
<technology name="-470K">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402JR-07470KL/311-470KJRCT-ND/729430" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-470KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07470KL" constant="no"/>
<attribute name="VALUE" value="470k" constant="no"/>
</technology>
<technology name="-47K">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402JR-0747KL/311-47KJRCT-ND/729432" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-47KJRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-0747KL" constant="no"/>
<attribute name="VALUE" value="47k" constant="no"/>
</technology>
<technology name="-4K7">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-074K7L/311-4.7KLRCT-ND/2827881" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-4.7KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo " constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-074K7L " constant="no"/>
<attribute name="VALUE" value="4k7" constant="no"/>
</technology>
<technology name="-5K49">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-075K49L/311-5.49KLRCT-ND/729573" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-5.49KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-075K49L" constant="no"/>
<attribute name="VALUE" value="5k49" constant="no"/>
</technology>
<technology name="-660R">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-07665RL/YAG3208CT-ND/5282073" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3208CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07665RL" constant="no"/>
<attribute name="VALUE" value="665R" constant="no"/>
</technology>
<technology name="-680K">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.it/product-detail/it/yageo/RC0402JR-07680KL/311-680KJRTR-ND/726501 " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-680KJRTR-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402JR-07680KL" constant="no"/>
<attribute name="VALUE" value="680k" constant="no"/>
</technology>
<technology name="-910K">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0402FR-07910KL/YAG3257CT-ND/5282123" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3257CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07910KL" constant="no"/>
<attribute name="VALUE" value="910k" constant="no"/>
</technology>
<technology name="-9K76">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RT0402DRD079K76L/311-2213-1-ND/6128632" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-2213-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RT0402DRD079K76L" constant="no"/>
<attribute name="VALUE" value="9k76" constant="no"/>
</technology>
<technology name="-DNP">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
<technology name="12K-1%">
<attribute name="DATASHEET" value="http://www.yageo.com/NewPortal/yageodocoutput?fileName=/pdf/R-Chip/PYu-RC_Group_51_RoHS_L_4.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.it/product-detail/it/yageo/RC0402FR-0712KL/311-12.0KLRCT-ND/729479" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-12.0KLRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-0712KL" constant="no"/>
<attribute name="VALUE" value="12k-1%" constant="no"/>
</technology>
<technology name="390K">
<attribute name="DATASHEET" value="www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/yageo/RC0402FR-07390KL/YAG3143CT-ND/5282008" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="YAG3143CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0402FR-07390KL" constant="no"/>
<attribute name="VALUE" value="390k" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0805" package="0805-R2013X50N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-0.012R">
<attribute name="DATASHEET" value="https://industrial.panasonic.com/cdbs/www-data/pdf/RDA0000/AOA0000C295.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/panasonic-electronic-components/ERJ-6CWFR012V/P19198CT-ND/6004553" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="P19198CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Panasonic" constant="no"/>
<attribute name="MANUFACTURER-PN" value="ERJ-6CWFR012V" constant="no"/>
<attribute name="VALUE" value="0.012R" constant="no"/>
</technology>
<technology name="-100R">
<attribute name="DATASHEET" value="http://www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.de/product-detail/en/yageo/RC0805FR-07100RL/311-100CRTR-ND/727543?cur=EUR&amp;lang=en " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-100CRTR-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0805FR-07100RL" constant="no"/>
<attribute name="VALUE" value="100R" constant="no"/>
</technology>
<technology name="-47R">
<attribute name="DATASHEET" value="http://www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.de/product-detail/en/yageo/RC0805FR-0747RL/311-47.0CRCT-ND/730919" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-47.0CRCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0805FR-0747RL" constant="no"/>
<attribute name="VALUE" value="47R" constant="no"/>
</technology>
<technology name="-DNP">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="TH-VERTICAL" package="0204V">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="PWR" package="PWR">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-.03MR">
<attribute name="DATASHEET" value="http://www.vishay.com/docs/30176/wslp3921.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/products/en?keywords=%20WSLPD-.0003CT-ND%20" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="WSLPD-.0003CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Vishay Dale" constant="no"/>
<attribute name="MANUFCATURER-PN" value="WSLP5931L3000FEB" constant="no"/>
<attribute name="VALUE" value="0.3mR" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0201" package="C0201">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-0R">
<attribute name="DATASHEET" value="http://www.yageo.com.tw/exep/pages/download/literatures/PYu-R_INT-thick_7.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/RC0201JR-070RL/311-0.0NCT-ND/1949004" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-0.0NCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RC0201JR-070RL" constant="no"/>
<attribute name="VALUE" value="0R" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0603" package="C0603">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-1M">
<attribute name="DATASHEET" value="industrial.panasonic.com/www-cgi/jvcr13pz.cgi?E+PZ+3+AOA0001+ERJ3GEYJ105V+7+WW" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/panasonic-electronic-components/ERJ-3GEYJ105V/P1.0MGCT-ND/134885" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="P1.0MGCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Panasonic" constant="no"/>
<attribute name="MANUFACTURER-PN" value="ERJ-3GEYJ105V" constant="no"/>
<attribute name="VALUE" value="1M" constant="no"/>
</technology>
</technologies>
</device>
<device name="-1206" package="C1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-0.01R">
<attribute name="DATASHEET" value="http://www.te.com/commerce/DocumentDelivery/DDEController?Action=srchrtrv&amp;DocNm=1773269&amp;DocType=DS&amp;DocLang=English" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/te-connectivity-passive-product/RLP73V2BR010FTDF/A109621CT-ND/4032387" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="A109621CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="TE" constant="no"/>
<attribute name="MANUFACTURER-PN" value="RLP73V2BR010FTDF" constant="no"/>
<attribute name="VALUE" value="10m" constant="no"/>
</technology>
<technology name="-20R">
<attribute name="DATASHEET" value="http://www.susumu.co.jp/common/pdf/n_catalog_partition24_en.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/susumu/HRG3216Q-20R0-D-T1/408-1893-1-ND/5762673" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="408-1893-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Susumu" constant="no"/>
<attribute name="MANUFACTURER-PN" value="HRG3216Q-20R0-D-T1" constant="no"/>
<attribute name="VALUE" value="20R" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-crystals">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="ABS07">
<circle x="0" y="0" radius="0.25" width="0.05" layer="39"/>
<wire x1="-0.175" y1="-0.375" x2="-0.575" y2="-0.375" width="0.01" layer="51"/>
<wire x1="-0.175" y1="-0.2" x2="-0.175" y2="-0.55" width="0.01" layer="51"/>
<wire x1="-0.1" y1="-0.55" x2="0.1" y2="-0.55" width="0.01" layer="51"/>
<wire x1="0.1" y1="-0.55" x2="0.1" y2="-0.2" width="0.01" layer="51"/>
<wire x1="0.1" y1="-0.2" x2="-0.1" y2="-0.2" width="0.01" layer="51"/>
<wire x1="-0.1" y1="-0.2" x2="-0.1" y2="-0.55" width="0.01" layer="51"/>
<wire x1="0.175" y1="-0.375" x2="0.575" y2="-0.375" width="0.01" layer="51"/>
<wire x1="0.175" y1="-0.2" x2="0.175" y2="-0.55" width="0.01" layer="51"/>
<wire x1="1.2" y1="-0.65" x2="1.5" y2="-0.35" width="0.01" layer="51" curve="90"/>
<wire x1="1.2" y1="-0.65" x2="-1.2" y2="-0.65" width="0.01" layer="51"/>
<wire x1="-1.5" y1="-0.35" x2="-1.2" y2="-0.65" width="0.01" layer="51" curve="90"/>
<wire x1="-1.5" y1="-0.35" x2="-1.5" y2="0.35" width="0.01" layer="51"/>
<wire x1="-1.2" y1="0.65" x2="-1.5" y2="0.35" width="0.01" layer="51" curve="90"/>
<wire x1="-1.2" y1="0.65" x2="1.2" y2="0.65" width="0.01" layer="51"/>
<wire x1="1.5" y1="0.35" x2="1.2" y2="0.65" width="0.01" layer="51" curve="90"/>
<wire x1="1.5" y1="0.35" x2="1.5" y2="-0.35" width="0.01" layer="51"/>
<wire x1="1.6" y1="-0.6" x2="1.45" y2="-0.75" width="0.025" layer="51" curve="90"/>
<wire x1="1.45" y1="-0.75" x2="-1.45" y2="-0.75" width="0.025" layer="51"/>
<wire x1="-1.45" y1="-0.75" x2="-1.6" y2="-0.6" width="0.025" layer="51" curve="90"/>
<wire x1="-1.6" y1="-0.6" x2="-1.6" y2="0.6" width="0.025" layer="51"/>
<wire x1="-1.6" y1="0.6" x2="-1.45" y2="0.75" width="0.025" layer="51" curve="90"/>
<wire x1="-1.45" y1="0.75" x2="1.45" y2="0.75" width="0.025" layer="51"/>
<wire x1="1.45" y1="0.75" x2="1.6" y2="0.6" width="0.025" layer="51" curve="90"/>
<wire x1="1.6" y1="0.6" x2="1.6" y2="-0.6" width="0.025" layer="51"/>
<wire x1="-0.35" y1="0" x2="0.35" y2="0" width="0.05" layer="39"/>
<wire x1="0" y1="-0.35" x2="0" y2="0.35" width="0.05" layer="39"/>
<smd name="1" x="-1.25" y="0" dx="1.1" dy="1.9" layer="1" roundness="3"/>
<smd name="2" x="1.25" y="0" dx="1.1" dy="1.9" layer="1" roundness="3"/>
<text x="-1.27" y="1.27" size="0.92" layer="51" font="vector" ratio="10">&gt;NAME</text>
</package>
</packages>
<symbols>
<symbol name="Q">
<wire x1="1.016" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="0" x2="-1.016" y2="0" width="0.1524" layer="94"/>
<wire x1="-0.381" y1="1.524" x2="-0.381" y2="-1.524" width="0.254" layer="94"/>
<wire x1="-0.381" y1="-1.524" x2="0.381" y2="-1.524" width="0.254" layer="94"/>
<wire x1="0.381" y1="-1.524" x2="0.381" y2="1.524" width="0.254" layer="94"/>
<wire x1="0.381" y1="1.524" x2="-0.381" y2="1.524" width="0.254" layer="94"/>
<wire x1="1.016" y1="1.778" x2="1.016" y2="-1.778" width="0.254" layer="94"/>
<wire x1="-1.016" y1="1.778" x2="-1.016" y2="-1.778" width="0.254" layer="94"/>
<pin name="1" x="-2.54" y="0" visible="off" length="point" direction="pas" swaplevel="1"/>
<pin name="2" x="2.54" y="0" visible="off" length="point" direction="pas" swaplevel="1" rot="R180"/>
<text x="2.54" y="1.016" size="1.778" layer="95">&gt;NAME</text>
<text x="2.54" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
<text x="-2.159" y="-1.143" size="0.8636" layer="93">1</text>
<text x="1.524" y="-1.143" size="0.8636" layer="93">2</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="32.768KHZ" prefix="Y" uservalue="yes">
<description>LF crystal</description>
<gates>
<gate name="G$1" symbol="Q" x="0" y="0"/>
</gates>
<devices>
<device name="" package="ABS07">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-BCE" value="-" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.abracon.com/Resonators/ABS07.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/abracon-llc/ABS07-32.768KHZ-T/535-9542-1-ND/1237009" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="535-9542-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Abracon LLC" constant="no"/>
<attribute name="MANUFACTURER-PN" value="ABS07-32.768KHZ-T " constant="no"/>
<attribute name="VALUE" value="32768Hz" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-connectors">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="MODULINO-4">
<description>&lt;b&gt;AMP MTA connector&lt;/b&gt;&lt;p&gt;
Source: http://ecommas.tycoelectronics.com .. ENG_CD_640456_W.pdf</description>
<wire x1="5.08" y1="3.2" x2="5.08" y2="-1.77" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-1.77" x2="5.08" y2="-1.77" width="0.1524" layer="21"/>
<wire x1="5.08" y1="3.2" x2="-5.08" y2="3.2" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-1.77" x2="5.08" y2="-2.6" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-2.6" x2="5.08" y2="-2.6" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-1.77" x2="-5.08" y2="3.2" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-2.6" x2="-5.08" y2="-1.77" width="0.1524" layer="21"/>
<rectangle x1="3.556" y1="-0.254" x2="4.064" y2="0.254" layer="21"/>
<rectangle x1="1.016" y1="-0.254" x2="1.524" y2="0.254" layer="21"/>
<rectangle x1="-1.524" y1="-0.254" x2="-1.016" y2="0.254" layer="21"/>
<pad name="1" x="3.81" y="0" drill="1.016" shape="long" rot="R90"/>
<pad name="2" x="1.27" y="0" drill="1.016" shape="long" rot="R90"/>
<pad name="3" x="-1.27" y="0" drill="1.016" shape="long" rot="R90"/>
<text x="0" y="2.3641" size="1.27" layer="27" rot="R180" align="center">&gt;NAME</text>
<rectangle x1="-4.064" y1="-0.254" x2="-3.556" y2="0.254" layer="21"/>
<pad name="4" x="-3.81" y="0" drill="1.016" shape="long" rot="R90"/>
</package>
<package name="MODULINO-4SM">
<description>&lt;b&gt;AMP MTA connector&lt;/b&gt;&lt;p&gt;
Source: http://ecommas.tycoelectronics.com .. ENG_CD_640456_W.pdf</description>
<wire x1="6.35" y1="3.2" x2="6.35" y2="-1.77" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-1.77" x2="6.35" y2="-1.77" width="0.1524" layer="21"/>
<wire x1="6.35" y1="3.2" x2="-3.81" y2="3.2" width="0.1524" layer="21"/>
<wire x1="6.35" y1="-1.77" x2="6.35" y2="-2.6" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-2.6" x2="6.35" y2="-2.6" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-1.77" x2="-3.81" y2="3.2" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-2.6" x2="-3.81" y2="-1.77" width="0.1524" layer="21"/>
<rectangle x1="4.826" y1="-0.254" x2="5.334" y2="0.254" layer="21"/>
<rectangle x1="2.286" y1="-0.254" x2="2.794" y2="0.254" layer="21"/>
<rectangle x1="-0.254" y1="-0.254" x2="0.254" y2="0.254" layer="21"/>
<pad name="1" x="5.08" y="0" drill="1.016" rot="R90"/>
<pad name="2" x="2.54" y="0" drill="1.016" rot="R90"/>
<pad name="3" x="0" y="0" drill="1.016" rot="R90"/>
<text x="1.27" y="2.3641" size="1.27" layer="27" rot="R180" align="center">&gt;NAME</text>
<rectangle x1="-2.794" y1="-0.254" x2="-2.286" y2="0.254" layer="21"/>
<pad name="4" x="-2.54" y="0" drill="1.016" rot="R90"/>
</package>
<package name="MODULINO-4-RA">
<wire x1="-5.1" y1="0.83" x2="5.1" y2="0.83" width="0.127" layer="21"/>
<wire x1="-5.1" y1="0.83" x2="-5.1" y2="2.73" width="0.127" layer="21"/>
<wire x1="-5.1" y1="2.73" x2="-4.6" y2="2.73" width="0.127" layer="21"/>
<wire x1="-4.6" y1="2.73" x2="-4" y2="2.73" width="0.127" layer="21"/>
<wire x1="-3.7" y1="2.73" x2="-1.5" y2="2.73" width="0.127" layer="21"/>
<wire x1="-1.2" y1="2.73" x2="1.1" y2="2.73" width="0.127" layer="21"/>
<wire x1="1.1" y1="2.73" x2="1.2" y2="2.73" width="0.127" layer="21"/>
<wire x1="1.2" y1="2.73" x2="1.3" y2="2.73" width="0.127" layer="21"/>
<wire x1="1.3" y1="2.73" x2="1.4" y2="2.73" width="0.127" layer="21"/>
<wire x1="1.4" y1="2.73" x2="3.6" y2="2.73" width="0.127" layer="21"/>
<wire x1="3.9" y1="2.73" x2="4.4" y2="2.73" width="0.127" layer="21"/>
<wire x1="4.4" y1="2.73" x2="5.1" y2="2.73" width="0.127" layer="21"/>
<wire x1="5.1" y1="2.73" x2="5.1" y2="0.83" width="0.127" layer="21"/>
<wire x1="-4" y1="2.73" x2="-4" y2="10.43" width="0.127" layer="21"/>
<wire x1="-4" y1="10.43" x2="-3.9" y2="10.43" width="0.127" layer="21"/>
<wire x1="-3.9" y1="10.43" x2="-3.8" y2="10.43" width="0.127" layer="21"/>
<wire x1="-3.8" y1="10.43" x2="-3.7" y2="10.43" width="0.127" layer="21"/>
<wire x1="-3.7" y1="10.43" x2="-3.7" y2="2.73" width="0.127" layer="21"/>
<wire x1="-3.7" y1="2.73" x2="-3.8" y2="2.73" width="0.127" layer="21"/>
<wire x1="-3.8" y1="2.73" x2="-3.9" y2="2.73" width="0.127" layer="21"/>
<wire x1="-3.9" y1="2.73" x2="-4" y2="2.73" width="0.127" layer="21"/>
<wire x1="-1.5" y1="2.73" x2="-1.5" y2="10.43" width="0.127" layer="21"/>
<wire x1="-1.5" y1="10.43" x2="-1.4" y2="10.43" width="0.127" layer="21"/>
<wire x1="-1.4" y1="10.43" x2="-1.3" y2="10.43" width="0.127" layer="21"/>
<wire x1="-1.3" y1="10.43" x2="-1.2" y2="10.43" width="0.127" layer="21"/>
<wire x1="-1.2" y1="10.43" x2="-1.2" y2="2.73" width="0.127" layer="21"/>
<wire x1="-1.2" y1="2.73" x2="-1.3" y2="2.73" width="0.127" layer="21"/>
<wire x1="-1.3" y1="2.73" x2="-1.4" y2="2.73" width="0.127" layer="21"/>
<wire x1="-1.4" y1="2.73" x2="-1.5" y2="2.73" width="0.127" layer="21"/>
<wire x1="1.1" y1="10.43" x2="1.2" y2="10.43" width="0.127" layer="21"/>
<wire x1="1.2" y1="10.43" x2="1.3" y2="10.43" width="0.127" layer="21"/>
<wire x1="1.3" y1="10.43" x2="1.4" y2="10.43" width="0.127" layer="21"/>
<wire x1="1.4" y1="10.43" x2="1.4" y2="2.73" width="0.127" layer="21"/>
<wire x1="3.6" y1="2.73" x2="3.6" y2="10.43" width="0.127" layer="21"/>
<wire x1="3.6" y1="10.43" x2="3.7" y2="10.43" width="0.127" layer="21"/>
<wire x1="3.7" y1="10.43" x2="3.8" y2="10.43" width="0.127" layer="21"/>
<wire x1="3.8" y1="10.43" x2="3.9" y2="10.43" width="0.127" layer="21"/>
<wire x1="3.9" y1="10.43" x2="3.9" y2="2.73" width="0.127" layer="21"/>
<wire x1="3.9" y1="2.73" x2="3.8" y2="2.73" width="0.127" layer="21"/>
<wire x1="3.8" y1="2.73" x2="3.7" y2="2.73" width="0.127" layer="21"/>
<wire x1="3.7" y1="2.73" x2="3.6" y2="2.73" width="0.127" layer="21"/>
<wire x1="-4.6" y1="2.73" x2="-4.6" y2="10.13" width="0.127" layer="21"/>
<wire x1="-4.6" y1="10.13" x2="-4.1" y2="10.63" width="0.127" layer="21" curve="-90"/>
<wire x1="-4.1" y1="10.63" x2="3.9757375" y2="10.63" width="0.127" layer="21"/>
<wire x1="3.9757375" y1="10.63" x2="4.4" y2="10.2057375" width="0.127" layer="21" curve="-90"/>
<wire x1="4.4" y1="10.2057375" x2="4.4" y2="2.73" width="0.127" layer="21"/>
<wire x1="-3.9" y1="10.43" x2="-3.9" y2="2.73" width="0.127" layer="21"/>
<wire x1="-3.8" y1="10.43" x2="-3.8" y2="2.73" width="0.127" layer="21"/>
<wire x1="-1.3" y1="10.43" x2="-1.3" y2="2.73" width="0.127" layer="21"/>
<wire x1="-1.4" y1="10.43" x2="-1.4" y2="2.73" width="0.127" layer="21"/>
<wire x1="1.1" y1="2.73" x2="1.1" y2="10.43" width="0.127" layer="21"/>
<wire x1="1.2" y1="10.43" x2="1.2" y2="2.73" width="0.127" layer="21"/>
<wire x1="3.7" y1="2.73" x2="3.7" y2="10.43" width="0.127" layer="21"/>
<wire x1="3.8" y1="10.43" x2="3.8" y2="2.73" width="0.127" layer="21"/>
<wire x1="1.3" y1="10.43" x2="1.3" y2="2.73" width="0.127" layer="21"/>
<pad name="P$1" x="-3.81" y="-1.27" drill="1" rot="R90"/>
<pad name="P$2" x="-1.27" y="-1.27" drill="1" rot="R90"/>
<pad name="P$3" x="1.27" y="-1.27" drill="1" rot="R90"/>
<pad name="P$4" x="3.81" y="-1.27" drill="1" rot="R90"/>
</package>
</packages>
<symbols>
<symbol name="MODULINO-4">
<circle x="-2.54" y="0" radius="0.635" width="0.254" layer="94"/>
<circle x="0" y="0" radius="0.635" width="0.254" layer="94"/>
<circle x="2.54" y="0" radius="0.635" width="0.254" layer="94"/>
<wire x1="-3.81" y1="1.27" x2="-3.81" y2="-1.905" width="0.254" layer="94"/>
<wire x1="6.35" y1="-1.905" x2="-3.81" y2="-1.905" width="0.254" layer="94"/>
<wire x1="6.35" y1="-1.905" x2="6.35" y2="1.27" width="0.254" layer="94"/>
<wire x1="-3.81" y1="1.27" x2="6.35" y2="1.27" width="0.254" layer="94"/>
<pin name="1" x="-2.54" y="-2.54" visible="off" length="short" direction="pas" rot="R90"/>
<pin name="2" x="0" y="-2.54" visible="off" length="short" direction="pas" rot="R90"/>
<pin name="3" x="2.54" y="-2.54" visible="off" length="short" direction="pas" rot="R90"/>
<text x="-5.08" y="8.89" size="1.778" layer="95">&gt;NAME</text>
<text x="5.08" y="1.27" size="1.27" layer="95" rot="R90">GND</text>
<circle x="5.08" y="0" radius="0.635" width="0.254" layer="94"/>
<pin name="4" x="5.08" y="-2.54" visible="off" length="short" direction="pas" rot="R90"/>
<text x="2.54" y="1.27" size="1.27" layer="95" rot="R90">+V</text>
<text x="0" y="1.27" size="1.27" layer="95" rot="R90">TX/SDA</text>
<text x="-2.54" y="1.27" size="1.27" layer="95" rot="R90">RX/SCL</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="MODULINO-4" prefix="J">
<description>Modulino 4 connector</description>
<gates>
<gate name="G$1" symbol="MODULINO-4" x="0" y="0"/>
</gates>
<devices>
<device name="" package="MODULINO-4">
<connects>
<connect gate="G$1" pin="1" pad="4"/>
<connect gate="G$1" pin="2" pad="3"/>
<connect gate="G$1" pin="3" pad="2"/>
<connect gate="G$1" pin="4" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-BCE" value="-" constant="no"/>
<attribute name="CODE-BCMI" value="-" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="https://www.tme.eu/en/Document/21cd81e6196d70241c99017ffcf9ebee/LHA-XX-TS.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.tme.eu/en/details/lha-04-ts/raster-signal-connectors-254mm/adam-tech/" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="LHA-04-TS" constant="no"/>
<attribute name="MANUFACTURER" value="ADAM TECH" constant="no"/>
<attribute name="MANUFACTURER-PN" value="LHA-04-TS" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
<technology name="-TWI">
<attribute name="CODE-BCE" value="SP1693" constant="no"/>
<attribute name="CODE-BCMI" value="1693" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="-" constant="no"/>
<attribute name="MANUFACTURER-PN" value="-" constant="no"/>
<attribute name="VALUE" value="TWI" constant="no"/>
</technology>
</technologies>
</device>
<device name="SM" package="MODULINO-4SM">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
</connects>
<technologies>
<technology name="-DNP">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
<technology name="-SCREW">
<attribute name="DATASHEET" value="http://www.on-shore.com/wp-content/uploads/2015/09/ostvnxxa150.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/it/on-shore-technology-inc/OSTVN04A150/ED10563-ND/1588864" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="ED10563-ND" constant="no"/>
<attribute name="MANUFACTURER" value="On shore" constant="no"/>
<attribute name="MANUFACTURER-PN" value="OSTVN04A150" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
</technologies>
</device>
<device name="RA" package="MODULINO-4-RA">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
<connect gate="G$1" pin="3" pad="P$3"/>
<connect gate="G$1" pin="4" pad="P$4"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-pushbuttons">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="C&amp;K_PTS820">
<circle x="0" y="0" radius="0.8" width="0.127" layer="21"/>
<wire x1="-2.7" y1="2.1" x2="-2.7" y2="-2.1" width="0.127" layer="21"/>
<wire x1="-2.7" y1="-2.1" x2="2.7" y2="-2.1" width="0.127" layer="21"/>
<wire x1="2.7" y1="-2.1" x2="2.7" y2="2.1" width="0.127" layer="21"/>
<wire x1="2.7" y1="2.1" x2="-2.7" y2="2.1" width="0.127" layer="21"/>
<smd name="1" x="-1.575" y="1.525" dx="1.15" dy="0.75" layer="1" rot="R180"/>
<smd name="2" x="-1.575" y="-1.525" dx="1.15" dy="0.75" layer="1" rot="R180"/>
<smd name="3" x="1.575" y="1.525" dx="1.15" dy="0.75" layer="1" rot="R180"/>
<smd name="4" x="1.575" y="-1.525" dx="1.15" dy="0.75" layer="1" rot="R180"/>
<smd name="5" x="-2.075" y="0" dx="1.4" dy="0.95" layer="1" rot="R90"/>
<smd name="6" x="2.075" y="0" dx="1.4" dy="0.95" layer="1" rot="R90"/>
<hole x="0.9" y="0" drill="0.8"/>
<hole x="-0.9" y="0" drill="0.8"/>
</package>
<package name="C&amp;K_PTS820_NO_HOLES">
<circle x="0" y="0" radius="0.8" width="0.127" layer="21"/>
<wire x1="-2.7" y1="2.1" x2="-2.7" y2="-2.1" width="0.127" layer="21"/>
<wire x1="-2.7" y1="-2.1" x2="2.7" y2="-2.1" width="0.127" layer="21"/>
<wire x1="2.7" y1="-2.1" x2="2.7" y2="2.1" width="0.127" layer="21"/>
<wire x1="2.7" y1="2.1" x2="-2.7" y2="2.1" width="0.127" layer="21"/>
<smd name="1" x="-1.575" y="1.525" dx="1.15" dy="0.75" layer="1" rot="R180"/>
<smd name="2" x="-1.575" y="-1.525" dx="1.15" dy="0.75" layer="1" rot="R180"/>
<smd name="3" x="1.575" y="1.525" dx="1.15" dy="0.75" layer="1" rot="R180"/>
<smd name="4" x="1.575" y="-1.525" dx="1.15" dy="0.75" layer="1" rot="R180"/>
<smd name="5" x="-2.075" y="0" dx="1.4" dy="0.95" layer="1" rot="R90"/>
<smd name="6" x="2.075" y="0" dx="1.4" dy="0.95" layer="1" rot="R90"/>
</package>
</packages>
<symbols>
<symbol name="TACTILE-3PINS">
<circle x="0" y="-2.54" radius="0.127" width="0.4064" layer="94"/>
<circle x="0" y="2.54" radius="0.127" width="0.4064" layer="94"/>
<wire x1="0" y1="1.905" x2="0" y2="2.54" width="0.254" layer="94"/>
<wire x1="-4.445" y1="1.905" x2="-3.175" y2="1.905" width="0.254" layer="94"/>
<wire x1="-4.445" y1="-1.905" x2="-3.175" y2="-1.905" width="0.254" layer="94"/>
<wire x1="-4.445" y1="1.905" x2="-4.445" y2="0" width="0.254" layer="94"/>
<wire x1="-4.445" y1="0" x2="-4.445" y2="-1.905" width="0.254" layer="94"/>
<wire x1="-2.54" y1="0" x2="-1.905" y2="0" width="0.1524" layer="94"/>
<wire x1="-1.27" y1="0" x2="-0.635" y2="0" width="0.1524" layer="94"/>
<wire x1="-4.445" y1="0" x2="-3.175" y2="0" width="0.1524" layer="94"/>
<wire x1="0" y1="-2.54" x2="-1.27" y2="1.905" width="0.254" layer="94"/>
<wire x1="5.08" y1="-2.54" x2="5.08" y2="0" width="0.1524" layer="94"/>
<wire x1="5.08" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="2.54" y1="0" x2="2.54" y2="1.27" width="0.1524" layer="94"/>
<wire x1="2.54" y1="0" x2="2.54" y2="-1.27" width="0.1524" layer="94"/>
<pin name="1" x="0" y="-5.08" visible="pad" length="short" direction="pas" swaplevel="2" rot="R90"/>
<pin name="2" x="0" y="5.08" visible="pad" length="short" direction="pas" swaplevel="1" rot="R270"/>
<pin name="3" x="5.08" y="-5.08" visible="pad" length="short" direction="pwr" rot="R90"/>
<text x="-6.35" y="-2.54" size="1.778" layer="95" rot="R90">&gt;NAME</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="TACTILE1">
<description>Tactile Switch SPST-NO Top Actuated Surface Mount</description>
<gates>
<gate name="G$1" symbol="TACTILE-3PINS" x="0" y="0"/>
</gates>
<devices>
<device name="PTS820" package="C&amp;K_PTS820">
<connects>
<connect gate="G$1" pin="1" pad="5"/>
<connect gate="G$1" pin="2" pad="6"/>
<connect gate="G$1" pin="3" pad="1 2 3 4"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="-" constant="no"/>
<attribute name="MANUFACTURER-PN" value="-" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
</technologies>
</device>
<device name="PTS820-NH" package="C&amp;K_PTS820_NO_HOLES">
<connects>
<connect gate="G$1" pin="1" pad="5"/>
<connect gate="G$1" pin="2" pad="6"/>
<connect gate="G$1" pin="3" pad="1 2 3 4"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="http://www.ckswitches.com/media/1474/pts820.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/c-k/PTS820-J15M-SMTR-LFS/CKN10506CT-ND/4176681" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="PTS820 J25K SMTR LFS-ND" constant="no"/>
<attribute name="MANUFACTURER" value="C&amp;K" constant="no"/>
<attribute name="MANUFACTURER-PN" value="PTS820 J25K SMTR LFS" constant="no"/>
<attribute name="VALUE" value="PTS820" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-diodes">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="LEDC1608X80N-AK">
<circle x="0" y="0" radius="0.25" width="0.05" layer="39"/>
<wire x1="-0.645" y1="-0.395" x2="-0.355" y2="-0.395" width="0.01" layer="51"/>
<wire x1="-0.355" y1="-0.395" x2="-0.355" y2="0.395" width="0.01" layer="51"/>
<wire x1="-0.355" y1="0.395" x2="-0.645" y2="0.395" width="0.01" layer="51"/>
<wire x1="-0.645" y1="0.395" x2="-0.645" y2="-0.395" width="0.01" layer="51"/>
<wire x1="-0.64" y1="-0.39" x2="-0.36" y2="-0.39" width="0.01" layer="51"/>
<wire x1="-0.36" y1="-0.39" x2="-0.36" y2="0.39" width="0.01" layer="51"/>
<wire x1="-0.36" y1="0.39" x2="-0.64" y2="0.39" width="0.01" layer="51"/>
<wire x1="-0.64" y1="0.39" x2="-0.64" y2="-0.39" width="0.01" layer="51"/>
<wire x1="-0.53" y1="-0.28" x2="-0.47" y2="-0.28" width="0.2" layer="51"/>
<wire x1="-0.47" y1="-0.28" x2="-0.47" y2="0.28" width="0.2" layer="51"/>
<wire x1="-0.47" y1="0.28" x2="-0.53" y2="0.28" width="0.2" layer="51"/>
<wire x1="-0.53" y1="0.28" x2="-0.53" y2="-0.28" width="0.2" layer="51"/>
<wire x1="-0.58" y1="-0.33" x2="-0.42" y2="-0.33" width="0.1" layer="51"/>
<wire x1="-0.42" y1="-0.33" x2="-0.42" y2="0.33" width="0.1" layer="51"/>
<wire x1="-0.42" y1="0.33" x2="-0.58" y2="0.33" width="0.1" layer="51"/>
<wire x1="-0.58" y1="0.33" x2="-0.58" y2="-0.33" width="0.1" layer="51"/>
<wire x1="-0.8" y1="-0.4" x2="0.8" y2="-0.4" width="0.025" layer="51"/>
<wire x1="0.8" y1="-0.4" x2="0.8" y2="0.4" width="0.025" layer="51"/>
<wire x1="0.8" y1="0.4" x2="-0.8" y2="0.4" width="0.025" layer="51"/>
<wire x1="-0.8" y1="0.4" x2="-0.8" y2="-0.4" width="0.025" layer="51"/>
<wire x1="-0.63" y1="-0.38" x2="-0.37" y2="-0.38" width="0.025" layer="51"/>
<wire x1="-0.37" y1="-0.38" x2="-0.37" y2="0.38" width="0.025" layer="51"/>
<wire x1="-0.37" y1="0.38" x2="-0.63" y2="0.38" width="0.025" layer="51"/>
<wire x1="-0.63" y1="0.38" x2="-0.63" y2="-0.38" width="0.025" layer="51"/>
<wire x1="-0.618" y1="-0.367" x2="-0.383" y2="-0.367" width="0.025" layer="51"/>
<wire x1="-0.383" y1="-0.367" x2="-0.383" y2="0.368" width="0.025" layer="51"/>
<wire x1="-0.383" y1="0.368" x2="-0.618" y2="0.368" width="0.025" layer="51"/>
<wire x1="-0.618" y1="0.368" x2="-0.618" y2="-0.367" width="0.025" layer="51"/>
<wire x1="-0.605" y1="-0.355" x2="-0.395" y2="-0.355" width="0.05" layer="51"/>
<wire x1="-0.395" y1="-0.355" x2="-0.395" y2="0.355" width="0.05" layer="51"/>
<wire x1="-0.395" y1="0.355" x2="-0.605" y2="0.355" width="0.05" layer="51"/>
<wire x1="-0.605" y1="0.355" x2="-0.605" y2="-0.355" width="0.05" layer="51"/>
<wire x1="-0.35" y1="0" x2="0.35" y2="0" width="0.05" layer="39"/>
<wire x1="0" y1="-0.35" x2="0" y2="0.35" width="0.05" layer="39"/>
<wire x1="-1.55" y1="0.75" x2="-1.55" y2="-0.75" width="0.05" layer="39"/>
<wire x1="-1.55" y1="-0.75" x2="1.55" y2="-0.75" width="0.05" layer="39"/>
<wire x1="1.55" y1="-0.75" x2="1.55" y2="0.75" width="0.05" layer="39"/>
<wire x1="1.55" y1="0.75" x2="-1.55" y2="0.75" width="0.05" layer="39"/>
<smd name="A" x="0.8" y="0" dx="0.9" dy="0.95" layer="1" roundness="3"/>
<smd name="C" x="-0.8" y="0" dx="0.9" dy="0.95" layer="1" roundness="3"/>
<text x="0" y="0" size="1.2" layer="25" font="vector" ratio="10">&gt;NAME</text>
<text x="0" y="0" size="1.2" layer="27" font="vector" ratio="10">&gt;VALUE</text>
<text x="0" y="0" size="0.4064" layer="51" font="vector" ratio="10" align="center">&gt;NAME</text>
</package>
<package name="0402-LED">
<circle x="0" y="0" radius="0.25" width="0.05" layer="39"/>
<wire x1="-0.5" y1="-0.25" x2="0.5" y2="-0.25" width="0.025" layer="51"/>
<wire x1="0.5" y1="-0.25" x2="0.5" y2="0.25" width="0.025" layer="51"/>
<wire x1="0.5" y1="0.25" x2="-0.5" y2="0.25" width="0.025" layer="51"/>
<wire x1="-0.5" y1="0.25" x2="-0.5" y2="-0.25" width="0.025" layer="51"/>
<wire x1="-0.35" y1="0" x2="0.35" y2="0" width="0.05" layer="39"/>
<wire x1="0" y1="-0.35" x2="0" y2="0.35" width="0.05" layer="39"/>
<wire x1="-0.95" y1="0.45" x2="0.95" y2="0.45" width="0.05" layer="39"/>
<wire x1="0.95" y1="0.45" x2="0.95" y2="-0.45" width="0.05" layer="39"/>
<wire x1="0.95" y1="-0.45" x2="-0.95" y2="-0.45" width="0.05" layer="39"/>
<wire x1="-0.95" y1="-0.45" x2="-0.95" y2="0.45" width="0.05" layer="39"/>
<smd name="A" x="-0.45" y="0" dx="0.62" dy="0.62" layer="1" roundness="3"/>
<smd name="C" x="0.45" y="0" dx="0.62" dy="0.62" layer="1" roundness="3"/>
<text x="-0.9" y="0.5" size="0.4064" layer="51" font="vector" ratio="10">&gt;NAME</text>
<wire x1="0.26" y1="0.24" x2="0.26" y2="-0.24" width="0.0254" layer="51"/>
</package>
</packages>
<symbols>
<symbol name="LED">
<wire x1="1.27" y1="0" x2="0" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="-1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="-2.54" x2="0" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="-1.27" y2="-2.54" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="-1.27" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-2.032" y1="-0.762" x2="-3.429" y2="-2.159" width="0.1524" layer="94"/>
<wire x1="-1.905" y1="-1.905" x2="-3.302" y2="-3.302" width="0.1524" layer="94"/>
<pin name="A" x="0" y="2.54" visible="off" length="short" direction="pas" rot="R270"/>
<pin name="C" x="0" y="-5.08" visible="off" length="short" direction="pas" rot="R90"/>
<text x="3.556" y="-4.572" size="1.778" layer="95" rot="R90">&gt;NAME</text>
<text x="5.715" y="-4.572" size="1.778" layer="96" rot="R90">&gt;VALUE</text>
<polygon width="0.1524" layer="94">
<vertex x="-3.429" y="-2.159"/>
<vertex x="-3.048" y="-1.27"/>
<vertex x="-2.54" y="-1.778"/>
</polygon>
<polygon width="0.1524" layer="94">
<vertex x="-3.302" y="-3.302"/>
<vertex x="-2.921" y="-2.413"/>
<vertex x="-2.413" y="-2.921"/>
</polygon>
</symbol>
</symbols>
<devicesets>
<deviceset name="LED" prefix="DL" uservalue="yes">
<description>LED</description>
<gates>
<gate name="G$1" symbol="LED" x="0" y="0"/>
</gates>
<devices>
<device name="-0603" package="LEDC1608X80N-AK">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name="-DNP">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
<technology name="-GREEN">
<attribute name="DATASHEET" value="http://media.digikey.com/pdf/Data%20Sheets/Avago%20PDFs/HSMz-Czzz.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/broadcom-limited/HSMG-C190/516-1425-1-ND/637749" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="516-1425-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Avago " constant="no"/>
<attribute name="MANUFACTURER-PN" value="HSMG-C190 " constant="no"/>
<attribute name="VALUE" value="GREEN" constant="no"/>
</technology>
<technology name="-ORANGE">
<attribute name="DATASHEET" value="http://media.digikey.com/pdf/Data%20Sheets/Avago%20PDFs/HSMz-Czzz.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/broadcom-limited/HSMD-C190/516-2489-1-ND/2744915" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="516-2489-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Avago " constant="no"/>
<attribute name="MANUFACTURER-PN" value="HSMD-C190 " constant="no"/>
<attribute name="VALUE" value="ORANGE" constant="no"/>
</technology>
<technology name="-YELLOW">
<attribute name="DATASHEET" value="http://media.digikey.com/pdf/Data%20Sheets/Avago%20PDFs/HSMz-Czzz.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/broadcom-limited/HSMY-C190/516-1424-1-ND/637748" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="516-1424-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Avago" constant="no"/>
<attribute name="MANUFACTURER-PN" value="HSMY-C190" constant="no"/>
<attribute name="VALUE" value="YELLOW" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0402" package="0402-LED">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="http://www.kingbrightusa.com/images/catalog/SPEC/APHHS1005LSYCK-J3-PF.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/products/en?keywords=754-2125-1-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="754-2125-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Kingbright" constant="no"/>
<attribute name="MANUFACTURER-PN" value="APHHS1005LSYCK/J3-PF" constant="no"/>
<attribute name="VALUE" value="Yellow/20mcd" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
</libraries>
<attributes>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0.25" drill="0.25">
</class>
</classes>
<parts>
<part name="U1" library="Arduino-Sensors" deviceset="BNO055" device="" value="BNO055"/>
<part name="+3V1" library="Arduino-supply" deviceset="+3V3" device="" value="+3V3"/>
<part name="GND" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="C1" library="Arduino-rcl" deviceset="C" device="-0402" technology="-100NF" value="100n"/>
<part name="Y1" library="Arduino-crystals" deviceset="32.768KHZ" device="" value="32768Hz"/>
<part name="GND1" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="GND2" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="R1" library="Arduino-rcl" deviceset="R" device="-0402" technology="-1K" value="1k"/>
<part name="R2" library="Arduino-rcl" deviceset="R" device="-0402" technology="-1K" value="1k"/>
<part name="+3V2" library="Arduino-supply" deviceset="+3V3" device="" value="+3V3"/>
<part name="GND3" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="GND4" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="GND5" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="MKR1" library="Arduino-utility" deviceset="MKRBOARD" device="OUTLINE" value="DNP"/>
<part name="GND6" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="+3V3" library="Arduino-supply" deviceset="+3V3" device="" value="+3V3"/>
<part name="+3V4" library="Arduino-supply" deviceset="+3V3" device="" value="+3V3"/>
<part name="C4" library="Arduino-rcl" deviceset="C" device="-0402" technology="-100NF" value="100n"/>
<part name="GND7" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="GND8" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="R4" library="Arduino-rcl" deviceset="R" device="-0402" technology="-330R" value="330R"/>
<part name="R5" library="Arduino-rcl" deviceset="R" device="-0402" technology="-1K" value="1k"/>
<part name="+3V5" library="Arduino-supply" deviceset="+3V3" device="" value="+3V3"/>
<part name="C2" library="Arduino-rcl" deviceset="C" device="-0402" technology="-22PF" value="22p"/>
<part name="C3" library="Arduino-rcl" deviceset="C" device="-0402" technology="-22PF" value="22p"/>
<part name="+3V6" library="Arduino-supply" deviceset="+3V3" device="" value="+3V3"/>
<part name="C5" library="Arduino-rcl" deviceset="C" device="-0402" technology="-100NF" value="100n"/>
<part name="GND9" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="DL1" library="Arduino-diodes" deviceset="LED" device="-0603" technology="-GREEN" value="GREEN"/>
<part name="GND10" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="+3V7" library="Arduino-supply" deviceset="+3V3" device="" value="+3V3"/>
<part name="R3" library="Arduino-rcl" deviceset="R" device="-0402" technology="-330R" value="330R"/>
<part name="U$2" library="Arduino-pushbuttons" deviceset="TACTILE1" device="PTS820-NH" value="PTS820"/>
<part name="J2" library="Arduino-connectors" deviceset="MODULINO-4" device="RA"/>
<part name="FD1" library="Arduino-utility" deviceset="FIDUCIAL" device="-1.5MM" value="DNP"/>
<part name="FD2" library="Arduino-utility" deviceset="FIDUCIAL" device="-1.5MM" value="DNP"/>
<part name="FD3" library="Arduino-utility" deviceset="FIDUCIAL" device="-1.5MM" value="DNP"/>
<part name="FRAME1" library="Arduino-utility" deviceset="A3-FRAME" device="-STANDARD" value="DNP"/>
</parts>
<sheets>
<sheet>
<plain>
</plain>
<instances>
<instance part="U1" gate="G$1" x="124.46" y="116.84"/>
<instance part="+3V1" gate="G$1" x="93.98" y="142.24"/>
<instance part="GND" gate="1" x="96.52" y="106.68"/>
<instance part="C1" gate="G$1" x="96.52" y="124.46" rot="R180"/>
<instance part="Y1" gate="G$1" x="96.52" y="99.06" rot="R270"/>
<instance part="GND1" gate="1" x="81.28" y="88.9"/>
<instance part="GND2" gate="1" x="246.38" y="127" rot="R90"/>
<instance part="R1" gate="G$1" x="157.48" y="139.7" rot="R90"/>
<instance part="R2" gate="G$1" x="160.02" y="144.78" rot="R90"/>
<instance part="+3V2" gate="G$1" x="157.48" y="152.4"/>
<instance part="GND3" gate="1" x="149.86" y="129.54" rot="R90"/>
<instance part="GND4" gate="1" x="157.48" y="127" rot="R90"/>
<instance part="GND5" gate="1" x="157.48" y="109.22" rot="R90"/>
<instance part="MKR1" gate="G$1" x="226.06" y="116.84"/>
<instance part="GND6" gate="1" x="266.7" y="104.14"/>
<instance part="+3V3" gate="G$1" x="261.62" y="111.76" rot="R90"/>
<instance part="+3V4" gate="G$1" x="246.38" y="139.7"/>
<instance part="C4" gate="G$1" x="170.18" y="71.12"/>
<instance part="GND7" gate="1" x="139.7" y="63.5"/>
<instance part="GND8" gate="1" x="170.18" y="63.5"/>
<instance part="R4" gate="G$1" x="162.56" y="76.2"/>
<instance part="R5" gate="G$1" x="170.18" y="81.28" rot="R90"/>
<instance part="+3V5" gate="G$1" x="170.18" y="88.9"/>
<instance part="C2" gate="G$1" x="88.9" y="101.6" rot="R90"/>
<instance part="C3" gate="G$1" x="88.9" y="96.52" rot="R270"/>
<instance part="+3V6" gate="G$1" x="165.1" y="106.68"/>
<instance part="C5" gate="G$1" x="86.36" y="132.08" rot="R180"/>
<instance part="GND9" gate="1" x="86.36" y="127"/>
<instance part="DL1" gate="G$1" x="45.72" y="121.92"/>
<instance part="GND10" gate="1" x="45.72" y="109.22"/>
<instance part="+3V7" gate="G$1" x="45.72" y="142.24"/>
<instance part="R3" gate="G$1" x="45.72" y="132.08" rot="R90"/>
<instance part="U$2" gate="G$1" x="152.4" y="76.2" rot="R270"/>
<instance part="J2" gate="G$1" x="289.56" y="114.3" rot="R270"/>
<instance part="FD1" gate="G$1" x="7.62" y="251.46"/>
<instance part="FD2" gate="G$1" x="12.7" y="251.46"/>
<instance part="FD3" gate="G$1" x="17.78" y="251.46"/>
<instance part="FRAME1" gate="G$1" x="0" y="0"/>
</instances>
<busses>
<bus name="SDA,SCL,NBOOT,INT,NRESET">
<segment>
<wire x1="187.96" y1="71.12" x2="187.96" y2="144.1803875" width="0.762" layer="92"/>
<wire x1="187.96" y1="144.1803875" x2="193.6396125" y2="149.86" width="0.762" layer="92" curve="-90"/>
<wire x1="193.6396125" y1="149.86" x2="249.355796875" y2="149.86" width="0.762" layer="92"/>
<wire x1="249.355796875" y1="149.86" x2="256.54" y2="142.675796875" width="0.762" layer="92" curve="-90"/>
<wire x1="256.54" y1="142.675796875" x2="256.54" y2="99.06" width="0.762" layer="92"/>
</segment>
</bus>
</busses>
<nets>
<net name="+3V3" class="0">
<segment>
<pinref part="+3V1" gate="G$1" pin="+3V3"/>
<pinref part="U1" gate="G$1" pin="VDD"/>
<wire x1="93.98" y1="139.7" x2="93.98" y2="134.62" width="0.1524" layer="91"/>
<wire x1="93.98" y1="134.62" x2="101.6" y2="134.62" width="0.1524" layer="91"/>
<pinref part="U1" gate="G$1" pin="VDDIO"/>
<wire x1="101.6" y1="134.62" x2="104.14" y2="134.62" width="0.1524" layer="91"/>
<wire x1="104.14" y1="132.08" x2="101.6" y2="132.08" width="0.1524" layer="91"/>
<wire x1="101.6" y1="132.08" x2="101.6" y2="134.62" width="0.1524" layer="91"/>
<junction x="101.6" y="134.62"/>
<pinref part="C5" gate="G$1" pin="2"/>
<wire x1="93.98" y1="134.62" x2="86.36" y2="134.62" width="0.1524" layer="91"/>
<junction x="93.98" y="134.62"/>
</segment>
<segment>
<pinref part="R2" gate="G$1" pin="2"/>
<wire x1="160.02" y1="147.32" x2="160.02" y2="149.86" width="0.1524" layer="91"/>
<pinref part="+3V2" gate="G$1" pin="+3V3"/>
<wire x1="160.02" y1="149.86" x2="157.48" y2="149.86" width="0.1524" layer="91"/>
<pinref part="R1" gate="G$1" pin="2"/>
<wire x1="157.48" y1="142.24" x2="157.48" y2="149.86" width="0.1524" layer="91"/>
<junction x="157.48" y="149.86"/>
</segment>
<segment>
<pinref part="+3V3" gate="G$1" pin="+3V3"/>
<pinref part="J2" gate="G$1" pin="3"/>
<wire x1="264.16" y1="111.76" x2="287.02" y2="111.76" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="MKR1" gate="G$1" pin="VCC"/>
<pinref part="+3V4" gate="G$1" pin="+3V3"/>
<wire x1="241.3" y1="129.54" x2="246.38" y2="129.54" width="0.1524" layer="91"/>
<wire x1="246.38" y1="129.54" x2="246.38" y2="137.16" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="+3V5" gate="G$1" pin="+3V3"/>
<pinref part="R5" gate="G$1" pin="2"/>
<wire x1="170.18" y1="86.36" x2="170.18" y2="83.82" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U1" gate="G$1" pin="NBOOT_LOAD_PIN"/>
<pinref part="+3V6" gate="G$1" pin="+3V3"/>
<wire x1="144.78" y1="104.14" x2="165.1" y2="104.14" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="+3V7" gate="G$1" pin="+3V3"/>
<pinref part="R3" gate="G$1" pin="2"/>
<wire x1="45.72" y1="139.7" x2="45.72" y2="134.62" width="0.1524" layer="91"/>
</segment>
</net>
<net name="SDA" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="COM0/SDA/TX"/>
<wire x1="144.78" y1="134.62" x2="157.48" y2="134.62" width="0.1524" layer="91"/>
<wire x1="157.48" y1="134.62" x2="185.42" y2="134.62" width="0.1524" layer="91"/>
<wire x1="185.42" y1="134.62" x2="187.96" y2="137.16" width="0.1524" layer="91"/>
<label x="147.32" y="134.62" size="1.778" layer="95"/>
<pinref part="R1" gate="G$1" pin="1"/>
<wire x1="157.48" y1="137.16" x2="157.48" y2="134.62" width="0.1524" layer="91"/>
<junction x="157.48" y="134.62"/>
</segment>
<segment>
<wire x1="241.3" y1="114.3" x2="254" y2="114.3" width="0.1524" layer="91"/>
<wire x1="254" y1="114.3" x2="256.54" y2="116.84" width="0.1524" layer="91"/>
<label x="243.84" y="114.3" size="1.778" layer="95"/>
<pinref part="MKR1" gate="G$1" pin="11/SDA"/>
</segment>
<segment>
<wire x1="259.08" y1="114.3" x2="256.54" y2="116.84" width="0.1524" layer="91"/>
<label x="261.62" y="114.3" size="1.778" layer="95"/>
<pinref part="J2" gate="G$1" pin="2"/>
<wire x1="259.08" y1="114.3" x2="287.02" y2="114.3" width="0.1524" layer="91"/>
</segment>
</net>
<net name="SCL" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="COM1/SCL/RX"/>
<wire x1="144.78" y1="132.08" x2="160.02" y2="132.08" width="0.1524" layer="91"/>
<wire x1="160.02" y1="132.08" x2="185.42" y2="132.08" width="0.1524" layer="91"/>
<wire x1="185.42" y1="132.08" x2="187.96" y2="134.62" width="0.1524" layer="91"/>
<label x="147.32" y="132.08" size="1.778" layer="95"/>
<pinref part="R2" gate="G$1" pin="1"/>
<wire x1="160.02" y1="142.24" x2="160.02" y2="132.08" width="0.1524" layer="91"/>
<junction x="160.02" y="132.08"/>
</segment>
<segment>
<wire x1="241.3" y1="116.84" x2="254" y2="116.84" width="0.1524" layer="91"/>
<wire x1="254" y1="116.84" x2="256.54" y2="119.38" width="0.1524" layer="91"/>
<label x="243.84" y="116.84" size="1.778" layer="95"/>
<pinref part="MKR1" gate="G$1" pin="12/SCL"/>
</segment>
<segment>
<wire x1="259.08" y1="116.84" x2="256.54" y2="119.38" width="0.1524" layer="91"/>
<label x="261.62" y="116.84" size="1.778" layer="95"/>
<pinref part="J2" gate="G$1" pin="1"/>
<wire x1="259.08" y1="116.84" x2="287.02" y2="116.84" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$3" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="CAP"/>
<pinref part="C1" gate="G$1" pin="2"/>
<wire x1="104.14" y1="127" x2="96.52" y2="127" width="0.1524" layer="91"/>
</segment>
</net>
<net name="GND" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="GND@1"/>
<wire x1="104.14" y1="121.92" x2="99.06" y2="121.92" width="0.1524" layer="91"/>
<pinref part="U1" gate="G$1" pin="GND@2"/>
<wire x1="104.14" y1="119.38" x2="99.06" y2="119.38" width="0.1524" layer="91"/>
<wire x1="99.06" y1="119.38" x2="99.06" y2="121.92" width="0.1524" layer="91"/>
<pinref part="C1" gate="G$1" pin="1"/>
<wire x1="99.06" y1="121.92" x2="96.52" y2="121.92" width="0.1524" layer="91"/>
<junction x="99.06" y="121.92"/>
<pinref part="GND" gate="1" pin="GND"/>
<wire x1="96.52" y1="109.22" x2="96.52" y2="111.76" width="0.1524" layer="91"/>
<junction x="96.52" y="121.92"/>
<pinref part="U1" gate="G$1" pin="PIN15(GND)"/>
<wire x1="96.52" y1="111.76" x2="96.52" y2="121.92" width="0.1524" layer="91"/>
<wire x1="104.14" y1="111.76" x2="96.52" y2="111.76" width="0.1524" layer="91"/>
<junction x="96.52" y="111.76"/>
<pinref part="U1" gate="G$1" pin="PIN16(GND)"/>
<wire x1="104.14" y1="109.22" x2="96.52" y2="109.22" width="0.1524" layer="91"/>
<junction x="96.52" y="109.22"/>
</segment>
<segment>
<wire x1="86.36" y1="101.6" x2="81.28" y2="101.6" width="0.1524" layer="91"/>
<wire x1="81.28" y1="101.6" x2="81.28" y2="96.52" width="0.1524" layer="91"/>
<wire x1="81.28" y1="96.52" x2="81.28" y2="91.44" width="0.1524" layer="91"/>
<wire x1="86.36" y1="96.52" x2="81.28" y2="96.52" width="0.1524" layer="91"/>
<junction x="81.28" y="96.52"/>
<pinref part="GND1" gate="1" pin="GND"/>
<pinref part="C2" gate="G$1" pin="1"/>
<pinref part="C3" gate="G$1" pin="2"/>
</segment>
<segment>
<pinref part="GND2" gate="1" pin="GND"/>
<wire x1="243.84" y1="127" x2="241.3" y2="127" width="0.1524" layer="91"/>
<pinref part="MKR1" gate="G$1" pin="GND"/>
</segment>
<segment>
<pinref part="U1" gate="G$1" pin="COM2(GND)"/>
<pinref part="GND3" gate="1" pin="GND"/>
<wire x1="144.78" y1="129.54" x2="147.32" y2="129.54" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U1" gate="G$1" pin="COM3/I2C_ADDR"/>
<pinref part="GND4" gate="1" pin="GND"/>
<wire x1="144.78" y1="127" x2="154.94" y2="127" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U1" gate="G$1" pin="PS0"/>
<wire x1="144.78" y1="111.76" x2="154.94" y2="111.76" width="0.1524" layer="91"/>
<pinref part="GND5" gate="1" pin="GND"/>
<wire x1="154.94" y1="111.76" x2="154.94" y2="109.22" width="0.1524" layer="91"/>
<pinref part="U1" gate="G$1" pin="PS1"/>
<wire x1="144.78" y1="109.22" x2="154.94" y2="109.22" width="0.1524" layer="91"/>
<junction x="154.94" y="109.22"/>
</segment>
<segment>
<pinref part="GND6" gate="1" pin="GND"/>
<wire x1="266.7" y1="109.22" x2="266.7" y2="106.68" width="0.1524" layer="91"/>
<pinref part="J2" gate="G$1" pin="4"/>
<wire x1="266.7" y1="109.22" x2="287.02" y2="109.22" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="GND7" gate="1" pin="GND"/>
<wire x1="147.32" y1="76.2" x2="139.7" y2="76.2" width="0.1524" layer="91"/>
<wire x1="139.7" y1="76.2" x2="139.7" y2="71.12" width="0.1524" layer="91"/>
<wire x1="139.7" y1="71.12" x2="139.7" y2="66.04" width="0.1524" layer="91"/>
<wire x1="147.32" y1="71.12" x2="139.7" y2="71.12" width="0.1524" layer="91"/>
<junction x="139.7" y="71.12"/>
<pinref part="U$2" gate="G$1" pin="1"/>
<pinref part="U$2" gate="G$1" pin="3"/>
</segment>
<segment>
<pinref part="C4" gate="G$1" pin="2"/>
<pinref part="GND8" gate="1" pin="GND"/>
<wire x1="170.18" y1="68.58" x2="170.18" y2="66.04" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C5" gate="G$1" pin="1"/>
<pinref part="GND9" gate="1" pin="GND"/>
</segment>
<segment>
<pinref part="DL1" gate="G$1" pin="C"/>
<pinref part="GND10" gate="1" pin="GND"/>
<wire x1="45.72" y1="116.84" x2="45.72" y2="111.76" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$5" class="0">
<segment>
<pinref part="Y1" gate="G$1" pin="1"/>
<wire x1="96.52" y1="101.6" x2="91.44" y2="101.6" width="0.1524" layer="91"/>
<pinref part="U1" gate="G$1" pin="XIN32"/>
<wire x1="104.14" y1="104.14" x2="101.6" y2="104.14" width="0.1524" layer="91"/>
<wire x1="101.6" y1="104.14" x2="101.6" y2="101.6" width="0.1524" layer="91"/>
<wire x1="101.6" y1="101.6" x2="96.52" y2="101.6" width="0.1524" layer="91"/>
<junction x="96.52" y="101.6"/>
<pinref part="C2" gate="G$1" pin="2"/>
</segment>
</net>
<net name="N$6" class="0">
<segment>
<pinref part="Y1" gate="G$1" pin="2"/>
<wire x1="96.52" y1="96.52" x2="91.44" y2="96.52" width="0.1524" layer="91"/>
<pinref part="U1" gate="G$1" pin="XOUT32"/>
<wire x1="104.14" y1="99.06" x2="101.6" y2="99.06" width="0.1524" layer="91"/>
<wire x1="101.6" y1="99.06" x2="101.6" y2="96.52" width="0.1524" layer="91"/>
<wire x1="101.6" y1="96.52" x2="96.52" y2="96.52" width="0.1524" layer="91"/>
<junction x="96.52" y="96.52"/>
<pinref part="C3" gate="G$1" pin="1"/>
</segment>
</net>
<net name="INT" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="INT"/>
<wire x1="144.78" y1="121.92" x2="185.42" y2="121.92" width="0.1524" layer="91"/>
<wire x1="185.42" y1="121.92" x2="187.96" y2="124.46" width="0.1524" layer="91"/>
<label x="147.32" y="121.92" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="MKR1" gate="G$1" pin="0"/>
<wire x1="210.82" y1="114.3" x2="190.5" y2="114.3" width="0.1524" layer="91"/>
<wire x1="190.5" y1="114.3" x2="187.96" y2="116.84" width="0.1524" layer="91"/>
<label x="195.58" y="114.3" size="1.778" layer="95"/>
</segment>
</net>
<net name="NRESET" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="NRESET"/>
<wire x1="144.78" y1="116.84" x2="185.42" y2="116.84" width="0.1524" layer="91"/>
<wire x1="185.42" y1="116.84" x2="187.96" y2="119.38" width="0.1524" layer="91"/>
<label x="147.32" y="116.84" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C4" gate="G$1" pin="1"/>
<wire x1="170.18" y1="76.2" x2="170.18" y2="73.66" width="0.1524" layer="91"/>
<pinref part="R4" gate="G$1" pin="2"/>
<wire x1="165.1" y1="76.2" x2="170.18" y2="76.2" width="0.1524" layer="91"/>
<junction x="170.18" y="76.2"/>
<pinref part="R5" gate="G$1" pin="1"/>
<wire x1="170.18" y1="76.2" x2="185.42" y2="76.2" width="0.1524" layer="91"/>
<wire x1="170.18" y1="78.74" x2="170.18" y2="76.2" width="0.1524" layer="91"/>
<junction x="170.18" y="76.2"/>
<wire x1="185.42" y1="76.2" x2="187.96" y2="78.74" width="0.1524" layer="91"/>
<label x="175.26" y="76.2" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="MKR1" gate="G$1" pin="RST"/>
<wire x1="241.3" y1="124.46" x2="254" y2="124.46" width="0.1524" layer="91"/>
<wire x1="254" y1="124.46" x2="256.54" y2="127" width="0.1524" layer="91"/>
<label x="246.38" y="121.92" size="1.778" layer="95"/>
</segment>
</net>
<net name="N$2" class="0">
<segment>
<pinref part="R4" gate="G$1" pin="1"/>
<wire x1="157.48" y1="76.2" x2="160.02" y2="76.2" width="0.1524" layer="91"/>
<pinref part="U$2" gate="G$1" pin="2"/>
</segment>
</net>
<net name="N$1" class="0">
<segment>
<pinref part="R3" gate="G$1" pin="1"/>
<pinref part="DL1" gate="G$1" pin="A"/>
<wire x1="45.72" y1="129.54" x2="45.72" y2="124.46" width="0.1524" layer="91"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
</schematic>
</drawing>
<compatibility>
<note version="6.3" minversion="6.2.2" severity="warning">
Since Version 6.2.2 text objects can contain more than one line,
which will not be processed correctly with this version.
</note>
</compatibility>
</eagle>
