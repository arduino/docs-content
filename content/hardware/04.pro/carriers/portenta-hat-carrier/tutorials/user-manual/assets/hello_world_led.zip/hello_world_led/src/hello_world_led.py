#!/usr/bin/env python3

import time
import serial
import logging

class GPIOController:
    def __init__(self, gpio_number):
        self.gpio_number = gpio_number
        self.gpio_path = f"/sys/class/gpio/gpio{gpio_number}/"

    def export(self):
        with open("/sys/class/gpio/export", "w") as f:
            f.write(str(self.gpio_number))

    def unexport(self):
        with open("/sys/class/gpio/unexport", "w") as f:
            f.write(str(self.gpio_number))

    def set_direction(self, direction):
        with open(f"{self.gpio_path}direction", "w") as f:
            f.write(direction)

    def read_direction(self):
        with open(f"{self.gpio_path}direction", "r") as f:
            return f.read().strip()

    def set_value(self, value):
        with open(f"{self.gpio_path}value", "w") as f:
            f.write(str(value))

    def read_value(self):
        with open(f"{self.gpio_path}value", "r") as f:
            return int(f.read().strip())

def main():

    logging.info("============================================")
    logging.info("Hello World PHC!")
    logging.info("============================================")

    ser = serial.Serial()
    ser.baudrate = 19200
    ser.port = '/dev/ttymxc3'
    ser.bytesize = 8
    ser.parity = 'N'
    ser.stopbits = 2
    ser.timeout = 1
    logging.debug("Configured serial port with:\n\r%s" % str(ser))
    logging.debug("Opening serial port")

    gpio = GPIOController(163)

    # Export GPIO
    gpio.export()

    # Set as output
    gpio.set_direction("out")
    if gpio.read_direction() == "out":
        print("GPIO set as output.")

    # Turn on (set to 1) and then off (set to 0)
    while True:
        gpio.set_value(1)
        time.sleep(1)
        gpio.set_value(0)
        time.sleep(1)

    # Unexport
    # gpio.unexport()

if __name__ == "__main__":
    main()

### End Main program