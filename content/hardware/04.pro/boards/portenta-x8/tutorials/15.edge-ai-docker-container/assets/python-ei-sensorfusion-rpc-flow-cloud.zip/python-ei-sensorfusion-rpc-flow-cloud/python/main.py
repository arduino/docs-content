#!/usr/bin/env python3
import os
import time
import requests
import signal
import sys
import json
import argparse
from msgpackrpc import Address as RpcAddress, Client as RpcClient, error as RpcError

# Environment variables
CLIENT_ID = os.getenv("CLIENT_ID")
CLIENT_SECRET = os.getenv("CLIENT_SECRET")
THING_ID = os.getenv("THING_ID")
CLASSIFICATION_VARIABLE_ID = os.getenv("CLASSIFICATION_VARIABLE_ID")
CONFIDENCE_VARIABLE_ID = os.getenv("CONFIDENCE_VARIABLE_ID")
LOOP_INTERVAL = int(os.getenv("LOOP_INTERVAL", 5))

# Arduino IoT Cloud API URLs
TOKEN_URL = "https://api2.arduino.cc/iot/v1/clients/token"
PROPERTY_UPDATE_URL = "https://api2.arduino.cc/iot/v2/things/{thing_id}/properties/{variable_id}"

# M4 Proxy Configuration
m4_proxy_host = "m4-proxy"
m4_proxy_port = 5001
m4_proxy_address = RpcAddress(m4_proxy_host, m4_proxy_port)

# Inference Server Configuration (via script arguments)
inference_host = None
inference_port = None


def get_access_token():
    """Retrieve OAuth2 token for Arduino Cloud API."""
    try:
        print(f"CLIENT_ID: {CLIENT_ID}")
        print(f"CLIENT_SECRET: {'*' * len(CLIENT_SECRET)} (hidden)")

        response = requests.post(
            TOKEN_URL,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "grant_type": "client_credentials",
                "client_id": CLIENT_ID,
                "client_secret": CLIENT_SECRET,
                "audience": "https://api2.arduino.cc/iot"
            },
        )

        print("Response Status:", response.status_code)
        print("Response Text:", response.text)

        response.raise_for_status()
        return response.json().get("access_token")

    except requests.RequestException as e:
        print(f"Error getting access token: {e}")
        sys.exit(1)


def update_property(token, variable_id, value):
    """Update an Arduino Cloud property using REST API."""
    url = PROPERTY_UPDATE_URL.format(thing_id=THING_ID, variable_id=variable_id)
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    payload = json.dumps({"value": value})

    try:
        response = requests.put(url, headers=headers, data=payload)
        print(f"Updating {variable_id}: {value} → {url} (PUT)")
        print("Response Status:", response.status_code)
        print("Response Text:", response.text)

        response.raise_for_status()
        print(f"Successfully updated {variable_id}")

    except requests.RequestException as e:
        print(f"Error updating {variable_id}: {e}")


def get_sensors_data_from_m4():
    """Retrieve sensor data from the M4 using RPC (MessagePack-RPC)."""
    data = {}
    sensors = ("flow_rate",)

    try:
        client = RpcClient(m4_proxy_address)
        data = {sensor: client.call(sensor) for sensor in sensors}

    except RpcError.TimeoutError:
        print("RPC Timeout: Unable to retrieve sensors data from M4.")
    except Exception as e:
        print(f"Unexpected error in get_sensors_data_from_m4(): {e}")

    return data


def get_sensors_and_classify():
    """Collect sensor data, send to inference server, and update Arduino Cloud."""
    global inference_host, inference_port

    token = get_access_token()  # Get OAuth2 token once and reuse
    url = f"http://{inference_host}:{inference_port}/api/features"

    while True:
        print("Collecting 400 features from sensors... ", end="")

        data = {"features": []}
        start = time.time()

        for _ in range(100):
            sensors = get_sensors_data_from_m4()
            if sensors:
                print("flow_rate:", sensors.get("flow_rate", "N/A"))
                data["features"].extend(sensors.values())
            time.sleep(100e-6)

        stop = time.time()
        print(f"Done in {stop - start:.2f} seconds.")

        try:
            response = requests.post(url, json=data)
        except requests.ConnectionError:
            print("Connection Error: retrying later")
            time.sleep(5)
            break

        if response.status_code != 200:
            print(f"Failed to submit the features. Status Code: {response.status_code}")
            break

        print("Successfully submitted features. ", end="")

        classification_data = response.json()
        classification = classification_data.get("result", {}).get("classification", {})

        if classification:
            label = max(classification, key=classification.get)
            confidence = classification[label]

            print(f"Classification: {label} ({confidence:.2f})")

            # Update Arduino IoT Cloud with classification results
            update_property(token, CLASSIFICATION_VARIABLE_ID, label)
            update_property(token, CONFIDENCE_VARIABLE_ID, confidence)

        else:
            print("No classification found.")

        time.sleep(LOOP_INTERVAL)


def main():
    """Main function to start classification and cloud updates."""
    global inference_host, inference_port

    parser = argparse.ArgumentParser(description="Get sensor data and classify with AI, updating Arduino Cloud.")
    parser.add_argument("host", help="The hostname or IP address of the inference server")
    parser.add_argument("port", type=int, help="The port number of the inference server")

    args = parser.parse_args()
    inference_host = args.host
    inference_port = args.port

    def signal_handler(_sig, _frame):
        print("Exiting...")
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    print("\n============================================")
    print("==   Portenta X8 M4 Sensor Classification to Arduino Cloud ==")
    print("============================================\n")
    print("🔍 Running model type:", os.getenv("EI_MODEL_VERSION", "float32"))

    get_sensors_and_classify()


if __name__ == "__main__":
    main()
