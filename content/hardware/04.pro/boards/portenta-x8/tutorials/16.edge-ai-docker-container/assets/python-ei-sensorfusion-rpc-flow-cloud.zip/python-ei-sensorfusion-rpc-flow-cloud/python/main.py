import os
import time
import json
import requests
from msgpackrpc import Address, Client

# Retrieve environment variables
CLIENT_ID = os.getenv("CLIENT_ID")
CLIENT_SECRET = os.getenv("CLIENT_SECRET")
THING_ID = os.getenv("THING_ID")
FLOWRATE_VARIABLE_ID = os.getenv("FLOWRATE_VARIABLE_ID")
CLASSIFICATION_VARIABLE_ID = os.getenv("CLASSIFICATION_VARIABLE_ID")  # New variable for classification

# M4 proxy settings
M4_PROXY_HOST = os.getenv("M4_PROXY_HOST", "m4proxy")
M4_PROXY_PORT = int(os.getenv("M4_PROXY_PORT", "5001"))

# Define RPC address
m4_proxy = Address(M4_PROXY_HOST, M4_PROXY_PORT)

def get_sensor_data():
    """
    Retrieve the flow rate from the M4 via RPC.
    """
    client = Client(m4_proxy)
    try:
        return client.call("flow_rate")
    except Exception as e:
        print(f"Error retrieving sensor data: {e}")
        return None

def update_arduino_cloud(variable_id, value):
    """
    Send data to Arduino Cloud.
    """
    url = f"https://api2.arduino.cc/iot/v2/things/{THING_ID}/properties/{variable_id}/publish"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {CLIENT_ID}"  # Ensure valid token
    }
    payload = {"value": value}
    
    try:
        response = requests.put(url, headers=headers, json=payload)
        if response.status_code == 200:
            print(f"Updated Arduino Cloud: {variable_id} = {value}")
        else:
            print(f"Failed to update {variable_id}: {response.status_code}, {response.text}")
    except requests.exceptions.RequestException as e:
        print(f"Error updating Arduino Cloud: {e}")

def classify_flow(host, port):
    """
    Collects flow rate data, sends it for classification, and updates Arduino Cloud.
    """
    url = f"http://{host}:{port}/api/features"

    while True:
        data = {"features": [], "model_type": "int8"}

        # Collect 100 sensor readings
        for _ in range(100):
            flow_rate = get_sensor_data()
            
            if flow_rate is not None:
                data["features"].append(flow_rate)
                update_arduino_cloud(FLOWRATE_VARIABLE_ID, flow_rate)  # Send flow rate to Arduino Cloud
            
            time.sleep(0.1)

        # Send collected data for classification
        try:
            response = requests.post(url, json=data)
            if response.status_code == 200:
                classification = response.json().get("result", {}).get("classification", {})
                print(f"Classification: {classification}")
                
                if classification:
                    label = max(classification, key=classification.get)  # Get highest confidence label
                    update_arduino_cloud(CLASSIFICATION_VARIABLE_ID, label)  # Send classification to Arduino Cloud
            else:
                print(f"Failed classification: {response.status_code}, {response.text}")
        except requests.exceptions.RequestException as e:
            print(f"Error sending classification request: {e}")

if __name__ == "__main__":
    classify_flow("localhost", 1337)