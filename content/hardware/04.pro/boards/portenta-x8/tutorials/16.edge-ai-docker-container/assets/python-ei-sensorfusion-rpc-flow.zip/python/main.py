import os
import time
import json
import argparse
from msgpackrpc import Address as RpcAddress, Client as RpcClient, error as RpcError

# Retrieve M4 Proxy settings from environment variables (or use defaults)
m4_proxy_host = os.getenv("M4_PROXY_HOST", "m4proxy")
m4_proxy_port = int(os.getenv("M4_PROXY_PORT", "5001"))
m4_proxy_address = RpcAddress(m4_proxy_host, m4_proxy_port)

# Define the single sensor we are using
sensors = ("flow_rate",)  # Tuple with one element to keep extend() valid

def get_sensors_data_from_m4():
    """
    Get flow sensor data from the M4 via RPC (MessagePack-RPC).
    The Arduino sketch on the M4 must implement the "flow_rate" method.
    """
    try:
        get_value = lambda value: RpcClient(m4_proxy_address).call(value)  # Ensure this returns a value
        data = [get_value(sensor) for sensor in sensors]                   # Ensure it is a list
        
        print(f"Sensor Data: {data}")                                      # Debug output
        return data

    except RpcError.TimeoutError:
        print("Unable to retrieve sensor data from the M4: RPC Timeout")
        return []                                                          # Ensure an empty list is returned instead of `None`

def get_sensors_and_classify(host, port):
    """
    Collect sensor data and send it for classification to Edge Impulse.
    """
    url = f"http://{host}:{port}/api/features"

    while True:
        print("Collecting 400 features from sensors... ", end="")

        data = {
            "features": [],
            "model_type": "int8"                                           # Force quantized inference mode
        }
        start = time.time()

        for _ in range(100):                                               # Collect data in chunks
            sensor_values = get_sensors_data_from_m4()

            if not isinstance(sensor_values, list):                        # Validate that we get a list
                print(f"Error: Expected list but got {type(sensor_values)} with value {sensor_values}")
                sensor_values = []                                         # Default to an empty list
            
            data["features"].extend(sensor_values)                         # Avoid TypeError

            time.sleep(100e-6)                                             # Small delay to match sampling rate

        stop = time.time()
        print(f"Done in {stop - start:.2f} seconds.")

        try:
            response = requests.post(url, json=data)
        except ConnectionError:
            print("Connection Error: retrying later")
            time.sleep(5)
            continue

        # Check the response
        if response.status_code != 200:
            print(f"Failed to submit features. Status Code: {response.status_code}")
            continue

        print("Successfully submitted features.")

        # Process the JSON response to extract classification results
        response_data = response.json()
        classification = response_data.get("result", {}).get("classification", {})

        print(f"Classification: {classification}")

        if classification:
            label = max(classification, key=classification.get)
            value = classification[label]

            print(f"{label}: {value}")

            request_data = json.dumps({"label": label, "value": value})

            try:
                client = RpcClient(m4_proxy_address)
                result = client.call("classification", request_data)
                print(f"Sent to {m4_proxy_host}:{m4_proxy_port}: {request_data}. Result: {result}")
            except RpcError.TimeoutError:
                print("Unable to send classification data to M4: RPC Timeout.")
        else:
            print("No classification found.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Get flow sensor data and send it to inference container for classification")
    parser.add_argument("host", help="The hostname or IP address of the inference server")
    parser.add_argument("port", type=int, help="The port number of the inference server")

    args = parser.parse_args()

    print("Classifying Flow Sensor Data with AI... Press Ctrl+C to stop.")

    try:
        get_sensors_and_classify(args.host, args.port)
    except KeyboardInterrupt:
        print("Exiting gracefully...")
