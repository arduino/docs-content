#!/usr/bin/env python3
import os
import time
import requests # type: ignore
import signal
import sys
import json
import argparse

from msgpackrpc import Address as RpcAddress, Client as RpcClient, error as RpcError # type: ignore

m4_proxy_host = 'm4-proxy'
m4_proxy_port = 5001
m4_proxy_address = RpcAddress(m4_proxy_host, m4_proxy_port)
model_type = os.getenv("EI_MODEL_VERSION", "float32")

def get_sensors_data_from_m4():
    """Get data from the M4 via RPC (MessagePack-RPC)."""
    data = {}
    sensors = ('flow_rate',)  # Fixed tuple declaration

    try:
        client = RpcClient(m4_proxy_address)  # Use a single client instance
        data = {sensor: client.call(sensor) for sensor in sensors}

    except RpcError.TimeoutError:
        print("Unable to retrieve sensors data from the M4: RPC Timeout - A")

    except Exception as e:
        print(f"Unexpected error in get_sensors_data_from_m4(): {e}")

    return data

def get_sensors_and_classify(host, port):
    url = f"http://{host}:{port}/api/features"

    while True:
        print("Collecting 400 features from sensors... ", end="")
        
        data = {"features": []}
        start = time.time()

        for i in range(100):
            sensors = get_sensors_data_from_m4()
            if sensors:
                print("flow: ", sensors.get('flow_rate', 'N/A'))  # Fixed dictionary reference
                data["features"].extend(sensors.values())  # Correctly extract numerical values
            time.sleep(100e-6)        

        stop = time.time()
        print(f"Done in {stop - start:.2f} seconds.")
        
        try:
            response = requests.post(url, json=data)
        except requests.ConnectionError:  # Corrected exception type
            print("Connection Error: retrying later")
            time.sleep(5)
            break

        if response.status_code != 200:
            print(f"Failed to submit the features. Status Code: {response.status_code}")
            break
            
        print("Successfully submitted features. ", end="")

        classification_data = response.json()
        classification = classification_data.get('result', {}).get('classification', {})

        if classification:
            label = max(classification, key=classification.get)
            value = classification[label]

            print(f"{label}: {value}")

            request_data = json.dumps({'label': label, 'value': value})

            res = 0
            try:
                client = RpcClient(m4_proxy_address)
                res = client.call('classification', json.loads(request_data))  # Fixed JSON handling
            except RpcError.TimeoutError:
                print("Unable to retrieve data from the M4: RPC Timeout. - B")
            except Exception as e:
                print(f"Error calling classification RPC: {e}")

            print(f"Sent to {m4_proxy_host} on port {m4_proxy_port}: {request_data}. Result is {res}.")
        else:
            print("No classification found.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Get 1 second of sensors data and send to inference container for classification")
    parser.add_argument("host", help="The hostname or IP address of the inference server")
    parser.add_argument("port", type=int, help="The port number of the inference server")

    args = parser.parse_args()

    def signal_handler(_sig, _frame):
        print("Exiting...")
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    print("Classifying Flow Sensor Data with AI... Press Ctrl+C to stop.")
    print(f"Running model type: {model_type}")
    # Run the capture, upload, and process function
    get_sensors_and_classify(args.host, args.port)