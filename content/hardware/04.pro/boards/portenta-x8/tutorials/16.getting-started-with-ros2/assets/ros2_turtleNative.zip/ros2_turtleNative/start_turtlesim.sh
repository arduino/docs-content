#!/bin/bash
set -e

# Source ROS2 environment
source /opt/ros/jazzy/setup.bash

# Set Wayland environment variables
export QT_QPA_PLATFORM=wayland
export WAYLAND_DISPLAY=wayland-1
export XDG_RUNTIME_DIR=/run/user/63

echo "Starting Turtlesim with automatic movement..."
echo "Wayland Display: $WAYLAND_DISPLAY"
echo "Runtime Dir: $XDG_RUNTIME_DIR"

# Start turtlesim_node in background
echo "Starting turtlesim node..."
ros2 run turtlesim turtlesim_node &
TURTLESIM_PID=$!

# Wait for turtlesim to start up
echo "Waiting for turtlesim to initialize..."
sleep 3

# Check if turtlesim node is running
if ! kill -0 $TURTLESIM_PID 2>/dev/null; then
    echo "ERROR: Turtlesim node failed to start"
    exit 1
fi

echo "Turtlesim started successfully! Starting automatic movement..."

# Start the draw_square demo
echo "Running draw_square demo..."
ros2 run turtlesim draw_square &
DRAW_PID=$!

# Wait a bit then start continuous circular movement
sleep 5
echo "Starting continuous circular movement..."
ros2 topic pub --rate 1 /turtle1/cmd_vel geometry_msgs/msg/Twist "{linear: {x: 1.5, y: 0.0, z: 0.0}, angular: {x: 0.0, y: 0.0, z: 0.8}}" &
MOVE_PID=$!

echo "All processes started:"
echo "  - Turtlesim node (PID: $TURTLESIM_PID)"
echo "  - Draw square (PID: $DRAW_PID)"  
echo "  - Circular movement (PID: $MOVE_PID)"
echo ""
echo "Turtlesim should now be visible on your display with automatic movement!"
echo "Press Ctrl+C to stop all processes..."

# Function to cleanup processes
cleanup() {
    echo "Stopping all processes..."
    kill $TURTLESIM_PID $DRAW_PID $MOVE_PID 2>/dev/null || true
    wait $TURTLESIM_PID $DRAW_PID $MOVE_PID 2>/dev/null || true
    echo "All processes stopped."
    exit 0
}

# Set up signal handling
trap cleanup SIGINT SIGTERM

# Wait for all background processes
wait