#pragma once

typedef struct
{

  float water_usage_local;  //Liters
  float water_flow_local;   //0-25L/min

  int valve1_local = 0;  //zone 1 valve status
  int valve2_local = 0;  //zone 2 valve status
  int valve3_local = 0;  //zone 3 valve status
  int valve4_local = 0;  //zone 4 valve status

  float z1_on_time_local = 0;  //zone 1 valve On time accumulator
  float z2_on_time_local = 0;  //zone 2 valve On time accumulator
  float z3_on_time_local = 0;  //zone 3 valve On time accumulator
  float z4_on_time_local = 0;  //zone 4 valve On time accumulator

  int z1_moisture_local = 0;  //zone 1 countdown timer
  int z2_moisture_local = 0;  //zone 1 countdown timer
  int z3_moisture_local = 0;  //zone 1 countdown timer
  int z4_moisture_local = 0;  //zone 1 countdown timer

  float battery_volt_local = 0;  // battery voltage

} SensorValues_t;
