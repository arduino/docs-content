#pragma once

typedef struct
{

  float water_level_local;  //0-100% from o to 1 meter
  int z1_local = 0;         //zone 1 valve status
  int z2_local = 0;         //zone 2 valve status
  int z3_local = 0;         //zone 3 valve status
  int z4_local = 0;         //zone 4 valve status

  float z1_on_time = 0;  //zone 1 valve On time accumulator
  float z2_on_time = 0;  //zone 2 valve On time accumulator
  float z3_on_time = 0;  //zone 3 valve On time accumulator
  float z4_on_time = 0;  //zone 4 valve On time accumulator

  int z1_count = 0;  //zone 1 countdown timer
  int z2_count = 0;  //zone 1 countdown timer
  int z3_count = 0;  //zone 1 countdown timer
  int z4_count = 0;  //zone 1 countdown timer

} SensorValues_t;
