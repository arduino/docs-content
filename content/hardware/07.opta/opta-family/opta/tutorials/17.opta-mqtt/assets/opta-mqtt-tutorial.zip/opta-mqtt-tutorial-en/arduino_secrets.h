#define SECRET_SSID ""               // Wi-Fi network SSID (name)
#define SECRET_PASS ""               // Wi-Fi network password
#define MQTT_BROKER ""  // MQTT broker address
#define MQTT_PORT 1883                // MQTT broker port
#define MQTT_TOPIC ""   // MQTT topic to publish messages to
#define MQTT_USER ""                 // MQTT broker username (if required)
#define MQTT_PASSWORD ""             // MQTT broker password (if required)