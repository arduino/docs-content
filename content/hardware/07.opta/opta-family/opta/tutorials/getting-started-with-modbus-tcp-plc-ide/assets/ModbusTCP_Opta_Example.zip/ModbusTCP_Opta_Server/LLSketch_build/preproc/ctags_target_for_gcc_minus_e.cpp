# 1 "D:\\Downloads\\Personal Projects\\ARDUINO\\PLC IDE\\Modbus Tutorial Expansion\\Modbus TCP with PLC IDE - Opta\\Example Software\\ModbusTCP_Opta_Server\\LLSketch\\LLSketch.ino"
# 2 "D:\\Downloads\\Personal Projects\\ARDUINO\\PLC IDE\\Modbus Tutorial Expansion\\Modbus TCP with PLC IDE - Opta\\Example Software\\ModbusTCP_Opta_Server\\LLSketch\\LLSketch.ino" 2

/* opta_1.0.3
*/

struct PLCSharedVarsInput_t
{
};
PLCSharedVarsInput_t& PLCIn = (PLCSharedVarsInput_t&)m_PLCSharedVarsInputBuf;

struct PLCSharedVarsOutput_t
{
};
PLCSharedVarsOutput_t& PLCOut = (PLCSharedVarsOutput_t&)m_PLCSharedVarsOutputBuf;


AlPlc AxelPLC(825063354);

// shared variables can be accessed with PLCIn.varname and PLCOut.varname

// Enable usage of EtherClass, to set static IP address and other
# 23 "D:\\Downloads\\Personal Projects\\ARDUINO\\PLC IDE\\Modbus Tutorial Expansion\\Modbus TCP with PLC IDE - Opta\\Example Software\\ModbusTCP_Opta_Server\\LLSketch\\LLSketch.ino" 2
arduino::EthernetClass eth(&m_netInterface);

void setup()
{
 // Configure static IP address
 IPAddress ip(192, 168, 1, 2);
 IPAddress dns(192, 168, 1, 23);
 IPAddress gateway(192, 168, 1, 23);
 IPAddress subnet(255, 255, 255, 0);
 // If cable is not connected this will block the start of PLC with about 60s of timeout!
 eth.begin(ip, dns, gateway, subnet);

 AxelPLC.Run();
}

void loop()
{

}
