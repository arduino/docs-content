char ssid[] = "YOUR_SSID"; // Your network SSID (name)
char password[] = "YOUR_PASSWORD"; // Your network password (use for WPA, or use as key for WEP)