/**
  Axis Finder for the Nesso N1 Gesture Remote
  Name: nesso_axis_finder.ino
  Purpose: Streams accelerometer and gyroscope readings to the Serial
  Plotter so you can see which axis does what before configuring the
  gesture remote.

  @version 1.0 03/11/26
  @author Arduino Product Experience Team
*/

#include <Arduino_Nesso_N1.h>

void setup() {
  Serial.begin(115200);

  while (!IMU.begin()) {
    Serial.println("IMU not found, retrying...");
    delay(1000);
  }
}

void loop() {
  float ax, ay, az, gx, gy, gz;

  if (IMU.accelerationAvailable() && IMU.gyroscopeAvailable()) {
    IMU.readAcceleration(ax, ay, az);
    IMU.readGyroscope(gx, gy, gz);

    // Gyroscope values are divided by 100 so both sensors fit on one plot
    Serial.printf("aX:%.2f aY:%.2f aZ:%.2f gX:%.2f gY:%.2f gZ:%.2f\n",
                  ax, ay, az, gx / 100.0f, gy / 100.0f, gz / 100.0f);
  }

  delay(20);
}
