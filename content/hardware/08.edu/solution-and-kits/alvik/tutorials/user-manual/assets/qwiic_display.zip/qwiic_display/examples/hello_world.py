import qwiic_oled_base
import time

myOLED = qwiic_oled_base.QwiicOledBase()

myOLED.begin()
myOLED.set_font_type(4)

hello = "HELLO WORLD!"

for c in hello:
    myOLED.clear(myOLED.PAGE)
    myOLED.set_cursor(0, 0)
    myOLED.print(c)
    myOLED.display()
    time.sleep(0.1)

myOLED.set_font_type(1)
myOLED.clear(myOLED.PAGE)
myOLED.set_cursor(0, 0)
myOLED.print("Hello  World!")
myOLED.display()

