#!/bin/bash

connect_string=""

# Display help message
function display_help {
    echo "Usage: $0 [-p PORT]"
    echo "Options:"
    echo "  -p PORT     Specify the device port"
    echo "  -h          Display this help message"
}

# Parse command-line options
while getopts ":p:h" opt; do
    case $opt in
        p)
            # If -p is provided, set the port string
            connect_string="connect $OPTARG"
            ;;
        h)
            display_help
            exit 0
            ;;
        \?)
            echo "Invalid option: -$OPTARG" >&2
            exit 1
            ;;
        :)
            echo "Option -$OPTARG requires an argument." >&2
            exit 1
            ;;
    esac
done

if command -v python3 &>/dev/null; then
    python_command="python3"
else
    # If python3 is not available, use python
    python_command="python"
fi

# Uncomment the following line on windows machines
# python_command="python"

echo Installing oled library

$python_command -m mpremote $connect_string fs mkdir lib/qwiic_i2c
$python_command -m mpremote $connect_string fs mkdir lib/qwiic_oled_base
$python_command -m mpremote $connect_string fs mkdir lib/qwiic_oled_base/fonts

$python_command -m mpremote $connect_string fs cp qwiic_i2c/__init__.py :lib/qwiic_i2c/__init__.py
$python_command -m mpremote $connect_string fs cp qwiic_i2c/circuitpy_i2c.py :lib/qwiic_i2c/circuitpy_i2c.py
$python_command -m mpremote $connect_string fs cp qwiic_i2c/i2c_driver.py :lib/qwiic_i2c/i2c_driver.py
$python_command -m mpremote $connect_string fs cp qwiic_i2c/linux_i2c.py :lib/qwiic_i2c/linux_i2c.py
$python_command -m mpremote $connect_string fs cp qwiic_i2c/micropython_i2c.py :lib/qwiic_i2c/micropython_i2c.py

$python_command -m mpremote $connect_string fs cp qwiic_oled_base/__init__.py :lib/qwiic_oled_base/__init__.py
$python_command -m mpremote $connect_string fs cp qwiic_oled_base/oled_fonts.py :lib/qwiic_oled_base/oled_fonts.py
$python_command -m mpremote $connect_string fs cp qwiic_oled_base/oled_logos.py :lib/qwiic_oled_base/oled_logos.py
$python_command -m mpremote $connect_string fs cp qwiic_oled_base/qwiic_oled_base.py :lib/qwiic_oled_base/qwiic_oled_base.py

$python_command -m mpremote $connect_string fs cp qwiic_oled_base/fonts/0_font5x7.bin :lib/qwiic_oled_base/fonts/0_font5x7.bin
$python_command -m mpremote $connect_string fs cp qwiic_oled_base/fonts/1_font8x16.bin :lib/qwiic_oled_base/fonts/1_font8x16.bin
$python_command -m mpremote $connect_string fs cp qwiic_oled_base/fonts/2_7segment.bin :lib/qwiic_oled_base/fonts/2_7segment.bin
$python_command -m mpremote $connect_string fs cp qwiic_oled_base/fonts/3_fontlargenumber.bin :lib/qwiic_oled_base/fonts/3_fontlargenumber.bin
$python_command -m mpremote $connect_string fs cp qwiic_oled_base/fonts/4_fontlargeletter31x48.bin :lib/qwiic_oled_base/fonts/4_fontlargeletter31x48.bin

$python_command -m mpremote $connect_string reset
