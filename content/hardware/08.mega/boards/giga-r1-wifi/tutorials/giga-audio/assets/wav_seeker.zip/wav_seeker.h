
#include "AdvancedDAC.h"

struct adc_descr_t;

void wav_play_rl(FILE *wavefile, AdvancedDAC &dac_out, bool verbosity);