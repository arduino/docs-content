<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.1.3">
<drawing>
<settings>
<setting alwaysvectorfont="no"/>
<setting keepoldvectorfont="yes"/>
<setting verticaltext="up"/>
</settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="no" active="no"/>
<layer number="2" name="Route2" color="1" fill="3" visible="no" active="no"/>
<layer number="3" name="Route3" color="4" fill="3" visible="no" active="no"/>
<layer number="4" name="Route4" color="1" fill="4" visible="no" active="no"/>
<layer number="5" name="Route5" color="4" fill="4" visible="no" active="no"/>
<layer number="6" name="Route6" color="1" fill="8" visible="no" active="no"/>
<layer number="7" name="Route7" color="4" fill="8" visible="no" active="no"/>
<layer number="8" name="Route8" color="1" fill="2" visible="no" active="no"/>
<layer number="9" name="Route9" color="4" fill="2" visible="no" active="no"/>
<layer number="10" name="Route10" color="1" fill="7" visible="no" active="no"/>
<layer number="11" name="Route11" color="4" fill="7" visible="no" active="no"/>
<layer number="12" name="Route12" color="1" fill="5" visible="no" active="no"/>
<layer number="13" name="Route13" color="4" fill="5" visible="no" active="no"/>
<layer number="14" name="Route14" color="1" fill="6" visible="no" active="no"/>
<layer number="15" name="Route15" color="4" fill="6" visible="no" active="no"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="no" active="no"/>
<layer number="17" name="Pads" color="2" fill="1" visible="no" active="no"/>
<layer number="18" name="Vias" color="14" fill="1" visible="no" active="no"/>
<layer number="19" name="Unrouted" color="6" fill="1" visible="no" active="no"/>
<layer number="20" name="Dimension" color="15" fill="1" visible="no" active="no"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="22" name="bPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="23" name="tOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="24" name="bOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="25" name="tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="26" name="bNames" color="7" fill="1" visible="no" active="no"/>
<layer number="27" name="tValues" color="7" fill="1" visible="no" active="no"/>
<layer number="28" name="bValues" color="7" fill="1" visible="no" active="no"/>
<layer number="29" name="tStop" color="2" fill="3" visible="no" active="no"/>
<layer number="30" name="bStop" color="5" fill="6" visible="no" active="no"/>
<layer number="31" name="tCream" color="7" fill="4" visible="no" active="no"/>
<layer number="32" name="bCream" color="7" fill="5" visible="no" active="no"/>
<layer number="33" name="tFinish" color="6" fill="3" visible="no" active="no"/>
<layer number="34" name="bFinish" color="6" fill="6" visible="no" active="no"/>
<layer number="35" name="tGlue" color="7" fill="4" visible="no" active="no"/>
<layer number="36" name="bGlue" color="7" fill="5" visible="no" active="no"/>
<layer number="37" name="tTest" color="7" fill="1" visible="no" active="no"/>
<layer number="38" name="bTest" color="7" fill="1" visible="no" active="no"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="no" active="no"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="no" active="no"/>
<layer number="41" name="tRestrict" color="4" fill="10" visible="no" active="no"/>
<layer number="42" name="bRestrict" color="1" fill="10" visible="no" active="no"/>
<layer number="43" name="vRestrict" color="2" fill="10" visible="no" active="no"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="no"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="no"/>
<layer number="46" name="Milling" color="3" fill="1" visible="no" active="no"/>
<layer number="47" name="Measures" color="7" fill="1" visible="no" active="no"/>
<layer number="48" name="Document" color="7" fill="1" visible="no" active="no"/>
<layer number="49" name="Reference" color="13" fill="1" visible="no" active="no"/>
<layer number="50" name="dxf" color="12" fill="1" visible="no" active="no"/>
<layer number="51" name="tDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="52" name="bDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="53" name="tGND_GNDA" color="7" fill="1" visible="no" active="no"/>
<layer number="54" name="bGND_GNDA" color="7" fill="1" visible="no" active="no"/>
<layer number="56" name="wert" color="7" fill="1" visible="no" active="no"/>
<layer number="57" name="tCAD" color="7" fill="1" visible="no" active="no"/>
<layer number="59" name="tCarbon" color="7" fill="1" visible="no" active="no"/>
<layer number="60" name="bCarbon" color="7" fill="1" visible="no" active="no"/>
<layer number="88" name="SimResults" color="9" fill="1" visible="yes" active="yes"/>
<layer number="89" name="SimProbes" color="9" fill="1" visible="yes" active="yes"/>
<layer number="90" name="Modules" color="5" fill="1" visible="yes" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="yes" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
<layer number="98" name="Guide" color="6" fill="1" visible="yes" active="yes"/>
<layer number="99" name="SpiceOrder" color="7" fill="1" visible="yes" active="yes"/>
<layer number="100" name="Mechanical" color="7" fill="1" visible="no" active="no"/>
<layer number="101" name="Patch_Top" color="7" fill="1" visible="yes" active="yes"/>
<layer number="102" name="Vscore" color="7" fill="1" visible="yes" active="yes"/>
<layer number="103" name="tMap" color="7" fill="1" visible="yes" active="yes"/>
<layer number="104" name="Name" color="7" fill="1" visible="yes" active="yes"/>
<layer number="105" name="tPlate" color="7" fill="1" visible="yes" active="yes"/>
<layer number="106" name="bPlate" color="7" fill="1" visible="yes" active="yes"/>
<layer number="107" name="Crop" color="7" fill="1" visible="yes" active="yes"/>
<layer number="108" name="fp8" color="7" fill="1" visible="no" active="no"/>
<layer number="109" name="fp9" color="7" fill="1" visible="no" active="no"/>
<layer number="110" name="110" color="7" fill="1" visible="no" active="no"/>
<layer number="111" name="111" color="7" fill="1" visible="no" active="no"/>
<layer number="112" name="tSilk" color="7" fill="1" visible="no" active="no"/>
<layer number="113" name="ReferenceLS" color="7" fill="1" visible="no" active="no"/>
<layer number="114" name="FRNTMAAT1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="115" name="FRNTMAAT2" color="7" fill="1" visible="yes" active="yes"/>
<layer number="116" name="Patch_BOT" color="7" fill="1" visible="yes" active="yes"/>
<layer number="117" name="BACKMAAT1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="118" name="Rect_Pads" color="7" fill="1" visible="no" active="no"/>
<layer number="119" name="KAP_TEKEN" color="7" fill="1" visible="yes" active="yes"/>
<layer number="120" name="KAP_MAAT1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="121" name="_tsilk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="122" name="_bsilk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="123" name="tTestmark" color="7" fill="1" visible="no" active="no"/>
<layer number="124" name="bTestmark" color="7" fill="1" visible="no" active="no"/>
<layer number="125" name="_tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="126" name="_bNames" color="7" fill="1" visible="no" active="no"/>
<layer number="127" name="_tValues" color="7" fill="1" visible="no" active="no"/>
<layer number="128" name="_bValues" color="7" fill="1" visible="no" active="no"/>
<layer number="129" name="top_silk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="130" name="SMDSTROOK" color="7" fill="1" visible="yes" active="yes"/>
<layer number="131" name="tAdjust" color="7" fill="1" visible="no" active="no"/>
<layer number="132" name="bAdjust" color="7" fill="1" visible="no" active="no"/>
<layer number="133" name="bottom_silk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="134" name="silk_top" color="7" fill="1" visible="yes" active="yes"/>
<layer number="135" name="silk_bottom" color="7" fill="1" visible="yes" active="yes"/>
<layer number="136" name="silktop" color="7" fill="1" visible="yes" active="yes"/>
<layer number="137" name="silkbottom" color="7" fill="1" visible="yes" active="yes"/>
<layer number="138" name="EEE" color="7" fill="1" visible="yes" active="yes"/>
<layer number="139" name="_tKeepout" color="7" fill="1" visible="yes" active="yes"/>
<layer number="140" name="mbKeepout" color="7" fill="1" visible="yes" active="yes"/>
<layer number="141" name="ASSEMBLY_TOP" color="7" fill="1" visible="yes" active="yes"/>
<layer number="142" name="mbRestrict" color="7" fill="1" visible="yes" active="yes"/>
<layer number="143" name="PLACE_BOUND_TOP" color="7" fill="1" visible="yes" active="yes"/>
<layer number="144" name="Drill_legend" color="7" fill="1" visible="yes" active="yes"/>
<layer number="145" name="DrillLegend_01-16" color="7" fill="1" visible="yes" active="yes"/>
<layer number="146" name="DrillLegend_01-20" color="7" fill="1" visible="yes" active="yes"/>
<layer number="147" name="PIN_NUMBER" color="7" fill="1" visible="yes" active="yes"/>
<layer number="148" name="DrillLegend_01-20" color="7" fill="1" visible="yes" active="yes"/>
<layer number="149" name="DrillLegend_02-15" color="7" fill="1" visible="yes" active="yes"/>
<layer number="150" name="Notes" color="7" fill="1" visible="no" active="no"/>
<layer number="151" name="HeatSink" color="14" fill="1" visible="no" active="no"/>
<layer number="152" name="_bDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="153" name="FabDoc1" color="6" fill="1" visible="no" active="no"/>
<layer number="154" name="FabDoc2" color="2" fill="1" visible="no" active="no"/>
<layer number="155" name="FabDoc3" color="7" fill="15" visible="no" active="no"/>
<layer number="166" name="AntennaArea" color="7" fill="1" visible="yes" active="yes"/>
<layer number="168" name="4mmHeightArea" color="7" fill="1" visible="yes" active="yes"/>
<layer number="191" name="mNets" color="7" fill="1" visible="yes" active="yes"/>
<layer number="192" name="mBusses" color="7" fill="1" visible="yes" active="yes"/>
<layer number="193" name="mPins" color="7" fill="1" visible="yes" active="yes"/>
<layer number="194" name="mSymbols" color="7" fill="1" visible="yes" active="yes"/>
<layer number="195" name="mNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="196" name="mValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="199" name="Contour" color="7" fill="1" visible="no" active="no"/>
<layer number="200" name="200bmp" color="1" fill="10" visible="yes" active="yes"/>
<layer number="201" name="201bmp" color="2" fill="1" visible="yes" active="yes"/>
<layer number="202" name="202bmp" color="3" fill="1" visible="yes" active="yes"/>
<layer number="203" name="203bmp" color="4" fill="1" visible="yes" active="yes"/>
<layer number="204" name="204bmp" color="5" fill="1" visible="yes" active="yes"/>
<layer number="205" name="205bmp" color="6" fill="1" visible="yes" active="yes"/>
<layer number="206" name="206bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="207" name="207bmp" color="8" fill="1" visible="yes" active="yes"/>
<layer number="208" name="208bmp" color="9" fill="1" visible="yes" active="yes"/>
<layer number="209" name="209bmp" color="10" fill="1" visible="yes" active="yes"/>
<layer number="210" name="210bmp" color="11" fill="1" visible="yes" active="yes"/>
<layer number="211" name="211bmp" color="12" fill="1" visible="yes" active="yes"/>
<layer number="212" name="212bmp" color="13" fill="1" visible="yes" active="yes"/>
<layer number="213" name="213bmp" color="14" fill="1" visible="yes" active="yes"/>
<layer number="214" name="214bmp" color="15" fill="1" visible="yes" active="yes"/>
<layer number="215" name="215bmp" color="16" fill="1" visible="yes" active="yes"/>
<layer number="216" name="216bmp" color="17" fill="1" visible="yes" active="yes"/>
<layer number="217" name="217bmp" color="18" fill="1" visible="yes" active="yes"/>
<layer number="218" name="218bmp" color="19" fill="1" visible="yes" active="yes"/>
<layer number="219" name="219bmp" color="20" fill="1" visible="yes" active="yes"/>
<layer number="220" name="220bmp" color="21" fill="1" visible="yes" active="yes"/>
<layer number="221" name="221bmp" color="22" fill="1" visible="yes" active="yes"/>
<layer number="222" name="222bmp" color="23" fill="1" visible="yes" active="yes"/>
<layer number="223" name="223bmp" color="24" fill="1" visible="yes" active="yes"/>
<layer number="224" name="224bmp" color="25" fill="1" visible="yes" active="yes"/>
<layer number="225" name="225bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="226" name="226bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="227" name="227bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="228" name="228bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="229" name="229bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="230" name="230bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="231" name="Eagle3D_PG1" color="7" fill="1" visible="no" active="no"/>
<layer number="232" name="Eagle3D_PG2" color="7" fill="1" visible="no" active="no"/>
<layer number="233" name="Eagle3D_PG3" color="7" fill="1" visible="no" active="no"/>
<layer number="248" name="Housing" color="7" fill="1" visible="no" active="no"/>
<layer number="249" name="Edge" color="7" fill="1" visible="no" active="no"/>
<layer number="250" name="Descript" color="3" fill="1" visible="no" active="no"/>
<layer number="251" name="SMDround" color="12" fill="11" visible="no" active="no"/>
<layer number="254" name="OrgLBR" color="13" fill="1" visible="no" active="no"/>
<layer number="255" name="Accent" color="7" fill="1" visible="yes" active="yes"/>
</layers>
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<libraries>
<library name="supply1" urn="urn:adsk.eagle:library:371">
<packages>
</packages>
<symbols>
<symbol name="GND" urn="urn:adsk.eagle:symbol:26925/1" library_version="1">
<wire x1="-1.905" y1="0" x2="1.905" y2="0" width="0.254" layer="94"/>
<text x="-2.54" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="GND" urn="urn:adsk.eagle:component:26954/1" prefix="GND" library_version="1">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="1" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Opto">
<packages>
<package name="CHIPLED_0805">
<description>&lt;b&gt;CHIPLED&lt;/b&gt;&lt;p&gt;
Source: http://www.osram.convergy.de/ ... LG_R971.pdf</description>
<circle x="-0.45" y="0.85" radius="0.103" width="0.1016" layer="51"/>
<wire x1="-0.35" y1="0.925" x2="0.35" y2="0.925" width="0.1016" layer="51" curve="162.394521"/>
<wire x1="-0.35" y1="-0.925" x2="0.35" y2="-0.925" width="0.1016" layer="51" curve="-162.394521"/>
<wire x1="0.575" y1="0.525" x2="0.575" y2="-0.525" width="0.1016" layer="51"/>
<wire x1="-0.575" y1="-0.5" x2="-0.575" y2="0.925" width="0.1016" layer="51"/>
<rectangle x1="0.3" y1="0.5" x2="0.625" y2="1" layer="51"/>
<rectangle x1="-0.325" y1="0.5" x2="-0.175" y2="0.75" layer="51"/>
<rectangle x1="0.175" y1="0.5" x2="0.325" y2="0.75" layer="51"/>
<rectangle x1="-0.2" y1="0.5" x2="0.2" y2="0.675" layer="51"/>
<rectangle x1="0.3" y1="-1" x2="0.625" y2="-0.5" layer="51"/>
<rectangle x1="-0.625" y1="-1" x2="-0.3" y2="-0.5" layer="51"/>
<rectangle x1="0.175" y1="-0.75" x2="0.325" y2="-0.5" layer="51"/>
<rectangle x1="-0.325" y1="-0.75" x2="-0.175" y2="-0.5" layer="51"/>
<rectangle x1="-0.2" y1="-0.675" x2="0.2" y2="-0.5" layer="51"/>
<rectangle x1="-0.1" y1="0" x2="0.1" y2="0.2" layer="21"/>
<rectangle x1="-0.6" y1="0.5" x2="-0.3" y2="0.8" layer="51"/>
<rectangle x1="-0.625" y1="0.925" x2="-0.3" y2="1" layer="51"/>
<smd name="A" x="0" y="-1.05" dx="1.2" dy="1.2" layer="1"/>
<smd name="C" x="0" y="1.05" dx="1.2" dy="1.2" layer="1"/>
<text x="-1.27" y="-1.27" size="1.27" layer="25" rot="R90">&gt;NAME</text>
<text x="2.54" y="-1.27" size="1.27" layer="27" rot="R90">&gt;VALUE</text>
</package>
</packages>
<symbols>
<symbol name="LED">
<wire x1="1.27" y1="0" x2="0" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="-1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="-2.54" x2="0" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="-1.27" y2="-2.54" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="-1.27" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-2.032" y1="-0.762" x2="-3.429" y2="-2.159" width="0.1524" layer="94"/>
<wire x1="-1.905" y1="-1.905" x2="-3.302" y2="-3.302" width="0.1524" layer="94"/>
<pin name="A" x="0" y="2.54" visible="off" length="short" direction="pas" rot="R270"/>
<pin name="C" x="0" y="-5.08" visible="off" length="short" direction="pas" rot="R90"/>
<text x="3.556" y="-4.572" size="1.778" layer="95" rot="R90">&gt;NAME</text>
<text x="5.715" y="-4.572" size="1.778" layer="96" rot="R90">&gt;VALUE</text>
<polygon width="0.1524" layer="94">
<vertex x="-3.429" y="-2.159"/>
<vertex x="-3.048" y="-1.27"/>
<vertex x="-2.54" y="-1.778"/>
</polygon>
<polygon width="0.1524" layer="94">
<vertex x="-3.302" y="-3.302"/>
<vertex x="-2.921" y="-2.413"/>
<vertex x="-2.413" y="-2.921"/>
</polygon>
</symbol>
</symbols>
<devicesets>
<deviceset name="0044_KPT-2012YC" prefix="LED" uservalue="yes">
<description>LED YELLOW - SMD - 0805</description>
<gates>
<gate name="G$1" symbol="LED" x="0" y="0"/>
</gates>
<devices>
<device name="" package="CHIPLED_0805">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name="">
<attribute name="CASE" value=""/>
<attribute name="MONTHLY_USAGE" value="_____"/>
<attribute name="PART_NUMBER" value="KPT-2012YC"/>
<attribute name="PRICE" value="_____"/>
<attribute name="SUPPLIER" value="_____"/>
<attribute name="TYPE" value="Opto"/>
<attribute name="VALUE" value="Yellow"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-utility">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="FD-1-2">
<circle x="0" y="0" radius="0.5" width="2.1844" layer="29"/>
<circle x="0" y="0" radius="1.5" width="0.127" layer="41"/>
<smd name="P$1" x="0" y="0" dx="1.016" dy="1.016" layer="1" roundness="100"/>
</package>
<package name="FD-1-1.5">
<circle x="0" y="0" radius="0.5" width="1.2" layer="29"/>
<circle x="0" y="0" radius="1" width="0.127" layer="41"/>
<smd name="P$1" x="0" y="0" dx="1.016" dy="1.016" layer="1" roundness="100" cream="no"/>
</package>
<package name="FRAME-NO-BAN-FRAMEONLY">
</package>
<package name="FRAME">
<text x="0" y="-17.78" size="1.27" layer="51">Reference Designs ARE PROVIDED "AS IS" AND "WITH ALL FAULTS. Arduino SA DISCLAIMS ALL OTHER WARRANTIES, EXPRESS OR IMPLIED,
REGARDING PRODUCTS, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A 
PARTICULAR PURPOSE 
Arduino SA may make changes to specifications and product descriptions at any time, without notice. The Customer must not
rely on the absence or characteristics of any features or instructions marked "reserved" or "undefined." Arduino SA reserves
these for future definition and shall have no responsibility whatsoever for conflicts or incompatibilities arising from future changes to them.
The product information on the Web Site or Materials is subject to change without notice. Do not finalize a design with this info

ARDUINO and other Arduino brands and logos and Trademarks of Arduino SA. All Arduino SA Trademarks cannot be used without owner's formal permission

This file is licensed under : CC-SA-BY-NC</text>
</package>
</packages>
<symbols>
<symbol name="ARDUINO_FIDUCIAL">
<circle x="0" y="0" radius="2.54" width="0.254" layer="94"/>
</symbol>
<symbol name="A3L-LOC-FRAMEONLY">
<wire x1="288.29" y1="3.81" x2="342.265" y2="3.81" width="0.1016" layer="94"/>
<wire x1="342.265" y1="3.81" x2="373.38" y2="3.81" width="0.1016" layer="94"/>
<wire x1="373.38" y1="3.81" x2="383.54" y2="3.81" width="0.1016" layer="94"/>
<wire x1="383.54" y1="3.81" x2="383.54" y2="8.89" width="0.1016" layer="94"/>
<wire x1="383.54" y1="8.89" x2="383.54" y2="13.97" width="0.1016" layer="94"/>
<wire x1="383.54" y1="13.97" x2="383.54" y2="19.05" width="0.1016" layer="94"/>
<wire x1="383.54" y1="19.05" x2="383.54" y2="24.13" width="0.1016" layer="94"/>
<wire x1="288.29" y1="3.81" x2="288.29" y2="24.13" width="0.1016" layer="94"/>
<wire x1="288.29" y1="24.13" x2="342.265" y2="24.13" width="0.1016" layer="94"/>
<wire x1="342.265" y1="24.13" x2="383.54" y2="24.13" width="0.1016" layer="94"/>
<wire x1="373.38" y1="3.81" x2="373.38" y2="8.89" width="0.1016" layer="94"/>
<wire x1="373.38" y1="8.89" x2="383.54" y2="8.89" width="0.1016" layer="94"/>
<wire x1="373.38" y1="8.89" x2="342.265" y2="8.89" width="0.1016" layer="94"/>
<wire x1="342.265" y1="8.89" x2="342.265" y2="3.81" width="0.1016" layer="94"/>
<wire x1="342.265" y1="8.89" x2="342.265" y2="13.97" width="0.1016" layer="94"/>
<wire x1="342.265" y1="13.97" x2="383.54" y2="13.97" width="0.1016" layer="94"/>
<wire x1="342.265" y1="13.97" x2="342.265" y2="19.05" width="0.1016" layer="94"/>
<wire x1="342.265" y1="19.05" x2="383.54" y2="19.05" width="0.1016" layer="94"/>
<wire x1="342.265" y1="19.05" x2="342.265" y2="24.13" width="0.1016" layer="94"/>
<text x="344.17" y="15.24" size="2.54" layer="94" font="vector">&gt;DRAWING_NAME</text>
<text x="344.17" y="10.16" size="2.286" layer="94" font="vector">&gt;LAST_DATE_TIME</text>
<text x="357.505" y="5.08" size="2.54" layer="94" font="vector">&gt;SHEET</text>
<text x="343.916" y="4.953" size="2.54" layer="94" font="vector">Sheet:</text>
<frame x1="0" y1="0" x2="387.35" y2="260.35" columns="8" rows="5" layer="94"/>
</symbol>
<symbol name="TEXT-ONLY">
<text x="129.54" y="17.78" size="1.016" layer="98" font="vector" rot="R180">Reference Designs ARE PROVIDED "AS IS" AND "WITH ALL FAULTS. Arduino SA DISCLAIMS ALL OTHER WARRANTIES, EXPRESS OR IMPLIED,
REGARDING PRODUCTS, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A 
PARTICULAR PURPOSE 
Arduino SA may make changes to specifications and product descriptions at any time, without notice. The Customer must not
rely on the absence or characteristics of any features or instructions marked "reserved" or "undefined." Arduino SA reserves
these for future definition and shall have no responsibility whatsoever for conflicts or incompatibilities arising from future changes to them.
The product information on the Web Site or Materials is subject to change without notice. Do not finalize a design with this info

ARDUINO and other Arduino brands and logos and Trademarks of Arduino SA. All Arduino SA Trademarks cannot be used without owner's formal permission

This file is licensed under : CC-SA-BY-NC</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="FIDUCIAL" prefix="FD">
<description>Fiducial mount</description>
<gates>
<gate name="G$1" symbol="ARDUINO_FIDUCIAL" x="0" y="0"/>
</gates>
<devices>
<device name="-2MM" package="FD-1-2">
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="-1.5MM" package="FD-1-1.5">
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="A3-FRAMEONLY" prefix="FRAME" uservalue="yes">
<description>Schematic frame</description>
<gates>
<gate name="G$1" symbol="A3L-LOC-FRAMEONLY" x="0" y="0"/>
</gates>
<devices>
<device name="" package="FRAME-NO-BAN-FRAMEONLY">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="TEXT" prefix="FRAME" uservalue="yes">
<description>&lt;b&gt;TEXT&lt;/b&gt;&lt;p&gt;
Text only, no title block</description>
<gates>
<gate name="G$1" symbol="TEXT-ONLY" x="0" y="0"/>
</gates>
<devices>
<device name="TEXT_SCH" package="FRAME-NO-BAN-FRAMEONLY">
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="TEXT_BRDSCH" package="FRAME">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-rcl">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="0603-1608X90N">
<circle x="0" y="0" radius="0.25" width="0.05" layer="39"/>
<wire x1="-0.814" y1="-0.4" x2="0.786" y2="-0.4" width="0.025" layer="51"/>
<wire x1="0.786" y1="-0.4" x2="0.786" y2="0.4" width="0.025" layer="51"/>
<wire x1="0.786" y1="0.4" x2="-0.814" y2="0.4" width="0.025" layer="51"/>
<wire x1="-0.814" y1="0.4" x2="-0.814" y2="-0.4" width="0.025" layer="51"/>
<wire x1="-0.35" y1="0" x2="0.35" y2="0" width="0.05" layer="39"/>
<wire x1="0" y1="-0.35" x2="0" y2="0.35" width="0.05" layer="39"/>
<wire x1="-1.6" y1="0.8" x2="-1.6" y2="-0.8" width="0.05" layer="39"/>
<wire x1="-1.6" y1="-0.8" x2="1.6" y2="-0.8" width="0.05" layer="39"/>
<wire x1="1.6" y1="-0.8" x2="1.6" y2="0.8" width="0.05" layer="39"/>
<wire x1="1.6" y1="0.8" x2="-1.6" y2="0.8" width="0.05" layer="39"/>
<smd name="1" x="-0.8" y="0" dx="0.95" dy="1" layer="1" roundness="3"/>
<smd name="2" x="0.8" y="0" dx="0.95" dy="1" layer="1" roundness="3"/>
<text x="-1.27" y="0.9525" size="0.6096" layer="25" font="vector" ratio="10">&gt;NAME</text>
</package>
<package name="0402-1005X55N">
<circle x="0" y="0" radius="0.25" width="0.05" layer="39"/>
<wire x1="-0.5" y1="-0.25" x2="0.5" y2="-0.25" width="0.025" layer="51"/>
<wire x1="0.5" y1="-0.25" x2="0.5" y2="0.25" width="0.025" layer="51"/>
<wire x1="0.5" y1="0.25" x2="-0.5" y2="0.25" width="0.025" layer="51"/>
<wire x1="-0.5" y1="0.25" x2="-0.5" y2="-0.25" width="0.025" layer="51"/>
<wire x1="-0.35" y1="0" x2="0.35" y2="0" width="0.05" layer="39"/>
<wire x1="0" y1="-0.35" x2="0" y2="0.35" width="0.05" layer="39"/>
<wire x1="-0.95" y1="0.45" x2="0.95" y2="0.45" width="0.05" layer="39"/>
<wire x1="0.95" y1="0.45" x2="0.95" y2="-0.45" width="0.05" layer="39"/>
<wire x1="0.95" y1="-0.45" x2="-0.95" y2="-0.45" width="0.05" layer="39"/>
<wire x1="-0.95" y1="-0.45" x2="-0.95" y2="0.45" width="0.05" layer="39"/>
<smd name="1" x="-0.45" y="0" dx="0.62" dy="0.62" layer="1" roundness="3"/>
<smd name="2" x="0.45" y="0" dx="0.62" dy="0.62" layer="1" roundness="3"/>
<text x="-0.9" y="0.5" size="0.4064" layer="51" font="vector" ratio="10">&gt;NAME</text>
</package>
<package name="0805-R2013X50N">
<circle x="0" y="0" radius="0.25" width="0.05" layer="39"/>
<wire x1="1" y1="-0.625" x2="1" y2="0.625" width="0.025" layer="51"/>
<wire x1="1" y1="0.625" x2="-1" y2="0.625" width="0.025" layer="51"/>
<wire x1="-1" y1="0.625" x2="-1" y2="-0.625" width="0.025" layer="51"/>
<wire x1="-1" y1="-0.625" x2="1" y2="-0.625" width="0.025" layer="51"/>
<wire x1="0" y1="-0.35" x2="0" y2="0.35" width="0.05" layer="39"/>
<wire x1="0.35" y1="0" x2="-0.35" y2="0" width="0.05" layer="39"/>
<wire x1="-1.75" y1="1" x2="1.75" y2="1" width="0.05" layer="39"/>
<wire x1="1.75" y1="1" x2="1.75" y2="-1" width="0.05" layer="39"/>
<wire x1="1.75" y1="-1" x2="-1.75" y2="-1" width="0.05" layer="39"/>
<wire x1="-1.75" y1="-1" x2="-1.75" y2="1" width="0.05" layer="39"/>
<smd name="1" x="-1" y="0" dx="0.95" dy="1.45" layer="1" roundness="3"/>
<smd name="2" x="1" y="0" dx="0.95" dy="1.45" layer="1" roundness="3"/>
<text x="0" y="1.27" size="0.6096" layer="25" font="vector" ratio="10" align="center">&gt;NAME</text>
</package>
<package name="C1206">
<smd name="1" x="0" y="1.4" dx="1.8" dy="1.45" layer="1" roundness="20"/>
<smd name="2" x="0" y="-1.4" dx="1.8" dy="1.45" layer="1" roundness="20"/>
<wire x1="-0.85" y1="1.6" x2="-0.85" y2="1" width="0.127" layer="21"/>
<wire x1="-0.85" y1="1" x2="-0.85" y2="-1" width="0.127" layer="21"/>
<wire x1="-0.85" y1="-1" x2="-0.85" y2="-1.6" width="0.127" layer="21"/>
<wire x1="0.85" y1="1.6" x2="0.85" y2="1" width="0.127" layer="21"/>
<wire x1="0.85" y1="1" x2="0.85" y2="-1" width="0.127" layer="21"/>
<wire x1="0.85" y1="-1" x2="0.85" y2="-1.6" width="0.127" layer="21"/>
<wire x1="0.85" y1="1.6" x2="-0.85" y2="1.6" width="0.127" layer="21"/>
<wire x1="0.85" y1="-1.6" x2="-0.85" y2="-1.6" width="0.127" layer="21"/>
<wire x1="0.85" y1="1" x2="-0.85" y2="1" width="0.127" layer="21"/>
<wire x1="0.85" y1="-1" x2="-0.85" y2="-1" width="0.127" layer="21"/>
<text x="-1.5875" y="0" size="0.8128" layer="25" font="vector" ratio="10" rot="R270" align="center">&gt;NAME</text>
</package>
<package name="CAY16">
<description>&lt;b&gt;BOURNS&lt;/b&gt; Chip Resistor Array&lt;p&gt;
Source: RS Component / BUORNS</description>
<wire x1="-1.55" y1="0.75" x2="-1" y2="0.75" width="0.1016" layer="51"/>
<wire x1="-0.6" y1="0.75" x2="-0.2" y2="0.75" width="0.1016" layer="51"/>
<wire x1="0.2" y1="0.75" x2="0.6" y2="0.75" width="0.1016" layer="51"/>
<wire x1="1" y1="0.75" x2="1.55" y2="0.75" width="0.1016" layer="51"/>
<wire x1="1.55" y1="0.75" x2="1.55" y2="-0.75" width="0.1016" layer="51"/>
<wire x1="-1.55" y1="-0.75" x2="-1.55" y2="0.75" width="0.1016" layer="51"/>
<wire x1="-1" y1="0.75" x2="-0.6" y2="0.75" width="0.1016" layer="51" curve="180"/>
<wire x1="-0.2" y1="0.75" x2="0.2" y2="0.75" width="0.1016" layer="51" curve="180"/>
<wire x1="0.6" y1="0.75" x2="1" y2="0.75" width="0.1016" layer="51" curve="180"/>
<wire x1="1.55" y1="-0.75" x2="1" y2="-0.75" width="0.1016" layer="51"/>
<wire x1="0.6" y1="-0.75" x2="0.2" y2="-0.75" width="0.1016" layer="51"/>
<wire x1="-0.2" y1="-0.75" x2="-0.6" y2="-0.75" width="0.1016" layer="51"/>
<wire x1="-1" y1="-0.75" x2="-1.55" y2="-0.75" width="0.1016" layer="51"/>
<wire x1="1" y1="-0.75" x2="0.6" y2="-0.75" width="0.1016" layer="51" curve="180"/>
<wire x1="0.2" y1="-0.75" x2="-0.2" y2="-0.75" width="0.1016" layer="51" curve="180"/>
<wire x1="-0.6" y1="-0.75" x2="-1" y2="-0.75" width="0.1016" layer="51" curve="180"/>
<smd name="1" x="-1.2" y="-0.675" dx="0.5" dy="0.65" layer="1"/>
<smd name="2" x="-0.4" y="-0.675" dx="0.5" dy="0.65" layer="1"/>
<smd name="3" x="0.4" y="-0.675" dx="0.5" dy="0.65" layer="1"/>
<smd name="4" x="1.2" y="-0.675" dx="0.5" dy="0.65" layer="1"/>
<smd name="5" x="1.2" y="0.675" dx="0.5" dy="0.65" layer="1"/>
<smd name="6" x="0.4" y="0.675" dx="0.5" dy="0.65" layer="1"/>
<smd name="7" x="-0.4" y="0.675" dx="0.5" dy="0.65" layer="1"/>
<smd name="8" x="-1.2" y="0.675" dx="0.5" dy="0.65" layer="1"/>
<text x="-1.905" y="-2.54" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-1.905" y="1.27" size="1.27" layer="27" ratio="10">&gt;VALUE</text>
</package>
<package name="C1210">
<smd name="1" x="0" y="1.4" dx="2.7" dy="1.45" layer="1" roundness="20"/>
<smd name="2" x="0" y="-1.35" dx="2.7" dy="1.45" layer="1" roundness="20"/>
<text x="-2.2225" y="0" size="0.8128" layer="25" font="vector" ratio="10" rot="R270" align="center">&gt;NAME</text>
<text x="2.2225" y="0" size="0.8128" layer="27" font="vector" ratio="10" rot="R270" align="center">&gt;VALUE</text>
<wire x1="-1.3" y1="1.6" x2="-1.3" y2="1" width="0.127" layer="21"/>
<wire x1="-1.3" y1="1" x2="-1.3" y2="-1" width="0.127" layer="21"/>
<wire x1="-1.3" y1="-1" x2="-1.3" y2="-1.6" width="0.127" layer="21"/>
<wire x1="1.3" y1="1.6" x2="1.3" y2="1" width="0.127" layer="21"/>
<wire x1="1.3" y1="1" x2="1.3" y2="-1" width="0.127" layer="21"/>
<wire x1="1.3" y1="-1" x2="1.3" y2="-1.6" width="0.127" layer="21"/>
<wire x1="1.3" y1="1.6" x2="-1.3" y2="1.6" width="0.127" layer="21"/>
<wire x1="1.3" y1="-1.6" x2="-1.3" y2="-1.6" width="0.127" layer="21"/>
<wire x1="1.3" y1="1" x2="-1.3" y2="1" width="0.127" layer="21"/>
<wire x1="1.3" y1="-1" x2="-1.3" y2="-1" width="0.127" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="C">
<rectangle x1="-2.032" y1="-0.762" x2="2.032" y2="-0.254" layer="94"/>
<rectangle x1="-2.032" y1="0.254" x2="2.032" y2="0.762" layer="94"/>
<wire x1="0" y1="2.54" x2="0" y2="0.762" width="0.1524" layer="94"/>
<wire x1="0" y1="-2.54" x2="0" y2="-0.762" width="0.1524" layer="94"/>
<pin name="1" x="0" y="2.54" visible="off" length="point" direction="pas" swaplevel="1" rot="R270"/>
<pin name="2" x="0" y="-2.54" visible="off" length="point" direction="pas" swaplevel="1" rot="R90"/>
<text x="1.524" y="1.651" size="1.778" layer="95">&gt;NAME</text>
<text x="1.524" y="-3.429" size="1.778" layer="96">&gt;VALUE</text>
</symbol>
<symbol name="R1NV">
<wire x1="-2.54" y1="-0.762" x2="2.54" y2="-0.762" width="0.254" layer="94"/>
<wire x1="2.54" y1="0.762" x2="-2.54" y2="0.762" width="0.254" layer="94"/>
<wire x1="2.54" y1="-0.762" x2="2.54" y2="0.762" width="0.254" layer="94"/>
<wire x1="-2.54" y1="0.762" x2="-2.54" y2="-0.762" width="0.254" layer="94"/>
<pin name="1" x="-5.08" y="0" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="5.08" y="0" visible="pad" length="short" direction="pas" swaplevel="1" rot="R180"/>
<text x="2.54" y="-3.048" size="1.778" layer="96">&gt;VALUE</text>
<text x="-5.08" y="-3.048" size="1.778" layer="95">&gt;NAME</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="C" prefix="C" uservalue="yes">
<description>SMD Capacitor</description>
<gates>
<gate name="G$1" symbol="C" x="0" y="0"/>
</gates>
<devices>
<device name="-0402" package="0402-1005X55N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-100NF">
<attribute name="CODE-ARDUINO" value="0132" constant="no"/>
<attribute name="DATASHEET" value="http://www.tdk.com/pdf/TDKMLCCCapRange.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/tdk-corporation/C1005X5R1H104K050BB/445-5942-1-ND/2443982" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="445-5942-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="TDK" constant="no"/>
<attribute name="MANUFACTURER-PN" value="C1005X5R1H104K050BB" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="100n" constant="no"/>
</technology>
<technology name="-10NF">
<attribute name="CODE-ARDUINO" value="0165" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R71H103KA88J/490-6351-1-ND/3845548" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-6351-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata " constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R71H103KA88J " constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="10n" constant="no"/>
</technology>
<technology name="-10PF">
<attribute name="CODE-ARDUINO" value="3382" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM1555C1H100FA01D/490-6186-1-ND/3845386" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-6186-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM1555C1H100FA01D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="10p" constant="no"/>
</technology>
<technology name="-110P">
<attribute name="CODE-ARDUINO" value="2264" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/G101/ENG/GRM1555C1H111GA01-01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM1555C1H111GA01D/490-6195-1-ND/3845392" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-6195-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM1555C1H111GA01D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="110p" constant="no"/>
</technology>
<technology name="-12PF">
<attribute name="CODE-ARDUINO" value="A5006" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GJM1555C1H120GB01D/490-8078-1-ND/4380364" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-8078-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GJM1555C1H120GB01D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="12pF" constant="no"/>
</technology>
<technology name="-15PF">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM1555C1H150JA01D/490-5888-1-ND/3315234" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-5888-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM1555C1H150JA01D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="15p" constant="no"/>
</technology>
<technology name="-18PF">
<attribute name="CODE-ARDUINO" value="2320" constant="no"/>
<attribute name="DATASHEET" value="search.murata.co.jp/Ceramy/image/img/A01X/G101/ENG/GRM1555C1H180FA01-01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM1555C1H180FA01D/490-6203-1-ND/3845400" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-6203-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM1555C1H180FA01D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="18pF" constant="no"/>
</technology>
<technology name="-1NF">
<attribute name="CODE-ARDUINO" value="2321" constant="no"/>
<attribute name="DATASHEET" value="http://www.samsungsem.com/kr/support/product-search/mlcc/__icsFiles/afieldfile/2016/08/18/S_CL05B102KB5NNNC.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/samsung-electro-mechanics-america-inc/CL05B102KB5NNNC/1276-1032-1-ND/3889118" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="1276-1032-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Samsung" constant="no"/>
<attribute name="MANUFACTURER-PN" value="CL05B102KB5NNNC " constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="1n" constant="no"/>
</technology>
<technology name="-1UF">
<attribute name="CODE-ARDUINO" value="0133" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R61E105KA12D/490-10017-1-ND/5026367" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-10017-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R61E105KA12D " constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="1u" constant="no"/>
</technology>
<technology name="-2.2UF">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R61A225KE95D/490-10451-1-ND/5026361" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-10451-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R61A225KE95D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="2u2" constant="no"/>
</technology>
<technology name="-20PF">
<attribute name="CODE-ARDUINO" value="2188" constant="no"/>
<attribute name="DATASHEET" value="http://www.kemet.com/docfinder?Partnumber=CBR04C200J5GAC" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/kemet/CBR04C200J5GAC/399-6173-1-ND/2732143" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="399-6173-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Kemet" constant="no"/>
<attribute name="MANUFACTURER-PN" value="CBR04C200J5GAC " constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="20p" constant="no"/>
</technology>
<technology name="-22N">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R71H223KA12D/490-3884-1-ND/965926" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-3884-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R71H223KA12D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="22n" constant="no"/>
</technology>
<technology name="-22PF">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.se/products/en?keywords=490-8589-1-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-8589-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM1555C1H220FA01D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="22p" constant="no"/>
</technology>
<technology name="-27PF">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/products/en?keywords=%20490-6176-1-ND%20" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-6176-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM1555C1E270JA01D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="27p" constant="no"/>
</technology>
<technology name="-33PF">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.pdf " constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-search/en?keywords=490-5936-1-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-5936-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM1555C1H330JA01D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="33p" constant="no"/>
</technology>
<technology name="-4.7UF">
<attribute name="CODE-ARDUINO" value="0833" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R60J475ME47D/490-5915-1-ND/3719860" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-5915-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R60J475ME47D " constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="4u7" constant="no"/>
</technology>
<technology name="-47N">
<attribute name="CODE-ARDUINO" value="2216" constant="no"/>
<attribute name="DATASHEET" value="http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.pdf " constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R71E473KA88D/490-3254-1-ND/702795" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-3254-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R71E473KA88D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="47n" constant="no"/>
</technology>
<technology name="-4N7">
<attribute name="CODE-ARDUINO" value="2266" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R71H472KA01J/490-8259-1-ND/4380553" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-8259-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R71H472KA01J" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="4n7" constant="no"/>
</technology>
<technology name="-56P">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.mouser.com/ds/2/281/c02e-2905.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.mouser.it/ProductDetail/Murata-Electronics/GRM1555C1E560JA01D/?qs=sGAEpiMZZMs0AnBnWHyRQA3eyUP2RfX77sTVhhB4SFb8UyJFwKUI8g%3d%3d" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="81-GRM1555C1E560JA1D" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value=" GRM1555C1E560JA01D " constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="56p" constant="no"/>
</technology>
<technology name="-5N6">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R71H562KA88D/490-6364-1-ND/3845561" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-6364-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R71H562KA88D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="5n6" constant="no"/>
</technology>
<technology name="-68PF">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM1555C2A680JA01D/490-7309-1-ND/4213238" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-7309-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM1555C2A680JA01D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="68p" constant="no"/>
</technology>
<technology name="-6N8">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/G101/ENG/GRM155R71H682KA88-01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM155R71H682KA88D/490-4515-1-ND/1033274" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-4515-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM155R71H682KA88D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="6n8" constant="no"/>
</technology>
<technology name="-8N2">
<attribute name="CODE-ARDUINO" value="2263" constant="no"/>
<attribute name="DATASHEET" value="http://www.yageo.com/documents/recent/UPY-GPHC_X7R_6.3V-to-50V_18.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/yageo/CC0402KRX7R7BB822/311-1041-1-ND/302958" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="311-1041-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Yageo" constant="no"/>
<attribute name="MANUFACTURER-PN" value="CC0402KRX7R7BB822" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="8n2" constant="no"/>
</technology>
<technology name="DNP">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="NOTE" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0805" package="0805-R2013X50N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-22U">
<attribute name="CODE-ARDUINO" value="2233" constant="no"/>
<attribute name="DATASHEET" value="https://media.digikey.com/pdf/Data%20Sheets/Samsung%20PDFs/CL21A226MQCLQNC_character.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/samsung-electro-mechanics-america-inc/CL21A226MQCLQNC/1276-2412-1-ND/3890498" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="1276-2412-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Samsung" constant="no"/>
<attribute name="MANUFACTURER-PN" value="CL21A226MQCLQNC" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="22u" constant="no"/>
</technology>
<technology name="4.7NF">
<attribute name="CODE-ARDUINO" value="0689" constant="no"/>
<attribute name="DATASHEET" value="http://www.kemet.com/Lists/ProductCatalog/Attachments/40/KEM_C1010_X7R_HV_SMD.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="www.kemet.com/docfinder?Partnumber=C0805C472KDRACTU" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="399-6738-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Kemet" constant="no"/>
<attribute name="MANUFACTURER-PN" value="C0805C472KDRACTU" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="4n7" constant="no"/>
</technology>
<technology name="DNP">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="NOTE" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="-0603" package="0603-1608X90N">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-100NF">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/G101/ENG/GRM188R71C104KA01-01.pdf " constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM188R71C104KA01D/490-1532-1-ND/587771" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-1532-2-ND " constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM188R71C104KA01D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="100n" constant="no"/>
</technology>
<technology name="-10NF">
<attribute name="CODE-ARDUINO" value="0142" constant="no"/>
<attribute name="DATASHEET" value="http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM188R71H103KA01D/490-1512-1-ND/587862" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-1512-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM188R71H103KA01D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="10n" constant="no"/>
</technology>
<technology name="-10P">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="-" constant="no"/>
<attribute name="MANUFACTURER-PN" value="-" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="10p" constant="no"/>
</technology>
<technology name="-10UF">
<attribute name="CODE-ARDUINO" value="2213" constant="no"/>
<attribute name="DATASHEET" value="http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.pdf " constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-search/en?keywords=490-10728-1-ND " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-10728-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM188R61C106KAALD" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="10u" constant="no"/>
</technology>
<technology name="-1UF">
<attribute name="CODE-ARDUINO" value="0133" constant="no"/>
<attribute name="DATASHEET" value="http://www.samsungsem.com/kr/support/product-search/mlcc/__icsFiles/afieldfile/2016/08/18/S_CL10B105KP8NNNC.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/samsung-electro-mechanics-america-inc/CL10B105KP8NNNC/1276-1946-1-ND/3890032" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="1276-1946-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Samsung" constant="no"/>
<attribute name="MANUFACTURER-PN" value="CL10B105KP8NNNC" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="1u" constant="no"/>
</technology>
<technology name="-22PF">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.samsungsem.com/kr/support/product-search/mlcc/__icsFiles/afieldfile/2016/08/18/S_CL10C220JB8NNNC.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/samsung-electro-mechanics-america-inc/CL10C220JB8NNNC/1276-1023-1-ND/3889109" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="1276-1023-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Samsung" constant="no"/>
<attribute name="MANUFACTURER-PN" value="CL10C220JB8NNNC" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="22p" constant="no"/>
</technology>
<technology name="-4.7UF">
<attribute name="CODE-ARDUINO" value="0458" constant="no"/>
<attribute name="DATASHEET" value="http://www.murata.com/~/media/webrenewal/support/library/catalog/products/capacitor/mlcc/c02e.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-search/en?keywords=490-7203-1-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-7203-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM188R61E475KE11D" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="4u7" constant="no"/>
</technology>
<technology name="-DNP">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="NOTE" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="-1206" package="C1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-100UF">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://search.murata.co.jp/Ceramy/image/img/A01X/partnumbering_e_01.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/murata-electronics-north-america/GRM31CD80J107ME39L/490-10525-1-ND/5026461" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="490-10525-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Murata" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GRM31CD80J107ME39L" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="100uF" constant="no"/>
</technology>
<technology name="-10UF">
<attribute name="CODE-ARDUINO" value="2227" constant="no"/>
<attribute name="DATASHEET" value="https://product.tdk.com/info/en/catalog/datasheets/mlcc_commercial_general_en.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/tdk-corporation/C3216X7R1V106M160AC/445-8034-1-ND/2792174" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="445-8034-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="TDK Corporation" constant="no"/>
<attribute name="MANUFACTURER-PN" value="C3216X7R1V106M160AC" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="10uF" constant="no"/>
</technology>
<technology name="DNP">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="NOTE" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="-1210" package="C1210">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name="-10UF">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="ds.yuden.co.jp/TYCOMPAS/ut/detail.do?productNo=GMK325BJ106MN-T&amp;fileName=GMK325BJ106MN-T_SS&amp;mode=specSheetDownload" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/it/taiyo-yuden/GMK325BJ106MN-T/587-2832-1-ND/2607799" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="587-2832-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Taiyo Yuden" constant="no"/>
<attribute name="MANUFACTURER-PN" value="GMK325BJ106MN-T" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="10u" constant="no"/>
</technology>
<technology name="-22U">
<attribute name="CODE-ARDUINO" value="0167" constant="no"/>
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="-" constant="no"/>
<attribute name="MANUFACTURER-PN" value="-" constant="no"/>
<attribute name="NOTE" value="-" constant="no"/>
<attribute name="VALUE" value="22u" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="4R-N" prefix="RN" uservalue="yes">
<description>&lt;b&gt;Array Chip Resistor&lt;/b&gt;&lt;p&gt;
Source: RS Component / Phycomp</description>
<gates>
<gate name="A" symbol="R1NV" x="0" y="7.62" addlevel="always" swaplevel="1"/>
<gate name="B" symbol="R1NV" x="0" y="2.54" addlevel="always" swaplevel="1"/>
<gate name="C" symbol="R1NV" x="0" y="-2.54" addlevel="always" swaplevel="1"/>
<gate name="D" symbol="R1NV" x="0" y="-7.62" addlevel="always" swaplevel="1"/>
</gates>
<devices>
<device name="CAY16" package="CAY16">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="8"/>
<connect gate="B" pin="1" pad="2"/>
<connect gate="B" pin="2" pad="7"/>
<connect gate="C" pin="1" pad="3"/>
<connect gate="C" pin="2" pad="6"/>
<connect gate="D" pin="1" pad="4"/>
<connect gate="D" pin="2" pad="5"/>
</connects>
<technologies>
<technology name="-10K">
<attribute name="CODE-ARDUINO" value="0016" constant="no"/>
<attribute name="DATASHEET" value="http://www.bourns.com/docs/Product-Datasheets/CATCAY.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/products/en?keywords=CAY16-103J4LFTR-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="CAY16-103J4LFTR-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Bourns Inc." constant="no"/>
<attribute name="MANUFACTURER-PN" value="CAY16-103J4LF" constant="no"/>
<attribute name="RESTRICTIONS" value="NO" constant="no"/>
<attribute name="VALUE" value="10k" constant="no"/>
</technology>
<technology name="-1K">
<attribute name="CODE-ARDUINO" value="0005" constant="no"/>
<attribute name="DATASHEET" value="http://www.bourns.com/docs/Product-Datasheets/CATCAY.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/bourns-inc/CAY16-102J4LF/CAY16-102J4LFCT-ND/3437828" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="CAY16-102J4LFCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Bourns Inc." constant="no"/>
<attribute name="MANUFACTURER-PN" value="CAY16-102J4LF" constant="no"/>
<attribute name="RESTRICTIONS" value="NO" constant="no"/>
<attribute name="VALUE" value="1k" constant="no"/>
</technology>
<technology name="-22R">
<attribute name="CODE-ARDUINO" value="0003" constant="no"/>
<attribute name="DATASHEET" value="http://www.bourns.com/docs/Product-Datasheets/CATCAY.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/bourns-inc/CAY16-220J4LF/CAY16-220J4LFCT-ND/3437988" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="CAY16-220J4LFCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Bourns Inc." constant="no"/>
<attribute name="MANUFACTURER-PN" value="CAY16-220J4LF" constant="no"/>
<attribute name="RESTRICTIONS" value="NO" constant="no"/>
<attribute name="VALUE" value="22R" constant="no"/>
</technology>
<technology name="-470R">
<attribute name="CODE-ARDUINO" value="0540" constant="no"/>
<attribute name="DATASHEET" value="http://www.bourns.com/docs/Product-Datasheets/CATCAY.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/bourns-inc/CAY16-471J4LF/CAY16-471J4LFCT-ND/3437962" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="CAY16-471J4LFCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Bourns Inc." constant="no"/>
<attribute name="MANUFACTURER-PN" value="CAY16-471J4LF" constant="no"/>
<attribute name="RESTRICTIONS" value="NO" constant="no"/>
<attribute name="VALUE" value="470R" constant="no"/>
</technology>
<technology name="-49.9R">
<attribute name="CODE-ARDUINO" value="2298" constant="no"/>
<attribute name="DATASHEET" value="http://www.bourns.com/docs/Product-Datasheets/CATCAY.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/bourns-inc/CAY16-49R9F4LF/CAY16-49R9F4LFCT-ND/3437972" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="CAY16-49R9F4LFCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Bourns Inc." constant="no"/>
<attribute name="MANUFACTURER-PN" value="CAY16-49R9F4LF" constant="no"/>
<attribute name="RESTRICTIONS" value="NO" constant="no"/>
<attribute name="VALUE" value="49.9R" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-pushbuttons">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="TS42">
<circle x="0" y="0" radius="1.5" width="0.127" layer="21"/>
<circle x="0" y="0" radius="1.2" width="0.127" layer="21"/>
<wire x1="2.85" y1="-2" x2="2.85" y2="2" width="0.127" layer="21"/>
<wire x1="-2.85" y1="2" x2="-2.85" y2="0.5" width="0.127" layer="21"/>
<wire x1="-2.85" y1="-0.5" x2="-2.85" y2="-2" width="0.127" layer="21"/>
<wire x1="-2.85" y1="0.5" x2="-3.1" y2="0.5" width="0.127" layer="21"/>
<wire x1="-3.1" y1="0.5" x2="-3.1" y2="-0.5" width="0.127" layer="21"/>
<wire x1="-3.1" y1="-0.5" x2="-2.85" y2="-0.5" width="0.127" layer="21"/>
<wire x1="-1" y1="1.8" x2="1" y2="1.8" width="0.127" layer="21"/>
<wire x1="1" y1="1.8" x2="1" y2="2" width="0.127" layer="21"/>
<wire x1="1" y1="2" x2="1" y2="2.2" width="0.127" layer="21"/>
<wire x1="1" y1="2.2" x2="-1" y2="2.2" width="0.127" layer="21"/>
<wire x1="-1" y1="2.2" x2="-1" y2="2" width="0.127" layer="21"/>
<wire x1="-1" y1="2" x2="-1" y2="1.8" width="0.127" layer="21"/>
<wire x1="-1" y1="-2.2" x2="1" y2="-2.2" width="0.127" layer="21"/>
<wire x1="1" y1="-2.2" x2="1" y2="-2" width="0.127" layer="21"/>
<wire x1="1" y1="-2" x2="1" y2="-1.8" width="0.127" layer="21"/>
<wire x1="1" y1="-1.8" x2="-1" y2="-1.8" width="0.127" layer="21"/>
<wire x1="-1" y1="-1.8" x2="-1" y2="-2" width="0.127" layer="21"/>
<wire x1="-1" y1="-2" x2="-1" y2="-2.2" width="0.127" layer="21"/>
<wire x1="-2.85" y1="2" x2="-1" y2="2" width="0.127" layer="21"/>
<wire x1="1" y1="2" x2="2.85" y2="2" width="0.127" layer="21"/>
<wire x1="1" y1="-2" x2="2.85" y2="-2" width="0.127" layer="21"/>
<wire x1="-1" y1="-2" x2="-2.85" y2="-2" width="0.127" layer="21"/>
<rectangle x1="-4.699" y1="-0.381" x2="-3.81" y2="0.381" layer="31"/>
<smd name="1" x="-4.2" y="2.25" dx="1.6" dy="1.4" layer="1" roundness="15"/>
<smd name="2" x="4.2" y="2.25" dx="1.6" dy="1.4" layer="1" roundness="15"/>
<smd name="3" x="-4.2" y="-2.25" dx="1.6" dy="1.4" layer="1" roundness="15"/>
<smd name="4" x="4.2" y="-2.25" dx="1.6" dy="1.4" layer="1" roundness="15"/>
<smd name="5" x="-4.2" y="0" dx="1.6" dy="1.4" layer="1" roundness="15" cream="no"/>
<text x="-3" y="4" size="1.27" layer="21">&gt;VALUE</text>
<text x="-3" y="-4.5" size="1.27" layer="21">&gt;NAME</text>
</package>
</packages>
<symbols>
<symbol name="TACTILE-5PINS">
<circle x="0" y="-2.54" radius="0.127" width="0.4064" layer="94"/>
<circle x="0" y="2.54" radius="0.127" width="0.4064" layer="94"/>
<wire x1="0" y1="1.905" x2="0" y2="2.54" width="0.254" layer="94"/>
<wire x1="-4.445" y1="1.905" x2="-3.175" y2="1.905" width="0.254" layer="94"/>
<wire x1="-4.445" y1="-1.905" x2="-3.175" y2="-1.905" width="0.254" layer="94"/>
<wire x1="-4.445" y1="1.905" x2="-4.445" y2="0" width="0.254" layer="94"/>
<wire x1="-4.445" y1="0" x2="-4.445" y2="-1.905" width="0.254" layer="94"/>
<wire x1="-2.54" y1="0" x2="-1.905" y2="0" width="0.1524" layer="94"/>
<wire x1="-1.27" y1="0" x2="-0.635" y2="0" width="0.1524" layer="94"/>
<wire x1="-4.445" y1="0" x2="-3.175" y2="0" width="0.1524" layer="94"/>
<wire x1="2.54" y1="2.54" x2="0" y2="2.54" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-2.54" x2="0" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="0" y1="-2.54" x2="-1.27" y2="1.905" width="0.254" layer="94"/>
<wire x1="5.08" y1="-2.54" x2="5.08" y2="0" width="0.1524" layer="94"/>
<wire x1="5.08" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="2.54" y1="0" x2="2.54" y2="1.27" width="0.1524" layer="94"/>
<wire x1="2.54" y1="0" x2="2.54" y2="-1.27" width="0.1524" layer="94"/>
<pin name="1" x="0" y="-5.08" visible="pad" length="short" direction="pas" swaplevel="2" rot="R90"/>
<pin name="2" x="2.54" y="-5.08" visible="pad" length="short" direction="pas" swaplevel="2" rot="R90"/>
<pin name="3" x="0" y="5.08" visible="pad" length="short" direction="pas" swaplevel="1" rot="R270"/>
<pin name="4" x="2.54" y="5.08" visible="pad" length="short" direction="pas" swaplevel="1" rot="R270"/>
<pin name="5-GND" x="5.08" y="-5.08" visible="pad" length="short" direction="pwr" rot="R90"/>
<text x="-6.35" y="-2.54" size="1.778" layer="95" rot="R90">&gt;NAME</text>
<text x="-3.81" y="3.175" size="1.778" layer="96" rot="R90">&gt;VALUE</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="TACTILE2" prefix="PB">
<description>Pushbutton</description>
<gates>
<gate name="G$1" symbol="TACTILE-5PINS" x="0" y="0"/>
</gates>
<devices>
<device name="" package="TS42">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5-GND" pad="5"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="0946" constant="no"/>
<attribute name="DATASHEET" value="http://www.mouser.com/ds/2/418/NG_CD_1571636_C1-122399.pdf " constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.mouser.it/ProductDetail/TE-Connectivity/1571636-3/?qs=%2fha2pyFaduiys%2fNUBzym%252bcoSb9tuK3Sjuv54qjf0hQ0%3d" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="506-1571636-3" constant="no"/>
<attribute name="MANUFACTURER" value="TE" constant="no"/>
<attribute name="MANUFACTURER-PN" value="1571636-3" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
<technology name="-LONGSHAFT">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.te.com/commerce/DocumentDelivery/DDEController?Action=srchrtrv&amp;DocNm=1977223&amp;DocType=Customer+Drawing&amp;DocLang=English" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/te-connectivity-alcoswitch-switches/FSM14JSMAS/450-2161-ND/5343810" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="450-2161-ND" constant="no"/>
<attribute name="MANUFACTURER" value="TE" constant="no"/>
<attribute name="MANUFACTURER-PN" value="FSM14JSMAS" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-supply">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
</packages>
<symbols>
<symbol name="GND">
<wire x1="-1.905" y1="0" x2="1.905" y2="0" width="0.254" layer="94"/>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
<text x="-2.54" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
</symbol>
<symbol name="+5V">
<wire x1="0.889" y1="-1.27" x2="0" y2="0.127" width="0.254" layer="94"/>
<wire x1="0" y1="0.127" x2="-0.889" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-0.889" y1="-1.27" x2="0.889" y2="-1.27" width="0.254" layer="94"/>
<pin name="+5V" x="0" y="-2.54" visible="off" length="short" direction="sup" rot="R90"/>
<text x="0" y="0.508" size="1.778" layer="96" align="bottom-center">&gt;VALUE</text>
</symbol>
<symbol name="+3V3">
<wire x1="0.889" y1="-1.27" x2="0" y2="0.127" width="0.254" layer="94"/>
<wire x1="0" y1="0.127" x2="-0.889" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-0.889" y1="-1.27" x2="0.889" y2="-1.27" width="0.254" layer="94"/>
<pin name="+3V3" x="0" y="-2.54" visible="off" length="short" direction="sup" rot="R90"/>
<text x="0" y="0.508" size="1.778" layer="96" align="bottom-center">&gt;VALUE</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="GND" prefix="GND">
<description>GND symbol</description>
<gates>
<gate name="1" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="NOTE" value="DNP" constant="no"/>
<attribute name="VALUE" value="GND" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="+5V" prefix="P+">
<description>5V symbol</description>
<gates>
<gate name="1" symbol="+5V" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="NOTE" value="DNP" constant="no"/>
<attribute name="VALUE" value="+5V" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="+3V3" prefix="+3V3">
<description>3V3 symbol</description>
<gates>
<gate name="G$1" symbol="+3V3" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="NOTE" value="DNP" constant="no"/>
<attribute name="VALUE" value="+3V3" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-mechanical">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="RELE'-30SSERIES-DIL-2X">
<wire x1="-8.89" y1="5.08" x2="-8.89" y2="-5.08" width="0.127" layer="21"/>
<wire x1="-8.89" y1="-5.08" x2="11.43" y2="-5.08" width="0.127" layer="21"/>
<wire x1="11.43" y1="-5.08" x2="11.43" y2="5.08" width="0.127" layer="21"/>
<wire x1="11.43" y1="5.08" x2="-8.89" y2="5.08" width="0.127" layer="21"/>
<wire x1="-9" y1="5.2" x2="11.53" y2="5.2" width="0.05" layer="39"/>
<wire x1="11.53" y1="5.2" x2="11.53" y2="-5.2" width="0.05" layer="39"/>
<wire x1="11.53" y1="-5.2" x2="-9" y2="-5.2" width="0.05" layer="39"/>
<wire x1="-9" y1="-5.2" x2="-9" y2="5.2" width="0.05" layer="39"/>
<pad name="1" x="-7.62" y="-3.81" drill="0.8"/>
<pad name="2" x="0" y="-3.81" drill="0.8"/>
<pad name="3" x="5.08" y="-3.81" drill="0.8"/>
<pad name="4" x="10.16" y="-3.81" drill="0.8"/>
<pad name="5" x="10.16" y="3.81" drill="0.8"/>
<pad name="6" x="5.08" y="3.81" drill="0.8"/>
<pad name="7" x="0" y="3.81" drill="0.8"/>
<pad name="8" x="-7.62" y="3.81" drill="0.8"/>
<text x="3.81" y="6.35" size="1.27" layer="25">&gt;NAME</text>
<text x="-6.35" y="6.35" size="1.27" layer="27">&gt;VALUE</text>
</package>
</packages>
<symbols>
<symbol name="RELE-2X">
<wire x1="5.08" y1="-5.08" x2="5.08" y2="0" width="0.254" layer="94"/>
<wire x1="5.08" y1="0" x2="5.08" y2="25.4" width="0.254" layer="94"/>
<wire x1="5.08" y1="25.4" x2="22.86" y2="25.4" width="0.254" layer="94"/>
<wire x1="22.86" y1="25.4" x2="22.86" y2="0" width="0.254" layer="94"/>
<wire x1="22.86" y1="0" x2="22.86" y2="-5.08" width="0.254" layer="94"/>
<wire x1="22.86" y1="-5.08" x2="5.08" y2="-5.08" width="0.254" layer="94"/>
<wire x1="5.08" y1="0" x2="11.43" y2="0" width="0.254" layer="94"/>
<wire x1="11.43" y1="0" x2="12.7" y2="0" width="0.254" layer="94" curve="-180"/>
<wire x1="12.7" y1="0" x2="13.97" y2="0" width="0.254" layer="94" curve="-180"/>
<wire x1="13.97" y1="0" x2="15.24" y2="0" width="0.254" layer="94" curve="-180"/>
<wire x1="15.24" y1="0" x2="16.51" y2="0" width="0.254" layer="94" curve="-180"/>
<wire x1="16.51" y1="0" x2="22.86" y2="0" width="0.254" layer="94"/>
<pin name="A1" x="0" y="0" length="middle"/>
<pin name="A2" x="27.94" y="0" length="middle" rot="R180"/>
<pin name="C1" x="27.94" y="10.16" length="middle" rot="R180"/>
<pin name="C2" x="0" y="10.16" length="middle"/>
<pin name="NC1" x="27.94" y="15.24" length="middle" rot="R180"/>
<pin name="NC2" x="0" y="15.24" length="middle"/>
<pin name="NO1" x="27.94" y="20.32" length="middle" rot="R180"/>
<pin name="NO2" x="0" y="20.32" length="middle"/>
<text x="10.16" y="-7.62" size="1.778" layer="95">&gt;NAME</text>
<text x="10.16" y="-10.16" size="1.778" layer="96">&gt;VALUE</text>
<text x="20.32" y="-2.54" size="2.54" layer="94">+</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="RELAY-5" prefix="RL" uservalue="yes">
<description>Relay 5V black Omron</description>
<gates>
<gate name="G$1" symbol="RELE-2X" x="-5.08" y="5.08"/>
</gates>
<devices>
<device name="" package="RELE'-30SSERIES-DIL-2X">
<connects>
<connect gate="G$1" pin="A1" pad="8"/>
<connect gate="G$1" pin="A2" pad="1"/>
<connect gate="G$1" pin="C1" pad="2"/>
<connect gate="G$1" pin="C2" pad="7"/>
<connect gate="G$1" pin="NC1" pad="3"/>
<connect gate="G$1" pin="NC2" pad="6"/>
<connect gate="G$1" pin="NO1" pad="4"/>
<connect gate="G$1" pin="NO2" pad="5"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-BCE" value="SP0773" constant="no"/>
<attribute name="CODE-BCMI" value="0773" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://omronfs.omron.com/en_US/ecb/products/pdf/en-g5v_2.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/it/omron-electronics-inc-emc-div/G5V-2-H1-DC5/Z108-ND/277844" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="Z108-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Omron" constant="no"/>
<attribute name="MANUFACTURER-PN" value=" G5V-2-H1 DC5 " constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-transistors">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="SOT23">
<description>&lt;b&gt;SOT-23&lt;/b&gt;</description>
<wire x1="1.4224" y1="0.6604" x2="1.4224" y2="-0.6604" width="0.1524" layer="51"/>
<wire x1="1.4224" y1="-0.6604" x2="-1.4224" y2="-0.6604" width="0.1524" layer="51"/>
<wire x1="-1.4224" y1="-0.6604" x2="-1.4224" y2="0.6604" width="0.1524" layer="51"/>
<wire x1="-1.4224" y1="0.6604" x2="1.4224" y2="0.6604" width="0.1524" layer="51"/>
<smd name="3" x="0" y="1.1" dx="1" dy="1.4" layer="1"/>
<smd name="2" x="0.95" y="-1.1" dx="1" dy="1.4" layer="1"/>
<smd name="1" x="-0.95" y="-1.1" dx="1" dy="1.4" layer="1"/>
<text x="-1.905" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<rectangle x1="-0.2286" y1="0.7112" x2="0.2286" y2="1.2954" layer="51"/>
<rectangle x1="0.7112" y1="-1.2954" x2="1.1684" y2="-0.7112" layer="51"/>
<rectangle x1="-1.1684" y1="-1.2954" x2="-0.7112" y2="-0.7112" layer="51"/>
</package>
<package name="SOTFL50P160X78-3">
<description>Small Outline Transistor Flat Lead (SOTFL), 0.50 mm pitch; 3 pin, 1.60 mm L X 0.88 mm W X 0.78 mm H body&lt;p&gt;</description>
<circle x="0" y="0" radius="0.25" width="0.05" layer="39"/>
<wire x1="0" y1="0.35" x2="0" y2="-0.35" width="0.05" layer="39"/>
<wire x1="-0.35" y1="0" x2="0.35" y2="0" width="0.05" layer="39"/>
<wire x1="-0.85" y1="-0.49" x2="-0.85" y2="0.49" width="0.12" layer="51"/>
<wire x1="-0.85" y1="0.49" x2="0.85" y2="0.49" width="0.12" layer="51"/>
<wire x1="0.85" y1="0.49" x2="0.85" y2="-0.49" width="0.12" layer="51"/>
<wire x1="0.85" y1="-0.49" x2="-0.85" y2="-0.49" width="0.12" layer="51"/>
<wire x1="-1" y1="-0.64" x2="-0.9" y2="-0.64" width="0.05" layer="39"/>
<wire x1="-0.9" y1="-0.64" x2="-0.9" y2="-1.05" width="0.05" layer="39"/>
<wire x1="-0.9" y1="-1.05" x2="0.9" y2="-1.05" width="0.05" layer="39"/>
<wire x1="0.9" y1="-1.05" x2="0.9" y2="-0.64" width="0.05" layer="39"/>
<wire x1="0.9" y1="-0.64" x2="1" y2="-0.64" width="0.05" layer="39"/>
<wire x1="1" y1="-0.64" x2="1" y2="0.64" width="0.05" layer="39"/>
<wire x1="1" y1="0.64" x2="0.9" y2="0.64" width="0.05" layer="39"/>
<wire x1="0.9" y1="0.64" x2="0.9" y2="1.05" width="0.05" layer="39"/>
<wire x1="0.9" y1="1.05" x2="-0.9" y2="1.05" width="0.05" layer="39"/>
<wire x1="-0.9" y1="1.05" x2="-0.9" y2="0.64" width="0.05" layer="39"/>
<wire x1="-0.9" y1="0.64" x2="-1" y2="0.64" width="0.05" layer="39"/>
<wire x1="-1" y1="0.64" x2="-1" y2="-0.64" width="0.05" layer="39"/>
<wire x1="-0.93" y1="-0.24" x2="-0.93" y2="0.24" width="0.12" layer="21"/>
<wire x1="0.93" y1="-0.24" x2="0.93" y2="0.24" width="0.12" layer="21"/>
<smd name="D" x="0" y="0.57" dx="0.66" dy="0.5" layer="1" roundness="4" rot="R90"/>
<smd name="G" x="-0.5" y="-0.57" dx="0.66" dy="0.5" layer="1" roundness="4" rot="R270"/>
<smd name="S" x="0.5" y="-0.57" dx="0.66" dy="0.5" layer="1" roundness="4" rot="R270"/>
<text x="0" y="0" size="0.4064" layer="51" font="vector" ratio="10" align="center">&gt;NAME</text>
<polygon width="0.01" layer="29">
<vertex x="-0.75" y="-0.24"/>
<vertex x="-0.25" y="-0.24"/>
<vertex x="-0.25" y="-0.9"/>
<vertex x="-0.75" y="-0.9"/>
</polygon>
<polygon width="0.01" layer="31">
<vertex x="-0.75" y="-0.57"/>
<vertex x="-0.75" y="-0.25"/>
<vertex x="-0.7499" y="-0.2484"/>
<vertex x="-0.7495" y="-0.2469"/>
<vertex x="-0.7489" y="-0.2455"/>
<vertex x="-0.7481" y="-0.2441"/>
<vertex x="-0.7471" y="-0.2429"/>
<vertex x="-0.7459" y="-0.2419"/>
<vertex x="-0.7445" y="-0.2411"/>
<vertex x="-0.7431" y="-0.2405"/>
<vertex x="-0.7416" y="-0.2401"/>
<vertex x="-0.26" y="-0.24"/>
<vertex x="-0.2584" y="-0.2401"/>
<vertex x="-0.2569" y="-0.2405"/>
<vertex x="-0.2555" y="-0.2411"/>
<vertex x="-0.2541" y="-0.2419"/>
<vertex x="-0.2529" y="-0.2429"/>
<vertex x="-0.2519" y="-0.2441"/>
<vertex x="-0.2511" y="-0.2455"/>
<vertex x="-0.2505" y="-0.2469"/>
<vertex x="-0.2501" y="-0.2484"/>
<vertex x="-0.25" y="-0.25"/>
<vertex x="-0.25" y="-0.89"/>
<vertex x="-0.2501" y="-0.8916"/>
<vertex x="-0.2505" y="-0.8931"/>
<vertex x="-0.2511" y="-0.8945"/>
<vertex x="-0.2519" y="-0.8959"/>
<vertex x="-0.2529" y="-0.8971"/>
<vertex x="-0.2541" y="-0.8981"/>
<vertex x="-0.2555" y="-0.8989"/>
<vertex x="-0.2569" y="-0.8995"/>
<vertex x="-0.2584" y="-0.8999"/>
<vertex x="-0.74" y="-0.9"/>
<vertex x="-0.7416" y="-0.8999"/>
<vertex x="-0.7431" y="-0.8995"/>
<vertex x="-0.7445" y="-0.8989"/>
<vertex x="-0.7459" y="-0.8981"/>
<vertex x="-0.7471" y="-0.8971"/>
<vertex x="-0.7481" y="-0.8959"/>
<vertex x="-0.7489" y="-0.8945"/>
<vertex x="-0.7495" y="-0.8931"/>
<vertex x="-0.7499" y="-0.8916"/>
<vertex x="-0.75" y="-0.89"/>
</polygon>
<polygon width="0.01" layer="29">
<vertex x="0.25" y="-0.24"/>
<vertex x="0.75" y="-0.24"/>
<vertex x="0.75" y="-0.9"/>
<vertex x="0.25" y="-0.9"/>
</polygon>
<polygon width="0.01" layer="31">
<vertex x="0.25" y="-0.57"/>
<vertex x="0.25" y="-0.25"/>
<vertex x="0.2501" y="-0.2484"/>
<vertex x="0.2505" y="-0.2469"/>
<vertex x="0.2511" y="-0.2455"/>
<vertex x="0.2519" y="-0.2441"/>
<vertex x="0.2529" y="-0.2429"/>
<vertex x="0.2541" y="-0.2419"/>
<vertex x="0.2555" y="-0.2411"/>
<vertex x="0.2569" y="-0.2405"/>
<vertex x="0.2584" y="-0.2401"/>
<vertex x="0.74" y="-0.24"/>
<vertex x="0.7416" y="-0.2401"/>
<vertex x="0.7431" y="-0.2405"/>
<vertex x="0.7445" y="-0.2411"/>
<vertex x="0.7459" y="-0.2419"/>
<vertex x="0.7471" y="-0.2429"/>
<vertex x="0.7481" y="-0.2441"/>
<vertex x="0.7489" y="-0.2455"/>
<vertex x="0.7495" y="-0.2469"/>
<vertex x="0.7499" y="-0.2484"/>
<vertex x="0.75" y="-0.25"/>
<vertex x="0.75" y="-0.89"/>
<vertex x="0.7499" y="-0.8916"/>
<vertex x="0.7495" y="-0.8931"/>
<vertex x="0.7489" y="-0.8945"/>
<vertex x="0.7481" y="-0.8959"/>
<vertex x="0.7471" y="-0.8971"/>
<vertex x="0.7459" y="-0.8981"/>
<vertex x="0.7445" y="-0.8989"/>
<vertex x="0.7431" y="-0.8995"/>
<vertex x="0.7416" y="-0.8999"/>
<vertex x="0.26" y="-0.9"/>
<vertex x="0.2584" y="-0.8999"/>
<vertex x="0.2569" y="-0.8995"/>
<vertex x="0.2555" y="-0.8989"/>
<vertex x="0.2541" y="-0.8981"/>
<vertex x="0.2529" y="-0.8971"/>
<vertex x="0.2519" y="-0.8959"/>
<vertex x="0.2511" y="-0.8945"/>
<vertex x="0.2505" y="-0.8931"/>
<vertex x="0.2501" y="-0.8916"/>
<vertex x="0.25" y="-0.89"/>
</polygon>
<polygon width="0.01" layer="29">
<vertex x="0.25" y="0.24"/>
<vertex x="-0.25" y="0.24"/>
<vertex x="-0.25" y="0.9"/>
<vertex x="0.25" y="0.9"/>
</polygon>
<polygon width="0.01" layer="31">
<vertex x="0.25" y="0.57"/>
<vertex x="0.25" y="0.25"/>
<vertex x="0.2499" y="0.2484"/>
<vertex x="0.2495" y="0.2469"/>
<vertex x="0.2489" y="0.2455"/>
<vertex x="0.2481" y="0.2441"/>
<vertex x="0.2471" y="0.2429"/>
<vertex x="0.2459" y="0.2419"/>
<vertex x="0.2445" y="0.2411"/>
<vertex x="0.2431" y="0.2405"/>
<vertex x="0.2416" y="0.2401"/>
<vertex x="-0.24" y="0.24"/>
<vertex x="-0.2416" y="0.2401"/>
<vertex x="-0.2431" y="0.2405"/>
<vertex x="-0.2445" y="0.2411"/>
<vertex x="-0.2459" y="0.2419"/>
<vertex x="-0.2471" y="0.2429"/>
<vertex x="-0.2481" y="0.2441"/>
<vertex x="-0.2489" y="0.2455"/>
<vertex x="-0.2495" y="0.2469"/>
<vertex x="-0.2499" y="0.2484"/>
<vertex x="-0.25" y="0.25"/>
<vertex x="-0.25" y="0.89"/>
<vertex x="-0.2499" y="0.8916"/>
<vertex x="-0.2495" y="0.8931"/>
<vertex x="-0.2489" y="0.8945"/>
<vertex x="-0.2481" y="0.8959"/>
<vertex x="-0.2471" y="0.8971"/>
<vertex x="-0.2459" y="0.8981"/>
<vertex x="-0.2445" y="0.8989"/>
<vertex x="-0.2431" y="0.8995"/>
<vertex x="-0.2416" y="0.8999"/>
<vertex x="0.24" y="0.9"/>
<vertex x="0.2416" y="0.8999"/>
<vertex x="0.2431" y="0.8995"/>
<vertex x="0.2445" y="0.8989"/>
<vertex x="0.2459" y="0.8981"/>
<vertex x="0.2471" y="0.8971"/>
<vertex x="0.2481" y="0.8959"/>
<vertex x="0.2489" y="0.8945"/>
<vertex x="0.2495" y="0.8931"/>
<vertex x="0.2499" y="0.8916"/>
<vertex x="0.25" y="0.89"/>
</polygon>
</package>
</packages>
<symbols>
<symbol name="N-MOS-1">
<circle x="0" y="-2.794" radius="0.3592" width="0" layer="94"/>
<circle x="0" y="-2.032" radius="0.3592" width="0" layer="94"/>
<circle x="0" y="3.048" radius="0.3592" width="0" layer="94"/>
<rectangle x1="-2.032" y1="1.27" x2="-1.524" y2="2.54" layer="94"/>
<rectangle x1="-2.032" y1="-2.54" x2="-1.524" y2="-1.27" layer="94"/>
<rectangle x1="-2.032" y1="-0.762" x2="-1.524" y2="0.762" layer="94"/>
<wire x1="-1.27" y1="0" x2="-0.254" y2="0.381" width="0.1524" layer="94"/>
<wire x1="-0.254" y1="0.381" x2="-0.254" y2="-0.381" width="0.1524" layer="94"/>
<wire x1="-0.254" y1="-0.381" x2="-1.27" y2="0" width="0.1524" layer="94"/>
<wire x1="-1.27" y1="0" x2="-1.016" y2="0" width="0.1524" layer="94"/>
<wire x1="-1.016" y1="0" x2="-0.889" y2="0" width="0.1524" layer="94"/>
<wire x1="-0.889" y1="0" x2="0" y2="0" width="0.1524" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-2.032" width="0.1524" layer="94"/>
<wire x1="0" y1="-2.032" x2="0" y2="-2.794" width="0.1524" layer="94"/>
<wire x1="-1.524" y1="0" x2="-1.27" y2="0" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="2.54" x2="-2.54" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="3.048" x2="1.27" y2="3.048" width="0.1524" layer="94"/>
<wire x1="1.27" y1="3.048" x2="1.27" y2="0.762" width="0.1524" layer="94"/>
<wire x1="1.27" y1="0.762" x2="1.27" y2="0.508" width="0.1524" layer="94"/>
<wire x1="1.27" y1="0.508" x2="1.27" y2="-2.794" width="0.1524" layer="94"/>
<wire x1="1.27" y1="-2.794" x2="0" y2="-2.794" width="0.1524" layer="94"/>
<wire x1="1.778" y1="0" x2="0.762" y2="0" width="0.1524" layer="94"/>
<wire x1="0.762" y1="0" x2="1.27" y2="0.762" width="0.1524" layer="94"/>
<wire x1="1.27" y1="0.762" x2="1.778" y2="0" width="0.1524" layer="94"/>
<wire x1="1.778" y1="0.762" x2="0.762" y2="0.762" width="0.1524" layer="94"/>
<wire x1="-1.524" y1="2.032" x2="0" y2="2.032" width="0.1524" layer="94"/>
<wire x1="0" y1="2.032" x2="0" y2="2.54" width="0.1524" layer="94"/>
<wire x1="-1.524" y1="-2.032" x2="0" y2="-2.032" width="0.1524" layer="94"/>
<wire x1="-1.016" y1="0" x2="-0.381" y2="-0.254" width="0.254" layer="94"/>
<wire x1="-0.381" y1="-0.254" x2="-0.381" y2="0.254" width="0.254" layer="94"/>
<wire x1="-0.381" y1="0.254" x2="-0.889" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="0.508" x2="1.016" y2="0.127" width="0.254" layer="94"/>
<wire x1="1.016" y1="0.127" x2="1.524" y2="0.127" width="0.254" layer="94"/>
<wire x1="1.524" y1="0.127" x2="1.27" y2="0.508" width="0.254" layer="94"/>
<pin name="D" x="0" y="5.08" visible="off" length="short" direction="pas" rot="R270"/>
<pin name="G" x="-5.08" y="-2.54" visible="off" length="short" direction="pas"/>
<pin name="S" x="0" y="-5.08" visible="off" length="short" direction="pas" rot="R90"/>
<text x="2.54" y="0" size="1.778" layer="95">&gt;NAME</text>
<text x="2.54" y="-2.54" size="1.778" layer="96">&gt;VALUE</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="2N7002T" prefix="Q">
<description>MOSFET N-CH 60V 115MA</description>
<gates>
<gate name="G$1" symbol="N-MOS-1" x="0" y="0"/>
</gates>
<devices>
<device name="-SOT523" package="SOTFL50P160X78-3">
<connects>
<connect gate="G$1" pin="D" pad="D"/>
<connect gate="G$1" pin="G" pad="G"/>
<connect gate="G$1" pin="S" pad="S"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="1612" constant="no"/>
<attribute name="DATASHEET" value="http://www.diodes.com/_files/datasheets/ds30301.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/diodes-incorporated/2N7002T-7-F/2N7002T-FDICT-ND/815290" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="2N7002T-FDICT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Diodes Incorporated" constant="no"/>
<attribute name="MANUFACTURER-PN" value="2N7002T-7-F" constant="no"/>
<attribute name="VALUE" value="2N7002" constant="no"/>
</technology>
<technology name="DNP">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
<device name="-SOT23" package="SOT23">
<connects>
<connect gate="G$1" pin="D" pad="3"/>
<connect gate="G$1" pin="G" pad="1"/>
<connect gate="G$1" pin="S" pad="2"/>
</connects>
<technologies>
<technology name="-SOT23">
<attribute name="CODE-ARDUINO" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.mccsemi.com/up_pdf/2N7002(SOT-23).PDF" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/it/micro-commercial-co/2N7002-TP/2N7002-TPMSCT-ND/1960099" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="2N7002-TPMSCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Micro Commercial Co" constant="no"/>
<attribute name="MANUFACTURER-PN" value="2N7002-TP" constant="no"/>
<attribute name="VALUE" value="2N7002" constant="no"/>
</technology>
<technology name="DNP">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-diodes">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="SOD123">
<description>&lt;b&gt;Diode&lt;/b&gt;</description>
<wire x1="-1.1" y1="0.7" x2="1.1" y2="0.7" width="0.254" layer="51"/>
<wire x1="1.1" y1="0.7" x2="1.1" y2="-0.7" width="0.254" layer="51"/>
<wire x1="1.1" y1="-0.7" x2="-1.1" y2="-0.7" width="0.254" layer="51"/>
<wire x1="-1.1" y1="-0.7" x2="-1.1" y2="0.7" width="0.254" layer="51"/>
<rectangle x1="-1.95" y1="-0.45" x2="-1.2" y2="0.4" layer="51"/>
<rectangle x1="1.2" y1="-0.45" x2="1.95" y2="0.4" layer="51"/>
<rectangle x1="-1.05" y1="-0.65" x2="-0.15" y2="0.7" layer="51"/>
<smd name="A" x="1.9" y="0" dx="1.4" dy="1.4" layer="1"/>
<smd name="C" x="-1.9" y="0" dx="1.4" dy="1.4" layer="1"/>
<text x="-1.1" y="1" size="1.27" layer="25">&gt;NAME</text>
</package>
<package name="SMB_DO214AA">
<smd name="C" x="0" y="2" dx="2.5" dy="2.2" layer="1" roundness="20"/>
<smd name="A" x="0" y="-2" dx="2.5" dy="2.2" layer="1" roundness="20"/>
<wire x1="1.9" y1="2.35" x2="1.9" y2="1.11" width="0.127" layer="21"/>
<wire x1="1.9" y1="1.11" x2="1.9" y2="0.99" width="0.127" layer="21"/>
<wire x1="1.9" y1="0.99" x2="1.9" y2="-2.35" width="0.127" layer="21"/>
<wire x1="-1.9" y1="2.35" x2="-1.9" y2="1.11" width="0.127" layer="21"/>
<wire x1="-1.9" y1="1.11" x2="-1.9" y2="0.99" width="0.127" layer="21"/>
<wire x1="-1.9" y1="0.99" x2="-1.9" y2="-2.35" width="0.127" layer="21"/>
<wire x1="1.9" y1="2.35" x2="-1.9" y2="2.35" width="0.127" layer="21"/>
<wire x1="1.9" y1="-2.35" x2="-1.9" y2="-2.35" width="0.127" layer="21"/>
<text x="2.54" y="0" size="0.8128" layer="25" font="vector" ratio="10" rot="R270" align="center">&gt;NAME</text>
<text x="-2.54" y="0" size="0.8128" layer="27" font="vector" rot="R90" align="center">&gt;VALUE</text>
<wire x1="1.9" y1="1.11" x2="-1.9" y2="1.11" width="0.127" layer="21"/>
<wire x1="1.9" y1="0.99" x2="-1.9" y2="0.99" width="0.127" layer="21"/>
<wire x1="0.6" y1="-0.627" x2="0" y2="0.373" width="0.127" layer="21"/>
<wire x1="0" y1="0.373" x2="-0.6" y2="-0.627" width="0.127" layer="21"/>
<wire x1="-0.6" y1="-0.627" x2="0.6" y2="-0.627" width="0.127" layer="21"/>
<rectangle x1="-0.3048" y1="-0.2286" x2="0.3048" y2="1.3462" layer="21" rot="R270"/>
</package>
<package name="SMA_DO214AC">
<smd name="C" x="0" y="1.7" dx="1.7" dy="1.7" layer="1" roundness="20"/>
<smd name="A" x="0" y="-1.7" dx="1.7" dy="1.7" layer="1" roundness="20"/>
<wire x1="1.45" y1="2.3" x2="1.45" y2="1.11" width="0.127" layer="21"/>
<wire x1="1.45" y1="1.11" x2="1.45" y2="0.99" width="0.127" layer="21"/>
<wire x1="1.45" y1="0.99" x2="1.45" y2="-2.3" width="0.127" layer="21"/>
<wire x1="-1.45" y1="2.3" x2="-1.45" y2="1.11" width="0.127" layer="21"/>
<wire x1="-1.45" y1="1.11" x2="-1.45" y2="0.99" width="0.127" layer="21"/>
<wire x1="-1.45" y1="0.99" x2="-1.45" y2="-2.3" width="0.127" layer="21"/>
<wire x1="1.45" y1="2.3" x2="-1.45" y2="2.3" width="0.127" layer="21"/>
<wire x1="1.45" y1="-2.3" x2="-1.45" y2="-2.3" width="0.127" layer="21"/>
<text x="1.905" y="0" size="0.8128" layer="25" font="vector" ratio="10" rot="R270" align="center">&gt;NAME</text>
<text x="-1.905" y="0" size="0.8128" layer="27" font="vector" rot="R90" align="center">&gt;VALUE</text>
<wire x1="1.45" y1="1.11" x2="-1.45" y2="1.11" width="0.127" layer="21"/>
<wire x1="1.45" y1="0.99" x2="-1.45" y2="0.99" width="0.127" layer="21"/>
<wire x1="0.6" y1="-0.627" x2="0" y2="0.373" width="0.127" layer="21"/>
<wire x1="0" y1="0.373" x2="-0.6" y2="-0.627" width="0.127" layer="21"/>
<wire x1="-0.6" y1="-0.627" x2="0.6" y2="-0.627" width="0.127" layer="21"/>
<rectangle x1="-0.3048" y1="-0.2286" x2="0.3048" y2="1.3462" layer="21" rot="R270"/>
</package>
<package name="SOD106">
<wire x1="0.7874" y1="-1.8208" x2="0.7874" y2="1.8208" width="0.127" layer="21"/>
<wire x1="-0.7874" y1="-1.8208" x2="-0.7874" y2="1.8208" width="0.127" layer="21"/>
<wire x1="0.6" y1="-0.28575" x2="0" y2="0.71425" width="0.2032" layer="21"/>
<wire x1="0" y1="0.71425" x2="-0.6" y2="-0.28575" width="0.2032" layer="21"/>
<wire x1="-0.6" y1="-0.28575" x2="0.6" y2="-0.28575" width="0.2032" layer="21"/>
<smd name="C" x="0" y="2.25" dx="2.1" dy="1.6" layer="1" roundness="20"/>
<smd name="A" x="0" y="-2.25" dx="2.1" dy="1.6" layer="1" roundness="20"/>
<text x="1.905" y="0" size="0.8128" layer="25" font="vector" ratio="10" rot="R270" align="center">&gt;NAME</text>
<text x="-1.905" y="0" size="0.8128" layer="27" font="vector" ratio="10" rot="R270" align="center">&gt;VALUE</text>
<rectangle x1="-0.2794" y1="1.2112" x2="0.2794" y2="2.9384" layer="21" rot="R270"/>
<rectangle x1="-0.2794" y1="-2.9384" x2="0.2794" y2="-1.2112" layer="21" rot="R270"/>
<rectangle x1="-0.3048" y1="0.11265" x2="0.3048" y2="1.68745" layer="21" rot="R270"/>
</package>
<package name="SOD110">
<wire x1="0.5" y1="1" x2="0.5" y2="-1.05" width="0.127" layer="21"/>
<wire x1="0.5" y1="-1.05" x2="-0.5" y2="-1.05" width="0.127" layer="21"/>
<wire x1="-0.5" y1="-1.05" x2="-0.5" y2="1" width="0.127" layer="21"/>
<wire x1="-0.5" y1="1" x2="0.5" y2="1" width="0.127" layer="21"/>
<smd name="C" x="0" y="0.95" dx="1" dy="0.8" layer="1" roundness="20"/>
<smd name="A" x="0" y="-0.95" dx="1" dy="0.8" layer="1" roundness="20"/>
<text x="-1.27" y="0" size="0.8128" layer="25" font="vector" ratio="10" rot="R270" align="center">&gt;NAME</text>
<text x="1.27" y="0" size="0.8128" layer="27" font="vector" ratio="10" rot="R270" align="center">&gt;VALUE</text>
<rectangle x1="-0.125" y1="-0.08375" x2="0.125" y2="0.81625" layer="21" rot="R270"/>
<wire x1="0.44125" y1="-0.3095" x2="0" y2="0.373" width="0.127" layer="21"/>
<wire x1="0" y1="0.373" x2="-0.44125" y2="-0.3095" width="0.127" layer="21"/>
<wire x1="-0.44125" y1="-0.3095" x2="0.44125" y2="-0.3095" width="0.127" layer="21"/>
</package>
<package name="SOD80">
<wire x1="0.7874" y1="-1.3208" x2="0.7874" y2="1.3208" width="0.127" layer="21"/>
<wire x1="-0.7874" y1="-1.3208" x2="-0.7874" y2="1.3208" width="0.127" layer="21"/>
<wire x1="0.6" y1="-0.627" x2="0" y2="0.373" width="0.127" layer="21"/>
<wire x1="0" y1="0.373" x2="-0.6" y2="-0.627" width="0.127" layer="21"/>
<wire x1="-0.6" y1="-0.627" x2="0.6" y2="-0.627" width="0.127" layer="21"/>
<smd name="C" x="0" y="1.65" dx="1.9" dy="1.2" layer="1" roundness="20"/>
<smd name="A" x="0" y="-1.65" dx="1.9" dy="1.2" layer="1" roundness="20"/>
<text x="-1.905" y="0" size="0.8128" layer="25" font="vector" rot="R270" align="center">&gt;NAME</text>
<text x="1.905" y="0" size="0.8128" layer="27" font="vector" ratio="10" rot="R90" align="center">&gt;VALUE</text>
<rectangle x1="-0.2794" y1="0.7112" x2="0.2794" y2="2.4384" layer="21" rot="R270"/>
<rectangle x1="-0.2794" y1="-2.4384" x2="0.2794" y2="-0.7112" layer="21" rot="R270"/>
<rectangle x1="-0.3048" y1="-0.2286" x2="0.3048" y2="1.3462" layer="21" rot="R270"/>
</package>
<package name="SOD882">
<wire x1="0.25" y1="0.45" x2="0.25" y2="-0.2" width="0.127" layer="21"/>
<wire x1="0.25" y1="-0.2" x2="0.25" y2="-0.45" width="0.127" layer="21"/>
<wire x1="0.25" y1="-0.45" x2="-0.25" y2="-0.45" width="0.127" layer="21"/>
<wire x1="-0.25" y1="-0.45" x2="-0.25" y2="-0.2" width="0.127" layer="21"/>
<wire x1="-0.25" y1="-0.2" x2="-0.25" y2="0.45" width="0.127" layer="21"/>
<wire x1="-0.25" y1="0.45" x2="0.25" y2="0.45" width="0.127" layer="21"/>
<smd name="C" x="0" y="0.35" dx="0.65" dy="0.4" layer="1" roundness="20"/>
<smd name="A" x="0" y="-0.35" dx="0.65" dy="0.4" layer="1" roundness="20"/>
<text x="-1.27" y="0" size="0.8128" layer="25" font="vector" ratio="10" rot="R270" align="center">&gt;NAME</text>
<text x="1.27" y="0" size="0.8128" layer="27" font="vector" ratio="10" rot="R270" align="center">&gt;VALUE</text>
<rectangle x1="-0.079375" y1="0.020625" x2="0.079375" y2="0.620625" layer="21" rot="R270"/>
<wire x1="0.25" y1="-0.2" x2="0" y2="0.3" width="0.127" layer="21"/>
<wire x1="0" y1="0.3" x2="-0.25" y2="-0.2" width="0.127" layer="21"/>
<wire x1="-0.25" y1="-0.2" x2="0.25" y2="-0.2" width="0.127" layer="21"/>
</package>
<package name="SMC_DO214AB">
<smd name="C" x="0" y="3.3" dx="3.5" dy="2.5" layer="1" roundness="20"/>
<smd name="A" x="0" y="-3.3" dx="3.5" dy="2.5" layer="1" roundness="20"/>
<wire x1="3.1" y1="3.55" x2="3.1" y2="2.1" width="0.127" layer="21"/>
<wire x1="3.1" y1="2.1" x2="3.1" y2="2" width="0.127" layer="21"/>
<wire x1="3.1" y1="2" x2="3.1" y2="-3.55" width="0.127" layer="21"/>
<wire x1="-3.1" y1="3.55" x2="-3.1" y2="2.1" width="0.127" layer="21"/>
<wire x1="-3.1" y1="2.1" x2="-3.1" y2="2" width="0.127" layer="21"/>
<wire x1="-3.1" y1="2" x2="-3.1" y2="-3.55" width="0.127" layer="21"/>
<wire x1="3.1" y1="3.55" x2="-3.1" y2="3.55" width="0.127" layer="21"/>
<wire x1="3.1" y1="-3.55" x2="-3.1" y2="-3.55" width="0.127" layer="21"/>
<text x="2.54" y="0" size="0.8128" layer="25" font="vector" ratio="10" rot="R270" align="center">&gt;NAME</text>
<text x="-2.54" y="0" size="0.8128" layer="27" font="vector" rot="R90" align="center">&gt;VALUE</text>
<wire x1="3.1" y1="2.1" x2="-3.1" y2="2.1" width="0.127" layer="21"/>
<wire x1="3.1" y1="2" x2="-3.1" y2="2" width="0.127" layer="21"/>
<wire x1="0.6" y1="-0.627" x2="0" y2="0.373" width="0.127" layer="21"/>
<wire x1="0" y1="0.373" x2="-0.6" y2="-0.627" width="0.127" layer="21"/>
<wire x1="-0.6" y1="-0.627" x2="0.6" y2="-0.627" width="0.127" layer="21"/>
<rectangle x1="-0.3048" y1="-0.2286" x2="0.3048" y2="1.3462" layer="21" rot="R270"/>
</package>
<package name="SMA_DO123">
<smd name="C" x="0" y="1.4" dx="1.2" dy="1.2" layer="1" roundness="20"/>
<smd name="A" x="0" y="-1.4" dx="1.2" dy="1.2" layer="1" roundness="20"/>
<wire x1="0.85" y1="2" x2="0.85" y2="1.11" width="0.127" layer="21"/>
<wire x1="0.85" y1="1.11" x2="0.85" y2="0.99" width="0.127" layer="21"/>
<wire x1="0.85" y1="0.99" x2="0.85" y2="-2" width="0.127" layer="21"/>
<wire x1="-0.85" y1="2" x2="-0.85" y2="1.11" width="0.127" layer="21"/>
<wire x1="-0.85" y1="1.11" x2="-0.85" y2="0.99" width="0.127" layer="21"/>
<wire x1="-0.85" y1="0.99" x2="-0.85" y2="-2" width="0.127" layer="21"/>
<wire x1="0.85" y1="2" x2="-0.85" y2="2" width="0.127" layer="21"/>
<wire x1="0.85" y1="-2" x2="-0.85" y2="-2" width="0.127" layer="21"/>
<text x="1.405" y="0" size="0.8128" layer="25" font="vector" ratio="10" rot="R270" align="center">&gt;NAME</text>
<text x="-1.405" y="0" size="0.8128" layer="27" font="vector" rot="R90" align="center">&gt;VALUE</text>
<wire x1="0.85" y1="1.11" x2="-0.85" y2="1.11" width="0.127" layer="21"/>
<wire x1="0.85" y1="0.99" x2="-0.85" y2="0.99" width="0.127" layer="21"/>
<wire x1="0.6" y1="-0.627" x2="0" y2="0.373" width="0.127" layer="21"/>
<wire x1="0" y1="0.373" x2="-0.6" y2="-0.627" width="0.127" layer="21"/>
<wire x1="-0.6" y1="-0.627" x2="0.6" y2="-0.627" width="0.127" layer="21"/>
<rectangle x1="-0.3048" y1="-0.2286" x2="0.3048" y2="1.3462" layer="21" rot="R270"/>
</package>
<package name="SOD-128">
<smd name="P$1" x="-2.2" y="0" dx="1.2" dy="1.9" layer="1"/>
<smd name="P$2" x="2.2" y="0" dx="1.2" dy="1.9" layer="1"/>
<wire x1="2.1" y1="1.7" x2="-1.3" y2="1.7" width="0.127" layer="21"/>
<wire x1="-1.4" y1="1.7" x2="-1.5" y2="1.7" width="0.127" layer="21"/>
<wire x1="-1.5" y1="1.7" x2="-2.1" y2="1.7" width="0.127" layer="21"/>
<wire x1="-2.1" y1="-1.7" x2="-1.5" y2="-1.7" width="0.127" layer="21"/>
<wire x1="-1.4" y1="-1.7" x2="-1.3" y2="-1.7" width="0.127" layer="21"/>
<wire x1="-1.3" y1="-1.7" x2="2.1" y2="-1.7" width="0.127" layer="21"/>
<wire x1="2.1" y1="-1.7" x2="2.1" y2="-1.1" width="0.127" layer="21"/>
<wire x1="2.1" y1="-1.1" x2="2.9" y2="-1.1" width="0.127" layer="21"/>
<wire x1="2.9" y1="-1.1" x2="2.9" y2="1.1" width="0.127" layer="21"/>
<wire x1="2.9" y1="1.1" x2="2.1" y2="1.1" width="0.127" layer="21"/>
<wire x1="2.1" y1="1.1" x2="2.1" y2="1.7" width="0.127" layer="21"/>
<wire x1="-2.1" y1="-1.7" x2="-2.1" y2="-1.1" width="0.127" layer="21"/>
<wire x1="-2.1" y1="-1.1" x2="-2.9" y2="-1.1" width="0.127" layer="21"/>
<wire x1="-2.9" y1="-1.1" x2="-2.9" y2="1.1" width="0.127" layer="21"/>
<wire x1="-2.9" y1="1.1" x2="-2.1" y2="1.1" width="0.127" layer="21"/>
<wire x1="-2.1" y1="1.1" x2="-2.1" y2="1.7" width="0.127" layer="21"/>
<wire x1="0.627" y1="0.6" x2="-0.373" y2="0" width="0.127" layer="21"/>
<wire x1="-0.373" y1="0" x2="0.627" y2="-0.6" width="0.127" layer="21"/>
<wire x1="0.627" y1="-0.6" x2="0.627" y2="0.6" width="0.127" layer="21"/>
<rectangle x1="-0.8636" y1="-0.7874" x2="-0.254" y2="0.7874" layer="21"/>
<wire x1="-1.5" y1="1.7" x2="-1.5" y2="-1.7" width="0.127" layer="21"/>
<wire x1="-1.5" y1="-1.7" x2="-1.4" y2="-1.7" width="0.127" layer="21"/>
<wire x1="-1.4" y1="-1.7" x2="-1.4" y2="1.7" width="0.127" layer="21"/>
<wire x1="-1.4" y1="1.7" x2="-1.3" y2="1.7" width="0.127" layer="21"/>
<wire x1="-1.3" y1="1.7" x2="-1.3" y2="-1.7" width="0.127" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="D">
<wire x1="-1.27" y1="-1.27" x2="1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="-1.27" y2="1.27" width="0.254" layer="94"/>
<wire x1="1.27" y1="1.27" x2="1.27" y2="0" width="0.254" layer="94"/>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="-1.27" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="1.27" y2="-1.27" width="0.254" layer="94"/>
<pin name="A" x="-2.54" y="0" visible="off" length="short" direction="pas"/>
<pin name="C" x="2.54" y="0" visible="off" length="short" direction="pas" rot="R180"/>
<text x="2.54" y="0.4826" size="1.778" layer="95">&gt;NAME</text>
<text x="2.54" y="-2.3114" size="1.778" layer="96">&gt;VALUE</text>
</symbol>
<symbol name="SCHOTTKY">
<wire x1="-1.27" y1="-1.27" x2="1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="-1.27" y2="1.27" width="0.254" layer="94"/>
<wire x1="1.905" y1="1.27" x2="1.27" y2="1.27" width="0.254" layer="94"/>
<wire x1="1.27" y1="1.27" x2="1.27" y2="0" width="0.254" layer="94"/>
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="-1.27" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="1.27" y2="-1.27" width="0.254" layer="94"/>
<wire x1="1.905" y1="1.27" x2="1.905" y2="1.016" width="0.254" layer="94"/>
<wire x1="1.27" y1="-1.27" x2="0.635" y2="-1.27" width="0.254" layer="94"/>
<wire x1="0.635" y1="-1.016" x2="0.635" y2="-1.27" width="0.254" layer="94"/>
<text x="-2.286" y="1.905" size="1.778" layer="95">&gt;NAME</text>
<text x="-2.286" y="-3.429" size="1.778" layer="96">&gt;VALUE</text>
<pin name="A" x="-2.54" y="0" visible="off" length="short" direction="pas"/>
<pin name="C" x="2.54" y="0" visible="off" length="short" direction="pas" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="DIODE" prefix="D" uservalue="yes">
<description>FAST SMALL SIGNAL DIODES SMD 200mA 100V SOD123</description>
<gates>
<gate name="G$1" symbol="D" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOD123">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name="-DNP">
<attribute name="CODE-BCE" value="DNP" constant="no"/>
<attribute name="CODE-BCMI" value="DNP" constant="no"/>
<attribute name="CODE-TK2" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
<technology name="-SOD123">
<attribute name="CODE-BCE" value="SP0234" constant="no"/>
<attribute name="CODE-BCMI" value="0234" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="http://www.mccsemi.com/up_pdf/1N4148WX(SOD323).pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/it/micro-commercial-co/1N4148WX-TP/1N4148WXTPMSCT-ND/717312" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="1N4148WXTPMSCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Micro Commercial Co" constant="no"/>
<attribute name="MANUFACTURER-PN" value="1N4148WX-TP" constant="no"/>
<attribute name="VALUE" value="1N4148" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="D_SCHOTTKY" prefix="D" uservalue="yes">
<description>Schottky Diodes</description>
<gates>
<gate name="D" symbol="SCHOTTKY" x="0" y="0"/>
</gates>
<devices>
<device name="-SMA" package="SMA_DO214AC">
<connects>
<connect gate="D" pin="A" pad="A"/>
<connect gate="D" pin="C" pad="C"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-BCE" value="SP0234" constant="no"/>
<attribute name="CODE-BCMI" value="0234" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="https://www.fairchildsemi.com/datasheets/SS/SS12.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/it/on-semiconductor/SS14/SS14CT-ND/965729" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="SS14CT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="On Semi" constant="no"/>
<attribute name="MANUFACTURER-PN" value="SS14" constant="no"/>
<attribute name="VALUE" value="SS14" constant="no"/>
</technology>
</technologies>
</device>
<device name="-SOD106" package="SOD106">
<connects>
<connect gate="D" pin="A" pad="A"/>
<connect gate="D" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-SOD110" package="SOD110">
<connects>
<connect gate="D" pin="A" pad="A"/>
<connect gate="D" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-SOD80" package="SOD80">
<connects>
<connect gate="D" pin="A" pad="A"/>
<connect gate="D" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-SOD882" package="SOD882">
<connects>
<connect gate="D" pin="A" pad="A"/>
<connect gate="D" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-SMB" package="SMB_DO214AA">
<connects>
<connect gate="D" pin="A" pad="A"/>
<connect gate="D" pin="C" pad="C"/>
</connects>
<technologies>
<technology name="-4007">
<attribute name="CODE-ARDUINO" value="0020" constant="no"/>
<attribute name="DATASHEET" value="www.comchiptech.com/cms/UserFiles/CGRA4001-G%20Thru.%20CGRA4007-HF%20RevD.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/en/comchip-technology/CGRA4007-G/641-1018-1-ND/1121140" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="641-1018-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Comchip" constant="no"/>
<attribute name="MANUFACTURER-PN" value="CGRA4007-G" constant="no"/>
<attribute name="VALUE" value="1N4007" constant="no"/>
</technology>
<technology name="-DNP">
<attribute name="CODE-ARDUINO" value="DNP" constant="no"/>
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
<technology name="-SMB">
<attribute name="CODE-ARDUINO" value="0234" constant="no"/>
<attribute name="DATASHEET" value="http://www.mccsemi.com/up_pdf/SK12-L~SK110-L(DO-214AA).PDF" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/it/micro-commercial-co/SK14-LTP/SK14-LTPMSCT-ND/2642062" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="SK14-LTPMSCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Micro Commercial Co" constant="no"/>
<attribute name="MANUFACTURER-PN" value="SK14-LTP" constant="no"/>
<attribute name="VALUE" value="SK14" constant="no"/>
</technology>
</technologies>
</device>
<device name="-SMC" package="SMC_DO214AB">
<connects>
<connect gate="D" pin="A" pad="A"/>
<connect gate="D" pin="C" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SO123" package="SMA_DO123">
<connects>
<connect gate="D" pin="A" pad="A"/>
<connect gate="D" pin="C" pad="C"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="http://www.mccsemi.com/up_pdf/MBR0520~MBR0580%28SOD123%29.pdf " constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="http://www.digikey.com/product-detail/en/micro-commercial-co/MBR0560-TP/MBR0560TPMSCT-ND/717368 " constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="MBR0560TPMSCT-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Micro Comm " constant="no"/>
<attribute name="MANUFACTURER-PN" value="MBR0560-TP" constant="no"/>
<attribute name="VALUE" value="MBR0560" constant="no"/>
</technology>
</technologies>
</device>
<device name="-PMEG4050EP" package="SOD-128">
<connects>
<connect gate="D" pin="A" pad="P$2"/>
<connect gate="D" pin="C" pad="P$1"/>
</connects>
<technologies>
<technology name="">
<attribute name="DATASHEET" value="https://assets.nexperia.com/documents/data-sheet/PMEG4050EP.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.se/products/en?keywords=1727-5842-1-ND" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="1727-5842-1-ND" constant="no"/>
<attribute name="MANUFACTURER" value="Nexperia USA Inc." constant="no"/>
<attribute name="MANUFACTURER-PN" value="PMEG4050EP,115" constant="no"/>
<attribute name="VALUE" value="40V/5A" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Arduino-connectors">
<description>Copyright (c) 2016-2017 Arduino LLC.  All right reserved.</description>
<packages>
<package name="MODULINO-4">
<description>&lt;b&gt;AMP MTA connector&lt;/b&gt;&lt;p&gt;
Source: http://ecommas.tycoelectronics.com .. ENG_CD_640456_W.pdf</description>
<wire x1="5.08" y1="3.2" x2="5.08" y2="-1.77" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-1.77" x2="5.08" y2="-1.77" width="0.1524" layer="21"/>
<wire x1="5.08" y1="3.2" x2="-5.08" y2="3.2" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-1.77" x2="5.08" y2="-2.6" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-2.6" x2="5.08" y2="-2.6" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-1.77" x2="-5.08" y2="3.2" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-2.6" x2="-5.08" y2="-1.77" width="0.1524" layer="21"/>
<rectangle x1="3.556" y1="-0.254" x2="4.064" y2="0.254" layer="21"/>
<rectangle x1="1.016" y1="-0.254" x2="1.524" y2="0.254" layer="21"/>
<rectangle x1="-1.524" y1="-0.254" x2="-1.016" y2="0.254" layer="21"/>
<pad name="1" x="3.81" y="0" drill="1.016" shape="long" rot="R90"/>
<pad name="2" x="1.27" y="0" drill="1.016" shape="long" rot="R90"/>
<pad name="3" x="-1.27" y="0" drill="1.016" shape="long" rot="R90"/>
<text x="0" y="2.3641" size="1.27" layer="27" rot="R180" align="center">&gt;NAME</text>
<rectangle x1="-4.064" y1="-0.254" x2="-3.556" y2="0.254" layer="21"/>
<pad name="4" x="-3.81" y="0" drill="1.016" shape="long" rot="R90"/>
</package>
<package name="MODULINO-4SM">
<description>&lt;b&gt;AMP MTA connector&lt;/b&gt;&lt;p&gt;
Source: http://ecommas.tycoelectronics.com .. ENG_CD_640456_W.pdf</description>
<wire x1="6.35" y1="3.2" x2="6.35" y2="-1.77" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-1.77" x2="6.35" y2="-1.77" width="0.1524" layer="21"/>
<wire x1="6.35" y1="3.2" x2="-3.81" y2="3.2" width="0.1524" layer="21"/>
<wire x1="6.35" y1="-1.77" x2="6.35" y2="-2.6" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-2.6" x2="6.35" y2="-2.6" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-1.77" x2="-3.81" y2="3.2" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-2.6" x2="-3.81" y2="-1.77" width="0.1524" layer="21"/>
<rectangle x1="4.826" y1="-0.254" x2="5.334" y2="0.254" layer="21"/>
<rectangle x1="2.286" y1="-0.254" x2="2.794" y2="0.254" layer="21"/>
<rectangle x1="-0.254" y1="-0.254" x2="0.254" y2="0.254" layer="21"/>
<pad name="1" x="5.08" y="0" drill="1.016" rot="R90"/>
<pad name="2" x="2.54" y="0" drill="1.016" rot="R90"/>
<pad name="3" x="0" y="0" drill="1.016" rot="R90"/>
<text x="1.27" y="2.3641" size="1.27" layer="27" rot="R180" align="center">&gt;NAME</text>
<rectangle x1="-2.794" y1="-0.254" x2="-2.286" y2="0.254" layer="21"/>
<pad name="4" x="-2.54" y="0" drill="1.016" rot="R90"/>
</package>
<package name="MODULINO-3">
<description>&lt;b&gt;AMP MTA connector&lt;/b&gt;&lt;p&gt;
Source: http://ecommas.tycoelectronics.com .. ENG_CD_640456_W.pdf</description>
<wire x1="3.81" y1="2.7" x2="3.81" y2="1.54" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="1.54" x2="3.81" y2="1.54" width="0.1524" layer="21"/>
<wire x1="3.81" y1="2.7" x2="-3.81" y2="2.7" width="0.1524" layer="21"/>
<wire x1="3.81" y1="1.54" x2="3.81" y2="-3.1" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-3.1" x2="3.81" y2="-3.1" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="1.54" x2="-3.81" y2="2.7" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-3.1" x2="-3.81" y2="1.54" width="0.1524" layer="21"/>
<rectangle x1="2.286" y1="-0.254" x2="2.794" y2="0.254" layer="21"/>
<rectangle x1="-0.254" y1="-0.254" x2="0.254" y2="0.254" layer="21"/>
<rectangle x1="-2.794" y1="-0.254" x2="-2.286" y2="0.254" layer="21"/>
<pad name="1" x="-2.54" y="0" drill="1.016" shape="long" rot="R270"/>
<pad name="2" x="0" y="0" drill="1.016" shape="long" rot="R270"/>
<pad name="3" x="2.54" y="0" drill="1.016" shape="long" rot="R270"/>
<text x="0" y="-2.3641" size="1.27" layer="25" align="center">&gt;NAME</text>
</package>
<package name="MODULINO-3SM">
<description>&lt;b&gt;AMP MTA connector&lt;/b&gt;&lt;p&gt;
Source: http://ecommas.tycoelectronics.com .. ENG_CD_640456_W.pdf</description>
<wire x1="3.81" y1="3.2" x2="3.81" y2="-1.77" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-1.77" x2="3.81" y2="-1.77" width="0.1524" layer="21"/>
<wire x1="3.81" y1="3.2" x2="-3.81" y2="3.2" width="0.1524" layer="21"/>
<wire x1="3.81" y1="-1.77" x2="3.81" y2="-2.6" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-2.6" x2="3.81" y2="-2.6" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-1.77" x2="-3.81" y2="3.2" width="0.1524" layer="21"/>
<wire x1="-3.81" y1="-2.6" x2="-3.81" y2="-1.77" width="0.1524" layer="21"/>
<rectangle x1="2.286" y1="-0.254" x2="2.794" y2="0.254" layer="21"/>
<rectangle x1="-0.254" y1="-0.254" x2="0.254" y2="0.254" layer="21"/>
<rectangle x1="-2.794" y1="-0.254" x2="-2.286" y2="0.254" layer="21"/>
<pad name="1" x="2.54" y="0" drill="1.016" rot="R90"/>
<pad name="2" x="0" y="0" drill="1.016" rot="R90"/>
<pad name="3" x="-2.54" y="0" drill="1.016" rot="R90"/>
<text x="0" y="2.3641" size="1.27" layer="27" rot="R180" align="center">&gt;NAME</text>
</package>
<package name="1X06-TH">
<wire x1="0.635" y1="1.27" x2="1.905" y2="1.27" width="0.1524" layer="21"/>
<wire x1="1.905" y1="1.27" x2="2.54" y2="0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="0.635" x2="2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="-0.635" x2="1.905" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="2.54" y1="0.635" x2="3.175" y2="1.27" width="0.1524" layer="21"/>
<wire x1="3.175" y1="1.27" x2="4.445" y2="1.27" width="0.1524" layer="21"/>
<wire x1="4.445" y1="1.27" x2="5.08" y2="0.635" width="0.1524" layer="21"/>
<wire x1="5.08" y1="0.635" x2="5.08" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-0.635" x2="4.445" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="4.445" y1="-1.27" x2="3.175" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="3.175" y1="-1.27" x2="2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="0.635" x2="-1.905" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="1.27" x2="-0.635" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="1.27" x2="0" y2="0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="0.635" x2="0" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="-0.635" x2="-0.635" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="-1.27" x2="-1.905" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="-1.27" x2="-2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="0.635" y1="1.27" x2="0" y2="0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="-0.635" x2="0.635" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-1.27" x2="0.635" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-6.985" y1="1.27" x2="-5.715" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-5.715" y1="1.27" x2="-5.08" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0.635" x2="-5.08" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-0.635" x2="-5.715" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0.635" x2="-4.445" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-4.445" y1="1.27" x2="-3.175" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="1.27" x2="-2.54" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="0.635" x2="-2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="-0.635" x2="-3.175" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="-1.27" x2="-4.445" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-4.445" y1="-1.27" x2="-5.08" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="0.635" x2="-7.62" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-6.985" y1="1.27" x2="-7.62" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="-0.635" x2="-6.985" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-5.715" y1="-1.27" x2="-6.985" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="5.715" y1="1.27" x2="6.985" y2="1.27" width="0.1524" layer="21"/>
<wire x1="6.985" y1="1.27" x2="7.62" y2="0.635" width="0.1524" layer="21"/>
<wire x1="7.62" y1="0.635" x2="7.62" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="7.62" y1="-0.635" x2="6.985" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="5.715" y1="1.27" x2="5.08" y2="0.635" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-0.635" x2="5.715" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="6.985" y1="-1.27" x2="5.715" y2="-1.27" width="0.1524" layer="21"/>
<rectangle x1="3.556" y1="-0.254" x2="4.064" y2="0.254" layer="51"/>
<rectangle x1="1.016" y1="-0.254" x2="1.524" y2="0.254" layer="51"/>
<rectangle x1="-1.524" y1="-0.254" x2="-1.016" y2="0.254" layer="51"/>
<rectangle x1="-4.064" y1="-0.254" x2="-3.556" y2="0.254" layer="51"/>
<rectangle x1="-6.604" y1="-0.254" x2="-6.096" y2="0.254" layer="51"/>
<rectangle x1="6.096" y1="-0.254" x2="6.604" y2="0.254" layer="51"/>
<pad name="1" x="-6.35" y="0" drill="0.95" diameter="1.4224" shape="long" rot="R90"/>
<pad name="2" x="-3.81" y="0" drill="0.95" diameter="1.4224" shape="long" rot="R90"/>
<pad name="3" x="-1.27" y="0" drill="0.95" diameter="1.4224" shape="long" rot="R90"/>
<pad name="4" x="1.27" y="0" drill="0.95" diameter="1.4224" shape="long" rot="R90"/>
<pad name="5" x="3.81" y="0" drill="0.95" diameter="1.4224" shape="long" rot="R90"/>
<pad name="6" x="6.35" y="0" drill="0.95" diameter="1.4224" shape="long" rot="R90"/>
<text x="-7.6962" y="1.8288" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-7.62" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
</package>
<package name="1X06_LITTLE">
<wire x1="0.635" y1="1.27" x2="1.905" y2="1.27" width="0.1524" layer="21"/>
<wire x1="1.905" y1="1.27" x2="2.54" y2="0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="0.635" x2="2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="-0.635" x2="1.905" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="2.54" y1="0.635" x2="3.175" y2="1.27" width="0.1524" layer="21"/>
<wire x1="3.175" y1="1.27" x2="4.445" y2="1.27" width="0.1524" layer="21"/>
<wire x1="4.445" y1="1.27" x2="5.08" y2="0.635" width="0.1524" layer="21"/>
<wire x1="5.08" y1="0.635" x2="5.08" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-0.635" x2="4.445" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="4.445" y1="-1.27" x2="3.175" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="3.175" y1="-1.27" x2="2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="0.635" x2="-1.905" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="1.27" x2="-0.635" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="1.27" x2="0" y2="0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="0.635" x2="0" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="-0.635" x2="-0.635" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="-1.27" x2="-1.905" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="-1.27" x2="-2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="0.635" y1="1.27" x2="0" y2="0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="-0.635" x2="0.635" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-1.27" x2="0.635" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-6.985" y1="1.27" x2="-5.715" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-5.715" y1="1.27" x2="-5.08" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0.635" x2="-5.08" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-0.635" x2="-5.715" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0.635" x2="-4.445" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-4.445" y1="1.27" x2="-3.175" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="1.27" x2="-2.54" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="0.635" x2="-2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="-0.635" x2="-3.175" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="-1.27" x2="-4.445" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-4.445" y1="-1.27" x2="-5.08" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="0.635" x2="-7.62" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-6.985" y1="1.27" x2="-7.62" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="-0.635" x2="-6.985" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-5.715" y1="-1.27" x2="-6.985" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="5.715" y1="1.27" x2="6.985" y2="1.27" width="0.1524" layer="21"/>
<wire x1="6.985" y1="1.27" x2="7.62" y2="0.635" width="0.1524" layer="21"/>
<wire x1="7.62" y1="0.635" x2="7.62" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="7.62" y1="-0.635" x2="6.985" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="5.715" y1="1.27" x2="5.08" y2="0.635" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-0.635" x2="5.715" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="6.985" y1="-1.27" x2="5.715" y2="-1.27" width="0.1524" layer="21"/>
<rectangle x1="3.556" y1="-0.254" x2="4.064" y2="0.254" layer="51"/>
<rectangle x1="1.016" y1="-0.254" x2="1.524" y2="0.254" layer="51"/>
<rectangle x1="-1.524" y1="-0.254" x2="-1.016" y2="0.254" layer="51"/>
<rectangle x1="-4.064" y1="-0.254" x2="-3.556" y2="0.254" layer="51"/>
<rectangle x1="-6.604" y1="-0.254" x2="-6.096" y2="0.254" layer="51"/>
<rectangle x1="6.096" y1="-0.254" x2="6.604" y2="0.254" layer="51"/>
<pad name="1" x="-6.35" y="0" drill="0.95" diameter="1.4224" shape="octagon" rot="R90"/>
<pad name="2" x="-3.81" y="0" drill="0.95" diameter="1.4224" shape="octagon" rot="R90"/>
<pad name="3" x="-1.27" y="0" drill="0.95" diameter="1.4224" shape="octagon" rot="R90"/>
<pad name="4" x="1.27" y="0" drill="0.95" diameter="1.4224" shape="octagon" rot="R90"/>
<pad name="5" x="3.81" y="0" drill="0.95" diameter="1.4224" shape="octagon" rot="R90"/>
<pad name="6" x="6.35" y="0" drill="0.95" diameter="1.4224" shape="octagon" rot="R90"/>
<text x="-7.6962" y="1.8288" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-7.62" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
</package>
<package name="1X06_SMD">
<wire x1="-7.87" y1="1.25" x2="-7.87" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-7.87" y1="-1.25" x2="-6.985" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-7.87" y1="1.25" x2="-6.985" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-5.588" y1="1.25" x2="-4.572" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-3.048" y1="1.25" x2="-2.032" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-0.508" y1="1.25" x2="0.508" y2="1.25" width="0.1778" layer="21"/>
<wire x1="2.032" y1="1.25" x2="3.048" y2="1.25" width="0.1778" layer="21"/>
<wire x1="4.572" y1="1.25" x2="5.588" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-4.572" y1="-1.25" x2="-5.588" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-2.032" y1="-1.25" x2="-3.048" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="0.508" y1="-1.25" x2="-0.508" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="3.048" y1="-1.25" x2="2.032" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="5.588" y1="-1.25" x2="4.572" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="7.87" y1="-1.25" x2="7.87" y2="1.25" width="0.1778" layer="21"/>
<wire x1="7.112" y1="1.25" x2="7.87" y2="1.25" width="0.1778" layer="21"/>
<wire x1="7.87" y1="-1.25" x2="7.112" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-7.349" y1="-0.724" x2="-7.349" y2="0.726" width="0.001" layer="51"/>
<wire x1="-7.049" y1="0.701" x2="-6.849" y2="0.501" width="0.001" layer="51"/>
<wire x1="-7.049" y1="0.701" x2="-7.049" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-7.049" y1="-0.699" x2="-6.849" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-6.849" y1="-0.499" x2="-6.849" y2="0.501" width="0.001" layer="51"/>
<wire x1="-6.849" y1="0.501" x2="-5.849" y2="0.501" width="0.001" layer="51"/>
<wire x1="-5.849" y1="0.501" x2="-5.649" y2="0.701" width="0.001" layer="51"/>
<wire x1="-5.649" y1="0.701" x2="-7.049" y2="0.701" width="0.001" layer="51"/>
<wire x1="-5.649" y1="0.701" x2="-5.649" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-5.649" y1="-0.699" x2="-5.849" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-5.849" y1="-0.499" x2="-5.849" y2="0.501" width="0.001" layer="51"/>
<wire x1="-6.849" y1="-0.499" x2="-5.849" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-5.649" y1="-0.699" x2="-7.049" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-7.87" y1="1.251" x2="-7.87" y2="0.726" width="0.001" layer="51"/>
<wire x1="-7.87" y1="0.726" x2="-7.87" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-7.87" y1="-0.724" x2="-7.87" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-7.87" y1="-1.249" x2="-6.631190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-6.631190625" y1="-1.249" x2="-6.031190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-6.031190625" y1="-1.249" x2="-1.551190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-1.551190625" y1="-1.249" x2="-0.951190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-0.951190625" y1="-1.249" x2="3.528809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="3.528809375" y1="-1.249" x2="4.128809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="4.128809375" y1="-1.249" x2="7.87" y2="-1.249" width="0.001" layer="51"/>
<wire x1="7.87" y1="-1.249" x2="7.87" y2="-0.724" width="0.001" layer="51"/>
<wire x1="7.87" y1="-0.724" x2="7.87" y2="0.726" width="0.001" layer="51"/>
<wire x1="7.87" y1="0.726" x2="7.87" y2="1.251" width="0.001" layer="51"/>
<wire x1="7.87" y1="1.251" x2="6.651" y2="1.251" width="0.001" layer="51"/>
<wire x1="6.651" y1="1.251" x2="6.051" y2="1.251" width="0.001" layer="51"/>
<wire x1="6.051" y1="1.251" x2="1.571" y2="1.251" width="0.001" layer="51"/>
<wire x1="1.571" y1="1.251" x2="0.971" y2="1.251" width="0.001" layer="51"/>
<wire x1="0.971" y1="1.251" x2="-3.509" y2="1.251" width="0.001" layer="51"/>
<wire x1="-3.509" y1="1.251" x2="-4.109" y2="1.251" width="0.001" layer="51"/>
<wire x1="-4.109" y1="1.251" x2="-7.87" y2="1.251" width="0.001" layer="51"/>
<wire x1="-7.87" y1="0.726" x2="-5.349" y2="0.726" width="0.001" layer="51"/>
<wire x1="-5.349" y1="0.726" x2="-4.809" y2="0.726" width="0.001" layer="51"/>
<wire x1="-4.809" y1="0.726" x2="-2.809" y2="0.726" width="0.001" layer="51"/>
<wire x1="-2.809" y1="0.726" x2="-2.269" y2="0.726" width="0.001" layer="51"/>
<wire x1="-2.269" y1="0.726" x2="-0.269" y2="0.726" width="0.001" layer="51"/>
<wire x1="-0.269" y1="0.726" x2="0.271" y2="0.726" width="0.001" layer="51"/>
<wire x1="0.271" y1="0.726" x2="2.271" y2="0.726" width="0.001" layer="51"/>
<wire x1="2.271" y1="0.726" x2="2.811" y2="0.726" width="0.001" layer="51"/>
<wire x1="2.811" y1="0.726" x2="4.811" y2="0.726" width="0.001" layer="51"/>
<wire x1="4.811" y1="0.726" x2="5.351" y2="0.726" width="0.001" layer="51"/>
<wire x1="5.351" y1="0.726" x2="7.351" y2="0.726" width="0.001" layer="51"/>
<wire x1="7.351" y1="0.726" x2="7.87" y2="0.726" width="0.001" layer="51"/>
<wire x1="7.87" y1="-0.724" x2="7.351" y2="-0.724" width="0.001" layer="51"/>
<wire x1="7.351" y1="-0.724" x2="5.351" y2="-0.724" width="0.001" layer="51"/>
<wire x1="5.351" y1="-0.724" x2="4.811" y2="-0.724" width="0.001" layer="51"/>
<wire x1="4.811" y1="-0.724" x2="2.811" y2="-0.724" width="0.001" layer="51"/>
<wire x1="2.811" y1="-0.724" x2="2.271" y2="-0.724" width="0.001" layer="51"/>
<wire x1="2.271" y1="-0.724" x2="0.271" y2="-0.724" width="0.001" layer="51"/>
<wire x1="0.271" y1="-0.724" x2="-0.269" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-0.269" y1="-0.724" x2="-2.269" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-2.269" y1="-0.724" x2="-2.809" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-2.809" y1="-0.724" x2="-4.809" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-4.809" y1="-0.724" x2="-5.349" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-5.349" y1="-0.724" x2="-7.87" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-5.349" y1="0.726" x2="-5.349" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-4.809" y1="-0.724" x2="-4.809" y2="0.726" width="0.001" layer="51"/>
<wire x1="-4.509" y1="0.701" x2="-4.309" y2="0.501" width="0.001" layer="51"/>
<wire x1="-4.509" y1="0.701" x2="-4.509" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-4.509" y1="-0.699" x2="-4.309" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-4.309" y1="-0.499" x2="-4.309" y2="0.501" width="0.001" layer="51"/>
<wire x1="-4.309" y1="0.501" x2="-3.309" y2="0.501" width="0.001" layer="51"/>
<wire x1="-3.309" y1="0.501" x2="-3.109" y2="0.701" width="0.001" layer="51"/>
<wire x1="-3.109" y1="0.701" x2="-4.509" y2="0.701" width="0.001" layer="51"/>
<wire x1="-3.109" y1="0.701" x2="-3.109" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-3.109" y1="-0.699" x2="-3.309" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-3.309" y1="-0.499" x2="-3.309" y2="0.501" width="0.001" layer="51"/>
<wire x1="-4.309" y1="-0.499" x2="-3.309" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-3.109" y1="-0.699" x2="-4.509" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-2.809" y1="0.726" x2="-2.809" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-2.269" y1="-0.724" x2="-2.269" y2="0.726" width="0.001" layer="51"/>
<wire x1="-1.969" y1="0.701" x2="-1.769" y2="0.501" width="0.001" layer="51"/>
<wire x1="-1.969" y1="0.701" x2="-1.969" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-1.969" y1="-0.699" x2="-1.769" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-1.769" y1="-0.499" x2="-1.769" y2="0.501" width="0.001" layer="51"/>
<wire x1="-1.769" y1="0.501" x2="-0.769" y2="0.501" width="0.001" layer="51"/>
<wire x1="-0.769" y1="0.501" x2="-0.569" y2="0.701" width="0.001" layer="51"/>
<wire x1="-0.569" y1="0.701" x2="-1.969" y2="0.701" width="0.001" layer="51"/>
<wire x1="-0.569" y1="0.701" x2="-0.569" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-0.569" y1="-0.699" x2="-0.769" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-0.769" y1="-0.499" x2="-0.769" y2="0.501" width="0.001" layer="51"/>
<wire x1="-1.769" y1="-0.499" x2="-0.769" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-0.569" y1="-0.699" x2="-1.969" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-0.269" y1="0.726" x2="-0.269" y2="-0.724" width="0.001" layer="51"/>
<wire x1="0.271" y1="-0.724" x2="0.271" y2="0.726" width="0.001" layer="51"/>
<wire x1="0.571" y1="0.701" x2="0.771" y2="0.501" width="0.001" layer="51"/>
<wire x1="0.571" y1="0.701" x2="0.571" y2="-0.699" width="0.001" layer="51"/>
<wire x1="0.571" y1="-0.699" x2="0.771" y2="-0.499" width="0.001" layer="51"/>
<wire x1="0.771" y1="-0.499" x2="0.771" y2="0.501" width="0.001" layer="51"/>
<wire x1="0.771" y1="0.501" x2="1.771" y2="0.501" width="0.001" layer="51"/>
<wire x1="1.771" y1="0.501" x2="1.971" y2="0.701" width="0.001" layer="51"/>
<wire x1="1.971" y1="0.701" x2="0.571" y2="0.701" width="0.001" layer="51"/>
<wire x1="1.971" y1="0.701" x2="1.971" y2="-0.699" width="0.001" layer="51"/>
<wire x1="1.971" y1="-0.699" x2="1.771" y2="-0.499" width="0.001" layer="51"/>
<wire x1="1.771" y1="-0.499" x2="1.771" y2="0.501" width="0.001" layer="51"/>
<wire x1="0.771" y1="-0.499" x2="1.771" y2="-0.499" width="0.001" layer="51"/>
<wire x1="1.971" y1="-0.699" x2="0.571" y2="-0.699" width="0.001" layer="51"/>
<wire x1="2.271" y1="0.726" x2="2.271" y2="-0.724" width="0.001" layer="51"/>
<wire x1="2.811" y1="-0.724" x2="2.811" y2="0.726" width="0.001" layer="51"/>
<wire x1="3.111" y1="0.701" x2="3.311" y2="0.501" width="0.001" layer="51"/>
<wire x1="3.111" y1="0.701" x2="3.111" y2="-0.699" width="0.001" layer="51"/>
<wire x1="3.111" y1="-0.699" x2="3.311" y2="-0.499" width="0.001" layer="51"/>
<wire x1="3.311" y1="-0.499" x2="3.311" y2="0.501" width="0.001" layer="51"/>
<wire x1="3.311" y1="0.501" x2="4.311" y2="0.501" width="0.001" layer="51"/>
<wire x1="4.311" y1="0.501" x2="4.511" y2="0.701" width="0.001" layer="51"/>
<wire x1="4.511" y1="0.701" x2="3.111" y2="0.701" width="0.001" layer="51"/>
<wire x1="4.511" y1="0.701" x2="4.511" y2="-0.699" width="0.001" layer="51"/>
<wire x1="4.511" y1="-0.699" x2="4.311" y2="-0.499" width="0.001" layer="51"/>
<wire x1="4.311" y1="-0.499" x2="4.311" y2="0.501" width="0.001" layer="51"/>
<wire x1="3.311" y1="-0.499" x2="4.311" y2="-0.499" width="0.001" layer="51"/>
<wire x1="4.511" y1="-0.699" x2="3.111" y2="-0.699" width="0.001" layer="51"/>
<wire x1="4.811" y1="0.726" x2="4.811" y2="-0.724" width="0.001" layer="51"/>
<wire x1="5.351" y1="-0.724" x2="5.351" y2="0.726" width="0.001" layer="51"/>
<wire x1="5.651" y1="0.701" x2="5.851" y2="0.501" width="0.001" layer="51"/>
<wire x1="5.651" y1="0.701" x2="5.651" y2="-0.699" width="0.001" layer="51"/>
<wire x1="5.651" y1="-0.699" x2="5.851" y2="-0.499" width="0.001" layer="51"/>
<wire x1="5.851" y1="-0.499" x2="5.851" y2="0.501" width="0.001" layer="51"/>
<wire x1="5.851" y1="0.501" x2="6.851" y2="0.501" width="0.001" layer="51"/>
<wire x1="6.851" y1="0.501" x2="7.051" y2="0.701" width="0.001" layer="51"/>
<wire x1="7.051" y1="0.701" x2="5.651" y2="0.701" width="0.001" layer="51"/>
<wire x1="7.051" y1="0.701" x2="7.051" y2="-0.699" width="0.001" layer="51"/>
<wire x1="7.051" y1="-0.699" x2="6.851" y2="-0.499" width="0.001" layer="51"/>
<wire x1="6.851" y1="-0.499" x2="6.851" y2="0.501" width="0.001" layer="51"/>
<wire x1="5.851" y1="-0.499" x2="6.851" y2="-0.499" width="0.001" layer="51"/>
<wire x1="7.051" y1="-0.699" x2="5.651" y2="-0.699" width="0.001" layer="51"/>
<wire x1="7.351" y1="0.726" x2="7.351" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-4.109" y1="1.251" x2="-4.109" y2="1.826" width="0.001" layer="51"/>
<wire x1="-4.109" y1="1.826" x2="-3.909" y2="2.026" width="0.001" layer="51"/>
<wire x1="-3.909" y1="2.026" x2="-3.709" y2="2.026" width="0.001" layer="51"/>
<wire x1="-3.709" y1="2.026" x2="-3.509" y2="1.826" width="0.001" layer="51"/>
<wire x1="-3.509" y1="1.826" x2="-3.509" y2="1.251" width="0.001" layer="51"/>
<wire x1="0.971" y1="1.251" x2="0.971" y2="1.826" width="0.001" layer="51"/>
<wire x1="0.971" y1="1.826" x2="1.171" y2="2.026" width="0.001" layer="51"/>
<wire x1="1.171" y1="2.026" x2="1.371" y2="2.026" width="0.001" layer="51"/>
<wire x1="1.371" y1="2.026" x2="1.571" y2="1.826" width="0.001" layer="51"/>
<wire x1="1.571" y1="1.826" x2="1.571" y2="1.251" width="0.001" layer="51"/>
<wire x1="6.051" y1="1.251" x2="6.051" y2="1.826" width="0.001" layer="51"/>
<wire x1="6.051" y1="1.826" x2="6.251" y2="2.026" width="0.001" layer="51"/>
<wire x1="6.251" y1="2.026" x2="6.451" y2="2.026" width="0.001" layer="51"/>
<wire x1="6.451" y1="2.026" x2="6.651" y2="1.826" width="0.001" layer="51"/>
<wire x1="6.651" y1="1.826" x2="6.651" y2="1.251" width="0.001" layer="51"/>
<wire x1="-6.031190625" y1="-1.249" x2="-6.031190625" y2="-1.824" width="0.001" layer="51"/>
<wire x1="-6.031190625" y1="-1.824" x2="-6.231190625" y2="-2.024" width="0.001" layer="51"/>
<wire x1="-6.231190625" y1="-2.024" x2="-6.431190625" y2="-2.024" width="0.001" layer="51"/>
<wire x1="-6.431190625" y1="-2.024" x2="-6.631190625" y2="-1.824" width="0.001" layer="51"/>
<wire x1="-6.631190625" y1="-1.824" x2="-6.631190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-0.951190625" y1="-1.249" x2="-0.951190625" y2="-1.824" width="0.001" layer="51"/>
<wire x1="-0.951190625" y1="-1.824" x2="-1.151190625" y2="-2.024" width="0.001" layer="51"/>
<wire x1="-1.151190625" y1="-2.024" x2="-1.351190625" y2="-2.024" width="0.001" layer="51"/>
<wire x1="-1.351190625" y1="-2.024" x2="-1.551190625" y2="-1.824" width="0.001" layer="51"/>
<wire x1="-1.551190625" y1="-1.824" x2="-1.551190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="4.128809375" y1="-1.249" x2="4.128809375" y2="-1.824" width="0.001" layer="51"/>
<wire x1="4.128809375" y1="-1.824" x2="3.928809375" y2="-2.024" width="0.001" layer="51"/>
<wire x1="3.928809375" y1="-2.024" x2="3.728809375" y2="-2.024" width="0.001" layer="51"/>
<wire x1="3.728809375" y1="-2.024" x2="3.528809375" y2="-1.824" width="0.001" layer="51"/>
<wire x1="3.528809375" y1="-1.824" x2="3.528809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-7.8" y1="-1.6" x2="-7.8" y2="-2.4" width="0.127" layer="21"/>
<wire x1="-7.8" y1="-2.4" x2="-7.1" y2="-2" width="0.127" layer="21"/>
<wire x1="-7.1" y1="-2" x2="-7.8" y2="-1.6" width="0.127" layer="21"/>
<smd name="1" x="-6.35" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="2" x="-3.81" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="3" x="-1.27" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="4" x="1.27" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="5" x="3.81" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="6" x="6.35" y="0" dx="1" dy="5.2" layer="1"/>
<text x="-7.35" y="3.321" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-7.35" y="-4.591" size="1.27" layer="27">&gt;VALUE</text>
<text x="8.5" y="-0.2" size="0.7" layer="51">&gt;NAME</text>
</package>
<package name="1X08">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<wire x1="5.715" y1="1.27" x2="6.985" y2="1.27" width="0.1524" layer="21"/>
<wire x1="6.985" y1="1.27" x2="7.62" y2="0.635" width="0.1524" layer="21"/>
<wire x1="7.62" y1="0.635" x2="7.62" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="7.62" y1="-0.635" x2="6.985" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="2.54" y1="0.635" x2="3.175" y2="1.27" width="0.1524" layer="21"/>
<wire x1="3.175" y1="1.27" x2="4.445" y2="1.27" width="0.1524" layer="21"/>
<wire x1="4.445" y1="1.27" x2="5.08" y2="0.635" width="0.1524" layer="21"/>
<wire x1="5.08" y1="0.635" x2="5.08" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-0.635" x2="4.445" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="4.445" y1="-1.27" x2="3.175" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="3.175" y1="-1.27" x2="2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="5.715" y1="1.27" x2="5.08" y2="0.635" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-0.635" x2="5.715" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="6.985" y1="-1.27" x2="5.715" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="1.27" x2="-0.635" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="1.27" x2="0" y2="0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="0.635" x2="0" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="-0.635" x2="-0.635" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="0" y1="0.635" x2="0.635" y2="1.27" width="0.1524" layer="21"/>
<wire x1="0.635" y1="1.27" x2="1.905" y2="1.27" width="0.1524" layer="21"/>
<wire x1="1.905" y1="1.27" x2="2.54" y2="0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="0.635" x2="2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="-0.635" x2="1.905" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-1.27" x2="0.635" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="0.635" y1="-1.27" x2="0" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0.635" x2="-4.445" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-4.445" y1="1.27" x2="-3.175" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="1.27" x2="-2.54" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="0.635" x2="-2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="-0.635" x2="-3.175" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="-1.27" x2="-4.445" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-4.445" y1="-1.27" x2="-5.08" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="1.27" x2="-2.54" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="-0.635" x2="-1.905" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="-1.27" x2="-1.905" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-9.525" y1="1.27" x2="-8.255" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="1.27" x2="-7.62" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="0.635" x2="-7.62" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="-0.635" x2="-8.255" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="0.635" x2="-6.985" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-6.985" y1="1.27" x2="-5.715" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-5.715" y1="1.27" x2="-5.08" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0.635" x2="-5.08" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-0.635" x2="-5.715" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-5.715" y1="-1.27" x2="-6.985" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-6.985" y1="-1.27" x2="-7.62" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="0.635" x2="-10.16" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-9.525" y1="1.27" x2="-10.16" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="-0.635" x2="-9.525" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="-1.27" x2="-9.525" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="8.255" y1="1.27" x2="9.525" y2="1.27" width="0.1524" layer="21"/>
<wire x1="9.525" y1="1.27" x2="10.16" y2="0.635" width="0.1524" layer="21"/>
<wire x1="10.16" y1="0.635" x2="10.16" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="10.16" y1="-0.635" x2="9.525" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="8.255" y1="1.27" x2="7.62" y2="0.635" width="0.1524" layer="21"/>
<wire x1="7.62" y1="-0.635" x2="8.255" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="9.525" y1="-1.27" x2="8.255" y2="-1.27" width="0.1524" layer="21"/>
<rectangle x1="6.096" y1="-0.254" x2="6.604" y2="0.254" layer="51"/>
<rectangle x1="3.556" y1="-0.254" x2="4.064" y2="0.254" layer="51"/>
<rectangle x1="1.016" y1="-0.254" x2="1.524" y2="0.254" layer="51"/>
<rectangle x1="-1.524" y1="-0.254" x2="-1.016" y2="0.254" layer="51"/>
<rectangle x1="-4.064" y1="-0.254" x2="-3.556" y2="0.254" layer="51"/>
<rectangle x1="-6.604" y1="-0.254" x2="-6.096" y2="0.254" layer="51"/>
<rectangle x1="-9.144" y1="-0.254" x2="-8.636" y2="0.254" layer="51"/>
<rectangle x1="8.636" y1="-0.254" x2="9.144" y2="0.254" layer="51"/>
<pad name="1" x="-8.89" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="2" x="-6.35" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="3" x="-3.81" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="4" x="-1.27" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="5" x="1.27" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="6" x="3.81" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="7" x="6.35" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="8" x="8.89" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<text x="-10.2362" y="1.8288" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-10.16" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
</package>
<package name="1X08_SMD">
<wire x1="-10.414" y1="1.25" x2="-10.414" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-10.414" y1="-1.25" x2="-9.525" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-10.414" y1="1.25" x2="-9.525" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-8.128" y1="1.25" x2="-7.112" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-5.588" y1="1.25" x2="-4.572" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-3.048" y1="1.25" x2="-2.032" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-0.508" y1="1.25" x2="0.508" y2="1.25" width="0.1778" layer="21"/>
<wire x1="2.032" y1="1.25" x2="3.048" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-7.112" y1="-1.25" x2="-8.128" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-4.572" y1="-1.25" x2="-5.588" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-2.032" y1="-1.25" x2="-3.048" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="0.508" y1="-1.25" x2="-0.508" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="3.048" y1="-1.25" x2="2.032" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="10.414" y1="-1.25" x2="10.414" y2="1.25" width="0.1778" layer="21"/>
<wire x1="7.112" y1="1.25" x2="8.128" y2="1.25" width="0.1778" layer="21"/>
<wire x1="8.128" y1="-1.25" x2="7.112" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="10.414" y1="-1.25" x2="9.525" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="10.414" y1="1.25" x2="9.525" y2="1.25" width="0.1778" layer="21"/>
<wire x1="4.572" y1="1.25" x2="5.588" y2="1.25" width="0.1778" layer="21"/>
<wire x1="5.588" y1="-1.25" x2="4.572" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-9.189" y1="1.251" x2="-9.189" y2="1.826" width="0.001" layer="51"/>
<wire x1="-9.189" y1="1.826" x2="-8.989" y2="2.026" width="0.001" layer="51"/>
<wire x1="-8.989" y1="2.026" x2="-8.789" y2="2.026" width="0.001" layer="51"/>
<wire x1="-8.789" y1="2.026" x2="-8.589" y2="1.826" width="0.001" layer="51"/>
<wire x1="-8.589" y1="1.826" x2="-8.589" y2="1.251" width="0.001" layer="51"/>
<wire x1="-9.589" y1="0.701" x2="-9.389" y2="0.501" width="0.001" layer="51"/>
<wire x1="-9.589" y1="0.701" x2="-9.589" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-9.589" y1="-0.699" x2="-9.389" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-9.389" y1="-0.499" x2="-9.389" y2="0.501" width="0.001" layer="51"/>
<wire x1="-9.389" y1="0.501" x2="-8.389" y2="0.501" width="0.001" layer="51"/>
<wire x1="-8.389" y1="0.501" x2="-8.189" y2="0.701" width="0.001" layer="51"/>
<wire x1="-8.189" y1="0.701" x2="-9.589" y2="0.701" width="0.001" layer="51"/>
<wire x1="-8.189" y1="0.701" x2="-8.189" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-8.189" y1="-0.699" x2="-8.389" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-8.389" y1="-0.499" x2="-8.389" y2="0.501" width="0.001" layer="51"/>
<wire x1="-9.389" y1="-0.499" x2="-8.389" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-8.189" y1="-0.699" x2="-9.589" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-7.889" y1="0.726" x2="-7.889" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-7.349" y1="-0.724" x2="-7.349" y2="0.726" width="0.001" layer="51"/>
<wire x1="-7.049" y1="0.701" x2="-6.849" y2="0.501" width="0.001" layer="51"/>
<wire x1="-7.049" y1="0.701" x2="-7.049" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-7.049" y1="-0.699" x2="-6.849" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-6.849" y1="-0.499" x2="-6.849" y2="0.501" width="0.001" layer="51"/>
<wire x1="-6.849" y1="0.501" x2="-5.849" y2="0.501" width="0.001" layer="51"/>
<wire x1="-5.849" y1="0.501" x2="-5.649" y2="0.701" width="0.001" layer="51"/>
<wire x1="-5.649" y1="0.701" x2="-7.049" y2="0.701" width="0.001" layer="51"/>
<wire x1="-5.649" y1="0.701" x2="-5.649" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-5.649" y1="-0.699" x2="-5.849" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-5.849" y1="-0.499" x2="-5.849" y2="0.501" width="0.001" layer="51"/>
<wire x1="-6.849" y1="-0.499" x2="-5.849" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-5.649" y1="-0.699" x2="-7.049" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-9.889" y1="0.726" x2="-9.889" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-10.41" y1="1.251" x2="-10.41" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-10.41" y1="-1.249" x2="-6.631190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-6.631190625" y1="-1.249" x2="-6.031190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-6.031190625" y1="-1.249" x2="-1.551190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-1.551190625" y1="-1.249" x2="-0.951190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-0.951190625" y1="-1.249" x2="3.528809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="3.528809375" y1="-1.249" x2="4.128809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="4.128809375" y1="-1.249" x2="8.608809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="8.608809375" y1="-1.249" x2="9.208809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="9.208809375" y1="-1.249" x2="10.41" y2="-1.249" width="0.001" layer="51"/>
<wire x1="10.41" y1="-1.249" x2="10.41" y2="1.251" width="0.001" layer="51"/>
<wire x1="10.41" y1="1.251" x2="6.651" y2="1.251" width="0.001" layer="51"/>
<wire x1="6.651" y1="1.251" x2="6.051" y2="1.251" width="0.001" layer="51"/>
<wire x1="6.051" y1="1.251" x2="1.571" y2="1.251" width="0.001" layer="51"/>
<wire x1="1.571" y1="1.251" x2="0.971" y2="1.251" width="0.001" layer="51"/>
<wire x1="0.971" y1="1.251" x2="-3.509" y2="1.251" width="0.001" layer="51"/>
<wire x1="-3.509" y1="1.251" x2="-4.109" y2="1.251" width="0.001" layer="51"/>
<wire x1="-4.109" y1="1.251" x2="-10.41" y2="1.251" width="0.001" layer="51"/>
<wire x1="-10.409" y1="0.726" x2="-5.349" y2="0.726" width="0.001" layer="51"/>
<wire x1="-5.349" y1="0.726" x2="-4.809" y2="0.726" width="0.001" layer="51"/>
<wire x1="-4.809" y1="0.726" x2="-2.809" y2="0.726" width="0.001" layer="51"/>
<wire x1="-2.809" y1="0.726" x2="-2.269" y2="0.726" width="0.001" layer="51"/>
<wire x1="-2.269" y1="0.726" x2="-0.269" y2="0.726" width="0.001" layer="51"/>
<wire x1="-0.269" y1="0.726" x2="0.271" y2="0.726" width="0.001" layer="51"/>
<wire x1="0.271" y1="0.726" x2="2.271" y2="0.726" width="0.001" layer="51"/>
<wire x1="2.271" y1="0.726" x2="2.811" y2="0.726" width="0.001" layer="51"/>
<wire x1="2.811" y1="0.726" x2="4.811" y2="0.726" width="0.001" layer="51"/>
<wire x1="4.811" y1="0.726" x2="5.351" y2="0.726" width="0.001" layer="51"/>
<wire x1="5.351" y1="0.726" x2="7.351" y2="0.726" width="0.001" layer="51"/>
<wire x1="7.351" y1="0.726" x2="7.891" y2="0.726" width="0.001" layer="51"/>
<wire x1="7.891" y1="0.726" x2="9.891" y2="0.726" width="0.001" layer="51"/>
<wire x1="9.891" y1="0.726" x2="10.411" y2="0.726" width="0.001" layer="51"/>
<wire x1="10.411" y1="-0.724" x2="9.891" y2="-0.724" width="0.001" layer="51"/>
<wire x1="9.891" y1="-0.724" x2="7.891" y2="-0.724" width="0.001" layer="51"/>
<wire x1="7.891" y1="-0.724" x2="7.351" y2="-0.724" width="0.001" layer="51"/>
<wire x1="7.351" y1="-0.724" x2="5.351" y2="-0.724" width="0.001" layer="51"/>
<wire x1="5.351" y1="-0.724" x2="4.811" y2="-0.724" width="0.001" layer="51"/>
<wire x1="4.811" y1="-0.724" x2="2.811" y2="-0.724" width="0.001" layer="51"/>
<wire x1="2.811" y1="-0.724" x2="2.271" y2="-0.724" width="0.001" layer="51"/>
<wire x1="2.271" y1="-0.724" x2="0.271" y2="-0.724" width="0.001" layer="51"/>
<wire x1="0.271" y1="-0.724" x2="-0.269" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-0.269" y1="-0.724" x2="-2.269" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-2.269" y1="-0.724" x2="-2.809" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-2.809" y1="-0.724" x2="-4.809" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-4.809" y1="-0.724" x2="-5.349" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-5.349" y1="-0.724" x2="-10.409" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-5.349" y1="0.726" x2="-5.349" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-4.809" y1="-0.724" x2="-4.809" y2="0.726" width="0.001" layer="51"/>
<wire x1="-4.509" y1="0.701" x2="-4.309" y2="0.501" width="0.001" layer="51"/>
<wire x1="-4.509" y1="0.701" x2="-4.509" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-4.509" y1="-0.699" x2="-4.309" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-4.309" y1="-0.499" x2="-4.309" y2="0.501" width="0.001" layer="51"/>
<wire x1="-4.309" y1="0.501" x2="-3.309" y2="0.501" width="0.001" layer="51"/>
<wire x1="-3.309" y1="0.501" x2="-3.109" y2="0.701" width="0.001" layer="51"/>
<wire x1="-3.109" y1="0.701" x2="-4.509" y2="0.701" width="0.001" layer="51"/>
<wire x1="-3.109" y1="0.701" x2="-3.109" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-3.109" y1="-0.699" x2="-3.309" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-3.309" y1="-0.499" x2="-3.309" y2="0.501" width="0.001" layer="51"/>
<wire x1="-4.309" y1="-0.499" x2="-3.309" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-3.109" y1="-0.699" x2="-4.509" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-2.809" y1="0.726" x2="-2.809" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-2.269" y1="-0.724" x2="-2.269" y2="0.726" width="0.001" layer="51"/>
<wire x1="-1.969" y1="0.701" x2="-1.769" y2="0.501" width="0.001" layer="51"/>
<wire x1="-1.969" y1="0.701" x2="-1.969" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-1.969" y1="-0.699" x2="-1.769" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-1.769" y1="-0.499" x2="-1.769" y2="0.501" width="0.001" layer="51"/>
<wire x1="-1.769" y1="0.501" x2="-0.769" y2="0.501" width="0.001" layer="51"/>
<wire x1="-0.769" y1="0.501" x2="-0.569" y2="0.701" width="0.001" layer="51"/>
<wire x1="-0.569" y1="0.701" x2="-1.969" y2="0.701" width="0.001" layer="51"/>
<wire x1="-0.569" y1="0.701" x2="-0.569" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-0.569" y1="-0.699" x2="-0.769" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-0.769" y1="-0.499" x2="-0.769" y2="0.501" width="0.001" layer="51"/>
<wire x1="-1.769" y1="-0.499" x2="-0.769" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-0.569" y1="-0.699" x2="-1.969" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-0.269" y1="0.726" x2="-0.269" y2="-0.724" width="0.001" layer="51"/>
<wire x1="0.271" y1="-0.724" x2="0.271" y2="0.726" width="0.001" layer="51"/>
<wire x1="0.571" y1="0.701" x2="0.771" y2="0.501" width="0.001" layer="51"/>
<wire x1="0.571" y1="0.701" x2="0.571" y2="-0.699" width="0.001" layer="51"/>
<wire x1="0.571" y1="-0.699" x2="0.771" y2="-0.499" width="0.001" layer="51"/>
<wire x1="0.771" y1="-0.499" x2="0.771" y2="0.501" width="0.001" layer="51"/>
<wire x1="0.771" y1="0.501" x2="1.771" y2="0.501" width="0.001" layer="51"/>
<wire x1="1.771" y1="0.501" x2="1.971" y2="0.701" width="0.001" layer="51"/>
<wire x1="1.971" y1="0.701" x2="0.571" y2="0.701" width="0.001" layer="51"/>
<wire x1="1.971" y1="0.701" x2="1.971" y2="-0.699" width="0.001" layer="51"/>
<wire x1="1.971" y1="-0.699" x2="1.771" y2="-0.499" width="0.001" layer="51"/>
<wire x1="1.771" y1="-0.499" x2="1.771" y2="0.501" width="0.001" layer="51"/>
<wire x1="0.771" y1="-0.499" x2="1.771" y2="-0.499" width="0.001" layer="51"/>
<wire x1="1.971" y1="-0.699" x2="0.571" y2="-0.699" width="0.001" layer="51"/>
<wire x1="2.271" y1="0.726" x2="2.271" y2="-0.724" width="0.001" layer="51"/>
<wire x1="2.811" y1="-0.724" x2="2.811" y2="0.726" width="0.001" layer="51"/>
<wire x1="3.111" y1="0.701" x2="3.311" y2="0.501" width="0.001" layer="51"/>
<wire x1="3.111" y1="0.701" x2="3.111" y2="-0.699" width="0.001" layer="51"/>
<wire x1="3.111" y1="-0.699" x2="3.311" y2="-0.499" width="0.001" layer="51"/>
<wire x1="3.311" y1="-0.499" x2="3.311" y2="0.501" width="0.001" layer="51"/>
<wire x1="3.311" y1="0.501" x2="4.311" y2="0.501" width="0.001" layer="51"/>
<wire x1="4.311" y1="0.501" x2="4.511" y2="0.701" width="0.001" layer="51"/>
<wire x1="4.511" y1="0.701" x2="3.111" y2="0.701" width="0.001" layer="51"/>
<wire x1="4.511" y1="0.701" x2="4.511" y2="-0.699" width="0.001" layer="51"/>
<wire x1="4.511" y1="-0.699" x2="4.311" y2="-0.499" width="0.001" layer="51"/>
<wire x1="4.311" y1="-0.499" x2="4.311" y2="0.501" width="0.001" layer="51"/>
<wire x1="3.311" y1="-0.499" x2="4.311" y2="-0.499" width="0.001" layer="51"/>
<wire x1="4.511" y1="-0.699" x2="3.111" y2="-0.699" width="0.001" layer="51"/>
<wire x1="4.811" y1="0.726" x2="4.811" y2="-0.724" width="0.001" layer="51"/>
<wire x1="5.351" y1="-0.724" x2="5.351" y2="0.726" width="0.001" layer="51"/>
<wire x1="5.651" y1="0.701" x2="5.851" y2="0.501" width="0.001" layer="51"/>
<wire x1="5.651" y1="0.701" x2="5.651" y2="-0.699" width="0.001" layer="51"/>
<wire x1="5.651" y1="-0.699" x2="5.851" y2="-0.499" width="0.001" layer="51"/>
<wire x1="5.851" y1="-0.499" x2="5.851" y2="0.501" width="0.001" layer="51"/>
<wire x1="5.851" y1="0.501" x2="6.851" y2="0.501" width="0.001" layer="51"/>
<wire x1="6.851" y1="0.501" x2="7.051" y2="0.701" width="0.001" layer="51"/>
<wire x1="7.051" y1="0.701" x2="5.651" y2="0.701" width="0.001" layer="51"/>
<wire x1="7.051" y1="0.701" x2="7.051" y2="-0.699" width="0.001" layer="51"/>
<wire x1="7.051" y1="-0.699" x2="6.851" y2="-0.499" width="0.001" layer="51"/>
<wire x1="6.851" y1="-0.499" x2="6.851" y2="0.501" width="0.001" layer="51"/>
<wire x1="5.851" y1="-0.499" x2="6.851" y2="-0.499" width="0.001" layer="51"/>
<wire x1="7.051" y1="-0.699" x2="5.651" y2="-0.699" width="0.001" layer="51"/>
<wire x1="7.351" y1="0.726" x2="7.351" y2="-0.724" width="0.001" layer="51"/>
<wire x1="7.891" y1="-0.724" x2="7.891" y2="0.726" width="0.001" layer="51"/>
<wire x1="8.191" y1="0.701" x2="8.391" y2="0.501" width="0.001" layer="51"/>
<wire x1="8.191" y1="0.701" x2="8.191" y2="-0.699" width="0.001" layer="51"/>
<wire x1="8.191" y1="-0.699" x2="8.391" y2="-0.499" width="0.001" layer="51"/>
<wire x1="8.391" y1="-0.499" x2="8.391" y2="0.501" width="0.001" layer="51"/>
<wire x1="8.391" y1="0.501" x2="9.391" y2="0.501" width="0.001" layer="51"/>
<wire x1="9.391" y1="0.501" x2="9.591" y2="0.701" width="0.001" layer="51"/>
<wire x1="9.591" y1="0.701" x2="8.191" y2="0.701" width="0.001" layer="51"/>
<wire x1="9.591" y1="0.701" x2="9.591" y2="-0.699" width="0.001" layer="51"/>
<wire x1="9.591" y1="-0.699" x2="9.391" y2="-0.499" width="0.001" layer="51"/>
<wire x1="9.391" y1="-0.499" x2="9.391" y2="0.501" width="0.001" layer="51"/>
<wire x1="8.391" y1="-0.499" x2="9.391" y2="-0.499" width="0.001" layer="51"/>
<wire x1="9.591" y1="-0.699" x2="8.191" y2="-0.699" width="0.001" layer="51"/>
<wire x1="9.891" y1="0.726" x2="9.891" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-4.109" y1="1.251" x2="-4.109" y2="1.826" width="0.001" layer="51"/>
<wire x1="-4.109" y1="1.826" x2="-3.909" y2="2.026" width="0.001" layer="51"/>
<wire x1="-3.909" y1="2.026" x2="-3.709" y2="2.026" width="0.001" layer="51"/>
<wire x1="-3.709" y1="2.026" x2="-3.509" y2="1.826" width="0.001" layer="51"/>
<wire x1="-3.509" y1="1.826" x2="-3.509" y2="1.251" width="0.001" layer="51"/>
<wire x1="0.971" y1="1.251" x2="0.971" y2="1.826" width="0.001" layer="51"/>
<wire x1="0.971" y1="1.826" x2="1.171" y2="2.026" width="0.001" layer="51"/>
<wire x1="1.171" y1="2.026" x2="1.371" y2="2.026" width="0.001" layer="51"/>
<wire x1="1.371" y1="2.026" x2="1.571" y2="1.826" width="0.001" layer="51"/>
<wire x1="1.571" y1="1.826" x2="1.571" y2="1.251" width="0.001" layer="51"/>
<wire x1="6.051" y1="1.251" x2="6.051" y2="1.826" width="0.001" layer="51"/>
<wire x1="6.051" y1="1.826" x2="6.251" y2="2.026" width="0.001" layer="51"/>
<wire x1="6.251" y1="2.026" x2="6.451" y2="2.026" width="0.001" layer="51"/>
<wire x1="6.451" y1="2.026" x2="6.651" y2="1.826" width="0.001" layer="51"/>
<wire x1="6.651" y1="1.826" x2="6.651" y2="1.251" width="0.001" layer="51"/>
<wire x1="-6.031190625" y1="-1.249" x2="-6.031190625" y2="-1.824" width="0.001" layer="51"/>
<wire x1="-6.031190625" y1="-1.824" x2="-6.231190625" y2="-2.024" width="0.001" layer="51"/>
<wire x1="-6.231190625" y1="-2.024" x2="-6.431190625" y2="-2.024" width="0.001" layer="51"/>
<wire x1="-6.431190625" y1="-2.024" x2="-6.631190625" y2="-1.824" width="0.001" layer="51"/>
<wire x1="-6.631190625" y1="-1.824" x2="-6.631190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-0.951190625" y1="-1.249" x2="-0.951190625" y2="-1.824" width="0.001" layer="51"/>
<wire x1="-0.951190625" y1="-1.824" x2="-1.151190625" y2="-2.024" width="0.001" layer="51"/>
<wire x1="-1.151190625" y1="-2.024" x2="-1.351190625" y2="-2.024" width="0.001" layer="51"/>
<wire x1="-1.351190625" y1="-2.024" x2="-1.551190625" y2="-1.824" width="0.001" layer="51"/>
<wire x1="-1.551190625" y1="-1.824" x2="-1.551190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="4.128809375" y1="-1.249" x2="4.128809375" y2="-1.824" width="0.001" layer="51"/>
<wire x1="4.128809375" y1="-1.824" x2="3.928809375" y2="-2.024" width="0.001" layer="51"/>
<wire x1="3.928809375" y1="-2.024" x2="3.728809375" y2="-2.024" width="0.001" layer="51"/>
<wire x1="3.728809375" y1="-2.024" x2="3.528809375" y2="-1.824" width="0.001" layer="51"/>
<wire x1="3.528809375" y1="-1.824" x2="3.528809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="9.208809375" y1="-1.249" x2="9.208809375" y2="-1.824" width="0.001" layer="51"/>
<wire x1="9.208809375" y1="-1.824" x2="9.008809375" y2="-2.024" width="0.001" layer="51"/>
<wire x1="9.008809375" y1="-2.024" x2="8.808809375" y2="-2.024" width="0.001" layer="51"/>
<wire x1="8.808809375" y1="-2.024" x2="8.608809375" y2="-1.824" width="0.001" layer="51"/>
<wire x1="8.608809375" y1="-1.824" x2="8.608809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-10.3" y1="-1.6" x2="-10.3" y2="-2.4" width="0.127" layer="21"/>
<wire x1="-10.3" y1="-2.4" x2="-9.6" y2="-2" width="0.127" layer="21"/>
<wire x1="-9.6" y1="-2" x2="-10.3" y2="-1.6" width="0.127" layer="21"/>
<smd name="1" x="-8.89" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="2" x="-6.35" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="3" x="-3.81" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="4" x="-1.27" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="5" x="1.27" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="6" x="3.81" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="7" x="6.35" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="8" x="8.89" y="0" dx="1" dy="5.2" layer="1"/>
<text x="-9.89" y="3.321" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-9.89" y="-4.591" size="1.27" layer="27">&gt;VALUE</text>
<text x="10.7" y="-0.5" size="0.7" layer="51">&gt;NAME</text>
</package>
<package name="1X10">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<wire x1="7.62" y1="0.635" x2="8.255" y2="1.27" width="0.1524" layer="21"/>
<wire x1="8.255" y1="1.27" x2="9.525" y2="1.27" width="0.1524" layer="21"/>
<wire x1="9.525" y1="1.27" x2="10.16" y2="0.635" width="0.1524" layer="21"/>
<wire x1="10.16" y1="0.635" x2="10.16" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="10.16" y1="-0.635" x2="9.525" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="9.525" y1="-1.27" x2="8.255" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="8.255" y1="-1.27" x2="7.62" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="3.175" y1="1.27" x2="4.445" y2="1.27" width="0.1524" layer="21"/>
<wire x1="4.445" y1="1.27" x2="5.08" y2="0.635" width="0.1524" layer="21"/>
<wire x1="5.08" y1="0.635" x2="5.08" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="5.08" y1="-0.635" x2="4.445" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="5.08" y1="0.635" x2="5.715" y2="1.27" width="0.1524" layer="21"/>
<wire x1="5.715" y1="1.27" x2="6.985" y2="1.27" width="0.1524" layer="21"/>
<wire x1="6.985" y1="1.27" x2="7.62" y2="0.635" width="0.1524" layer="21"/>
<wire x1="7.62" y1="0.635" x2="7.62" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="7.62" y1="-0.635" x2="6.985" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="6.985" y1="-1.27" x2="5.715" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="5.715" y1="-1.27" x2="5.08" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="0.635" x2="0.635" y2="1.27" width="0.1524" layer="21"/>
<wire x1="0.635" y1="1.27" x2="1.905" y2="1.27" width="0.1524" layer="21"/>
<wire x1="1.905" y1="1.27" x2="2.54" y2="0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="0.635" x2="2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="-0.635" x2="1.905" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="1.905" y1="-1.27" x2="0.635" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="0.635" y1="-1.27" x2="0" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="3.175" y1="1.27" x2="2.54" y2="0.635" width="0.1524" layer="21"/>
<wire x1="2.54" y1="-0.635" x2="3.175" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="4.445" y1="-1.27" x2="3.175" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-4.445" y1="1.27" x2="-3.175" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="1.27" x2="-2.54" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="0.635" x2="-2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="-0.635" x2="-3.175" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-2.54" y1="0.635" x2="-1.905" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="1.27" x2="-0.635" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="1.27" x2="0" y2="0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="0.635" x2="0" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="0" y1="-0.635" x2="-0.635" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-0.635" y1="-1.27" x2="-1.905" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-1.905" y1="-1.27" x2="-2.54" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="0.635" x2="-6.985" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-6.985" y1="1.27" x2="-5.715" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-5.715" y1="1.27" x2="-5.08" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="0.635" x2="-5.08" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-0.635" x2="-5.715" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-5.715" y1="-1.27" x2="-6.985" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-6.985" y1="-1.27" x2="-7.62" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-4.445" y1="1.27" x2="-5.08" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-5.08" y1="-0.635" x2="-4.445" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="-1.27" x2="-4.445" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-12.065" y1="1.27" x2="-10.795" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-10.795" y1="1.27" x2="-10.16" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="0.635" x2="-10.16" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="-0.635" x2="-10.795" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-10.16" y1="0.635" x2="-9.525" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-9.525" y1="1.27" x2="-8.255" y2="1.27" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="1.27" x2="-7.62" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="0.635" x2="-7.62" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-7.62" y1="-0.635" x2="-8.255" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-8.255" y1="-1.27" x2="-9.525" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-9.525" y1="-1.27" x2="-10.16" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-12.7" y1="0.635" x2="-12.7" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="-12.065" y1="1.27" x2="-12.7" y2="0.635" width="0.1524" layer="21"/>
<wire x1="-12.7" y1="-0.635" x2="-12.065" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="-10.795" y1="-1.27" x2="-12.065" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="10.795" y1="1.27" x2="12.065" y2="1.27" width="0.1524" layer="21"/>
<wire x1="12.065" y1="1.27" x2="12.7" y2="0.635" width="0.1524" layer="21"/>
<wire x1="12.7" y1="0.635" x2="12.7" y2="-0.635" width="0.1524" layer="21"/>
<wire x1="12.7" y1="-0.635" x2="12.065" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="10.795" y1="1.27" x2="10.16" y2="0.635" width="0.1524" layer="21"/>
<wire x1="10.16" y1="-0.635" x2="10.795" y2="-1.27" width="0.1524" layer="21"/>
<wire x1="12.065" y1="-1.27" x2="10.795" y2="-1.27" width="0.1524" layer="21"/>
<rectangle x1="8.636" y1="-0.254" x2="9.144" y2="0.254" layer="51"/>
<rectangle x1="6.096" y1="-0.254" x2="6.604" y2="0.254" layer="51"/>
<rectangle x1="3.556" y1="-0.254" x2="4.064" y2="0.254" layer="51"/>
<rectangle x1="1.016" y1="-0.254" x2="1.524" y2="0.254" layer="51"/>
<rectangle x1="-1.524" y1="-0.254" x2="-1.016" y2="0.254" layer="51"/>
<rectangle x1="-4.064" y1="-0.254" x2="-3.556" y2="0.254" layer="51"/>
<rectangle x1="-6.604" y1="-0.254" x2="-6.096" y2="0.254" layer="51"/>
<rectangle x1="-9.144" y1="-0.254" x2="-8.636" y2="0.254" layer="51"/>
<rectangle x1="-11.684" y1="-0.254" x2="-11.176" y2="0.254" layer="51"/>
<rectangle x1="11.176" y1="-0.254" x2="11.684" y2="0.254" layer="51"/>
<pad name="1" x="-11.43" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="2" x="-8.89" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="3" x="-6.35" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="4" x="-3.81" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="5" x="-1.27" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="6" x="1.27" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="7" x="3.81" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="8" x="6.35" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="9" x="8.89" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<pad name="10" x="11.43" y="0" drill="0.85" diameter="1.4224" shape="long" rot="R90"/>
<text x="-12.7762" y="1.8288" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-12.7" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
</package>
<package name="1X10_SMD">
<wire x1="-12.95" y1="1.25" x2="-12.95" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-12.95" y1="-1.25" x2="-12.065" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-12.95" y1="1.25" x2="-12.065" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-10.668" y1="1.25" x2="-9.652" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-8.128" y1="1.25" x2="-7.112" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-5.588" y1="1.25" x2="-4.572" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-3.048" y1="1.25" x2="-2.032" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-0.508" y1="1.25" x2="0.508" y2="1.25" width="0.1778" layer="21"/>
<wire x1="-9.652" y1="-1.25" x2="-10.668" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-7.112" y1="-1.25" x2="-8.128" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-4.572" y1="-1.25" x2="-5.588" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-2.032" y1="-1.25" x2="-3.048" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="0.508" y1="-1.25" x2="-0.508" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="12.95" y1="-1.25" x2="12.95" y2="1.25" width="0.1778" layer="21"/>
<wire x1="4.572" y1="1.25" x2="5.588" y2="1.25" width="0.1778" layer="21"/>
<wire x1="5.588" y1="-1.25" x2="4.572" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="12.95" y1="-1.25" x2="12.065" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="12.95" y1="1.25" x2="12.065" y2="1.25" width="0.1778" layer="21"/>
<wire x1="2.032" y1="1.25" x2="3.048" y2="1.25" width="0.1778" layer="21"/>
<wire x1="3.048" y1="-1.25" x2="2.032" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="7.112" y1="1.25" x2="8.128" y2="1.25" width="0.1778" layer="21"/>
<wire x1="9.652" y1="1.25" x2="10.668" y2="1.25" width="0.1778" layer="21"/>
<wire x1="8.128" y1="-1.25" x2="7.112" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="10.668" y1="-1.25" x2="9.652" y2="-1.25" width="0.1778" layer="21"/>
<wire x1="-9.189" y1="1.251" x2="-9.189" y2="1.826" width="0.001" layer="51"/>
<wire x1="-9.189" y1="1.826" x2="-8.989" y2="2.026" width="0.001" layer="51"/>
<wire x1="-8.989" y1="2.026" x2="-8.789" y2="2.026" width="0.001" layer="51"/>
<wire x1="-8.789" y1="2.026" x2="-8.589" y2="1.826" width="0.001" layer="51"/>
<wire x1="-8.589" y1="1.826" x2="-8.589" y2="1.251" width="0.001" layer="51"/>
<wire x1="-9.589" y1="0.701" x2="-9.389" y2="0.501" width="0.001" layer="51"/>
<wire x1="-9.589" y1="0.701" x2="-9.589" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-9.589" y1="-0.699" x2="-9.389" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-9.389" y1="-0.499" x2="-9.389" y2="0.501" width="0.001" layer="51"/>
<wire x1="-9.389" y1="0.501" x2="-8.389" y2="0.501" width="0.001" layer="51"/>
<wire x1="-8.389" y1="0.501" x2="-8.189" y2="0.701" width="0.001" layer="51"/>
<wire x1="-8.189" y1="0.701" x2="-9.589" y2="0.701" width="0.001" layer="51"/>
<wire x1="-8.189" y1="0.701" x2="-8.189" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-8.189" y1="-0.699" x2="-8.389" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-8.389" y1="-0.499" x2="-8.389" y2="0.501" width="0.001" layer="51"/>
<wire x1="-9.389" y1="-0.499" x2="-8.389" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-8.189" y1="-0.699" x2="-9.589" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-7.889" y1="0.726" x2="-7.889" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-7.349" y1="-0.724" x2="-7.349" y2="0.726" width="0.001" layer="51"/>
<wire x1="-7.049" y1="0.701" x2="-6.849" y2="0.501" width="0.001" layer="51"/>
<wire x1="-7.049" y1="0.701" x2="-7.049" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-7.049" y1="-0.699" x2="-6.849" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-6.849" y1="-0.499" x2="-6.849" y2="0.501" width="0.001" layer="51"/>
<wire x1="-6.849" y1="0.501" x2="-5.849" y2="0.501" width="0.001" layer="51"/>
<wire x1="-5.849" y1="0.501" x2="-5.649" y2="0.701" width="0.001" layer="51"/>
<wire x1="-5.649" y1="0.701" x2="-7.049" y2="0.701" width="0.001" layer="51"/>
<wire x1="-5.649" y1="0.701" x2="-5.649" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-5.649" y1="-0.699" x2="-5.849" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-5.849" y1="-0.499" x2="-5.849" y2="0.501" width="0.001" layer="51"/>
<wire x1="-6.849" y1="-0.499" x2="-5.849" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-5.649" y1="-0.699" x2="-7.049" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-9.889" y1="0.726" x2="-9.889" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-12.95" y1="1.251" x2="-12.95" y2="0.726" width="0.001" layer="51"/>
<wire x1="-12.95" y1="0.726" x2="-12.95" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-12.95" y1="-0.724" x2="-12.95" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-12.95" y1="-1.249" x2="-11.711190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-11.711190625" y1="-1.249" x2="-11.111190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-11.111190625" y1="-1.249" x2="-6.631190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-6.631190625" y1="-1.249" x2="-6.031190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-6.031190625" y1="-1.249" x2="-1.551190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-1.551190625" y1="-1.249" x2="-0.951190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-0.951190625" y1="-1.249" x2="3.528809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="3.528809375" y1="-1.249" x2="4.128809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="4.128809375" y1="-1.249" x2="8.608809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="8.608809375" y1="-1.249" x2="9.208809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="9.208809375" y1="-1.249" x2="12.95" y2="-1.249" width="0.001" layer="51"/>
<wire x1="12.95" y1="-1.249" x2="12.95" y2="-0.724" width="0.001" layer="51"/>
<wire x1="12.95" y1="-0.724" x2="12.95" y2="0.726" width="0.001" layer="51"/>
<wire x1="12.95" y1="0.726" x2="12.95" y2="1.251" width="0.001" layer="51"/>
<wire x1="12.95" y1="1.251" x2="11.731" y2="1.251" width="0.001" layer="51"/>
<wire x1="11.731" y1="1.251" x2="11.131" y2="1.251" width="0.001" layer="51"/>
<wire x1="11.131" y1="1.251" x2="6.651" y2="1.251" width="0.001" layer="51"/>
<wire x1="6.651" y1="1.251" x2="6.051" y2="1.251" width="0.001" layer="51"/>
<wire x1="6.051" y1="1.251" x2="1.571" y2="1.251" width="0.001" layer="51"/>
<wire x1="1.571" y1="1.251" x2="0.971" y2="1.251" width="0.001" layer="51"/>
<wire x1="0.971" y1="1.251" x2="-3.509" y2="1.251" width="0.001" layer="51"/>
<wire x1="-3.509" y1="1.251" x2="-4.109" y2="1.251" width="0.001" layer="51"/>
<wire x1="-4.109" y1="1.251" x2="-12.95" y2="1.251" width="0.001" layer="51"/>
<wire x1="-12.95" y1="0.726" x2="-12.429" y2="0.726" width="0.001" layer="51"/>
<wire x1="-12.429" y1="0.726" x2="-10.429" y2="0.726" width="0.001" layer="51"/>
<wire x1="-10.429" y1="0.726" x2="-5.349" y2="0.726" width="0.001" layer="51"/>
<wire x1="-5.349" y1="0.726" x2="-4.809" y2="0.726" width="0.001" layer="51"/>
<wire x1="-4.809" y1="0.726" x2="-2.809" y2="0.726" width="0.001" layer="51"/>
<wire x1="-2.809" y1="0.726" x2="-2.269" y2="0.726" width="0.001" layer="51"/>
<wire x1="-2.269" y1="0.726" x2="-0.269" y2="0.726" width="0.001" layer="51"/>
<wire x1="-0.269" y1="0.726" x2="0.271" y2="0.726" width="0.001" layer="51"/>
<wire x1="0.271" y1="0.726" x2="2.271" y2="0.726" width="0.001" layer="51"/>
<wire x1="2.271" y1="0.726" x2="2.811" y2="0.726" width="0.001" layer="51"/>
<wire x1="2.811" y1="0.726" x2="4.811" y2="0.726" width="0.001" layer="51"/>
<wire x1="4.811" y1="0.726" x2="5.351" y2="0.726" width="0.001" layer="51"/>
<wire x1="5.351" y1="0.726" x2="7.351" y2="0.726" width="0.001" layer="51"/>
<wire x1="7.351" y1="0.726" x2="7.891" y2="0.726" width="0.001" layer="51"/>
<wire x1="7.891" y1="0.726" x2="9.891" y2="0.726" width="0.001" layer="51"/>
<wire x1="9.891" y1="0.726" x2="10.431" y2="0.726" width="0.001" layer="51"/>
<wire x1="10.431" y1="0.726" x2="12.431" y2="0.726" width="0.001" layer="51"/>
<wire x1="12.431" y1="0.726" x2="12.95" y2="0.726" width="0.001" layer="51"/>
<wire x1="12.95" y1="-0.724" x2="12.431" y2="-0.724" width="0.001" layer="51"/>
<wire x1="12.431" y1="-0.724" x2="10.431" y2="-0.724" width="0.001" layer="51"/>
<wire x1="10.431" y1="-0.724" x2="9.891" y2="-0.724" width="0.001" layer="51"/>
<wire x1="9.891" y1="-0.724" x2="7.891" y2="-0.724" width="0.001" layer="51"/>
<wire x1="7.891" y1="-0.724" x2="7.351" y2="-0.724" width="0.001" layer="51"/>
<wire x1="7.351" y1="-0.724" x2="5.351" y2="-0.724" width="0.001" layer="51"/>
<wire x1="5.351" y1="-0.724" x2="4.811" y2="-0.724" width="0.001" layer="51"/>
<wire x1="4.811" y1="-0.724" x2="2.811" y2="-0.724" width="0.001" layer="51"/>
<wire x1="2.811" y1="-0.724" x2="2.271" y2="-0.724" width="0.001" layer="51"/>
<wire x1="2.271" y1="-0.724" x2="0.271" y2="-0.724" width="0.001" layer="51"/>
<wire x1="0.271" y1="-0.724" x2="-0.269" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-0.269" y1="-0.724" x2="-2.269" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-2.269" y1="-0.724" x2="-2.809" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-2.809" y1="-0.724" x2="-4.809" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-4.809" y1="-0.724" x2="-5.349" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-5.349" y1="-0.724" x2="-10.429" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-10.429" y1="-0.724" x2="-12.429" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-12.429" y1="-0.724" x2="-12.95" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-5.349" y1="0.726" x2="-5.349" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-4.809" y1="-0.724" x2="-4.809" y2="0.726" width="0.001" layer="51"/>
<wire x1="-4.509" y1="0.701" x2="-4.309" y2="0.501" width="0.001" layer="51"/>
<wire x1="-4.509" y1="0.701" x2="-4.509" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-4.509" y1="-0.699" x2="-4.309" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-4.309" y1="-0.499" x2="-4.309" y2="0.501" width="0.001" layer="51"/>
<wire x1="-4.309" y1="0.501" x2="-3.309" y2="0.501" width="0.001" layer="51"/>
<wire x1="-3.309" y1="0.501" x2="-3.109" y2="0.701" width="0.001" layer="51"/>
<wire x1="-3.109" y1="0.701" x2="-4.509" y2="0.701" width="0.001" layer="51"/>
<wire x1="-3.109" y1="0.701" x2="-3.109" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-3.109" y1="-0.699" x2="-3.309" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-3.309" y1="-0.499" x2="-3.309" y2="0.501" width="0.001" layer="51"/>
<wire x1="-4.309" y1="-0.499" x2="-3.309" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-3.109" y1="-0.699" x2="-4.509" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-2.809" y1="0.726" x2="-2.809" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-2.269" y1="-0.724" x2="-2.269" y2="0.726" width="0.001" layer="51"/>
<wire x1="-1.969" y1="0.701" x2="-1.769" y2="0.501" width="0.001" layer="51"/>
<wire x1="-1.969" y1="0.701" x2="-1.969" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-1.969" y1="-0.699" x2="-1.769" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-1.769" y1="-0.499" x2="-1.769" y2="0.501" width="0.001" layer="51"/>
<wire x1="-1.769" y1="0.501" x2="-0.769" y2="0.501" width="0.001" layer="51"/>
<wire x1="-0.769" y1="0.501" x2="-0.569" y2="0.701" width="0.001" layer="51"/>
<wire x1="-0.569" y1="0.701" x2="-1.969" y2="0.701" width="0.001" layer="51"/>
<wire x1="-0.569" y1="0.701" x2="-0.569" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-0.569" y1="-0.699" x2="-0.769" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-0.769" y1="-0.499" x2="-0.769" y2="0.501" width="0.001" layer="51"/>
<wire x1="-1.769" y1="-0.499" x2="-0.769" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-0.569" y1="-0.699" x2="-1.969" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-0.269" y1="0.726" x2="-0.269" y2="-0.724" width="0.001" layer="51"/>
<wire x1="0.271" y1="-0.724" x2="0.271" y2="0.726" width="0.001" layer="51"/>
<wire x1="0.571" y1="0.701" x2="0.771" y2="0.501" width="0.001" layer="51"/>
<wire x1="0.571" y1="0.701" x2="0.571" y2="-0.699" width="0.001" layer="51"/>
<wire x1="0.571" y1="-0.699" x2="0.771" y2="-0.499" width="0.001" layer="51"/>
<wire x1="0.771" y1="-0.499" x2="0.771" y2="0.501" width="0.001" layer="51"/>
<wire x1="0.771" y1="0.501" x2="1.771" y2="0.501" width="0.001" layer="51"/>
<wire x1="1.771" y1="0.501" x2="1.971" y2="0.701" width="0.001" layer="51"/>
<wire x1="1.971" y1="0.701" x2="0.571" y2="0.701" width="0.001" layer="51"/>
<wire x1="1.971" y1="0.701" x2="1.971" y2="-0.699" width="0.001" layer="51"/>
<wire x1="1.971" y1="-0.699" x2="1.771" y2="-0.499" width="0.001" layer="51"/>
<wire x1="1.771" y1="-0.499" x2="1.771" y2="0.501" width="0.001" layer="51"/>
<wire x1="0.771" y1="-0.499" x2="1.771" y2="-0.499" width="0.001" layer="51"/>
<wire x1="1.971" y1="-0.699" x2="0.571" y2="-0.699" width="0.001" layer="51"/>
<wire x1="2.271" y1="0.726" x2="2.271" y2="-0.724" width="0.001" layer="51"/>
<wire x1="2.811" y1="-0.724" x2="2.811" y2="0.726" width="0.001" layer="51"/>
<wire x1="3.111" y1="0.701" x2="3.311" y2="0.501" width="0.001" layer="51"/>
<wire x1="3.111" y1="0.701" x2="3.111" y2="-0.699" width="0.001" layer="51"/>
<wire x1="3.111" y1="-0.699" x2="3.311" y2="-0.499" width="0.001" layer="51"/>
<wire x1="3.311" y1="-0.499" x2="3.311" y2="0.501" width="0.001" layer="51"/>
<wire x1="3.311" y1="0.501" x2="4.311" y2="0.501" width="0.001" layer="51"/>
<wire x1="4.311" y1="0.501" x2="4.511" y2="0.701" width="0.001" layer="51"/>
<wire x1="4.511" y1="0.701" x2="3.111" y2="0.701" width="0.001" layer="51"/>
<wire x1="4.511" y1="0.701" x2="4.511" y2="-0.699" width="0.001" layer="51"/>
<wire x1="4.511" y1="-0.699" x2="4.311" y2="-0.499" width="0.001" layer="51"/>
<wire x1="4.311" y1="-0.499" x2="4.311" y2="0.501" width="0.001" layer="51"/>
<wire x1="3.311" y1="-0.499" x2="4.311" y2="-0.499" width="0.001" layer="51"/>
<wire x1="4.511" y1="-0.699" x2="3.111" y2="-0.699" width="0.001" layer="51"/>
<wire x1="4.811" y1="0.726" x2="4.811" y2="-0.724" width="0.001" layer="51"/>
<wire x1="5.351" y1="-0.724" x2="5.351" y2="0.726" width="0.001" layer="51"/>
<wire x1="5.651" y1="0.701" x2="5.851" y2="0.501" width="0.001" layer="51"/>
<wire x1="5.651" y1="0.701" x2="5.651" y2="-0.699" width="0.001" layer="51"/>
<wire x1="5.651" y1="-0.699" x2="5.851" y2="-0.499" width="0.001" layer="51"/>
<wire x1="5.851" y1="-0.499" x2="5.851" y2="0.501" width="0.001" layer="51"/>
<wire x1="5.851" y1="0.501" x2="6.851" y2="0.501" width="0.001" layer="51"/>
<wire x1="6.851" y1="0.501" x2="7.051" y2="0.701" width="0.001" layer="51"/>
<wire x1="7.051" y1="0.701" x2="5.651" y2="0.701" width="0.001" layer="51"/>
<wire x1="7.051" y1="0.701" x2="7.051" y2="-0.699" width="0.001" layer="51"/>
<wire x1="7.051" y1="-0.699" x2="6.851" y2="-0.499" width="0.001" layer="51"/>
<wire x1="6.851" y1="-0.499" x2="6.851" y2="0.501" width="0.001" layer="51"/>
<wire x1="5.851" y1="-0.499" x2="6.851" y2="-0.499" width="0.001" layer="51"/>
<wire x1="7.051" y1="-0.699" x2="5.651" y2="-0.699" width="0.001" layer="51"/>
<wire x1="7.351" y1="0.726" x2="7.351" y2="-0.724" width="0.001" layer="51"/>
<wire x1="7.891" y1="-0.724" x2="7.891" y2="0.726" width="0.001" layer="51"/>
<wire x1="8.191" y1="0.701" x2="8.391" y2="0.501" width="0.001" layer="51"/>
<wire x1="8.191" y1="0.701" x2="8.191" y2="-0.699" width="0.001" layer="51"/>
<wire x1="8.191" y1="-0.699" x2="8.391" y2="-0.499" width="0.001" layer="51"/>
<wire x1="8.391" y1="-0.499" x2="8.391" y2="0.501" width="0.001" layer="51"/>
<wire x1="8.391" y1="0.501" x2="9.391" y2="0.501" width="0.001" layer="51"/>
<wire x1="9.391" y1="0.501" x2="9.591" y2="0.701" width="0.001" layer="51"/>
<wire x1="9.591" y1="0.701" x2="8.191" y2="0.701" width="0.001" layer="51"/>
<wire x1="9.591" y1="0.701" x2="9.591" y2="-0.699" width="0.001" layer="51"/>
<wire x1="9.591" y1="-0.699" x2="9.391" y2="-0.499" width="0.001" layer="51"/>
<wire x1="9.391" y1="-0.499" x2="9.391" y2="0.501" width="0.001" layer="51"/>
<wire x1="8.391" y1="-0.499" x2="9.391" y2="-0.499" width="0.001" layer="51"/>
<wire x1="9.591" y1="-0.699" x2="8.191" y2="-0.699" width="0.001" layer="51"/>
<wire x1="9.891" y1="0.726" x2="9.891" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-4.109" y1="1.251" x2="-4.109" y2="1.826" width="0.001" layer="51"/>
<wire x1="-4.109" y1="1.826" x2="-3.909" y2="2.026" width="0.001" layer="51"/>
<wire x1="-3.909" y1="2.026" x2="-3.709" y2="2.026" width="0.001" layer="51"/>
<wire x1="-3.709" y1="2.026" x2="-3.509" y2="1.826" width="0.001" layer="51"/>
<wire x1="-3.509" y1="1.826" x2="-3.509" y2="1.251" width="0.001" layer="51"/>
<wire x1="0.971" y1="1.251" x2="0.971" y2="1.826" width="0.001" layer="51"/>
<wire x1="0.971" y1="1.826" x2="1.171" y2="2.026" width="0.001" layer="51"/>
<wire x1="1.171" y1="2.026" x2="1.371" y2="2.026" width="0.001" layer="51"/>
<wire x1="1.371" y1="2.026" x2="1.571" y2="1.826" width="0.001" layer="51"/>
<wire x1="1.571" y1="1.826" x2="1.571" y2="1.251" width="0.001" layer="51"/>
<wire x1="6.051" y1="1.251" x2="6.051" y2="1.826" width="0.001" layer="51"/>
<wire x1="6.051" y1="1.826" x2="6.251" y2="2.026" width="0.001" layer="51"/>
<wire x1="6.251" y1="2.026" x2="6.451" y2="2.026" width="0.001" layer="51"/>
<wire x1="6.451" y1="2.026" x2="6.651" y2="1.826" width="0.001" layer="51"/>
<wire x1="6.651" y1="1.826" x2="6.651" y2="1.251" width="0.001" layer="51"/>
<wire x1="-6.031190625" y1="-1.249" x2="-6.031190625" y2="-1.824" width="0.001" layer="51"/>
<wire x1="-6.031190625" y1="-1.824" x2="-6.231190625" y2="-2.024" width="0.001" layer="51"/>
<wire x1="-6.231190625" y1="-2.024" x2="-6.431190625" y2="-2.024" width="0.001" layer="51"/>
<wire x1="-6.431190625" y1="-2.024" x2="-6.631190625" y2="-1.824" width="0.001" layer="51"/>
<wire x1="-6.631190625" y1="-1.824" x2="-6.631190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="-0.951190625" y1="-1.249" x2="-0.951190625" y2="-1.824" width="0.001" layer="51"/>
<wire x1="-0.951190625" y1="-1.824" x2="-1.151190625" y2="-2.024" width="0.001" layer="51"/>
<wire x1="-1.151190625" y1="-2.024" x2="-1.351190625" y2="-2.024" width="0.001" layer="51"/>
<wire x1="-1.351190625" y1="-2.024" x2="-1.551190625" y2="-1.824" width="0.001" layer="51"/>
<wire x1="-1.551190625" y1="-1.824" x2="-1.551190625" y2="-1.249" width="0.001" layer="51"/>
<wire x1="4.128809375" y1="-1.249" x2="4.128809375" y2="-1.824" width="0.001" layer="51"/>
<wire x1="4.128809375" y1="-1.824" x2="3.928809375" y2="-2.024" width="0.001" layer="51"/>
<wire x1="3.928809375" y1="-2.024" x2="3.728809375" y2="-2.024" width="0.001" layer="51"/>
<wire x1="3.728809375" y1="-2.024" x2="3.528809375" y2="-1.824" width="0.001" layer="51"/>
<wire x1="3.528809375" y1="-1.824" x2="3.528809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="9.208809375" y1="-1.249" x2="9.208809375" y2="-1.824" width="0.001" layer="51"/>
<wire x1="9.208809375" y1="-1.824" x2="9.008809375" y2="-2.024" width="0.001" layer="51"/>
<wire x1="9.008809375" y1="-2.024" x2="8.808809375" y2="-2.024" width="0.001" layer="51"/>
<wire x1="8.808809375" y1="-2.024" x2="8.608809375" y2="-1.824" width="0.001" layer="51"/>
<wire x1="8.608809375" y1="-1.824" x2="8.608809375" y2="-1.249" width="0.001" layer="51"/>
<wire x1="11.131" y1="1.251" x2="11.131" y2="1.826" width="0.001" layer="51"/>
<wire x1="11.131" y1="1.826" x2="11.331" y2="2.026" width="0.001" layer="51"/>
<wire x1="11.331" y1="2.026" x2="11.531" y2="2.026" width="0.001" layer="51"/>
<wire x1="11.531" y1="2.026" x2="11.731" y2="1.826" width="0.001" layer="51"/>
<wire x1="11.731" y1="1.826" x2="11.731" y2="1.251" width="0.001" layer="51"/>
<wire x1="10.431" y1="-0.724" x2="10.431" y2="0.726" width="0.001" layer="51"/>
<wire x1="10.731" y1="0.701" x2="10.931" y2="0.501" width="0.001" layer="51"/>
<wire x1="10.731" y1="0.701" x2="10.731" y2="-0.699" width="0.001" layer="51"/>
<wire x1="10.731" y1="-0.699" x2="10.931" y2="-0.499" width="0.001" layer="51"/>
<wire x1="10.931" y1="-0.499" x2="10.931" y2="0.501" width="0.001" layer="51"/>
<wire x1="10.931" y1="0.501" x2="11.931" y2="0.501" width="0.001" layer="51"/>
<wire x1="11.931" y1="0.501" x2="12.131" y2="0.701" width="0.001" layer="51"/>
<wire x1="12.131" y1="0.701" x2="10.731" y2="0.701" width="0.001" layer="51"/>
<wire x1="12.131" y1="0.701" x2="12.131" y2="-0.699" width="0.001" layer="51"/>
<wire x1="12.131" y1="-0.699" x2="11.931" y2="-0.499" width="0.001" layer="51"/>
<wire x1="11.931" y1="-0.499" x2="11.931" y2="0.501" width="0.001" layer="51"/>
<wire x1="10.931" y1="-0.499" x2="11.931" y2="-0.499" width="0.001" layer="51"/>
<wire x1="12.131" y1="-0.699" x2="10.731" y2="-0.699" width="0.001" layer="51"/>
<wire x1="12.431" y1="0.726" x2="12.431" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-12.129" y1="0.701" x2="-11.929" y2="0.501" width="0.001" layer="51"/>
<wire x1="-12.129" y1="0.701" x2="-12.129" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-12.129" y1="-0.699" x2="-11.929" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-11.929" y1="-0.499" x2="-11.929" y2="0.501" width="0.001" layer="51"/>
<wire x1="-11.929" y1="0.501" x2="-10.929" y2="0.501" width="0.001" layer="51"/>
<wire x1="-10.929" y1="0.501" x2="-10.729" y2="0.701" width="0.001" layer="51"/>
<wire x1="-10.729" y1="0.701" x2="-12.129" y2="0.701" width="0.001" layer="51"/>
<wire x1="-10.729" y1="0.701" x2="-10.729" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-10.729" y1="-0.699" x2="-10.929" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-10.929" y1="-0.499" x2="-10.929" y2="0.501" width="0.001" layer="51"/>
<wire x1="-11.929" y1="-0.499" x2="-10.929" y2="-0.499" width="0.001" layer="51"/>
<wire x1="-10.729" y1="-0.699" x2="-12.129" y2="-0.699" width="0.001" layer="51"/>
<wire x1="-10.429" y1="0.726" x2="-10.429" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-12.429" y1="0.726" x2="-12.429" y2="-0.724" width="0.001" layer="51"/>
<wire x1="-12.9" y1="-1.6" x2="-12.9" y2="-2.4" width="0.127" layer="21"/>
<wire x1="-12.9" y1="-2.4" x2="-12.2" y2="-2" width="0.127" layer="21"/>
<wire x1="-12.2" y1="-2" x2="-12.9" y2="-1.6" width="0.127" layer="21"/>
<wire x1="-11.111190625" y1="-1.249" x2="-11.111190625" y2="-1.824" width="0.001" layer="51"/>
<wire x1="-11.111190625" y1="-1.824" x2="-11.311190625" y2="-2.024" width="0.001" layer="51"/>
<wire x1="-11.311190625" y1="-2.024" x2="-11.511190625" y2="-2.024" width="0.001" layer="51"/>
<wire x1="-11.511190625" y1="-2.024" x2="-11.711190625" y2="-1.824" width="0.001" layer="51"/>
<wire x1="-11.711190625" y1="-1.824" x2="-11.711190625" y2="-1.249" width="0.001" layer="51"/>
<smd name="1" x="-11.43" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="2" x="-8.89" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="3" x="-6.35" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="4" x="-3.81" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="5" x="-1.27" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="6" x="1.27" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="7" x="3.81" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="8" x="6.35" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="9" x="8.89" y="0" dx="1" dy="5.2" layer="1"/>
<smd name="10" x="11.43" y="0" dx="1" dy="5.2" layer="1"/>
<text x="-12.43" y="3.321" size="1.27" layer="25" ratio="10">&gt;NAME</text>
<text x="-12.43" y="-4.591" size="1.27" layer="27">&gt;VALUE</text>
<text x="13.6" y="-0.3" size="0.7" layer="51">&gt;NAME</text>
</package>
<package name="MRB316-3,81-V-BL">
<wire x1="-3.7" y1="-11.43" x2="-3.7" y2="11.43" width="0.127" layer="21"/>
<wire x1="-3.7" y1="11.43" x2="-3" y2="11.43" width="0.127" layer="21"/>
<wire x1="-3" y1="11.43" x2="-2.4" y2="11.43" width="0.127" layer="21"/>
<wire x1="-2.4" y1="11.43" x2="-1.905" y2="11.43" width="0.127" layer="21"/>
<wire x1="-1.905" y1="11.43" x2="1.905" y2="11.43" width="0.127" layer="21"/>
<wire x1="1.905" y1="11.43" x2="2.415" y2="11.43" width="0.127" layer="21"/>
<wire x1="2.415" y1="11.43" x2="3.015" y2="11.43" width="0.127" layer="21"/>
<wire x1="3.015" y1="11.43" x2="3.7" y2="11.43" width="0.127" layer="21"/>
<wire x1="3.7" y1="11.43" x2="3.7" y2="10.225" width="0.127" layer="21"/>
<wire x1="3.7" y1="10.225" x2="3.7" y2="8.825" width="0.127" layer="21"/>
<wire x1="3.7" y1="8.825" x2="3.7" y2="6.415" width="0.127" layer="21"/>
<wire x1="3.7" y1="6.415" x2="3.7" y2="5.015" width="0.127" layer="21"/>
<wire x1="3.7" y1="5.015" x2="3.7" y2="2.605" width="0.127" layer="21"/>
<wire x1="3.7" y1="2.605" x2="3.7" y2="1.205" width="0.127" layer="21"/>
<wire x1="3.7" y1="1.205" x2="3.7" y2="-1.205" width="0.127" layer="21"/>
<wire x1="3.7" y1="-1.205" x2="3.7" y2="-2.605" width="0.127" layer="21"/>
<wire x1="3.7" y1="-2.605" x2="3.7" y2="-5.015" width="0.127" layer="21"/>
<wire x1="3.7" y1="-5.015" x2="3.7" y2="-6.415" width="0.127" layer="21"/>
<wire x1="3.7" y1="-6.415" x2="3.7" y2="-8.825" width="0.127" layer="21"/>
<wire x1="3.7" y1="-8.825" x2="3.7" y2="-10.225" width="0.127" layer="21"/>
<wire x1="3.7" y1="-10.225" x2="3.7" y2="-11.43" width="0.127" layer="21"/>
<wire x1="3.7" y1="-11.43" x2="1.905" y2="-11.43" width="0.127" layer="21"/>
<wire x1="1.905" y1="-11.43" x2="-1.905" y2="-11.43" width="0.127" layer="21"/>
<wire x1="-1.905" y1="-11.43" x2="-3" y2="-11.43" width="0.127" layer="21"/>
<wire x1="-3" y1="-11.43" x2="-3.7" y2="-11.43" width="0.127" layer="21"/>
<wire x1="-1.905" y1="11.43" x2="-1.905" y2="-11.43" width="0.127" layer="21"/>
<wire x1="1.905" y1="11.43" x2="1.905" y2="10.225" width="0.127" layer="21"/>
<wire x1="1.905" y1="10.225" x2="1.905" y2="8.825" width="0.127" layer="21"/>
<wire x1="1.905" y1="8.825" x2="1.905" y2="6.415" width="0.127" layer="21"/>
<wire x1="1.905" y1="6.415" x2="1.905" y2="5.015" width="0.127" layer="21"/>
<wire x1="1.905" y1="5.015" x2="1.905" y2="2.605" width="0.127" layer="21"/>
<wire x1="1.905" y1="2.605" x2="1.905" y2="1.205" width="0.127" layer="21"/>
<wire x1="1.905" y1="1.205" x2="1.905" y2="-1.205" width="0.127" layer="21"/>
<wire x1="1.905" y1="-1.205" x2="1.905" y2="-2.605" width="0.127" layer="21"/>
<wire x1="1.905" y1="-2.605" x2="1.905" y2="-5.015" width="0.127" layer="21"/>
<wire x1="1.905" y1="-5.015" x2="1.905" y2="-6.415" width="0.127" layer="21"/>
<wire x1="1.905" y1="-6.415" x2="1.905" y2="-8.825" width="0.127" layer="21"/>
<wire x1="1.905" y1="-8.825" x2="1.905" y2="-10.225" width="0.127" layer="21"/>
<wire x1="1.905" y1="-10.225" x2="1.905" y2="-11.43" width="0.127" layer="21"/>
<wire x1="1.905" y1="10.225" x2="3.7" y2="10.225" width="0.127" layer="21"/>
<wire x1="1.905" y1="8.825" x2="3.7" y2="8.825" width="0.127" layer="21"/>
<wire x1="-3" y1="11.43" x2="-3" y2="-11.43" width="0.127" layer="21"/>
<wire x1="1.905" y1="5.015" x2="3.7" y2="5.015" width="0.127" layer="21"/>
<wire x1="1.905" y1="6.415" x2="3.7" y2="6.415" width="0.127" layer="21"/>
<wire x1="1.905" y1="2.605" x2="3.7" y2="2.605" width="0.127" layer="21"/>
<wire x1="1.905" y1="1.205" x2="3.7" y2="1.205" width="0.127" layer="21"/>
<wire x1="1.905" y1="-1.205" x2="3.7" y2="-1.205" width="0.127" layer="21"/>
<wire x1="1.905" y1="-2.605" x2="3.7" y2="-2.605" width="0.127" layer="21"/>
<wire x1="1.905" y1="-5.015" x2="3.7" y2="-5.015" width="0.127" layer="21"/>
<wire x1="1.905" y1="-6.415" x2="3.7" y2="-6.415" width="0.127" layer="21"/>
<wire x1="1.905" y1="-8.825" x2="3.7" y2="-8.825" width="0.127" layer="21"/>
<wire x1="1.905" y1="-10.225" x2="3.7" y2="-10.225" width="0.127" layer="21"/>
<wire x1="-3" y1="11.43" x2="-3.3" y2="11.73" width="0.127" layer="21"/>
<wire x1="-3.3" y1="11.73" x2="-2.1" y2="11.73" width="0.127" layer="21"/>
<wire x1="-2.1" y1="11.73" x2="-2.4" y2="11.43" width="0.127" layer="21"/>
<wire x1="2.415" y1="11.43" x2="2.115" y2="11.73" width="0.127" layer="21"/>
<wire x1="2.115" y1="11.73" x2="3.315" y2="11.73" width="0.127" layer="21"/>
<wire x1="3.315" y1="11.73" x2="3.015" y2="11.43" width="0.127" layer="21"/>
<pad name="1" x="0" y="9.525" drill="1.3208" diameter="2.159" shape="octagon"/>
<pad name="2" x="0" y="5.715" drill="1.3208" diameter="2.159" shape="octagon"/>
<pad name="3" x="0" y="1.905" drill="1.3208" diameter="2.159" shape="octagon"/>
<pad name="4" x="0" y="-1.905" drill="1.3208" diameter="2.159" shape="octagon"/>
<pad name="5" x="0" y="-5.715" drill="1.3208" diameter="2.159" shape="octagon"/>
<pad name="6" x="0" y="-9.525" drill="1.3208" diameter="2.159" shape="octagon"/>
<text x="-3.81" y="12.135" size="1.27" layer="21">&gt;NAME</text>
<text x="-3.81" y="-13.335" size="1.27" layer="27">&gt;VALUE</text>
</package>
</packages>
<symbols>
<symbol name="MODULINO-4">
<circle x="-2.54" y="0" radius="0.635" width="0.254" layer="94"/>
<circle x="0" y="0" radius="0.635" width="0.254" layer="94"/>
<circle x="2.54" y="0" radius="0.635" width="0.254" layer="94"/>
<wire x1="-3.81" y1="1.27" x2="-3.81" y2="-1.905" width="0.254" layer="94"/>
<wire x1="6.35" y1="-1.905" x2="-3.81" y2="-1.905" width="0.254" layer="94"/>
<wire x1="6.35" y1="-1.905" x2="6.35" y2="1.27" width="0.254" layer="94"/>
<wire x1="-3.81" y1="1.27" x2="6.35" y2="1.27" width="0.254" layer="94"/>
<pin name="1" x="-2.54" y="-2.54" visible="off" length="short" direction="pas" rot="R90"/>
<pin name="2" x="0" y="-2.54" visible="off" length="short" direction="pas" rot="R90"/>
<pin name="3" x="2.54" y="-2.54" visible="off" length="short" direction="pas" rot="R90"/>
<text x="-2.54" y="-6.35" size="1.778" layer="95">&gt;NAME</text>
<text x="-2.54" y="1.27" size="1.27" layer="95" rot="R90">GND</text>
<circle x="5.08" y="0" radius="0.635" width="0.254" layer="94"/>
<pin name="4" x="5.08" y="-2.54" visible="off" length="short" direction="pas" rot="R90"/>
<text x="0" y="1.27" size="1.27" layer="95" rot="R90">+V</text>
<text x="2.54" y="1.27" size="1.27" layer="95" rot="R90">TX/SDA</text>
<text x="5.08" y="1.27" size="1.27" layer="95" rot="R90">RX/SCL</text>
</symbol>
<symbol name="MODULINO-3">
<circle x="-2.54" y="0" radius="0.635" width="0.254" layer="94"/>
<circle x="0" y="0" radius="0.635" width="0.254" layer="94"/>
<circle x="2.54" y="0" radius="0.635" width="0.254" layer="94"/>
<wire x1="-3.81" y1="1.27" x2="-3.81" y2="-1.905" width="0.254" layer="94"/>
<wire x1="3.81" y1="-1.905" x2="-3.81" y2="-1.905" width="0.254" layer="94"/>
<wire x1="3.81" y1="-1.905" x2="3.81" y2="1.27" width="0.254" layer="94"/>
<wire x1="-3.81" y1="1.27" x2="3.81" y2="1.27" width="0.254" layer="94"/>
<pin name="1" x="-2.54" y="-2.54" visible="off" length="short" direction="pas" rot="R90"/>
<pin name="2" x="0" y="-2.54" visible="off" length="short" direction="pas" rot="R90"/>
<pin name="3" x="2.54" y="-2.54" visible="off" length="short" direction="pas" rot="R90"/>
<text x="-5.08" y="6.35" size="1.778" layer="95">&gt;NAME</text>
<text x="-2.54" y="1.27" size="1.27" layer="95" rot="R90">GND</text>
<text x="0" y="1.27" size="1.27" layer="95" rot="R90">SIG</text>
<text x="2.54" y="1.27" size="1.27" layer="95" rot="R90">+V</text>
</symbol>
<symbol name="PINHD-1X06">
<wire x1="-6.35" y1="-7.62" x2="1.27" y2="-7.62" width="0.4064" layer="94"/>
<wire x1="1.27" y1="-7.62" x2="1.27" y2="10.16" width="0.4064" layer="94"/>
<wire x1="1.27" y1="10.16" x2="-6.35" y2="10.16" width="0.4064" layer="94"/>
<wire x1="-6.35" y1="10.16" x2="-6.35" y2="-7.62" width="0.4064" layer="94"/>
<pin name="1" x="-2.54" y="7.62" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="2" x="-2.54" y="5.08" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="3" x="-2.54" y="2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="4" x="-2.54" y="0" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="5" x="-2.54" y="-2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="6" x="-2.54" y="-5.08" visible="pad" length="short" direction="pas" function="dot"/>
<text x="-6.35" y="10.795" size="1.778" layer="95">&gt;NAME</text>
</symbol>
<symbol name="PINHD-1X08">
<wire x1="-6.35" y1="-10.16" x2="1.27" y2="-10.16" width="0.4064" layer="94"/>
<wire x1="1.27" y1="-10.16" x2="1.27" y2="12.7" width="0.4064" layer="94"/>
<wire x1="1.27" y1="12.7" x2="-6.35" y2="12.7" width="0.4064" layer="94"/>
<wire x1="-6.35" y1="12.7" x2="-6.35" y2="-10.16" width="0.4064" layer="94"/>
<pin name="1" x="-2.54" y="10.16" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="2" x="-2.54" y="7.62" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="3" x="-2.54" y="5.08" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="4" x="-2.54" y="2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="5" x="-2.54" y="0" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="6" x="-2.54" y="-2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="7" x="-2.54" y="-5.08" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="8" x="-2.54" y="-7.62" visible="pad" length="short" direction="pas" function="dot"/>
<text x="-6.35" y="13.335" size="1.778" layer="95">&gt;NAME</text>
</symbol>
<symbol name="PINHD-1X10">
<wire x1="-6.35" y1="-15.24" x2="1.27" y2="-15.24" width="0.4064" layer="94"/>
<wire x1="1.27" y1="-15.24" x2="1.27" y2="12.7" width="0.4064" layer="94"/>
<wire x1="1.27" y1="12.7" x2="-6.35" y2="12.7" width="0.4064" layer="94"/>
<wire x1="-6.35" y1="12.7" x2="-6.35" y2="-15.24" width="0.4064" layer="94"/>
<pin name="1" x="-2.54" y="10.16" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="2" x="-2.54" y="7.62" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="3" x="-2.54" y="5.08" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="4" x="-2.54" y="2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="5" x="-2.54" y="0" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="6" x="-2.54" y="-2.54" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="7" x="-2.54" y="-5.08" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="8" x="-2.54" y="-7.62" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="9" x="-2.54" y="-10.16" visible="pad" length="short" direction="pas" function="dot"/>
<pin name="10" x="-2.54" y="-12.7" visible="pad" length="short" direction="pas" function="dot"/>
<text x="-6.35" y="13.335" size="1.778" layer="95">&gt;NAME</text>
</symbol>
<symbol name="TERMINALBLOCK-6">
<circle x="1.27" y="2.54" radius="1.135921875" width="0.254" layer="94"/>
<circle x="1.27" y="-2.54" radius="1.135921875" width="0.254" layer="94"/>
<circle x="1.27" y="-7.62" radius="1.135921875" width="0.254" layer="94"/>
<circle x="1.27" y="-12.7" radius="1.135921875" width="0.254" layer="94"/>
<circle x="1.27" y="7.62" radius="1.135921875" width="0.254" layer="94"/>
<circle x="1.27" y="12.7" radius="1.135921875" width="0.254" layer="94"/>
<wire x1="0.508" y1="6.858" x2="2.032" y2="8.382" width="0.254" layer="94"/>
<wire x1="0.508" y1="1.778" x2="2.032" y2="3.302" width="0.254" layer="94"/>
<wire x1="0.508" y1="-3.302" x2="2.032" y2="-1.778" width="0.254" layer="94"/>
<wire x1="0.508" y1="-8.382" x2="2.032" y2="-6.858" width="0.254" layer="94"/>
<wire x1="0.508" y1="-13.462" x2="2.032" y2="-11.938" width="0.254" layer="94"/>
<wire x1="0.508" y1="11.938" x2="2.032" y2="13.462" width="0.254" layer="94"/>
<wire x1="-2.54" y1="15.24" x2="-2.54" y2="-15.24" width="0.254" layer="94"/>
<wire x1="-2.54" y1="-15.24" x2="3.81" y2="-15.24" width="0.254" layer="94"/>
<wire x1="3.81" y1="-15.24" x2="3.81" y2="15.24" width="0.254" layer="94"/>
<wire x1="3.81" y1="15.24" x2="-2.54" y2="15.24" width="0.254" layer="94"/>
<pin name="1" x="5.08" y="12.7" length="short" rot="R180"/>
<pin name="2" x="5.08" y="7.62" length="short" rot="R180"/>
<pin name="3" x="5.08" y="2.54" length="short" rot="R180"/>
<pin name="4" x="5.08" y="-2.54" length="short" rot="R180"/>
<pin name="5" x="5.08" y="-7.62" length="short" rot="R180"/>
<pin name="6" x="5.08" y="-12.7" length="short" rot="R180"/>
<text x="-2.54" y="16.002" size="1.27" layer="95">&gt;NAME</text>
<text x="-2.54" y="-17.272" size="1.27" layer="96">&gt;VALUE</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="MODULINO-4" prefix="J">
<description>Modulino 4 connector</description>
<gates>
<gate name="G$1" symbol="MODULINO-4" x="0" y="0"/>
</gates>
<devices>
<device name="" package="MODULINO-4">
<connects>
<connect gate="G$1" pin="1" pad="4"/>
<connect gate="G$1" pin="2" pad="3"/>
<connect gate="G$1" pin="3" pad="2"/>
<connect gate="G$1" pin="4" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-BCE" value="-" constant="no"/>
<attribute name="CODE-BCMI" value="-" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="https://www.tme.eu/en/Document/21cd81e6196d70241c99017ffcf9ebee/LHA-XX-TS.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.tme.eu/en/details/lha-04-ts/raster-signal-connectors-254mm/adam-tech/" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="LHA-04-TS" constant="no"/>
<attribute name="MANUFACTURER" value="ADAM TECH" constant="no"/>
<attribute name="MANUFACTURER-PN" value="LHA-04-TS" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
<technology name="-TWI">
<attribute name="CODE-BCE" value="SP1693" constant="no"/>
<attribute name="CODE-BCMI" value="1693" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="-" constant="no"/>
<attribute name="MANUFACTURER-PN" value="-" constant="no"/>
<attribute name="VALUE" value="TWI" constant="no"/>
</technology>
</technologies>
</device>
<device name="SM" package="MODULINO-4SM">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
</connects>
<technologies>
<technology name="-DNP">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
<technology name="-SCREW">
<attribute name="DATASHEET" value="http://www.on-shore.com/wp-content/uploads/2015/09/ostvnxxa150.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/it/on-shore-technology-inc/OSTVN04A150/ED10563-ND/1588864" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="ED10563-ND" constant="no"/>
<attribute name="MANUFACTURER" value="On shore" constant="no"/>
<attribute name="MANUFACTURER-PN" value="OSTVN04A150" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="MODULINO-3" prefix="J" uservalue="yes">
<description>Modulino 4 connector</description>
<gates>
<gate name="G$1" symbol="MODULINO-3" x="0" y="0"/>
</gates>
<devices>
<device name="" package="MODULINO-3">
<connects>
<connect gate="G$1" pin="1" pad="3"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-BCE" value="-" constant="no"/>
<attribute name="CODE-BCMI" value="-" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="https://www.alliedelec.com/m/d/412bc68f123f3befd9509afa982df40c.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.alliedelec.com/adam-tech-lha-03-ts/70949176/" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value=" 70949176 " constant="no"/>
<attribute name="MANUFACTURER" value=" Adam Tech" constant="no"/>
<attribute name="MANUFACTURER-PN" value="LHA-03-TS" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
<technology name="-IN">
<attribute name="CODE-BCE" value="SP1695" constant="no"/>
<attribute name="CODE-BCMI" value="1695" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="-" constant="no"/>
<attribute name="MANUFACTURER-PN" value="-" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
<technology name="-OUT">
<attribute name="CODE-BCE" value="SP1696" constant="no"/>
<attribute name="CODE-BCMI" value="1696" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="-" constant="no"/>
<attribute name="MANUFACTURER-PN" value="-" constant="no"/>
<attribute name="VALUE" value="OUT" constant="no"/>
</technology>
</technologies>
</device>
<device name="SM" package="MODULINO-3SM">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
</connects>
<technologies>
<technology name="-DNP">
<attribute name="DATASHEET" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="DNP" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="DNP" constant="no"/>
<attribute name="MANUFACTURER" value="DNP" constant="no"/>
<attribute name="MANUFACTURER-PN" value="DNP" constant="no"/>
<attribute name="VALUE" value="DNP" constant="no"/>
</technology>
<technology name="-SCREW">
<attribute name="DATASHEET" value="http://www.on-shore.com/wp-content/uploads/2015/09/ostvnxxa150.pdf" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="https://www.digikey.com/product-detail/it/on-shore-technology-inc/OSTVN03A150/ED10562-ND/1588863" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="ED10562-ND" constant="no"/>
<attribute name="MANUFACTURER" value="On Shore" constant="no"/>
<attribute name="MANUFACTURER-PN" value="OSTVN03A150" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="PINHD-1X06" prefix="J" uservalue="yes">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<gates>
<gate name="A" symbol="PINHD-1X06" x="0" y="-2.54"/>
</gates>
<devices>
<device name="LITTLE" package="1X06_LITTLE">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="3649" constant="no"/>
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="-" constant="no"/>
<attribute name="MANUFACTURER-PN" value="-" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
</technologies>
</device>
<device name="TH" package="1X06-TH">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="3649" constant="no"/>
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="-" constant="no"/>
<attribute name="MANUFACTURER-PN" value="FH254-106DF085149V" constant="no"/>
<attribute name="VALUE" value="Analog" constant="no"/>
</technology>
</technologies>
</device>
<device name="SMD" package="1X06_SMD">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-BCE" value="-" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="-" constant="no"/>
<attribute name="MANUFACTURER-PN" value="-" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="PINHD-1X08" prefix="JP" uservalue="yes">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<gates>
<gate name="A" symbol="PINHD-1X08" x="0" y="0"/>
</gates>
<devices>
<device name="TH" package="1X08">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
</connects>
<technologies>
<technology name="-DIGITAL">
<attribute name="CODE-ARDUINO" value="3648" constant="no"/>
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="-" constant="no"/>
<attribute name="MANUFACTURER-PN" value="FH254-108DF085149V" constant="no"/>
<attribute name="VALUE" value="Digital" constant="no"/>
</technology>
<technology name="-POWER">
<attribute name="CODE-ARDUINO" value="3649" constant="no"/>
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="-" constant="no"/>
<attribute name="MANUFACTURER-PN" value="FH254-108DF085149V" constant="no"/>
<attribute name="VALUE" value="Power" constant="no"/>
</technology>
</technologies>
</device>
<device name="SMD" package="1X08_SMD">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="PINHD-1X10" prefix="J" uservalue="yes">
<description>&lt;b&gt;PIN HEADER&lt;/b&gt;</description>
<gates>
<gate name="A" symbol="PINHD-1X10" x="0" y="0"/>
</gates>
<devices>
<device name="TH" package="1X10">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="10" pad="10"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
<connect gate="A" pin="9" pad="9"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-ARDUINO" value="3648" constant="no"/>
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="-" constant="no"/>
<attribute name="MANUFACTURER-PN" value="FH254-110DF085149V" constant="no"/>
<attribute name="VALUE" value="Digital" constant="no"/>
</technology>
</technologies>
</device>
<device name="SMD" package="1X10_SMD">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="10" pad="10"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
<connect gate="A" pin="9" pad="9"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="0698_MRB316-3,81-V-BL" prefix="TB" uservalue="yes">
<description>Morsetto 6 poli h8,5mm Blue - EURO-BLOCK</description>
<gates>
<gate name="G$1" symbol="TERMINALBLOCK-6" x="0" y="0"/>
</gates>
<devices>
<device name="" package="MRB316-3,81-V-BL">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="3" pad="3"/>
<connect gate="G$1" pin="4" pad="4"/>
<connect gate="G$1" pin="5" pad="5"/>
<connect gate="G$1" pin="6" pad="6"/>
</connects>
<technologies>
<technology name="">
<attribute name="CODE-BCE" value="SP0698" constant="no"/>
<attribute name="CODE-BCMI" value="0698" constant="no"/>
<attribute name="CODE-TK2" value="-" constant="no"/>
<attribute name="DATASHEET" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-LINK" value="-" constant="no"/>
<attribute name="DISTRIBUTOR-PN" value="-" constant="no"/>
<attribute name="MANUFACTURER" value="-" constant="no"/>
<attribute name="MANUFACTURER-PN" value="MRB316-3,81-V-BL" constant="no"/>
<attribute name="VALUE" value="-" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
</libraries>
<attributes>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0.254" drill="0.6096">
<clearance class="0" value="0.1524"/>
</class>
<class number="1" name="power" width="0.3048" drill="0.6096">
<clearance class="1" value="0.3048"/>
</class>
<class number="2" name="VIN" width="0.3048" drill="0.6096">
<clearance class="2" value="0.1524"/>
</class>
<class number="3" name="RelayOut" width="1.27" drill="0">
<clearance class="0" value="4.0005"/>
<clearance class="1" value="4.0005"/>
<clearance class="2" value="4.0005"/>
<clearance class="3" value="1.27"/>
</class>
</classes>
<parts>
<part name="JLOW" library="Arduino-connectors" deviceset="PINHD-1X08" device="TH" technology="-DIGITAL" value="Digital"/>
<part name="JANALOG" library="Arduino-connectors" deviceset="PINHD-1X06" device="TH" value="Analog"/>
<part name="GND5" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="P+4" library="Arduino-supply" deviceset="+5V" device="" value="+5V"/>
<part name="FID2" library="Arduino-utility" deviceset="FIDUCIAL" device="-2MM" value="DNP"/>
<part name="FID3" library="Arduino-utility" deviceset="FIDUCIAL" device="-2MM" value="DNP"/>
<part name="+3V5" library="Arduino-supply" deviceset="+3V3" device="" value="+3V3"/>
<part name="GND22" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="JHIGH" library="Arduino-connectors" deviceset="PINHD-1X10" device="TH" value="Digital"/>
<part name="POWER" library="Arduino-connectors" deviceset="PINHD-1X08" device="TH" technology="-POWER" value="Power"/>
<part name="D6" library="Arduino-connectors" deviceset="MODULINO-3" device="" technology="-OUT" value="OUT"/>
<part name="GND2" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="P+2" library="Arduino-supply" deviceset="+5V" device="" value="+5V"/>
<part name="D5" library="Arduino-connectors" deviceset="MODULINO-3" device="" technology="-OUT" value="OUT"/>
<part name="GND4" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="P+3" library="Arduino-supply" deviceset="+5V" device="" value="+5V"/>
<part name="A2" library="Arduino-connectors" deviceset="MODULINO-3" device="" technology="-IN" value="-"/>
<part name="GND7" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="P+6" library="Arduino-supply" deviceset="+5V" device="" value="+5V"/>
<part name="A3" library="Arduino-connectors" deviceset="MODULINO-3" device="" technology="-IN" value="-"/>
<part name="GND12" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="P+7" library="Arduino-supply" deviceset="+5V" device="" value="+5V"/>
<part name="GND26" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="P+25" library="Arduino-supply" deviceset="+5V" device="" value="+5V"/>
<part name="TWI1" library="Arduino-connectors" deviceset="MODULINO-4" device="" technology="-TWI" value="TWI"/>
<part name="GND16" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="P+9" library="Arduino-supply" deviceset="+5V" device="" value="+5V"/>
<part name="TWI2" library="Arduino-connectors" deviceset="MODULINO-4" device="" technology="-TWI" value="TWI"/>
<part name="RESET" library="Arduino-pushbuttons" deviceset="TACTILE2" device="" value="-"/>
<part name="GND17" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="TB1" library="Arduino-connectors" deviceset="0698_MRB316-3,81-V-BL" device="" value="-"/>
<part name="TB2" library="Arduino-connectors" deviceset="0698_MRB316-3,81-V-BL" device="" value="-"/>
<part name="RL1" library="Arduino-mechanical" deviceset="RELAY-5" device="" value="-"/>
<part name="RL2" library="Arduino-mechanical" deviceset="RELAY-5" device="" value="-"/>
<part name="RL3" library="Arduino-mechanical" deviceset="RELAY-5" device="" value="-"/>
<part name="RL4" library="Arduino-mechanical" deviceset="RELAY-5" device="" value="-"/>
<part name="D1" library="Arduino-diodes" deviceset="DIODE" device="" technology="-SOD123" value="1N4148"/>
<part name="D2" library="Arduino-diodes" deviceset="DIODE" device="" technology="-SOD123" value="1N4148"/>
<part name="D3" library="Arduino-diodes" deviceset="DIODE" device="" technology="-SOD123" value="1N4148"/>
<part name="D4" library="Arduino-diodes" deviceset="DIODE" device="" technology="-SOD123" value="1N4148"/>
<part name="REL1" library="Opto" deviceset="0044_KPT-2012YC" device="" value="Yellow"/>
<part name="REL2" library="Opto" deviceset="0044_KPT-2012YC" device="" value="Yellow"/>
<part name="REL3" library="Opto" deviceset="0044_KPT-2012YC" device="" value="Yellow"/>
<part name="REL4" library="Opto" deviceset="0044_KPT-2012YC" device="" value="Yellow"/>
<part name="TR1" library="Arduino-transistors" deviceset="2N7002T" device="-SOT23" technology="-SOT23" value="2N7002"/>
<part name="TR2" library="Arduino-transistors" deviceset="2N7002T" device="-SOT23" technology="-SOT23" value="2N7002"/>
<part name="TR3" library="Arduino-transistors" deviceset="2N7002T" device="-SOT23" technology="-SOT23" value="2N7002"/>
<part name="TR4" library="Arduino-transistors" deviceset="2N7002T" device="-SOT23" technology="-SOT23" value="2N7002"/>
<part name="GND1" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="GND3" library="supply1" library_urn="urn:adsk.eagle:library:371" deviceset="GND" device=""/>
<part name="GND6" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="GND8" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="RN1" library="Arduino-rcl" deviceset="4R-N" device="CAY16" technology="-10K" value="10k"/>
<part name="GND9" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="P+1" library="Arduino-supply" deviceset="+5V" device="" value="+5V"/>
<part name="P+5" library="Arduino-supply" deviceset="+5V" device="" value="+5V"/>
<part name="P+8" library="Arduino-supply" deviceset="+5V" device="" value="+5V"/>
<part name="P+10" library="Arduino-supply" deviceset="+5V" device="" value="+5V"/>
<part name="RN2" library="Arduino-rcl" deviceset="4R-N" device="CAY16" technology="-1K" value="1k"/>
<part name="C1" library="Arduino-rcl" deviceset="C" device="-0603" technology="-100NF" value="100n"/>
<part name="C2" library="Arduino-rcl" deviceset="C" device="-0603" technology="-100NF" value="100n"/>
<part name="C3" library="Arduino-rcl" deviceset="C" device="-0603" technology="-100NF" value="100n"/>
<part name="C4" library="Arduino-rcl" deviceset="C" device="-0603" technology="-100NF" value="100n"/>
<part name="C5" library="Arduino-rcl" deviceset="C" device="-0603" technology="-100NF" value="100n"/>
<part name="C6" library="Arduino-rcl" deviceset="C" device="-0603" technology="-100NF" value="100n"/>
<part name="GND10" library="Arduino-supply" deviceset="GND" device="" value="GND"/>
<part name="P+11" library="Arduino-supply" deviceset="+5V" device="" value="+5V"/>
<part name="D9" library="Arduino-diodes" deviceset="D_SCHOTTKY" device="-SMB" technology="-SMB" value="SK14"/>
<part name="D10" library="Arduino-diodes" deviceset="D_SCHOTTKY" device="-SMB" technology="-SMB" value="SK14"/>
<part name="FRAME1" library="Arduino-utility" deviceset="A3-FRAMEONLY" device=""/>
<part name="FRAME2" library="Arduino-utility" deviceset="TEXT" device="TEXT_BRDSCH"/>
</parts>
<sheets>
<sheet>
<plain>
<text x="304.8" y="236.22" size="1.778" layer="91">SCL</text>
<text x="304.8" y="233.68" size="1.778" layer="91">SDA</text>
<text x="337.82" y="236.22" size="1.778" layer="91">SCL</text>
<text x="337.82" y="233.68" size="1.778" layer="91">SDA</text>
<text x="276.86" y="251.46" size="1.778" layer="91">Controllare PINOUT SIMBOLO</text>
</plain>
<instances>
<instance part="JLOW" gate="A" x="246.38" y="149.86" rot="MR180"/>
<instance part="JANALOG" gate="A" x="246.38" y="121.92" rot="MR180"/>
<instance part="GND5" gate="1" x="226.06" y="205.74"/>
<instance part="P+4" gate="1" x="213.36" y="236.22" smashed="yes">
<attribute name="VALUE" x="215.265" y="238.76" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="FID2" gate="G$1" x="299.72" y="114.3"/>
<instance part="FID3" gate="G$1" x="309.88" y="114.3"/>
<instance part="+3V5" gate="G$1" x="220.98" y="236.22" smashed="yes">
<attribute name="VALUE" x="223.52" y="238.76" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="GND22" gate="1" x="233.68" y="165.1" rot="MR0"/>
<instance part="JHIGH" gate="A" x="246.38" y="193.04" rot="MR180"/>
<instance part="POWER" gate="A" x="246.38" y="226.06"/>
<instance part="D6" gate="G$1" x="281.94" y="200.66" rot="R90"/>
<instance part="GND2" gate="1" x="289.56" y="193.04" rot="MR0"/>
<instance part="P+2" gate="1" x="287.02" y="210.82" smashed="yes">
<attribute name="VALUE" x="288.925" y="213.36" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="D5" gate="G$1" x="281.94" y="175.26" rot="R90"/>
<instance part="GND4" gate="1" x="289.56" y="167.64" rot="MR0"/>
<instance part="P+3" gate="1" x="287.02" y="185.42" smashed="yes">
<attribute name="VALUE" x="288.925" y="187.96" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="A2" gate="G$1" x="320.04" y="200.66" rot="R90"/>
<instance part="GND7" gate="1" x="327.66" y="193.04" rot="MR0"/>
<instance part="P+6" gate="1" x="325.12" y="210.82" smashed="yes">
<attribute name="VALUE" x="327.025" y="213.36" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="A3" gate="G$1" x="320.04" y="175.26" rot="R90"/>
<instance part="GND12" gate="1" x="327.66" y="167.64" rot="MR0"/>
<instance part="P+7" gate="1" x="325.12" y="185.42" smashed="yes">
<attribute name="VALUE" x="327.025" y="187.96" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="GND26" gate="1" x="292.1" y="220.98"/>
<instance part="P+25" gate="1" x="292.1" y="243.84" smashed="yes">
<attribute name="VALUE" x="294.64" y="246.38" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="TWI1" gate="G$1" x="284.48" y="231.14" smashed="yes" rot="R90">
<attribute name="NAME" x="284.48" y="238.76" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="288.29" y="238.76" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="GND16" gate="1" x="325.12" y="220.98"/>
<instance part="P+9" gate="1" x="325.12" y="243.84" smashed="yes">
<attribute name="VALUE" x="327.66" y="246.38" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="TWI2" gate="G$1" x="317.5" y="231.14" smashed="yes" rot="R90">
<attribute name="NAME" x="317.5" y="238.76" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="321.31" y="238.76" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="RESET" gate="G$1" x="292.1" y="147.32" rot="R180"/>
<instance part="GND17" gate="1" x="289.56" y="132.08"/>
<instance part="TB1" gate="G$1" x="22.86" y="200.66"/>
<instance part="TB2" gate="G$1" x="22.86" y="99.06"/>
<instance part="RL1" gate="G$1" x="91.44" y="213.36" rot="R90"/>
<instance part="RL2" gate="G$1" x="91.44" y="162.56" rot="R90"/>
<instance part="RL3" gate="G$1" x="91.44" y="111.76" rot="R90"/>
<instance part="RL4" gate="G$1" x="91.44" y="63.5" rot="R90"/>
<instance part="D1" gate="G$1" x="104.14" y="226.06" rot="R90"/>
<instance part="D2" gate="G$1" x="104.14" y="175.26" rot="R90"/>
<instance part="D3" gate="G$1" x="104.14" y="124.46" rot="R90"/>
<instance part="D4" gate="G$1" x="104.14" y="73.66" rot="R90"/>
<instance part="REL1" gate="G$1" x="114.3" y="226.06"/>
<instance part="REL2" gate="G$1" x="114.3" y="175.26"/>
<instance part="REL3" gate="G$1" x="114.3" y="124.46"/>
<instance part="REL4" gate="G$1" x="114.3" y="73.66"/>
<instance part="TR1" gate="G$1" x="132.08" y="208.28" smashed="yes" rot="R90">
<attribute name="NAME" x="130.81" y="217.17" size="1.778" layer="95" rot="MR180"/>
</instance>
<instance part="TR2" gate="G$1" x="137.16" y="157.48" smashed="yes" rot="R90">
<attribute name="NAME" x="135.89" y="166.37" size="1.778" layer="95" rot="MR180"/>
</instance>
<instance part="TR3" gate="G$1" x="137.16" y="106.68" smashed="yes" rot="R90">
<attribute name="NAME" x="135.89" y="115.57" size="1.778" layer="95" rot="MR180"/>
</instance>
<instance part="TR4" gate="G$1" x="129.54" y="55.88" smashed="yes" rot="R90">
<attribute name="NAME" x="128.27" y="64.77" size="1.778" layer="95" rot="MR180"/>
</instance>
<instance part="GND1" gate="1" x="147.32" y="203.2"/>
<instance part="GND3" gate="1" x="147.32" y="152.4"/>
<instance part="GND6" gate="1" x="147.32" y="101.6"/>
<instance part="GND8" gate="1" x="147.32" y="53.34"/>
<instance part="RN1" gate="A" x="200.66" y="175.26" rot="R90"/>
<instance part="RN1" gate="B" x="205.74" y="175.26" rot="R90"/>
<instance part="RN1" gate="C" x="210.82" y="175.26" rot="R90"/>
<instance part="RN1" gate="D" x="215.9" y="175.26" rot="R90"/>
<instance part="GND9" gate="1" x="200.66" y="162.56" rot="MR0"/>
<instance part="P+1" gate="1" x="121.92" y="248.92" smashed="yes">
<attribute name="VALUE" x="124.46" y="251.46" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="P+5" gate="1" x="121.92" y="198.12" smashed="yes">
<attribute name="VALUE" x="124.46" y="200.66" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="P+8" gate="1" x="121.92" y="147.32" smashed="yes">
<attribute name="VALUE" x="124.46" y="149.86" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="P+10" gate="1" x="121.92" y="99.06" smashed="yes">
<attribute name="VALUE" x="124.46" y="101.6" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="RN2" gate="A" x="114.3" y="238.76" rot="R90"/>
<instance part="RN2" gate="C" x="114.3" y="187.96" rot="R90"/>
<instance part="RN2" gate="B" x="114.3" y="137.16" rot="R90"/>
<instance part="RN2" gate="D" x="114.3" y="86.36" rot="R90"/>
<instance part="C1" gate="G$1" x="317.5" y="147.32"/>
<instance part="C2" gate="G$1" x="327.66" y="147.32"/>
<instance part="C3" gate="G$1" x="337.82" y="147.32"/>
<instance part="C4" gate="G$1" x="347.98" y="147.32"/>
<instance part="C5" gate="G$1" x="358.14" y="147.32"/>
<instance part="C6" gate="G$1" x="368.3" y="147.32"/>
<instance part="GND10" gate="1" x="317.5" y="132.08"/>
<instance part="P+11" gate="1" x="317.5" y="160.02" smashed="yes">
<attribute name="VALUE" x="319.405" y="162.56" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="D9" gate="D" x="218.44" y="101.6" rot="R270"/>
<instance part="D10" gate="D" x="226.06" y="101.6" rot="R270"/>
<instance part="FRAME1" gate="G$1" x="0" y="0"/>
<instance part="FRAME2" gate="G$1" x="10.16" y="7.62"/>
</instances>
<busses>
</busses>
<nets>
<net name="+5V" class="1">
<segment>
<wire x1="243.84" y1="226.06" x2="213.36" y2="226.06" width="0.1524" layer="91"/>
<wire x1="213.36" y1="226.06" x2="213.36" y2="233.68" width="0.1524" layer="91"/>
<pinref part="P+4" gate="1" pin="+5V"/>
<pinref part="POWER" gate="A" pin="5"/>
</segment>
<segment>
<wire x1="284.48" y1="203.2" x2="287.02" y2="203.2" width="0.1524" layer="91"/>
<wire x1="287.02" y1="203.2" x2="287.02" y2="208.28" width="0.1524" layer="91"/>
<pinref part="D6" gate="G$1" pin="3"/>
<pinref part="P+2" gate="1" pin="+5V"/>
</segment>
<segment>
<wire x1="284.48" y1="177.8" x2="287.02" y2="177.8" width="0.1524" layer="91"/>
<wire x1="287.02" y1="177.8" x2="287.02" y2="182.88" width="0.1524" layer="91"/>
<pinref part="D5" gate="G$1" pin="3"/>
<pinref part="P+3" gate="1" pin="+5V"/>
</segment>
<segment>
<wire x1="322.58" y1="203.2" x2="325.12" y2="203.2" width="0.1524" layer="91"/>
<wire x1="325.12" y1="203.2" x2="325.12" y2="208.28" width="0.1524" layer="91"/>
<pinref part="A2" gate="G$1" pin="3"/>
<pinref part="P+6" gate="1" pin="+5V"/>
</segment>
<segment>
<wire x1="322.58" y1="177.8" x2="325.12" y2="177.8" width="0.1524" layer="91"/>
<wire x1="325.12" y1="177.8" x2="325.12" y2="182.88" width="0.1524" layer="91"/>
<pinref part="A3" gate="G$1" pin="3"/>
<pinref part="P+7" gate="1" pin="+5V"/>
</segment>
<segment>
<wire x1="287.02" y1="231.14" x2="292.1" y2="231.14" width="0.1524" layer="91"/>
<wire x1="292.1" y1="231.14" x2="292.1" y2="241.3" width="0.1524" layer="91"/>
<pinref part="P+25" gate="1" pin="+5V"/>
<pinref part="TWI1" gate="G$1" pin="2"/>
</segment>
<segment>
<wire x1="320.04" y1="231.14" x2="325.12" y2="231.14" width="0.1524" layer="91"/>
<wire x1="325.12" y1="231.14" x2="325.12" y2="241.3" width="0.1524" layer="91"/>
<pinref part="P+9" gate="1" pin="+5V"/>
<pinref part="TWI2" gate="G$1" pin="2"/>
</segment>
<segment>
<pinref part="RL4" gate="G$1" pin="A2"/>
<wire x1="91.44" y1="91.44" x2="91.44" y2="96.52" width="0.1524" layer="91"/>
<pinref part="D4" gate="G$1" pin="C"/>
<wire x1="91.44" y1="96.52" x2="104.14" y2="96.52" width="0.1524" layer="91"/>
<wire x1="104.14" y1="96.52" x2="104.14" y2="76.2" width="0.1524" layer="91"/>
<wire x1="104.14" y1="96.52" x2="114.3" y2="96.52" width="0.1524" layer="91"/>
<junction x="104.14" y="96.52"/>
<pinref part="P+10" gate="1" pin="+5V"/>
<pinref part="RN2" gate="D" pin="2"/>
<wire x1="114.3" y1="96.52" x2="121.92" y2="96.52" width="0.1524" layer="91"/>
<wire x1="114.3" y1="91.44" x2="114.3" y2="96.52" width="0.1524" layer="91"/>
<junction x="114.3" y="96.52"/>
</segment>
<segment>
<pinref part="RL3" gate="G$1" pin="A2"/>
<wire x1="91.44" y1="139.7" x2="91.44" y2="144.78" width="0.1524" layer="91"/>
<pinref part="D3" gate="G$1" pin="C"/>
<wire x1="91.44" y1="144.78" x2="104.14" y2="144.78" width="0.1524" layer="91"/>
<wire x1="104.14" y1="144.78" x2="104.14" y2="127" width="0.1524" layer="91"/>
<junction x="104.14" y="144.78"/>
<pinref part="P+8" gate="1" pin="+5V"/>
<wire x1="121.92" y1="144.78" x2="114.3" y2="144.78" width="0.1524" layer="91"/>
<pinref part="RN2" gate="B" pin="2"/>
<wire x1="114.3" y1="144.78" x2="104.14" y2="144.78" width="0.1524" layer="91"/>
<wire x1="114.3" y1="142.24" x2="114.3" y2="144.78" width="0.1524" layer="91"/>
<junction x="114.3" y="144.78"/>
</segment>
<segment>
<pinref part="RL2" gate="G$1" pin="A2"/>
<wire x1="91.44" y1="190.5" x2="91.44" y2="195.58" width="0.1524" layer="91"/>
<pinref part="D2" gate="G$1" pin="C"/>
<wire x1="91.44" y1="195.58" x2="104.14" y2="195.58" width="0.1524" layer="91"/>
<wire x1="104.14" y1="195.58" x2="104.14" y2="177.8" width="0.1524" layer="91"/>
<junction x="104.14" y="195.58"/>
<pinref part="P+5" gate="1" pin="+5V"/>
<wire x1="121.92" y1="195.58" x2="114.3" y2="195.58" width="0.1524" layer="91"/>
<pinref part="RN2" gate="C" pin="2"/>
<wire x1="114.3" y1="195.58" x2="104.14" y2="195.58" width="0.1524" layer="91"/>
<wire x1="114.3" y1="193.04" x2="114.3" y2="195.58" width="0.1524" layer="91"/>
<junction x="114.3" y="195.58"/>
</segment>
<segment>
<pinref part="RL1" gate="G$1" pin="A2"/>
<wire x1="91.44" y1="241.3" x2="91.44" y2="246.38" width="0.1524" layer="91"/>
<pinref part="D1" gate="G$1" pin="C"/>
<wire x1="91.44" y1="246.38" x2="104.14" y2="246.38" width="0.1524" layer="91"/>
<wire x1="104.14" y1="246.38" x2="104.14" y2="228.6" width="0.1524" layer="91"/>
<junction x="104.14" y="246.38"/>
<pinref part="P+1" gate="1" pin="+5V"/>
<wire x1="121.92" y1="246.38" x2="114.3" y2="246.38" width="0.1524" layer="91"/>
<pinref part="RN2" gate="A" pin="2"/>
<wire x1="114.3" y1="246.38" x2="104.14" y2="246.38" width="0.1524" layer="91"/>
<wire x1="114.3" y1="243.84" x2="114.3" y2="246.38" width="0.1524" layer="91"/>
<junction x="114.3" y="246.38"/>
</segment>
<segment>
<pinref part="C1" gate="G$1" pin="1"/>
<wire x1="317.5" y1="149.86" x2="317.5" y2="154.94" width="0.1524" layer="91"/>
<pinref part="C6" gate="G$1" pin="1"/>
<wire x1="317.5" y1="154.94" x2="327.66" y2="154.94" width="0.1524" layer="91"/>
<wire x1="327.66" y1="154.94" x2="337.82" y2="154.94" width="0.1524" layer="91"/>
<wire x1="337.82" y1="154.94" x2="347.98" y2="154.94" width="0.1524" layer="91"/>
<wire x1="347.98" y1="154.94" x2="358.14" y2="154.94" width="0.1524" layer="91"/>
<wire x1="358.14" y1="154.94" x2="368.3" y2="154.94" width="0.1524" layer="91"/>
<wire x1="368.3" y1="154.94" x2="368.3" y2="149.86" width="0.1524" layer="91"/>
<pinref part="C5" gate="G$1" pin="1"/>
<wire x1="358.14" y1="149.86" x2="358.14" y2="154.94" width="0.1524" layer="91"/>
<junction x="358.14" y="154.94"/>
<pinref part="C4" gate="G$1" pin="1"/>
<wire x1="347.98" y1="149.86" x2="347.98" y2="154.94" width="0.1524" layer="91"/>
<junction x="347.98" y="154.94"/>
<pinref part="C3" gate="G$1" pin="1"/>
<wire x1="337.82" y1="149.86" x2="337.82" y2="154.94" width="0.1524" layer="91"/>
<junction x="337.82" y="154.94"/>
<pinref part="C2" gate="G$1" pin="1"/>
<wire x1="327.66" y1="149.86" x2="327.66" y2="154.94" width="0.1524" layer="91"/>
<junction x="327.66" y="154.94"/>
<pinref part="P+11" gate="1" pin="+5V"/>
<wire x1="317.5" y1="154.94" x2="317.5" y2="157.48" width="0.1524" layer="91"/>
<junction x="317.5" y="154.94"/>
</segment>
</net>
<net name="GND" class="1">
<segment>
<wire x1="226.06" y1="223.52" x2="226.06" y2="220.98" width="0.1524" layer="91"/>
<wire x1="226.06" y1="220.98" x2="226.06" y2="208.28" width="0.1524" layer="91"/>
<wire x1="243.84" y1="223.52" x2="226.06" y2="223.52" width="0.1524" layer="91"/>
<wire x1="243.84" y1="220.98" x2="226.06" y2="220.98" width="0.1524" layer="91"/>
<junction x="226.06" y="220.98"/>
<pinref part="GND5" gate="1" pin="GND"/>
<pinref part="POWER" gate="A" pin="6"/>
<pinref part="POWER" gate="A" pin="7"/>
</segment>
<segment>
<wire x1="243.84" y1="198.12" x2="233.68" y2="198.12" width="0.1524" layer="91"/>
<wire x1="233.68" y1="198.12" x2="233.68" y2="167.64" width="0.1524" layer="91"/>
<pinref part="GND22" gate="1" pin="GND"/>
<pinref part="JHIGH" gate="A" pin="7"/>
</segment>
<segment>
<wire x1="289.56" y1="195.58" x2="289.56" y2="198.12" width="0.1524" layer="91"/>
<wire x1="289.56" y1="198.12" x2="284.48" y2="198.12" width="0.1524" layer="91"/>
<pinref part="GND2" gate="1" pin="GND"/>
<pinref part="D6" gate="G$1" pin="1"/>
</segment>
<segment>
<wire x1="284.48" y1="172.72" x2="289.56" y2="172.72" width="0.1524" layer="91"/>
<wire x1="289.56" y1="172.72" x2="289.56" y2="170.18" width="0.1524" layer="91"/>
<pinref part="GND4" gate="1" pin="GND"/>
<pinref part="D5" gate="G$1" pin="1"/>
</segment>
<segment>
<wire x1="327.66" y1="195.58" x2="327.66" y2="198.12" width="0.1524" layer="91"/>
<wire x1="327.66" y1="198.12" x2="322.58" y2="198.12" width="0.1524" layer="91"/>
<pinref part="GND7" gate="1" pin="GND"/>
<pinref part="A2" gate="G$1" pin="1"/>
</segment>
<segment>
<wire x1="327.66" y1="170.18" x2="327.66" y2="172.72" width="0.1524" layer="91"/>
<wire x1="327.66" y1="172.72" x2="322.58" y2="172.72" width="0.1524" layer="91"/>
<pinref part="GND12" gate="1" pin="GND"/>
<pinref part="A3" gate="G$1" pin="1"/>
</segment>
<segment>
<wire x1="292.1" y1="223.52" x2="292.1" y2="228.6" width="0.1524" layer="91"/>
<wire x1="292.1" y1="228.6" x2="287.02" y2="228.6" width="0.1524" layer="91"/>
<pinref part="GND26" gate="1" pin="GND"/>
<pinref part="TWI1" gate="G$1" pin="1"/>
</segment>
<segment>
<wire x1="325.12" y1="223.52" x2="325.12" y2="228.6" width="0.1524" layer="91"/>
<wire x1="325.12" y1="228.6" x2="320.04" y2="228.6" width="0.1524" layer="91"/>
<pinref part="GND16" gate="1" pin="GND"/>
<pinref part="TWI2" gate="G$1" pin="1"/>
</segment>
<segment>
<wire x1="289.56" y1="134.62" x2="289.56" y2="139.7" width="0.1524" layer="91"/>
<wire x1="289.56" y1="139.7" x2="289.56" y2="142.24" width="0.1524" layer="91"/>
<wire x1="289.56" y1="139.7" x2="292.1" y2="139.7" width="0.1524" layer="91"/>
<wire x1="292.1" y1="139.7" x2="292.1" y2="142.24" width="0.1524" layer="91"/>
<junction x="289.56" y="139.7"/>
<pinref part="GND17" gate="1" pin="GND"/>
<pinref part="RESET" gate="G$1" pin="4"/>
<pinref part="RESET" gate="G$1" pin="3"/>
<pinref part="RESET" gate="G$1" pin="5-GND"/>
<wire x1="287.02" y1="152.4" x2="287.02" y2="154.94" width="0.1524" layer="91"/>
<wire x1="287.02" y1="154.94" x2="284.48" y2="154.94" width="0.1524" layer="91"/>
<wire x1="284.48" y1="154.94" x2="284.48" y2="139.7" width="0.1524" layer="91"/>
<wire x1="284.48" y1="139.7" x2="289.56" y2="139.7" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="TR4" gate="G$1" pin="S"/>
<pinref part="GND8" gate="1" pin="GND"/>
<wire x1="134.62" y1="55.88" x2="147.32" y2="55.88" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="TR3" gate="G$1" pin="S"/>
<pinref part="GND6" gate="1" pin="GND"/>
<wire x1="142.24" y1="106.68" x2="147.32" y2="106.68" width="0.1524" layer="91"/>
<wire x1="147.32" y1="106.68" x2="147.32" y2="104.14" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="TR2" gate="G$1" pin="S"/>
<pinref part="GND3" gate="1" pin="GND"/>
<wire x1="142.24" y1="157.48" x2="147.32" y2="157.48" width="0.1524" layer="91"/>
<wire x1="147.32" y1="157.48" x2="147.32" y2="154.94" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="TR1" gate="G$1" pin="S"/>
<pinref part="GND1" gate="1" pin="GND"/>
<wire x1="137.16" y1="208.28" x2="147.32" y2="208.28" width="0.1524" layer="91"/>
<wire x1="147.32" y1="208.28" x2="147.32" y2="205.74" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="RN1" gate="D" pin="1"/>
<wire x1="215.9" y1="170.18" x2="215.9" y2="167.64" width="0.1524" layer="91"/>
<pinref part="RN1" gate="A" pin="1"/>
<wire x1="215.9" y1="167.64" x2="210.82" y2="167.64" width="0.1524" layer="91"/>
<wire x1="210.82" y1="167.64" x2="205.74" y2="167.64" width="0.1524" layer="91"/>
<wire x1="205.74" y1="167.64" x2="200.66" y2="167.64" width="0.1524" layer="91"/>
<wire x1="200.66" y1="167.64" x2="200.66" y2="170.18" width="0.1524" layer="91"/>
<pinref part="RN1" gate="B" pin="1"/>
<wire x1="205.74" y1="170.18" x2="205.74" y2="167.64" width="0.1524" layer="91"/>
<junction x="205.74" y="167.64"/>
<pinref part="RN1" gate="C" pin="1"/>
<wire x1="210.82" y1="170.18" x2="210.82" y2="167.64" width="0.1524" layer="91"/>
<junction x="210.82" y="167.64"/>
<pinref part="GND9" gate="1" pin="GND"/>
<wire x1="200.66" y1="165.1" x2="200.66" y2="167.64" width="0.1524" layer="91"/>
<junction x="200.66" y="167.64"/>
</segment>
<segment>
<pinref part="C1" gate="G$1" pin="2"/>
<wire x1="317.5" y1="144.78" x2="317.5" y2="137.16" width="0.1524" layer="91"/>
<pinref part="C6" gate="G$1" pin="2"/>
<wire x1="317.5" y1="137.16" x2="327.66" y2="137.16" width="0.1524" layer="91"/>
<wire x1="327.66" y1="137.16" x2="337.82" y2="137.16" width="0.1524" layer="91"/>
<wire x1="337.82" y1="137.16" x2="347.98" y2="137.16" width="0.1524" layer="91"/>
<wire x1="347.98" y1="137.16" x2="358.14" y2="137.16" width="0.1524" layer="91"/>
<wire x1="358.14" y1="137.16" x2="368.3" y2="137.16" width="0.1524" layer="91"/>
<wire x1="368.3" y1="137.16" x2="368.3" y2="144.78" width="0.1524" layer="91"/>
<pinref part="C5" gate="G$1" pin="2"/>
<wire x1="358.14" y1="144.78" x2="358.14" y2="137.16" width="0.1524" layer="91"/>
<junction x="358.14" y="137.16"/>
<pinref part="C4" gate="G$1" pin="2"/>
<wire x1="347.98" y1="144.78" x2="347.98" y2="137.16" width="0.1524" layer="91"/>
<junction x="347.98" y="137.16"/>
<pinref part="C3" gate="G$1" pin="2"/>
<wire x1="337.82" y1="144.78" x2="337.82" y2="137.16" width="0.1524" layer="91"/>
<junction x="337.82" y="137.16"/>
<pinref part="C2" gate="G$1" pin="2"/>
<wire x1="327.66" y1="144.78" x2="327.66" y2="137.16" width="0.1524" layer="91"/>
<junction x="327.66" y="137.16"/>
<pinref part="GND10" gate="1" pin="GND"/>
<wire x1="317.5" y1="134.62" x2="317.5" y2="137.16" width="0.1524" layer="91"/>
<junction x="317.5" y="137.16"/>
</segment>
</net>
<net name="+3V3" class="1">
<segment>
<wire x1="220.98" y1="228.6" x2="220.98" y2="233.68" width="0.1524" layer="91"/>
<wire x1="220.98" y1="228.6" x2="243.84" y2="228.6" width="0.1524" layer="91"/>
<pinref part="+3V5" gate="G$1" pin="+3V3"/>
<pinref part="POWER" gate="A" pin="4"/>
</segment>
</net>
<net name="IOREF" class="0">
<segment>
<wire x1="243.84" y1="233.68" x2="226.06" y2="233.68" width="0.1524" layer="91"/>
<label x="228.6" y="233.68" size="1.778" layer="95"/>
<pinref part="POWER" gate="A" pin="2"/>
</segment>
<segment>
<wire x1="218.44" y1="91.44" x2="226.06" y2="91.44" width="0.1524" layer="91"/>
<wire x1="226.06" y1="91.44" x2="241.3" y2="91.44" width="0.1524" layer="91"/>
<wire x1="218.44" y1="91.44" x2="218.44" y2="99.06" width="0.1524" layer="91"/>
<wire x1="226.06" y1="99.06" x2="226.06" y2="91.44" width="0.1524" layer="91"/>
<junction x="226.06" y="91.44"/>
<label x="233.68" y="91.44" size="1.778" layer="95"/>
<pinref part="D9" gate="D" pin="C"/>
<pinref part="D10" gate="D" pin="C"/>
</segment>
</net>
<net name="A2" class="0">
<segment>
<wire x1="213.36" y1="119.38" x2="226.06" y2="119.38" width="0.1524" layer="91"/>
<wire x1="226.06" y1="119.38" x2="243.84" y2="119.38" width="0.1524" layer="91"/>
<wire x1="226.06" y1="119.38" x2="226.06" y2="104.14" width="0.1524" layer="91"/>
<junction x="226.06" y="119.38"/>
<label x="228.6" y="119.38" size="1.778" layer="95"/>
<pinref part="JANALOG" gate="A" pin="3"/>
<pinref part="D10" gate="D" pin="A"/>
</segment>
<segment>
<wire x1="322.58" y1="200.66" x2="335.28" y2="200.66" width="0.1524" layer="91"/>
<label x="327.66" y="200.66" size="1.778" layer="95"/>
<pinref part="A2" gate="G$1" pin="2"/>
</segment>
</net>
<net name="A3" class="0">
<segment>
<wire x1="213.36" y1="121.92" x2="218.44" y2="121.92" width="0.1524" layer="91"/>
<wire x1="218.44" y1="121.92" x2="243.84" y2="121.92" width="0.1524" layer="91"/>
<wire x1="218.44" y1="121.92" x2="218.44" y2="104.14" width="0.1524" layer="91"/>
<junction x="218.44" y="121.92"/>
<label x="228.6" y="121.92" size="1.778" layer="95"/>
<pinref part="JANALOG" gate="A" pin="4"/>
<pinref part="D9" gate="D" pin="A"/>
</segment>
<segment>
<wire x1="322.58" y1="175.26" x2="335.28" y2="175.26" width="0.1524" layer="91"/>
<label x="327.66" y="175.26" size="1.778" layer="95"/>
<pinref part="A3" gate="G$1" pin="2"/>
</segment>
</net>
<net name="6" class="0">
<segment>
<wire x1="243.84" y1="154.94" x2="223.52" y2="154.94" width="0.1524" layer="91"/>
<label x="226.06" y="154.94" size="1.778" layer="95"/>
<pinref part="JLOW" gate="A" pin="7"/>
</segment>
<segment>
<wire x1="284.48" y1="200.66" x2="297.18" y2="200.66" width="0.1524" layer="91"/>
<label x="289.56" y="200.66" size="1.778" layer="95"/>
<pinref part="D6" gate="G$1" pin="2"/>
</segment>
</net>
<net name="5" class="0">
<segment>
<wire x1="243.84" y1="152.4" x2="223.52" y2="152.4" width="0.1524" layer="91"/>
<label x="226.06" y="152.4" size="1.778" layer="95"/>
<pinref part="JLOW" gate="A" pin="6"/>
</segment>
<segment>
<wire x1="284.48" y1="175.26" x2="297.18" y2="175.26" width="0.1524" layer="91"/>
<label x="289.56" y="175.26" size="1.778" layer="95"/>
<pinref part="D5" gate="G$1" pin="2"/>
</segment>
</net>
<net name="SDA" class="0">
<segment>
<wire x1="287.02" y1="233.68" x2="302.26" y2="233.68" width="0.1524" layer="91"/>
<label x="294.64" y="233.68" size="1.778" layer="95"/>
<pinref part="TWI1" gate="G$1" pin="3"/>
</segment>
<segment>
<wire x1="320.04" y1="233.68" x2="335.28" y2="233.68" width="0.1524" layer="91"/>
<label x="327.66" y="233.68" size="1.778" layer="95"/>
<pinref part="TWI2" gate="G$1" pin="3"/>
</segment>
<segment>
<wire x1="231.14" y1="203.2" x2="243.84" y2="203.2" width="0.1524" layer="91"/>
<label x="231.14" y="203.2" size="1.778" layer="95"/>
<pinref part="JHIGH" gate="A" pin="9"/>
</segment>
</net>
<net name="SCL" class="0">
<segment>
<wire x1="302.26" y1="236.22" x2="287.02" y2="236.22" width="0.1524" layer="91"/>
<label x="294.64" y="236.22" size="1.778" layer="95"/>
<pinref part="TWI1" gate="G$1" pin="4"/>
</segment>
<segment>
<wire x1="335.28" y1="236.22" x2="320.04" y2="236.22" width="0.1524" layer="91"/>
<label x="327.66" y="236.22" size="1.778" layer="95"/>
<pinref part="TWI2" gate="G$1" pin="4"/>
</segment>
<segment>
<wire x1="231.14" y1="205.74" x2="243.84" y2="205.74" width="0.1524" layer="91"/>
<label x="231.14" y="205.74" size="1.778" layer="95"/>
<pinref part="JHIGH" gate="A" pin="10"/>
</segment>
</net>
<net name="RESET" class="0">
<segment>
<wire x1="292.1" y1="152.4" x2="292.1" y2="157.48" width="0.1524" layer="91"/>
<wire x1="292.1" y1="157.48" x2="289.56" y2="157.48" width="0.1524" layer="91"/>
<wire x1="289.56" y1="157.48" x2="289.56" y2="152.4" width="0.1524" layer="91"/>
<wire x1="289.56" y1="157.48" x2="287.02" y2="157.48" width="0.1524" layer="91"/>
<junction x="289.56" y="157.48"/>
<label x="274.32" y="157.48" size="1.778" layer="95"/>
<pinref part="RESET" gate="G$1" pin="1"/>
<pinref part="RESET" gate="G$1" pin="2"/>
<wire x1="287.02" y1="157.48" x2="274.32" y2="157.48" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="243.84" y1="231.14" x2="226.06" y2="231.14" width="0.1524" layer="91"/>
<label x="228.6" y="231.14" size="1.778" layer="95"/>
<pinref part="POWER" gate="A" pin="3"/>
</segment>
</net>
<net name="REL1_NO" class="3">
<segment>
<pinref part="RL1" gate="G$1" pin="NO1"/>
<wire x1="71.12" y1="241.3" x2="71.12" y2="246.38" width="0.1524" layer="91"/>
<wire x1="71.12" y1="246.38" x2="63.5" y2="246.38" width="0.1524" layer="91"/>
<wire x1="63.5" y1="246.38" x2="63.5" y2="213.36" width="0.1524" layer="91"/>
<pinref part="RL1" gate="G$1" pin="NO2"/>
<wire x1="63.5" y1="213.36" x2="63.5" y2="210.82" width="0.1524" layer="91"/>
<wire x1="63.5" y1="210.82" x2="71.12" y2="210.82" width="0.1524" layer="91"/>
<wire x1="71.12" y1="210.82" x2="71.12" y2="213.36" width="0.1524" layer="91"/>
<pinref part="TB1" gate="G$1" pin="1"/>
<wire x1="27.94" y1="213.36" x2="63.5" y2="213.36" width="0.1524" layer="91"/>
<junction x="63.5" y="213.36"/>
</segment>
</net>
<net name="REL3_NC" class="3">
<segment>
<wire x1="76.2" y1="144.78" x2="60.96" y2="144.78" width="0.1524" layer="91"/>
<wire x1="60.96" y1="144.78" x2="60.96" y2="106.68" width="0.1524" layer="91"/>
<wire x1="60.96" y1="106.68" x2="76.2" y2="106.68" width="0.1524" layer="91"/>
<pinref part="RL3" gate="G$1" pin="NC2"/>
<wire x1="76.2" y1="111.76" x2="76.2" y2="106.68" width="0.1524" layer="91"/>
<pinref part="RL3" gate="G$1" pin="NC1"/>
<wire x1="76.2" y1="139.7" x2="76.2" y2="144.78" width="0.1524" layer="91"/>
<pinref part="TB2" gate="G$1" pin="2"/>
<wire x1="27.94" y1="106.68" x2="60.96" y2="106.68" width="0.1524" layer="91"/>
<junction x="60.96" y="106.68"/>
</segment>
</net>
<net name="REL3_NO" class="3">
<segment>
<pinref part="RL3" gate="G$1" pin="NO1"/>
<wire x1="71.12" y1="139.7" x2="71.12" y2="142.24" width="0.1524" layer="91"/>
<wire x1="71.12" y1="142.24" x2="63.5" y2="142.24" width="0.1524" layer="91"/>
<wire x1="63.5" y1="142.24" x2="63.5" y2="109.22" width="0.1524" layer="91"/>
<pinref part="RL3" gate="G$1" pin="NO2"/>
<wire x1="63.5" y1="109.22" x2="71.12" y2="109.22" width="0.1524" layer="91"/>
<wire x1="71.12" y1="109.22" x2="71.12" y2="111.76" width="0.1524" layer="91"/>
<pinref part="TB2" gate="G$1" pin="3"/>
<wire x1="27.94" y1="101.6" x2="63.5" y2="101.6" width="0.1524" layer="91"/>
<wire x1="63.5" y1="101.6" x2="63.5" y2="109.22" width="0.1524" layer="91"/>
<junction x="63.5" y="109.22"/>
</segment>
</net>
<net name="REL4_NO" class="3">
<segment>
<pinref part="RL4" gate="G$1" pin="NO2"/>
<wire x1="63.5" y1="60.96" x2="71.12" y2="60.96" width="0.1524" layer="91"/>
<wire x1="71.12" y1="60.96" x2="71.12" y2="63.5" width="0.1524" layer="91"/>
<pinref part="RL4" gate="G$1" pin="NO1"/>
<wire x1="71.12" y1="91.44" x2="63.5" y2="91.44" width="0.1524" layer="91"/>
<wire x1="63.5" y1="91.44" x2="63.5" y2="86.36" width="0.1524" layer="91"/>
<pinref part="TB2" gate="G$1" pin="6"/>
<wire x1="63.5" y1="86.36" x2="63.5" y2="60.96" width="0.1524" layer="91"/>
<wire x1="27.94" y1="86.36" x2="63.5" y2="86.36" width="0.1524" layer="91"/>
<junction x="63.5" y="86.36"/>
</segment>
</net>
<net name="REL4_NC" class="3">
<segment>
<pinref part="RL4" gate="G$1" pin="NC2"/>
<wire x1="60.96" y1="58.42" x2="76.2" y2="58.42" width="0.1524" layer="91"/>
<wire x1="76.2" y1="58.42" x2="76.2" y2="63.5" width="0.1524" layer="91"/>
<pinref part="RL4" gate="G$1" pin="NC1"/>
<wire x1="76.2" y1="91.44" x2="76.2" y2="93.98" width="0.1524" layer="91"/>
<wire x1="76.2" y1="93.98" x2="60.96" y2="93.98" width="0.1524" layer="91"/>
<wire x1="60.96" y1="93.98" x2="60.96" y2="91.44" width="0.1524" layer="91"/>
<pinref part="TB2" gate="G$1" pin="5"/>
<wire x1="60.96" y1="91.44" x2="60.96" y2="58.42" width="0.1524" layer="91"/>
<wire x1="27.94" y1="91.44" x2="60.96" y2="91.44" width="0.1524" layer="91"/>
<junction x="60.96" y="91.44"/>
</segment>
</net>
<net name="REL4_COM" class="3">
<segment>
<pinref part="RL4" gate="G$1" pin="C2"/>
<wire x1="58.42" y1="55.88" x2="81.28" y2="55.88" width="0.1524" layer="91"/>
<wire x1="81.28" y1="55.88" x2="81.28" y2="63.5" width="0.1524" layer="91"/>
<wire x1="81.28" y1="91.44" x2="81.28" y2="96.52" width="0.1524" layer="91"/>
<wire x1="81.28" y1="96.52" x2="58.42" y2="96.52" width="0.1524" layer="91"/>
<pinref part="RL4" gate="G$1" pin="C1"/>
<wire x1="58.42" y1="96.52" x2="58.42" y2="55.88" width="0.1524" layer="91"/>
<pinref part="TB2" gate="G$1" pin="4"/>
<wire x1="27.94" y1="96.52" x2="58.42" y2="96.52" width="0.1524" layer="91"/>
<junction x="58.42" y="96.52"/>
</segment>
</net>
<net name="N$14" class="0">
<segment>
<pinref part="D1" gate="G$1" pin="A"/>
<wire x1="104.14" y1="223.52" x2="104.14" y2="208.28" width="0.1524" layer="91"/>
<pinref part="RL1" gate="G$1" pin="A1"/>
<wire x1="104.14" y1="208.28" x2="91.44" y2="208.28" width="0.1524" layer="91"/>
<wire x1="91.44" y1="208.28" x2="91.44" y2="213.36" width="0.1524" layer="91"/>
<pinref part="REL1" gate="G$1" pin="C"/>
<wire x1="114.3" y1="220.98" x2="114.3" y2="208.28" width="0.1524" layer="91"/>
<wire x1="114.3" y1="208.28" x2="104.14" y2="208.28" width="0.1524" layer="91"/>
<junction x="104.14" y="208.28"/>
<pinref part="TR1" gate="G$1" pin="D"/>
<wire x1="127" y1="208.28" x2="114.3" y2="208.28" width="0.1524" layer="91"/>
<junction x="114.3" y="208.28"/>
</segment>
</net>
<net name="N$16" class="0">
<segment>
<pinref part="D2" gate="G$1" pin="A"/>
<wire x1="104.14" y1="172.72" x2="104.14" y2="157.48" width="0.1524" layer="91"/>
<pinref part="RL2" gate="G$1" pin="A1"/>
<wire x1="104.14" y1="157.48" x2="91.44" y2="157.48" width="0.1524" layer="91"/>
<wire x1="91.44" y1="157.48" x2="91.44" y2="162.56" width="0.1524" layer="91"/>
<pinref part="REL2" gate="G$1" pin="C"/>
<wire x1="114.3" y1="170.18" x2="114.3" y2="157.48" width="0.1524" layer="91"/>
<wire x1="114.3" y1="157.48" x2="104.14" y2="157.48" width="0.1524" layer="91"/>
<junction x="104.14" y="157.48"/>
<pinref part="TR2" gate="G$1" pin="D"/>
<wire x1="132.08" y1="157.48" x2="114.3" y2="157.48" width="0.1524" layer="91"/>
<junction x="114.3" y="157.48"/>
</segment>
</net>
<net name="N$18" class="0">
<segment>
<pinref part="RL3" gate="G$1" pin="A1"/>
<wire x1="91.44" y1="111.76" x2="91.44" y2="106.68" width="0.1524" layer="91"/>
<pinref part="D3" gate="G$1" pin="A"/>
<wire x1="91.44" y1="106.68" x2="104.14" y2="106.68" width="0.1524" layer="91"/>
<wire x1="104.14" y1="106.68" x2="104.14" y2="121.92" width="0.1524" layer="91"/>
<pinref part="REL3" gate="G$1" pin="C"/>
<wire x1="114.3" y1="119.38" x2="114.3" y2="106.68" width="0.1524" layer="91"/>
<wire x1="114.3" y1="106.68" x2="104.14" y2="106.68" width="0.1524" layer="91"/>
<junction x="104.14" y="106.68"/>
<pinref part="TR3" gate="G$1" pin="D"/>
<wire x1="132.08" y1="106.68" x2="114.3" y2="106.68" width="0.1524" layer="91"/>
<junction x="114.3" y="106.68"/>
</segment>
</net>
<net name="N$20" class="0">
<segment>
<pinref part="D4" gate="G$1" pin="A"/>
<wire x1="104.14" y1="71.12" x2="104.14" y2="55.88" width="0.1524" layer="91"/>
<pinref part="RL4" gate="G$1" pin="A1"/>
<wire x1="104.14" y1="55.88" x2="91.44" y2="55.88" width="0.1524" layer="91"/>
<wire x1="91.44" y1="55.88" x2="91.44" y2="63.5" width="0.1524" layer="91"/>
<pinref part="REL4" gate="G$1" pin="C"/>
<wire x1="114.3" y1="68.58" x2="114.3" y2="55.88" width="0.1524" layer="91"/>
<wire x1="114.3" y1="55.88" x2="104.14" y2="55.88" width="0.1524" layer="91"/>
<junction x="104.14" y="55.88"/>
<pinref part="TR4" gate="G$1" pin="D"/>
<wire x1="124.46" y1="55.88" x2="114.3" y2="55.88" width="0.1524" layer="91"/>
<junction x="114.3" y="55.88"/>
</segment>
</net>
<net name="RL1" class="0">
<segment>
<pinref part="TR1" gate="G$1" pin="G"/>
<wire x1="134.62" y1="203.2" x2="134.62" y2="198.12" width="0.1524" layer="91"/>
<wire x1="134.62" y1="198.12" x2="152.4" y2="198.12" width="0.1524" layer="91"/>
<label x="147.32" y="195.58" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="RN1" gate="D" pin="2"/>
<wire x1="215.9" y1="180.34" x2="215.9" y2="182.88" width="0.1524" layer="91"/>
<wire x1="215.9" y1="182.88" x2="220.98" y2="182.88" width="0.1524" layer="91"/>
<wire x1="220.98" y1="182.88" x2="220.98" y2="149.86" width="0.1524" layer="91"/>
<label x="218.44" y="182.88" size="1.778" layer="95"/>
<pinref part="JLOW" gate="A" pin="5"/>
<wire x1="220.98" y1="149.86" x2="243.84" y2="149.86" width="0.1524" layer="91"/>
</segment>
</net>
<net name="RL2" class="0">
<segment>
<pinref part="TR2" gate="G$1" pin="G"/>
<wire x1="139.7" y1="152.4" x2="139.7" y2="142.24" width="0.1524" layer="91"/>
<wire x1="139.7" y1="142.24" x2="154.94" y2="142.24" width="0.1524" layer="91"/>
<label x="149.86" y="142.24" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="RN1" gate="C" pin="2"/>
<wire x1="228.6" y1="187.96" x2="210.82" y2="187.96" width="0.1524" layer="91"/>
<wire x1="210.82" y1="187.96" x2="210.82" y2="180.34" width="0.1524" layer="91"/>
<label x="218.44" y="187.96" size="1.778" layer="95"/>
<pinref part="JLOW" gate="A" pin="8"/>
<wire x1="243.84" y1="157.48" x2="228.6" y2="157.48" width="0.1524" layer="91"/>
<wire x1="228.6" y1="157.48" x2="228.6" y2="187.96" width="0.1524" layer="91"/>
</segment>
</net>
<net name="RL3" class="0">
<segment>
<pinref part="TR3" gate="G$1" pin="G"/>
<wire x1="139.7" y1="101.6" x2="139.7" y2="91.44" width="0.1524" layer="91"/>
<wire x1="139.7" y1="91.44" x2="154.94" y2="91.44" width="0.1524" layer="91"/>
<label x="149.86" y="91.44" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="RN1" gate="B" pin="2"/>
<wire x1="205.74" y1="180.34" x2="205.74" y2="190.5" width="0.1524" layer="91"/>
<wire x1="205.74" y1="190.5" x2="231.14" y2="190.5" width="0.1524" layer="91"/>
<wire x1="231.14" y1="190.5" x2="231.14" y2="182.88" width="0.1524" layer="91"/>
<pinref part="JHIGH" gate="A" pin="1"/>
<wire x1="231.14" y1="182.88" x2="243.84" y2="182.88" width="0.1524" layer="91"/>
<label x="218.44" y="190.5" size="1.778" layer="95"/>
</segment>
</net>
<net name="RL4" class="0">
<segment>
<pinref part="TR4" gate="G$1" pin="G"/>
<wire x1="132.08" y1="50.8" x2="132.08" y2="45.72" width="0.1524" layer="91"/>
<wire x1="132.08" y1="45.72" x2="152.4" y2="45.72" width="0.1524" layer="91"/>
<label x="147.32" y="45.72" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="RN1" gate="A" pin="2"/>
<label x="218.44" y="193.04" size="1.778" layer="95"/>
<pinref part="JHIGH" gate="A" pin="5"/>
<wire x1="200.66" y1="193.04" x2="200.66" y2="180.34" width="0.1524" layer="91"/>
<wire x1="243.84" y1="193.04" x2="200.66" y2="193.04" width="0.1524" layer="91"/>
</segment>
</net>
<net name="REL3_COM" class="3">
<segment>
<pinref part="RL3" gate="G$1" pin="C1"/>
<wire x1="81.28" y1="139.7" x2="81.28" y2="147.32" width="0.1524" layer="91"/>
<wire x1="81.28" y1="147.32" x2="58.42" y2="147.32" width="0.1524" layer="91"/>
<wire x1="58.42" y1="147.32" x2="58.42" y2="111.76" width="0.1524" layer="91"/>
<pinref part="RL3" gate="G$1" pin="C2"/>
<wire x1="58.42" y1="111.76" x2="58.42" y2="104.14" width="0.1524" layer="91"/>
<wire x1="58.42" y1="104.14" x2="81.28" y2="104.14" width="0.1524" layer="91"/>
<wire x1="81.28" y1="104.14" x2="81.28" y2="111.76" width="0.1524" layer="91"/>
<pinref part="TB2" gate="G$1" pin="1"/>
<wire x1="27.94" y1="111.76" x2="58.42" y2="111.76" width="0.1524" layer="91"/>
<junction x="58.42" y="111.76"/>
</segment>
</net>
<net name="REL2_NC" class="3">
<segment>
<pinref part="RL2" gate="G$1" pin="NC2"/>
<wire x1="76.2" y1="162.56" x2="76.2" y2="157.48" width="0.1524" layer="91"/>
<wire x1="76.2" y1="157.48" x2="60.96" y2="157.48" width="0.1524" layer="91"/>
<wire x1="60.96" y1="157.48" x2="60.96" y2="190.5" width="0.1524" layer="91"/>
<pinref part="RL2" gate="G$1" pin="NC1"/>
<wire x1="60.96" y1="190.5" x2="60.96" y2="195.58" width="0.1524" layer="91"/>
<wire x1="60.96" y1="195.58" x2="76.2" y2="195.58" width="0.1524" layer="91"/>
<wire x1="76.2" y1="195.58" x2="76.2" y2="190.5" width="0.1524" layer="91"/>
<pinref part="TB1" gate="G$1" pin="5"/>
<wire x1="27.94" y1="193.04" x2="53.34" y2="193.04" width="0.1524" layer="91"/>
<wire x1="53.34" y1="193.04" x2="53.34" y2="190.5" width="0.1524" layer="91"/>
<wire x1="53.34" y1="190.5" x2="60.96" y2="190.5" width="0.1524" layer="91"/>
<junction x="60.96" y="190.5"/>
</segment>
</net>
<net name="REL2_COM" class="3">
<segment>
<pinref part="RL2" gate="G$1" pin="C1"/>
<wire x1="81.28" y1="190.5" x2="81.28" y2="198.12" width="0.1524" layer="91"/>
<wire x1="81.28" y1="198.12" x2="58.42" y2="198.12" width="0.1524" layer="91"/>
<wire x1="58.42" y1="198.12" x2="58.42" y2="187.96" width="0.1524" layer="91"/>
<wire x1="58.42" y1="187.96" x2="58.42" y2="154.94" width="0.1524" layer="91"/>
<wire x1="58.42" y1="154.94" x2="81.28" y2="154.94" width="0.1524" layer="91"/>
<pinref part="RL2" gate="G$1" pin="C2"/>
<wire x1="81.28" y1="154.94" x2="81.28" y2="162.56" width="0.1524" layer="91"/>
<pinref part="TB1" gate="G$1" pin="6"/>
<wire x1="27.94" y1="187.96" x2="58.42" y2="187.96" width="0.1524" layer="91"/>
<junction x="58.42" y="187.96"/>
</segment>
</net>
<net name="REL2_NO" class="3">
<segment>
<pinref part="RL2" gate="G$1" pin="NO1"/>
<wire x1="71.12" y1="190.5" x2="71.12" y2="193.04" width="0.1524" layer="91"/>
<wire x1="71.12" y1="193.04" x2="63.5" y2="193.04" width="0.1524" layer="91"/>
<pinref part="RL2" gate="G$1" pin="NO2"/>
<wire x1="63.5" y1="193.04" x2="63.5" y2="160.02" width="0.1524" layer="91"/>
<wire x1="63.5" y1="160.02" x2="71.12" y2="160.02" width="0.1524" layer="91"/>
<wire x1="71.12" y1="160.02" x2="71.12" y2="162.56" width="0.1524" layer="91"/>
<pinref part="TB1" gate="G$1" pin="4"/>
<wire x1="27.94" y1="198.12" x2="55.88" y2="198.12" width="0.1524" layer="91"/>
<wire x1="55.88" y1="198.12" x2="55.88" y2="193.04" width="0.1524" layer="91"/>
<wire x1="55.88" y1="193.04" x2="63.5" y2="193.04" width="0.1524" layer="91"/>
<junction x="63.5" y="193.04"/>
</segment>
</net>
<net name="REL1_NC" class="3">
<segment>
<pinref part="RL1" gate="G$1" pin="NC1"/>
<wire x1="76.2" y1="241.3" x2="76.2" y2="248.92" width="0.1524" layer="91"/>
<wire x1="76.2" y1="248.92" x2="60.96" y2="248.92" width="0.1524" layer="91"/>
<wire x1="60.96" y1="248.92" x2="60.96" y2="208.28" width="0.1524" layer="91"/>
<pinref part="RL1" gate="G$1" pin="NC2"/>
<wire x1="60.96" y1="208.28" x2="76.2" y2="208.28" width="0.1524" layer="91"/>
<wire x1="76.2" y1="208.28" x2="76.2" y2="213.36" width="0.1524" layer="91"/>
<pinref part="TB1" gate="G$1" pin="2"/>
<wire x1="27.94" y1="208.28" x2="60.96" y2="208.28" width="0.1524" layer="91"/>
<junction x="60.96" y="208.28"/>
</segment>
</net>
<net name="REL1_COM" class="3">
<segment>
<pinref part="RL1" gate="G$1" pin="C1"/>
<wire x1="81.28" y1="241.3" x2="81.28" y2="251.46" width="0.1524" layer="91"/>
<wire x1="81.28" y1="251.46" x2="58.42" y2="251.46" width="0.1524" layer="91"/>
<wire x1="58.42" y1="251.46" x2="58.42" y2="205.74" width="0.1524" layer="91"/>
<pinref part="RL1" gate="G$1" pin="C2"/>
<wire x1="58.42" y1="205.74" x2="81.28" y2="205.74" width="0.1524" layer="91"/>
<wire x1="81.28" y1="205.74" x2="81.28" y2="213.36" width="0.1524" layer="91"/>
<pinref part="TB1" gate="G$1" pin="3"/>
<wire x1="27.94" y1="203.2" x2="58.42" y2="203.2" width="0.1524" layer="91"/>
<wire x1="58.42" y1="203.2" x2="58.42" y2="205.74" width="0.1524" layer="91"/>
<junction x="58.42" y="205.74"/>
</segment>
</net>
<net name="N$1" class="0">
<segment>
<pinref part="REL1" gate="G$1" pin="A"/>
<pinref part="RN2" gate="A" pin="1"/>
<wire x1="114.3" y1="228.6" x2="114.3" y2="233.68" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$2" class="0">
<segment>
<pinref part="RN2" gate="C" pin="1"/>
<pinref part="REL2" gate="G$1" pin="A"/>
<wire x1="114.3" y1="182.88" x2="114.3" y2="177.8" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$3" class="0">
<segment>
<pinref part="REL3" gate="G$1" pin="A"/>
<pinref part="RN2" gate="B" pin="1"/>
<wire x1="114.3" y1="127" x2="114.3" y2="132.08" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$4" class="0">
<segment>
<pinref part="RN2" gate="D" pin="1"/>
<pinref part="REL4" gate="G$1" pin="A"/>
<wire x1="114.3" y1="81.28" x2="114.3" y2="76.2" width="0.1524" layer="91"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
</schematic>
</drawing>
<compatibility>
<note version="6.3" minversion="6.2.2" severity="warning">
Since Version 6.2.2 text objects can contain more than one line,
which will not be processed correctly with this version.
</note>
<note version="8.2" severity="warning">
Since Version 8.2, EAGLE supports online libraries. The ids
of those online libraries will not be understood (or retained)
with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports URNs for individual library
assets (packages, symbols, and devices). The URNs of those assets
will not be understood (or retained) with this version.
</note>
</compatibility>
</eagle>
