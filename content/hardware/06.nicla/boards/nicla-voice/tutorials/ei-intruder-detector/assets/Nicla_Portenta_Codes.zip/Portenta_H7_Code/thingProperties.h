
const char THING_ID[] = "c173a5b6-7f6a-4cdb-b21b-26878e98df18"; //"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"; // Arduino Cloud Thing ID

const char SSID[]    = "CLARO403"; // = "xxxxxxxx";    // Network SSID (name)
const char PASS[]    = "2336879809"; // = "xxxxxxxx";    // Network password (use for WPA, or use as key for WEP)

String DoorEvent = "System initiated";  
int battery;
bool BLEstatus;
bool alertStatus;

void initProperties(){

  ArduinoCloud.setThingId(THING_ID);
  ArduinoCloud.addProperty(DoorEvent, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(battery, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(BLEstatus, READ, ON_CHANGE, NULL);
  ArduinoCloud.addProperty(alertStatus, READ, ON_CHANGE, NULL);

}

WiFiConnectionHandler ArduinoIoTPreferredConnection(SSID, PASS);