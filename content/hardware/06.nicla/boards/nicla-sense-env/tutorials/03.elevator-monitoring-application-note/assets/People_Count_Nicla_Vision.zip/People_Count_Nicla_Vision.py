# Smart Elevator Monitoring System with Proto Kit
#
# This examples uses the builtin FOMO model to detect faces.

import sys
sys.path.append("lib")
import sensor
import time
from utime import ticks_ms
import ml
from ml.utils import NMS
import math
import image
import pyb
import tf
from pyb import I2C

min_confidence = 0.5
min_distance = 64
transmission_interval = 10 * 1000 # 10 seconds

lastcheck_transmission = None

green_led = pyb.LED(2)
blue_led = pyb.LED(3)

threshold_list = [(math.ceil(min_confidence * 255), 255)]

i2c = I2C(1, I2C.PERIPHERAL, addr=0x35)             # create I2C with address

buf = bytearray(1)  # to store people count data for I2C communication

sensor.reset()  # Reset and initialize the sensor.
sensor.set_pixformat(sensor.RGB565)  # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)  # Set frame size to QVGA (320x240)
sensor.set_windowing((240, 240))  # Set 240x240 window.
sensor.set_contrast(3)
sensor.set_gainceiling(16)
sensor.skip_frames(time=2000)  # Let the camera adjust.

# Load built-in FOMO face detection model
model = ml.Model("fomo_face_detection")
print(model)

colors = [  # Add more colors if you are detecting more than 7 types of classes at once.
    (255, 0, 0),
    (0, 255, 0),
    (255, 255, 0),
    (0, 0, 255),
    (255, 0, 255),
    (0, 255, 255),
    (255, 255, 255),
]


def calculate_distance(rect1, rect2):
    """
    Calculate the Euclidean distance between the centers of two rectangles.
    Each rectangle is defined by a tuple (x, y, w, h) where
    (x, y) is the top-left corner, and w and h are the width and height.
    """
    x1, y1, w1, h1 = rect1
    x2, y2, w2, h2 = rect2

    center1 = (x1 + w1 / 2, y1 + h1 / 2)
    center2 = (x2 + w2 / 2, y2 + h2 / 2)

    distance = math.sqrt((center1[0] - center2[0]) ** 2 + (center1[1] - center2[1]) ** 2)

    return distance

def merge_rectangles(rect1, rect2):
    """
    Merge two rectangles into a single rectangle that covers both.
    Each rectangle is defined by a tuple (x, y, w, h).
    """
    x1, y1, w1, h1 = rect1
    x2, y2, w2, h2 = rect2

    new_x = min(x1, x2)
    new_y = min(y1, y2)
    new_w = max(x1 + w1, x2 + w2) - new_x
    new_h = max(y1 + h1, y2 + h2) - new_y

    return (new_x, new_y, new_w, new_h)

def merge_close_rectangles(rectangles, minimal_distance):
     """
     Merge rectangles that are closer than min_distance.
     Each rectangle is defined by a tuple (x, y, w, h).
     """
     merged = True

     while merged:
         merged = False
         for i in range(len(rectangles)):
             for j in range(i + 1, len(rectangles)):
                 if calculate_distance(rectangles[i], rectangles[j]) < minimal_distance:
                     #print(f"Merging objects with distance: {distance}")
                     new_rectangle = merge_rectangles(rectangles[i], rectangles[j])
                     rectangles[i] = new_rectangle
                     rectangles.pop(j)
                     merged = True
                     break
             if merged:
                 break

     return rectangles

# FOMO outputs an image per class where each pixel in the image is the centroid of the trained
# object. So, we will get those output images and then run find_blobs() on them to extract the
# centroids. We will also run get_stats() on the detected blobs to determine their score.
# The Non-Max-Supression (NMS) object then filters out overlapping detections and maps their
# position in the output image back to the original input image. The function then returns a
# list per class which each contain a list of (rect, score) tuples representing the detected
# objects.
def fomo_post_process(model, inputs, outputs):
    n, oh, ow, oc = model.output_shape[0]
    nms = NMS(ow, oh, inputs[0].roi)
    for i in range(oc):
        img = image.Image(outputs[0][0, :, :, i] * 255)
        blobs = img.find_blobs(
            threshold_list, x_stride=1, area_threshold=1, pixels_threshold=1
        )
        for b in blobs:
            rect = b.rect()
            x, y, w, h = rect
            score = (
                img.get_statistics(thresholds=threshold_list, roi=rect).l_mean() / 255.0
            )
            nms.add_bounding_box(x, y, x + w, y + h, score, i)
    return nms.get_bounding_boxes()


def analyze_image(img):
    global min_distance

    for i, detection_list in enumerate(model.predict([img], callback=fomo_post_process)):
        if i == 0:
            continue  # background class
        if len(detection_list) == 0:
            continue  # no detections for this class?

        print(len(detection_list))

        #print("********** %s **********" % model.labels[i])
        if len(detection_list) == 1:
            detection_list = merge_close_rectangles(detection_list, min_distance)

        for (x, y, w, h), score in detection_list:
            center_x = math.floor(x + (w / 2))
            center_y = math.floor(y + (h / 2))
            print(f"x {center_x}\ty {center_y}\tscore {score}")
            img.draw_circle((center_x, center_y, 12), color=colors[i], thickness=2)

        return len(detection_list)
    return 0


if __name__ == "__main__":

    clock = time.clock()
    while True:
        clock.tick()

        img = sensor.snapshot()
        faces = analyze_image(img)

        green_led.on() if faces > 0 else green_led.off() # Turn on green LED when face is detected

        if(faces > 0):
            i2c.init(I2C.PERIPHERAL, addr=0x35)
            print("Faces detected:", faces)
            buf[0] = faces
            i2c.send(buf)
        else:
            i2c.deinit()

        now = ticks_ms()

