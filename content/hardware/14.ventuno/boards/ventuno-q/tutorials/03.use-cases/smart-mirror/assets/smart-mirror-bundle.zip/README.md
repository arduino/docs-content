# Smart Mirror — Reproducibility Bundle

Everything you need to replicate the Smart Mirror application note on the
Arduino VENTUNO Q.

## Contents

```
smart-mirror-bundle/
├── smart-mirror-app.zip            # App Lab-ready application archive
├── setup-kiosk.sh                  # Install the boot-to-kiosk configuration
├── remove-kiosk.sh                 # Restore the pre-kiosk system state
├── launch-mirror-kiosk.sh          # Standalone Chromium launcher (port 7000)
├── firmware/
│   └── scan-button/
│       └── scan-button.ino         # Arduino HID firmware for the Nano ESP32
└── holder/
    └── ventuno-q-holder.stl        # 3D-printable holder for the VENTUNO Q
```

## Quick start

1. Flash `firmware/scan-button/scan-button.ino` to a Nano ESP32 with the
   Arduino IDE.
2. In Arduino App Lab, open **My Apps**, select **Create new app + > Import
   App**, and import `smart-mirror-app.zip`.
3. Open the VLM and TTS Bricks in App Lab. From each Brick's **AI models** tab,
   download and select the model declared in `app.yaml`.
4. Run `sudo bash setup-kiosk.sh`, then reboot. The script discovers the
   imported app identifier and installs the model-aware boot unit and Chromium
   kiosk launcher.
5. To undo the kiosk configuration, run `sudo bash remove-kiosk.sh` and reboot.
6. Print `holder/ventuno-q-holder.stl` for the lower shelf.

For a command-line install instead of App Lab, extract `smart-mirror-app.zip`
under `~/ArduinoApps`, then start it with:

```bash
arduino-app-cli app start user:smart-mirror
```

Do not configure the daemon-level default app separately. `setup-kiosk.sh`
installs the boot unit and waits for the selected VLM to finish downloading
before it starts the application.

See the full application note for the theory and assembly details:
https://docs.arduino.cc/tutorials/ventuno-q/smart-mirror-application-note/
