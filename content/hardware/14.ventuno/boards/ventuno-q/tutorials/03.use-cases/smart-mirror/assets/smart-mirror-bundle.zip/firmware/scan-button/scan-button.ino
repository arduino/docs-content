#include "USB.h"
#include "USBHIDKeyboard.h"

USBHIDKeyboard Keyboard;

const int buttonPin = D2;
const unsigned long debounceDelay = 50;

bool lastReading = HIGH;
bool stableState = HIGH;
unsigned long lastDebounceTime = 0;

void setup() {
  // Button wired to GND, using internal pull-up
  pinMode(buttonPin, INPUT_PULLUP);

  // Start USB device stack and HID keyboard
  USB.begin();
  Keyboard.begin();
}

void loop() {
  int reading = digitalRead(buttonPin);

  // Debounce: reset timer on any change
  if (reading != lastReading) {
    lastDebounceTime = millis();
  }

  // If the state is stable long enough, accept it
  if (millis() - lastDebounceTime > debounceDelay) {
    if (reading != stableState) {
      stableState = reading;

      // LOW means pressed (because of INPUT_PULLUP)
      if (stableState == LOW) {
        Keyboard.press(KEY_RETURN);
        delay(10);
        Keyboard.release(KEY_RETURN);
      }
    }
  }

  lastReading = reading;
}
